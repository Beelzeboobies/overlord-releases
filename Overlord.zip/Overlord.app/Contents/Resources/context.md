# About Me

**Name:** Yevhen (Eugene) Ostapenko  
**Role:** COO, Freecords  
**Email:** eugeneo@freecords.com / distroadmin@freecords.com

## What I Do

I wear many hats at Freecords. My responsibilities include:

- **Copyright & infringement issues** — handling DMCA notices, takedown requests, licensing disputes, and correspondence with rights holders
- **Escalated support** — taking over the hardest support tickets that front-line staff can't resolve
- **Hiring** — conducting interviews with new hires, writing offer letters, coordinating onboarding
- **Sponsor relations** — reaching out to potential sponsors, nurturing existing sponsor relationships, negotiating deals
- **General executive correspondence** — anything that needs a senior voice or careful handling

## About Freecords

Freecords is a music distribution and services company. We help artists and labels get their music onto streaming platforms, manage rights, and grow their audience.

## Communication Style

- Direct and professional, but not stiff
- Gets to the point quickly
- Warm when the relationship calls for it
- Firm but fair in disputes and difficult situations
- Signs off as "Eugene" in most correspondence

## Notes for Claude

When helping me draft replies, consider:
- Who I'm writing to (their role, our history)
- The tone that fits the situation (formal dispute vs. casual sponsor chat)
- Keep replies concise — I don't write long emails unless the situation demands it
- If this is an infringement or legal matter, be measured and factual, avoid admissions
