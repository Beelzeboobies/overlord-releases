import json
import shutil
import sqlite3
import sys
import time
from pathlib import Path
from config import APP_SUPPORT, FRONTEND_DIST

DB_PATH = APP_SUPPORT / 'mail.db'


def _log_db_event(msg):
    try:
        with open(APP_SUPPORT / 'logs' / 'backend.log', 'a') as f:
            f.write(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] {msg}\n")
    except Exception:
        pass


def ensure_db_healthy():
    """
    Run before init_db() ever touches DB_PATH — catches corruption at the
    moment the app starts, in seconds, instead of waiting for
    backup.py's backup_loop() (up to 6 hours between cycles) to notice, or
    not noticing at all if the app never survives that loop's 60-second
    startup delay.

    Built after a real incident: this session repeatedly force-killed
    Overlord.exe/its dev backend during testing, which corrupted mail.db
    (`malformed database schema`) — and the existing safety net
    (backup.py's check_integrity/backup_loop) never caught it: the same
    rapid kill-and-restart pattern that caused the corruption also kept
    interrupting backup_loop's own 60-second warm-up before it could ever
    run once, and even the 6-hour scheduled cycle hadn't come due yet by
    the time this was found by hand, hours later, via a crashed launch
    with no log entry at all. **User, directly**: "we created safety nets
    several times... AND before today" — this was a real, repeated gap in
    those nets, not a one-off oversight, and just logging louder isn't
    enough if the check never runs in the first place.

    If DB_PATH fails even a quick integrity check, automatically restore
    the most recent backup that itself passes integrity_check — verified,
    not assumed, since a bad backup silently swapped in would just be a
    slower version of the same problem. The corrupted file is preserved
    alongside (renamed, not deleted) in case forensics are ever wanted.
    Logs loudly either way — success or "nothing to restore from" — using
    the same unmissable prefix as check_integrity()'s data-loss alert,
    since a fully unreadable database is strictly worse than the "a field
    went empty" case that alert was originally built for.
    """
    if not DB_PATH.exists():
        return  # first launch ever — nothing to check yet
    try:
        conn = sqlite3.connect(f'file:{DB_PATH}?mode=ro', uri=True)
        result = conn.execute('PRAGMA quick_check(1)').fetchone()
        conn.close()
        if result and result[0] == 'ok':
            return  # healthy, nothing to do
        reason = f'quick_check reported: {result}'
    except Exception as e:
        reason = str(e)

    _log_db_event(f'[DATA LOSS DETECTED] mail.db failed an integrity check on startup: {reason}')

    backup_dir = APP_SUPPORT / 'backups'
    candidates = sorted(backup_dir.glob('mail-*.db'), reverse=True) if backup_dir.is_dir() else []
    for candidate in candidates:
        try:
            bconn = sqlite3.connect(f'file:{candidate}?mode=ro', uri=True)
            bresult = bconn.execute('PRAGMA quick_check(1)').fetchone()
            bconn.close()
        except Exception:
            continue
        if not (bresult and bresult[0] == 'ok'):
            continue
        stamp = time.strftime('%Y%m%d-%H%M%S')
        corrupted_aside = DB_PATH.parent / f'mail.db.corrupted-{stamp}'
        try:
            shutil.copy2(DB_PATH, corrupted_aside)
            shutil.copy2(candidate, DB_PATH)
            # The corrupted instance may have left WAL sidecar files behind
            # (mail.db-wal/-shm) — orphaned now that DB_PATH itself has been
            # replaced with a plain (non-WAL) backup snapshot. They won't
            # cause further corruption (SQLite decides WAL-vs-rollback from
            # the restored file's own header, not from a stray sidecar's
            # presence), but leaving them isn't clean, so remove them.
            for ext in ('-wal', '-shm'):
                stale = DB_PATH.parent / (DB_PATH.name + ext)
                stale.unlink(missing_ok=True)
        except Exception as e:
            _log_db_event(f'[DATA LOSS DETECTED] found a good backup ({candidate.name}) but restore failed: {e}')
            return
        _log_db_event(
            f'[DATA LOSS DETECTED] mail.db was corrupted — automatically restored from '
            f'{candidate.name}. The corrupted original is preserved at {corrupted_aside.name} '
            f'for forensics. Anything written between that backup and the corruption is lost.'
        )
        return

    _log_db_event(
        '[DATA LOSS DETECTED] mail.db is corrupted and no usable backup was found in '
        f'{backup_dir} — manual recovery needed.'
    )


# ── DB ────────────────────────────────────────────────────────────────────────

def get_db():
    # No busy_timeout meant any concurrent writer (this app has several
    # background loops plus request-handler threads all writing to the same
    # file) hit "database is locked" immediately rather than waiting a
    # moment for the other writer to finish — confirmed as the actual root
    # cause of a real incident (2026-09-04): a background loop's commit
    # failed silently under exactly this contention, its cursor never
    # advanced, and it recreated the same ticket every 60s for 71 minutes
    # (111 duplicates) before caught. That specific call site got a local
    # retry-with-backoff wrapper as an immediate fix, but this file already
    # had at least two *other* copies of that same local-retry pattern
    # scattered across different background loops (each with a comment
    # explicitly noting the lack of busy_timeout here as the reason) — a
    # sign the real fix belongs at the connection level, not patched call
    # site by call site. 5s: long enough to ride out a normal commit from
    # another thread, short enough that a genuinely stuck lock still surfaces
    # promptly instead of hanging a request.
    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.execute('PRAGMA busy_timeout = 5000')
    # WAL instead of the default rollback-journal mode: confirmed real cause
    # of repeated mail.db corruption this session (see ensure_db_healthy's
    # docstring) is a force-killed Overlord.exe/dev backend during testing.
    # Rollback-journal mode is fragile against exactly that — WAL is
    # specifically designed to survive a killed writer without corrupting
    # the main file (uncommitted WAL frames are just discarded on next
    # open). A no-op after the first call ever makes it (the mode is
    # stored in the file header), safe to set on every connection.
    conn.execute('PRAGMA journal_mode=WAL')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    ensure_db_healthy()
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS email_meta (
            uid           TEXT PRIMARY KEY,
            folder        TEXT NOT NULL DEFAULT 'INBOX',
            flagged       INTEGER DEFAULT 0,
            completed     INTEGER DEFAULT 0,
            custom_status TEXT,
            reminder_at   TEXT
        );
        CREATE TABLE IF NOT EXISTS custom_statuses (
            id    INTEGER PRIMARY KEY AUTOINCREMENT,
            name  TEXT UNIQUE NOT NULL,
            color TEXT DEFAULT '#e8a020'
        );
        CREATE TABLE IF NOT EXISTS custom_folders (
            id   INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS contacts (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            name      TEXT NOT NULL,
            email     TEXT UNIQUE NOT NULL,
            city      TEXT,
            timezone  TEXT,
            notes     TEXT,
            dob       TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS message_cache (
            account      TEXT NOT NULL DEFAULT '',
            folder       TEXT NOT NULL DEFAULT 'INBOX',
            uid          TEXT NOT NULL,
            from_name    TEXT,
            from_addr    TEXT,
            subject      TEXT,
            date         TEXT,
            read         INTEGER DEFAULT 0,
            flagged_imap INTEGER DEFAULT 0,
            has_attachment INTEGER DEFAULT 0,
            attachment_names TEXT DEFAULT '',
            cached_at    REAL,
            PRIMARY KEY (account, folder, uid)
        );
        CREATE TABLE IF NOT EXISTS account_configs (
            email       TEXT PRIMARY KEY,
            imap_host   TEXT NOT NULL,
            imap_port   INTEGER NOT NULL DEFAULT 993,
            smtp_host   TEXT NOT NULL,
            smtp_port   INTEGER NOT NULL DEFAULT 465
        );
        CREATE TABLE IF NOT EXISTS scheduled_sends (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            account     TEXT NOT NULL,
            send_at_utc TEXT NOT NULL,
            payload     TEXT NOT NULL,
            status      TEXT DEFAULT 'pending',
            created_at  TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS rules (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            name            TEXT NOT NULL DEFAULT '',
            condition_field TEXT NOT NULL DEFAULT 'subject',
            condition_op    TEXT NOT NULL DEFAULT 'contains',
            condition_value TEXT NOT NULL DEFAULT '',
            action          TEXT NOT NULL DEFAULT 'move',
            action_value    TEXT DEFAULT '',
            active          INTEGER DEFAULT 1,
            created_at      TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS ticket_rules (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            name            TEXT NOT NULL DEFAULT '',
            condition_field TEXT NOT NULL DEFAULT 'subject',
            condition_op    TEXT NOT NULL DEFAULT 'contains',
            condition_value TEXT NOT NULL DEFAULT '',
            action          TEXT NOT NULL DEFAULT 'add_tag',
            action_value    TEXT DEFAULT '',
            active          INTEGER DEFAULT 1,
            created_at      TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS labels (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL UNIQUE,
            color       TEXT NOT NULL DEFAULT '#e8a020',
            created_at  TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS email_labels (
            account     TEXT NOT NULL,
            uid         TEXT NOT NULL,
            label_id    INTEGER NOT NULL REFERENCES labels(id) ON DELETE CASCADE,
            PRIMARY KEY (account, uid, label_id)
        );
        CREATE TABLE IF NOT EXISTS events (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            title           TEXT NOT NULL DEFAULT '',
            start_dt        TEXT NOT NULL,
            end_dt          TEXT NOT NULL,
            all_day         INTEGER DEFAULT 0,
            location        TEXT DEFAULT '',
            description     TEXT DEFAULT '',
            meet_url        TEXT DEFAULT '',
            color           TEXT DEFAULT '#e8a020',
            reminder_minutes INTEGER DEFAULT 10,
            notified        INTEGER DEFAULT 0,
            ical_uid        TEXT DEFAULT '',
            recurrence      TEXT DEFAULT '',
            created_at      TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS contact_notes (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            email       TEXT NOT NULL,
            author      TEXT NOT NULL DEFAULT '',
            note        TEXT NOT NULL,
            created_at  TEXT DEFAULT (datetime('now'))
        );
    """)
    conn.commit()
    conn.close()


# ── Schema migrations ─────────────────────────────────────────────────────────
def _migrate_schema():
    conn = get_db()
    cols = [r[1] for r in conn.execute("PRAGMA table_info(message_cache)").fetchall()]
    if 'attachment_names' not in cols:
        conn.execute("ALTER TABLE message_cache ADD COLUMN attachment_names TEXT DEFAULT ''")
        conn.commit()
    if 'cc' not in cols:
        conn.execute("ALTER TABLE message_cache ADD COLUMN cc TEXT DEFAULT ''")
        conn.commit()
    if 'to_addrs' not in cols:
        conn.execute("ALTER TABLE message_cache ADD COLUMN to_addrs TEXT DEFAULT ''")
        conn.commit()
    if 'snippet' not in cols:
        conn.execute("ALTER TABLE message_cache ADD COLUMN snippet TEXT DEFAULT ''")
        conn.commit()
    if 'reply_to' not in cols:
        conn.execute("ALTER TABLE message_cache ADD COLUMN reply_to TEXT DEFAULT ''")
        conn.commit()
    contact_cols = [r[1] for r in conn.execute("PRAGMA table_info(contacts)").fetchall()]
    if 'dob' not in contact_cols:
        conn.execute("ALTER TABLE contacts ADD COLUMN dob TEXT")
        conn.commit()
    if 'tags' not in contact_cols:
        conn.execute("ALTER TABLE contacts ADD COLUMN tags TEXT DEFAULT '[]'")
        conn.commit()
    ev_cols = [r[1] for r in conn.execute("PRAGMA table_info(events)").fetchall()]
    if 'sessions' not in ev_cols:
        conn.execute("ALTER TABLE events ADD COLUMN sessions TEXT DEFAULT '[]'")
        conn.commit()
    if 'deadline_dt' not in ev_cols:
        conn.execute("ALTER TABLE events ADD COLUMN deadline_dt TEXT DEFAULT ''")
        conn.commit()
    # contact_notes table — created by init_db on fresh installs; add on existing ones
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
    if 'contact_notes' not in tables:
        conn.execute("""
            CREATE TABLE contact_notes (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                email       TEXT NOT NULL,
                author      TEXT NOT NULL DEFAULT '',
                note        TEXT NOT NULL,
                created_at  TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()
    # Per-account signatures: seed from legacy global signature_html / signature_image
    # if account_signatures key does not yet exist.
    existing_sig_row = conn.execute(
        "SELECT value FROM settings WHERE key='account_signatures'"
    ).fetchone()
    if existing_sig_row is None:
        import json as _json
        old_html  = (conn.execute("SELECT value FROM settings WHERE key='signature_html'").fetchone()  or ('',))[0] or ''
        old_image = (conn.execute("SELECT value FROM settings WHERE key='signature_image'").fetchone() or ('',))[0] or ''
        # Read account list from account_configs so we can seed the first account
        first_acct_row = conn.execute("SELECT email FROM account_configs LIMIT 1").fetchone()
        initial = {}
        if first_acct_row and (old_html or old_image):
            initial[first_acct_row[0]] = {'html': old_html, 'image': old_image}
        conn.execute(
            "INSERT INTO settings (key, value) VALUES ('account_signatures', ?)",
            (_json.dumps(initial),)
        )
        conn.commit()
    # Per-scope Context Files: seed both 'email' and 'support' scopes from
    # the old shared keys, once, if the scoped keys don't exist yet. Real,
    # user-reported gap: Context Files was a single global config that only
    # Email's own Claude drafts ever actually read — Support/Tickets'
    # (SupportCompose.jsx) never fetched it at all, so a user's configured
    # company docs/policies never reached a single ticket reply. Splitting
    # into independent per-scope settings (see claude.py's
    # _build_context_text and settings.py's save_settings whitelist) means
    # editing one tab's Context Files no longer silently affects the other.
    # Both scopes seed from the SAME old value on this one-time migration —
    # "same default on first install", per spec — then diverge freely.
    # Default Claude Context links — genuinely never seeded on a fresh
    # install before this. The loop below only ever migrates an OLD shared
    # value forward; a brand-new install has no old value to migrate, so
    # it fell through to '[]' every time regardless of what was actually
    # agreed on. **User, directly**: "We specifically discussed and
    # arranged this would not happen before sharing the app for the first
    # time, yet this is still broken" — confirmed live against a fresh
    # install's own context_urls_email/context_urls_support: genuinely
    # empty, not corrupted (context_urls has its own dedicated save
    # endpoints, not the general autosave, so it isn't exposed to that
    # class of bug either — this was simply never implemented). The Apple
    # Music Style Guide's real fetch already happens unconditionally
    # elsewhere (see claude.py's _build_context_text, which also had its
    # own real bug fixed the same day — a malformed nav URL made it
    # silently return '' every time); it's included here as a visible
    # entry so it actually shows up in Settings rather than being an
    # invisible hardcoded inclusion nobody can see is active.
    _DEFAULT_CONTEXT_URLS = [
        'https://www.freecords.com/terms-of-use',
        'https://www.freecords.com/privacy-policy',
        'https://www.freecords.com/terms-of-use-distribution',
        'https://www.freecords.com/artist-privacy-policy',
        'https://www.freecords.com/anti-fraud-policy',
        'https://www.freecords.com/faqs',
        'https://www.freecords.com/distribution-faqs',
        'https://help.apple.com/itc/musicstyleguide/en.lproj/',
    ]
    for _base_key in ('context_folders', 'context_files_extra', 'context_urls', 'context_excludes'):
        for _scope in ('email', 'support'):
            _scoped_key = f'{_base_key}_{_scope}'
            _existing = conn.execute(
                "SELECT 1 FROM settings WHERE key=?", (_scoped_key,)
            ).fetchone()
            if _existing is None:
                _old_row = conn.execute(
                    "SELECT value FROM settings WHERE key=?", (_base_key,)
                ).fetchone()
                if _old_row and _old_row[0]:
                    _default_value = _old_row[0]
                elif _base_key == 'context_urls':
                    _default_value = json.dumps(_DEFAULT_CONTEXT_URLS)
                else:
                    _default_value = '[]'
                conn.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    (_scoped_key, _default_value)
                )
    conn.commit()

    # Default sound selections — sound_inbox/sound_send were only ever
    # writable via upload/drag-in, no default was ever actually seeded
    # despite being designed and discussed. Real, live data got wiped in
    # this session's original data-loss incident (same one that took
    # canned responses/contacts/five other settings — the restore script
    # built at the time never checked these two keys). One-time, only if
    # the key doesn't exist yet (same "seed once, then user's choice
    # sticks" shape as the context_folders migration above) — seeds
    # EVERY bundled preset in each category, not just one (**user,
    # after the first version of this only added one file each**: "you
    # added ONE sound for each instead of all sounds?"), discovered by
    # globbing FRONTEND_DIST/sounds rather than hardcoding a range,
    # since the real bundled set has non-contiguous indices (sound_send
    # skips 19/20) and mixed extensions (mostly .mp3, some .wav). Gain 1
    # for all of them (matches the gain a fresh upload gets before real
    # peak-normalization runs; sounds.js computes and caches the real
    # value on first play).
    for _event in ('inbox', 'send'):
        _key = f'sound_{_event}'
        _existing = conn.execute("SELECT 1 FROM settings WHERE key=?", (_key,)).fetchone()
        if _existing is None:
            _sounds_dir = FRONTEND_DIST / 'sounds'
            _files = sorted(_sounds_dir.glob(f'sound_{_event}_*.*')) if _sounds_dir.is_dir() else []
            _default = json.dumps([
                {'url': f'/sounds/{_f.name}', 'name': _f.name, 'gain': 1} for _f in _files
            ])
            conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (_key, _default))
    conn.commit()

    # user_ai_notes table — per-user persistent AI context notes
    if 'user_ai_notes' not in tables:
        conn.execute("""
            CREATE TABLE user_ai_notes (
                user_id    TEXT PRIMARY KEY,
                notes      TEXT NOT NULL DEFAULT '',
                updated_at TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()
    # freshdesk_sync_map — tracks which Freshdesk tickets have already been
    # mirrored into the native support.tickets system, so the sync loop knows
    # create vs. update and never double-creates on re-poll.
    if 'freshdesk_sync_map' not in tables:
        conn.execute("""
            CREATE TABLE freshdesk_sync_map (
                freshdesk_id        INTEGER PRIMARY KEY,
                native_ticket_id    TEXT NOT NULL,
                native_ticket_number INTEGER,
                last_status         TEXT,
                synced_at           TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()
    sync_map_cols = [r[1] for r in conn.execute("PRAGMA table_info(freshdesk_sync_map)").fetchall()]
    if 'last_message_count' not in sync_map_cols:
        conn.execute("ALTER TABLE freshdesk_sync_map ADD COLUMN last_message_count INTEGER DEFAULT 0")
        conn.commit()

    # Neither Freecords' native ticket list nor Freshdesk's own list endpoint
    # carries attachment presence — only the per-ticket detail call does.
    # Cache it locally, filled in opportunistically whenever a ticket is
    # opened (Support or Tickets), so the Tickets list can show a paperclip
    # icon without an expensive per-row Freshdesk call.
    if 'ticket_attachment_cache' not in tables:
        conn.execute("""
            CREATE TABLE ticket_attachment_cache (
                ticket_number    INTEGER PRIMARY KEY,
                has_attachments  INTEGER NOT NULL,
                checked_at       TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Native tickets have no read/unread concept at all (server or sync) —
    # tracked locally, per this Overlord install, same pattern as the
    # attachment cache above. Keyed by native ticket id (UUID), not
    # ticket_number, since that's what the detail route actually receives.
    if 'ticket_read_state' not in tables:
        conn.execute("""
            CREATE TABLE ticket_read_state (
                ticket_id  TEXT PRIMARY KEY,
                read_at    TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Same idea as ticket_read_state above, but for Freshdesk tickets —
    # Freshdesk's own API has no per-agent read/unread field either, so
    # Support tracks it locally too. Separate table (not a shared one keyed
    # by some combined id) since fadmin's ticket_id is a UUID string and
    # Freshdesk's is a plain integer — no natural overlap to worry about,
    # but keeping them apart avoids ever confusing one namespace for the other.
    if 'freshdesk_ticket_read_state' not in tables:
        conn.execute("""
            CREATE TABLE freshdesk_ticket_read_state (
                ticket_id  INTEGER PRIMARY KEY,
                read_at    TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # ticket_number -> native id for every ticket in Freecords' native CRM,
    # built by scanning our OWN admin API (no Freshdesk calls at all) — lets
    # the Freshdesk sync loop tell "already imported, just needs a status
    # patch" from "genuinely new, needs a full import" without doing an
    # expensive Freshdesk conversations/description fetch just to find out.
    if 'native_ticket_index' not in tables:
        conn.execute("""
            CREATE TABLE native_ticket_index (
                ticket_number  INTEGER PRIMARY KEY,
                native_id      TEXT NOT NULL,
                requester_email TEXT,
                subject         TEXT,
                created_at      TEXT,
                status          TEXT,
                thread_ref      TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_native_ticket_index_email ON native_ticket_index(requester_email)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_native_ticket_index_thread_ref ON native_ticket_index(thread_ref)")
        conn.commit()
    else:
        # Added later — existing installs' table predates these columns.
        # thread_ref specifically: tickets created directly (not imported
        # from Freshdesk) always get one at creation, and imported historical
        # tickets deliberately never do (see the import endpoint's own spec —
        # "no thread_ref needed, these are closed historical threads") — the
        # one reliable, already-available signal for "this ticket was never
        # on Freshdesk at all" (see ticket_attachments_local's use of it).
        existing_cols = {r['name'] for r in conn.execute("PRAGMA table_info(native_ticket_index)").fetchall()}
        for col in ('requester_email', 'subject', 'created_at', 'status', 'thread_ref'):
            if col not in existing_cols:
                conn.execute(f"ALTER TABLE native_ticket_index ADD COLUMN {col} TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_native_ticket_index_email ON native_ticket_index(requester_email)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_native_ticket_index_thread_ref ON native_ticket_index(thread_ref)")
        conn.commit()
    # Lookups by requester ignore letter case and stray spaces (see freecords_admin._email_key).
    conn.execute("CREATE INDEX IF NOT EXISTS idx_native_ticket_index_email_ci ON native_ticket_index(LOWER(TRIM(requester_email)))")
    conn.commit()

    # Real local storage for CRM ticket attachment files — not just presence
    # (ticket_attachment_cache above), the actual bytes. Freshdesk's own
    # attachment URLs are short-lived signed S3 links and the remote
    # Freecords ticket-import schema drops attachment data entirely on
    # import, so until this table existed there was no copy of any ticket
    # attachment anywhere Overlord controls — if Freshdesk were ever
    # decommissioned, every ticket attachment would simply become
    # unreachable. file_path is relative to APP_SUPPORT / 'ticket_attachments'.
    if 'ticket_attachment_files' not in tables:
        conn.execute("""
            CREATE TABLE ticket_attachment_files (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_number    INTEGER NOT NULL,
                filename         TEXT NOT NULL,
                content_type     TEXT,
                size             INTEGER,
                file_path        TEXT NOT NULL,
                downloaded_at    TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticket_attachment_files_ticket ON ticket_attachment_files(ticket_number)")
        conn.commit()

    # Tracks which tickets have already had their attachments backfilled
    # into ticket_attachment_files, so a restart of the backfill loop
    # doesn't redo work across potentially thousands of tickets.
    if 'ticket_attachment_backfill_done' not in tables:
        conn.execute("""
            CREATE TABLE ticket_attachment_backfill_done (
                ticket_number  INTEGER PRIMARY KEY,
                done_at        TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Real, confirmed incident (2026-09-18): ticket_creation_from_mail_enabled
    # was found back on with nobody able to account for having touched it —
    # the *second* time this exact setting has changed value unexplained
    # (first was 2026-09-07, the opposite direction, see Settings.jsx's own
    # comment on ticketMailEnabled). Both times, there was zero way to
    # answer "who/what changed this and when" because the settings table
    # only ever stores the current value. **User, directly**: "how about
    # that audit log?" — every settings write now leaves a permanent,
    # queryable record of exactly what changed and when, so this question
    # has a real answer next time instead of nothing to check against.
    if 'settings_change_log' not in tables:
        conn.execute("""
            CREATE TABLE settings_change_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                key         TEXT NOT NULL,
                old_value   TEXT,
                new_value   TEXT,
                changed_at  TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.execute("CREATE INDEX idx_settings_change_log_key ON settings_change_log(key, changed_at)")
        conn.commit()

    # Separate from ticket_attachment_backfill_done on purpose — real,
    # confirmed live (2026-09-15, ticket #67206): a customer's screenshot
    # was embedded inline in the message body (Freshdesk's own
    # eucattachment.freshdesk.com/inline/attachment mechanism) with the
    # ticket's `attachments` array empty. The original backfill only ever
    # read that array, so a ticket already marked done there can still be
    # missing real inline content — it needs its own completion marker so
    # the inline pass runs once per ticket independently, not gated behind
    # (or skipped by) the unrelated real-attachments pass.
    if 'ticket_inline_attachment_backfill_done' not in tables:
        conn.execute("""
            CREATE TABLE ticket_inline_attachment_backfill_done (
                ticket_number  INTEGER PRIMARY KEY,
                done_at        TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Tracks which native tickets are currently "awaiting our reply" — the
    # single blue-dot signal Support/FreshdeskView.jsx already had
    # (ATTENTION_BLUE/customerResponded there), reimplemented for Tickets.
    # Freshdesk exposed this via stats (agent_responded_at/
    # requester_responded_at/reopened_at) fetched live per ticket — no
    # equivalent field exists on the native ticket LIST endpoint at all
    # (confirmed live), and fetching each ticket's full thread just to
    # render a list dot isn't viable at hundreds of rows. Tracked locally
    # instead: a row here means "the last thing that happened on this
    # ticket was the customer, not us" — set the moment main.py's direct
    # IMAP path logs an inbound message (new ticket or reply to an
    # existing one) or a customer reopens one, cleared the moment Overlord
    # sends an outbound reply (fadmin_ticket_reply). Reliable specifically
    # because Freshdesk is retired — every message on every ticket now
    # flows through one of those two Overlord-owned paths, no third party
    # can update this out from under us anymore.
    if 'ticket_awaiting_reply' not in tables:
        conn.execute("""
            CREATE TABLE ticket_awaiting_reply (
                ticket_number  INTEGER PRIMARY KEY,
                marked_at      TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Tickets' equivalent of Support's "Sent" view (added there in 3.10) —
    # tickets created via Overlord's own New Ticket compose, not a customer
    # writing in. Support's version used a Freshdesk-only signal (an
    # unset-source API-created ticket defaults to Freshdesk's own source=2
    # "Portal") that has no native equivalent at all. Tracked locally
    # instead: fadmin_tickets_create() is the ONE code path a manually
    # composed ticket ever goes through — the direct-IMAP inbound path
    # (main.py) calls freecords_admin._api() directly and never touches
    # this Flask route at all, so there's no ambiguity to resolve, unlike
    # ticket_awaiting_reply which has to reason about ordering/timing.
    if 'ticket_manually_created' not in tables:
        conn.execute("""
            CREATE TABLE ticket_manually_created (
                ticket_number  INTEGER PRIMARY KEY,
                created_at     TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Real, user-reported bug (2026-09-08): the Closed view's date filter
    # ("closed in the past 24 hours") had no way to be answered correctly
    # server-side — Freecords' admin API only filters date_from/date_to
    # against created_at, never a close/update time, so there's no
    # "ask Nick's API" fix available (**user, directly**: "why the fuck
    # would we need any of the things you said [...] we are building a CRM
    # ourselves on top of a mail inbox" — right, same philosophy as
    # fadmin_tickets_list's own docstring). Every close action already goes
    # through this app's own single PATCH proxy (fadmin_ticket_patch) no
    # matter which UI button triggered it, so record the real close moment
    # locally there instead of ever guessing from a remote timestamp — an
    # instant, exact local lookup, no scanning, no dependency on Freecords
    # adding anything.
    if 'ticket_closed_at' not in tables:
        conn.execute("""
            CREATE TABLE ticket_closed_at (
                ticket_number  INTEGER PRIMARY KEY,
                closed_at      TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Tickets' "History" view (2026-09-08): every ticket any agent has
    # replied to or changed the status of, most-recent-activity first, with
    # who did it — deliberately NOT the same as Closed (an Open/Pending
    # ticket someone already replied to belongs here too). One row per
    # event rather than per-ticket so the same ticket can show up again
    # after a later reply moves it back to the top; the history route
    # reads only the newest row per ticket_number. Starts empty like
    # ticket_closed_at — no retroactive history for activity before this
    # table existed.
    if 'ticket_activity' not in tables:
        conn.execute("""
            CREATE TABLE ticket_activity (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_number  INTEGER NOT NULL,
                action         TEXT NOT NULL,
                agent_name     TEXT,
                at             TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticket_activity_ticket ON ticket_activity(ticket_number)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticket_activity_at ON ticket_activity(at)")
        conn.commit()

    # ticket_message_backfill (2026-09-09): local, durable copy of a
    # ticket's original message when Freecords' own POST .../message
    # endpoint refuses to log it — confirmed live that endpoint rejects
    # ANY message on a ticket that currently has zero messages ("Failed
    # to log inbound message"), succeeding only for tickets that already
    # have at least one. That's a real, reproducible limitation on
    # Freecords' side, not something Overlord's request shape can work
    # around — same situation as ticket_closed_at/ticket_attachment_files
    # (**user, directly**: "There is no 'Freecords-side' limitation. WE
    # are building the CRM in any way we want" — right, don't depend on a
    # remote endpoint that can't do the one thing needed; own the data
    # locally instead). fadmin_ticket_get serves a row here as a
    # synthetic first message whenever Freecords' own thread comes back
    # empty, so the fix lives entirely server-side — the frontend needs
    # no changes at all, it already just renders whatever `messages`
    # this endpoint returns.
    if 'ticket_message_backfill' not in tables:
        conn.execute("""
            CREATE TABLE ticket_message_backfill (
                ticket_number  INTEGER PRIMARY KEY,
                body           TEXT NOT NULL,
                from_email     TEXT,
                message_id     TEXT,
                message_date   TEXT,
                backfilled_at  TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # Seed data for 265 real tickets confirmed blank + recovered live
    # (2026-09-22/23) — this table is local-only per install (see the
    # comment above), so the recovery done on one machine never reached
    # any other install, including the one the user actually checks
    # tickets on. **User, directly**, re-checking on a different
    # instance: "missing content in that ticket" (#11267, already
    # confirmed recovered here). Baking the recovered rows into the app
    # itself so every install picks them up on first run of this version,
    # instead of requiring the repair to be re-run by hand on each one.
    # INSERT OR IGNORE — never overwrites a row an install already has
    # (e.g. one it recovered itself, or a newer backfill), and running
    # this again on a later version is a harmless no-op.
    _seed_flag = conn.execute(
        "SELECT value FROM settings WHERE key='ticket_message_backfill_seed_v1'"
    ).fetchone()
    if not _seed_flag:
        try:
            _seed_candidates = []
            if getattr(sys, 'frozen', False) and getattr(sys, '_MEIPASS', None):
                _seed_candidates.append(Path(sys._MEIPASS) / 'data' / 'ticket_message_backfill_seed.json')
            _seed_candidates.append(Path(__file__).parent / 'data' / 'ticket_message_backfill_seed.json')
            _seed_rows = None
            for _cand in _seed_candidates:
                if _cand.exists():
                    with open(_cand, encoding='utf-8') as _f:
                        _seed_rows = json.load(_f)
                    break
            if _seed_rows:
                for _row in _seed_rows:
                    conn.execute(
                        "INSERT OR IGNORE INTO ticket_message_backfill "
                        "(ticket_number, body, from_email, message_id, message_date) VALUES (?, ?, ?, ?, ?)",
                        (_row['ticket_number'], _row['body'], _row.get('from_email'),
                         _row.get('message_id'), _row.get('message_date')),
                    )
                conn.commit()
                _log_db_event(f"ticket_message_backfill_seed_v1: applied {len(_seed_rows)} recovered rows")
            conn.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES ('ticket_message_backfill_seed_v1', '1')"
            )
            conn.commit()
        except Exception as _seed_err:
            _log_db_event(f"ticket_message_backfill_seed_v1: failed: {_seed_err}")

    # local_moderation_action_log (2026-09-10): a real gap found live — a
    # song sitting in "Needs Action!" with `/api/admin/song/{id}/status-history`
    # returning a genuinely empty history, no record anywhere of how/when it
    # got that status. Freecords' own history table has no entry for
    # whatever set it — not fixable by changing what Overlord asks for,
    # since there's nothing to ask for. But every moderation action Overlord
    # itself sends (approve/deny/ban/takedown/etc.) goes through this app's
    # own routes first — logging each one here, independent of whether
    # Freecords' own history captures it, means a gap like this can never
    # happen again for anything WE actually do. Won't help retroactively or
    # for actions taken outside Overlord (their own automated systems,
    # another admin panel), but that's a real, separate limit, not a reason
    # not to own the half we control.
    if 'local_moderation_action_log' not in tables:
        conn.execute("""
            CREATE TABLE local_moderation_action_log (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                song_id      TEXT,
                user_id      TEXT,
                action_type  TEXT NOT NULL,
                detail       TEXT,
                admin_email  TEXT,
                created_at   TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_local_mod_log_song ON local_moderation_action_log(song_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_local_mod_log_user ON local_moderation_action_log(user_id)")
        conn.commit()

    # local_admin_notes (2026-09-30): Freecords' own `/api/admin/user/{id}/notes`
    # is a single overwritable text field — one note, one `updated_by`/
    # `updated_at` pair, full stop. Every save replaces it outright, so two
    # moderators' notes end up concatenated by hand into one blob (confirmed
    # live: Nik's fraud-warning note had "- Last edited by Nikola Jevtic ·
    # <timestamp>" pasted into the text itself, since that's the only way to
    # preserve who wrote what once a second person saves over the field) —
    # **user-reported, directly**: "I need a new admin note created every
    # time somebody touches it with that moderator's name and time/date
    # stamp, NOT REPLACING the previous action's log, but creating a new
    # one." Real per-entry history isn't something the upstream field can
    # give us, so — same reasoning as local_moderation_action_log just
    # above — Overlord keeps its own append-only log of what IT writes.
    if 'local_admin_notes' not in tables:
        conn.execute("""
            CREATE TABLE local_admin_notes (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id      TEXT NOT NULL,
                author       TEXT,
                note         TEXT NOT NULL,
                created_at   TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_local_admin_notes_user ON local_admin_notes(user_id)")
        conn.commit()

    # artist_impersonation_checks (2026-09-30): **user, directly**: a
    # one-button AI web-research check on the Songs Moderation page — is
    # this artist a pretender posing as an already-established one? —
    # whose "written and logged result... remains on the song page." No
    # Freecords-side endpoint does this; it's Overlord's own Claude
    # (web-search-tool) call, so the result has to live somewhere on our
    # side to persist across reselecting the song, same reasoning as every
    # other local-only table above. One row per song, overwritten on
    # re-run — matches the existing ACR/Shazam/AIMD analysis sections'
    # "Run" -> "Refresh" pattern this sits alongside, not an accumulating
    # log like local_admin_notes.
    if 'artist_impersonation_checks' not in tables:
        conn.execute("""
            CREATE TABLE artist_impersonation_checks (
                song_id      TEXT PRIMARY KEY,
                artist_name  TEXT,
                result       TEXT NOT NULL,
                checked_by   TEXT,
                checked_at   TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    # ticket_expiry_notified (2026-09-10): dedup guard for main.py's
    # _ticket_expiry_loop — **user, directly**: a ticket left unanswered by
    # us for 30 days gets an apologetic "your ticket expired" email and is
    # closed, and "automation should check not to send this email to the
    # same [ticket] twice". One row per ticket the loop has already
    # notified/closed (or found already closed by other means) — checked
    # before ever sending, so a restart mid-run or a re-scan can't double-
    # send the same notice.
    if 'ticket_expiry_notified' not in tables:
        conn.execute("""
            CREATE TABLE ticket_expiry_notified (
                ticket_number   INTEGER PRIMARY KEY,
                requester_email TEXT,
                notified        INTEGER DEFAULT 1,
                notified_at     TEXT DEFAULT (datetime('now'))
            )
        """)
        conn.commit()

    conn.close()
