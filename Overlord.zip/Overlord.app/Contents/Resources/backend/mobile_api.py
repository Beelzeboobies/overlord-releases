"""
mobile_api.py — Read-only API surface for the Overlord iPhone companion app.

Phase 1 scope (see /Users/ozz/.claude/plans/piped-squishing-ocean.md):
tickets + admin/moderation lookup only, no actions. Every route here is a
GET — that's the actual enforcement of "no write actions from mobile," not
just a UI-level choice. Do not add PATCH/POST/DELETE routes to this file;
if mobile ever needs to write something, that's a deliberate scope change
to be made explicitly, not slipped in here.

Deliberately thin proxies over the same Freecords admin API calls the
desktop app already makes — reuses freecords_admin.py's `_api()` helper
(auth + 429/connection-error retry) rather than reimplementing it.

Routes:
  GET /api/mobile/tickets                — list, filters: status, q (search)
  GET /api/mobile/tickets/<id>            — full detail + conversation thread
  GET /api/mobile/user?email=...          — admin/moderation lookup
"""

from flask import Blueprint, jsonify, request

from freecords_client import _api

bp = Blueprint('mobile_api', __name__)


@bp.route('/api/mobile/tickets')
def mobile_tickets_list():
    params = {}
    status = request.args.get('status', '').strip()
    q = request.args.get('q', '').strip()
    page = request.args.get('page', '1')
    if status:
        params['status'] = status
    if q:
        params['q'] = q
    params['page'] = page
    params['limit'] = request.args.get('limit', '30')

    data, err = _api('GET', '/api/admin/tickets', params=params)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/mobile/tickets/<ticket_id>')
def mobile_ticket_detail(ticket_id):
    data, err = _api('GET', f'/api/admin/tickets/{ticket_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/mobile/user')
def mobile_user_lookup():
    email = request.args.get('email', '').strip()
    if not email:
        return jsonify({'error': 'email required'}), 400

    search, err = _api('GET', '/api/admin/search', params={'q': email})
    if err:
        return jsonify({'error': err}), 503

    results = search.get('results', [])
    match = next(
        (r for r in results
         if r.get('type') == 'user'
         and (
             r.get('subtitle', '').lower() == email.lower()
             or r.get('metadata', {}).get('email', '').lower() == email.lower()
         )),
        None,
    )
    if not match:
        return jsonify({'user': None}), 200

    user_id = match.get('userId') or match.get('id')
    profile, err = _api('GET', f'/api/admin/user/{user_id}')
    if err:
        return jsonify({'error': err}), 503

    notes_data, _   = _api('GET', f'/api/admin/user/{user_id}/notes')
    history_data, _ = _api('GET', f'/api/admin/user/{user_id}/ban-history')

    return jsonify({
        'user': profile.get('user') or {},
        'songs': profile.get('songs') or [],
        'admin_note': (notes_data or {}).get('note') if notes_data else None,
        'ban_history': (history_data or {}).get('history', []) if history_data else [],
    })
