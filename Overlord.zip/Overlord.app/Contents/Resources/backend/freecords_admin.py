"""
freecords_admin.py — Freecords Admin API proxy

Authentication: OAuth browser flow via freecords_auth.py.
POST /api/fadmin/connect to start; poll GET /api/fadmin/status until connected.

All requests use Authorization: Bearer <jwt> via freecords_auth.get_token().
On 401, surfaces a plain error (does NOT auto-open the browser).

Routes:
  GET    /api/fadmin/status              — is a token stored?
  POST   /api/fadmin/connect             — start browser login (non-blocking)
  POST   /api/fadmin/disconnect          — clear stored token
  GET    /api/fadmin/user?email=...      — search + full profile load
                                           returns { user, songs, admin_note, ban_history }
  PUT    /api/fadmin/note                — upsert admin note  { user_id, note }
  POST   /api/fadmin/ban                 — ban user           { user_id, reason, details }
  POST   /api/fadmin/unban               — unban user         { user_id }
  DELETE /api/fadmin/delete              — delete profile     { user_id }
  POST   /api/fadmin/takedown            — DDEX takedown      { song_id }
  GET    /api/fadmin/docs?user_id=...    — documents on file, { song: [], identity: [], other: [] }
  POST   /api/fadmin/docs                — upload a document, multipart: user_id, file, category, song_id?, label?
  POST   /api/fadmin/docs/from-url       — attach a CRM attachment to the profile, { user_id, category, source_url, filename, song_id?, label? }
  DELETE /api/fadmin/docs                — delete an admin-uploaded doc, { user_id, doc_id }
  GET    /api/fadmin/tickets/read-state?ticket_ids=...  — local read-state, { read: { id: true } }
  POST   /api/fadmin/tickets             — create; { requesterEmail, subject, body, messageId, send_email?, attachments? }
                                           send_email or any attachments → the email is sent by Overlord itself
                                           (Freecords' create endpoint only records the ticket, it emails nobody)
  POST   /api/fadmin/tickets/<id>/reply  — { subject?, body, attachments? }; with attachments the email is sent by
                                           Overlord over SMTP (Freecords' reply endpoint is JSON-only) and logged to the thread
  POST   /api/fadmin/download-file       — save a signed URL to ~/Downloads server-side, { url, filename }
"""

import base64
import datetime as _dt
import email.utils
import html as _html
import json
import os
import re
import subprocess
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import keyring
import requests as http
import freecords_auth
from flask import Blueprint, jsonify, request, Response, send_file
from claude_bulk_classify import CANCELLED_CODE, CREDIT_ERROR_CODE, classify_and_draft, get_anthropic_client, is_credit_error, resolve_buckets, suggest_instructions
from config import ANTHROPIC_KEYRING, APP_SUPPORT
from db import get_db
from freecords_client import _api
from helpers import render_xlsx_table, render_docx_table, _do_send, clear_ticket_awaiting_reply
from imap import get_all_accounts
from ticket_rules_engine import apply_ticket_rules
from ticket_tagger import suggest_tag

bp = Blueprint('freecords_admin', __name__)

_login_state = {'running': False, 'error': None}
_login_lock  = threading.Lock()

# ── Local moderation-action log ────────────────────────────────────────────────
# See db.py's local_moderation_action_log schema comment for the full
# rationale (2026-09-10: a song stuck in "Needs Action!" with genuinely zero
# entries in Freecords' own status-history — an upstream gap nothing here can
# retroactively fix, but every action Overlord itself sends can be logged
# locally going forward so this can't happen again for anything WE do).

_admin_identity_cache = {'email': None, 'at': 0}


def _get_current_admin_email():
    """Cached (5 min) current-admin email for stamping the local action log —
    avoids an extra /api/admin/me round trip on every single moderation
    action just to record who performed it."""
    import time as _time
    now = _time.time()
    if now - _admin_identity_cache['at'] > 300:
        data, err = _api('GET', '/api/admin/me')
        if not err and data:
            _admin_identity_cache['email'] = data.get('email') or data.get('username') or None
            _admin_identity_cache['name'] = data.get('username') or data.get('email') or None
            _admin_identity_cache['at'] = now
    return _admin_identity_cache['email']


def _get_current_admin_name():
    """Display name (username) for stamping shared notes — the email is
    what the local action log wants, but a note read by other moderators
    should say who it is, not leak an address."""
    _get_current_admin_email()
    return _admin_identity_cache.get('name')


def _log_local_moderation_action(action_type, song_id=None, user_id=None, detail=None):
    """Record one moderation action Overlord itself just sent — independent
    of whether Freecords' own status-history captures it. Best-effort: a
    logging failure must never break the action that already succeeded."""
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO local_moderation_action_log (song_id, user_id, action_type, detail, admin_email) "
            "VALUES (?, ?, ?, ?, ?)",
            (song_id, user_id, action_type, detail, _get_current_admin_email()),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def _url_is_fetchable(url):
    """
    Guards the handful of routes below that fetch a caller-supplied URL
    server-side (download-file, preview-file, preview-file-table,
    docs/from-url) — the https-only check exists to stop this app being
    used as an open SSRF proxy against arbitrary internal http:// hosts.
    Confirmed live this was also rejecting a URL that's actually safe:
    /api/fadmin/requester-attachments-local (freshdesk.py's
    local_ticket_attachment) builds its attachment_url from
    request.host_url, which is this app's own http://localhost:PORT
    origin, not an external host — a real, reproducible bug ("Couldn't
    download 'image.png': url must be https" on an attachment the User
    panel could preview fine, since AttachmentPreviewModal already
    special-cases same-origin URLs and skips this check entirely; nothing
    downstream of it did). A request back to this exact process is not an
    SSRF vector, so it's allowed alongside https.
    """
    return url.startswith('https://') or url.startswith(request.host_url.rstrip('/') + '/')


# ── Status ────────────────────────────────────────────────────────────────────

_AUTH_FAILURE_ERRORS = (
    'Session expired — reconnect in Settings → Tickets',
    'Not connected — connect your Freecords account in Settings → Tickets',
)


@bp.route('/api/fadmin/status')
def fadmin_status():
    """
    Was `connected: bool(token)` — only checked whether a token was ever
    stored, never whether it's still valid. Confirmed live: tokens expire
    after 7 days (see Settings' own copy), and Freecords_client's `_api()`
    detects that correctly on any real call ("Session expired — reconnect
    in Settings → Tickets") but never clears the stale token from the
    keychain — so Settings kept showing "Connected" indefinitely after
    real expiry while Tickets' sidebar (which polls the real
    /api/fadmin/me, not just token presence) correctly showed "Not
    connected", a visible contradiction between the two. Now makes the
    same lightweight real call Tickets' indicator already uses and only
    reports connected=False for an actual auth failure — a transient
    error (e.g. Freecords rate-limiting) shouldn't flip this and send
    someone down the wrong "go reconnect" path for what's just a slow
    moment.
    """
    token = freecords_auth.get_token()
    with _login_lock:
        running = _login_state['running']
        error   = _login_state['error']
    connected = False
    if token:
        _, api_err = _api('GET', '/api/admin/me')
        connected = api_err not in _AUTH_FAILURE_ERRORS
    return jsonify({'connected': connected, 'connecting': running, 'error': error})


# ── Connect ───────────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/connect', methods=['POST'])
def fadmin_connect():
    with _login_lock:
        if _login_state['running']:
            return jsonify({'ok': True, 'message': 'Login already in progress — check your browser.'})
        _login_state['running'] = True
        _login_state['error']   = None

    def _run():
        try:
            freecords_auth.login()
        except freecords_auth.AuthError as e:
            with _login_lock:
                _login_state['error'] = str(e)
        except Exception as e:
            with _login_lock:
                _login_state['error'] = str(e)
        finally:
            with _login_lock:
                _login_state['running'] = False

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({'ok': True, 'message': 'Browser opened — authorize Overlord on the Freecords page.'})


# ── Disconnect ────────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/disconnect', methods=['POST'])
def fadmin_disconnect():
    freecords_auth.clear_token()
    return jsonify({'ok': True})


# ── Current admin identity ────────────────────────────────────────────────────

@bp.route('/api/fadmin/me')
def fadmin_me():
    data, err = _api('GET', '/api/admin/me')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── Agent list (for ticket assignment) ────────────────────────────────────────

@bp.route('/api/fadmin/agents')
def fadmin_agents():
    data, err = _api('GET', '/api/admin/agents')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── User lookup ───────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/search')
def fadmin_search():
    q = request.args.get('q', '').strip()
    if not q:
        return jsonify({'results': []}), 200
    data, err = _api('GET', '/api/admin/search', params={'q': q})
    if err:
        return jsonify({'error': err}), 503
    return jsonify({'results': data.get('results', [])})


@bp.route('/api/fadmin/mod-search')
def fadmin_mod_search():
    """Moderation-scoped song search."""
    q = request.args.get('q', '').strip()
    if not q:
        return jsonify({'results': []}), 200
    data, err = _api('GET', '/api/admin/moderation/search', params={'q': q})
    if err:
        return jsonify({'error': err}), 503
    return jsonify({'results': data.get('results', [])})


@bp.route('/api/fadmin/mod-song')
def fadmin_mod_song():
    """Full song data for moderation (includes ai_analysis)."""
    song_id = request.args.get('song_id', '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('GET', f'/api/admin/moderation/song/{song_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/song-collaborators')
def fadmin_song_collaborators():
    """Per-song collaborators + royalty splits — the web admin's own song
    detail page shows this (name, role, royalty_share, is_primary) but
    Individual Search/Moderation Queue never did. Not documented anywhere
    (checked FREECORDS_API_REFERENCE.md first, genuinely absent) and
    doesn't show up under any of `mod-song`/the user profile's songs[]/
    other plausible endpoint-name guesses — confirmed live via the real
    web admin's own network requests (2026-09-17/18, user's own browser,
    same account): `GET /api/admin/moderation/song/{songId}/collaborators`,
    response `{ success, collaborators: [{id, song_id, name, email, role,
    royalty_share, spotify_profile, is_primary, created_at, updated_at}],
    song: {...} }`. Only the `collaborators` list is surfaced here — the
    embedded `song` echo duplicates what `mod-song` already gives."""
    song_id = request.args.get('song_id', '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('GET', f'/api/admin/moderation/song/{song_id}/collaborators')
    if err:
        return jsonify({'error': err}), 503
    return jsonify({'collaborators': (data or {}).get('collaborators', [])})


@bp.route('/api/fadmin/song-status-history')
def fadmin_song_status_history():
    """
    Full ordered status-transition history for a song — who/what changed
    it and when. New endpoint Nick built for Round 8 item 4: user asked
    "when a song is Needs Action/Denied/Taken Down, can we see who did
    it?" — this answers that, plus Approved and every other status.
    Returns { status, previous_status, action_type, changed_by: {type,
    email}, at } per transition, ordered.
    """
    song_id = request.args.get('song_id', '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('GET', f'/api/admin/song/{song_id}/status-history')
    if err:
        return jsonify({'error': err}), 503
    result = data or {}
    remote_history = result.get('statusHistory') or []

    # Merge in local_moderation_action_log entries Freecords' own history is
    # missing — see that table's schema comment in db.py (2026-09-10: a real
    # song found with a live "Needs Action!" status and zero remote history
    # for how it got there). Only fills gaps: an action within the same
    # minute as a real remote entry is assumed to be that same action
    # already correctly recorded, and skipped, so a working case never gets
    # a duplicate row.
    _ACTION_TO_STATUS = {
        'approve':      'Approved',
        'approve_ada':  'Approved',
        'deny':         'Needs Action!',
        'deny_silent':  'Needs Action!',
        'takedown':     'Takedown',
        'fp_add':       'Added to FP',
        'fp_remove':    'Removed from FP',
    }

    def _minute_key(iso_str):
        try:
            s = (iso_str or '').replace('Z', '+00:00')
            if ' ' in s and 'T' not in s:
                s = s.replace(' ', 'T') + '+00:00'
            return int(_dt.datetime.fromisoformat(s).timestamp() // 60)
        except Exception:
            return None

    remote_minutes = {mk for mk in (_minute_key(h.get('at')) for h in remote_history) if mk is not None}

    conn = get_db()
    local_rows = conn.execute(
        "SELECT action_type, detail, admin_email, created_at FROM local_moderation_action_log "
        "WHERE song_id=? ORDER BY created_at", (song_id,)
    ).fetchall()
    conn.close()

    merged = list(remote_history)
    for row in local_rows:
        status = _ACTION_TO_STATUS.get(row['action_type'])
        if not status:
            continue
        if _minute_key(row['created_at']) in remote_minutes:
            continue
        merged.append({
            'status': status,
            'previous_status': None,
            'action_type': row['action_type'],
            'changed_by': {'type': 'admin', 'email': row['admin_email'] or 'Unknown (recorded locally by Overlord)'},
            'at': row['created_at'],
        })
    merged.sort(key=lambda h: h.get('at') or '')
    result['statusHistory'] = merged
    result['total'] = len(merged)
    return jsonify(result)


@bp.route('/api/fadmin/song-url')
def fadmin_song_url():
    """Get signed download/stream URL for a song."""
    song_id = request.args.get('song_id', '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('GET', f'/api/admin/song/{song_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify({'url': (data or {}).get('downloadUrl', '')})


@bp.route('/api/fadmin/risk')
def fadmin_risk():
    """Account risk score for a user."""
    user_id = request.args.get('user_id', '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    data, err = _api('GET', f'/api/admin/risk/score/{user_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/update-user', methods=['POST'])
def fadmin_update_user():
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    payload = {k: v for k, v in body.items() if k != 'user_id'}
    data, err = _api('PUT', f'/api/admin/user/{user_id}', json=payload)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# The user object's real spotify_id/spotify_uri/verified_spotify fields
# ARE the actual source of truth for an artist's linked Spotify profile —
# confirmed live against the real web admin (network-captured its Edit/
# Delete flow directly): the site's own "Add/Edit Spotify Profile" dialog
# posts here, and "Delete" is just fadmin_update_user above with all three
# fields nulled. An earlier comment elsewhere claiming these fields are
# "always null" was wrong — they were just never being set from Overlord.
@bp.route('/api/fadmin/user-spotify', methods=['POST'])
def fadmin_user_spotify():
    body           = request.get_json(force=True) or {}
    user_id        = (body.get('user_id') or '').strip()
    spotify_input  = (body.get('spotifyInput') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    if not spotify_input:
        return jsonify({'error': 'spotifyInput required'}), 400
    data, err = _api('POST', f'/api/admin/user/{user_id}/spotify', json={'spotifyInput': spotify_input})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/spotify-artist')
def fadmin_spotify_artist():
    """Resolve a bare Spotify artist ID to real name/followers/genres for
    display — same endpoint the web admin's own Spotify Profile card uses."""
    spotify_id = request.args.get('spotify_id', '').strip()
    if not spotify_id:
        return jsonify({'error': 'spotify_id required'}), 400
    data, err = _api('GET', f'/api/spotify/artist/{spotify_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/user')
def fadmin_user():
    email   = request.args.get('email', '').strip()
    user_id = request.args.get('user_id', '').strip()

    if user_id:
        # Direct lookup by ID — skip search step
        pass
    elif email:
        # Step 1 — search by email to get the userId
        search, err = _api('GET', '/api/admin/search', params={'q': email})
        if err:
            return jsonify({'error': err}), 503

        results = search.get('results', [])
        match = next(
            (r for r in results
             if r.get('type') == 'user'
             and (
                 r.get('subtitle', '').lower() == email.lower()
                 or r.get('metadata', {}).get('email', '').lower() == email.lower()
             )),
            None,
        )
        if not match:
            return jsonify({'user': None}), 200
        user_id = match.get('userId') or match.get('id')
    else:
        return jsonify({'error': 'email or user_id required'}), 400

    # Step 2 — load full profile (includes songs array)
    profile, err = _api('GET', f'/api/admin/user/{user_id}')
    if err:
        return jsonify({'error': err}), 503

    # A deleted account's profile 404s, which _api turns into
    # ({'_not_found': True}, None) — not an error string, so this was
    # falling through to build a near-empty user object ({id: user_id},
    # no username/email/is_banned) that rendered as a broken-looking but
    # technically "Active" profile, with nothing telling the moderator the
    # account was actually deleted. Flag it explicitly instead.
    if isinstance(profile, dict) and profile.get('_not_found'):
        return jsonify({
            'user':        {'id': user_id, 'deleted': True},
            'songs':       [],
            'admin_note':  None,
            'ban_history': [],
        })

    # Step 3 — notes and ban history (best-effort; failures return empty)
    notes_data, _    = _api('GET', f'/api/admin/user/{user_id}/notes')
    history_data, _  = _api('GET', f'/api/admin/user/{user_id}/ban-history')

    user = profile.get('user') or {}
    # Attach the internal userId so the frontend can reference it
    if 'id' not in user:
        user['id'] = user_id

    return jsonify({
        'user':        user,
        'songs':       profile.get('songs', []),
        'admin_note':  notes_data.get('note')       if notes_data    else None,
        'ban_history': history_data.get('banHistory') if history_data else [],
    })


@bp.route('/api/fadmin/user-status')
def fadmin_user_status():
    """
    Lightweight status for search-result badges — just is_banned/deleted,
    not the full profile+notes+ban-history bundle fadmin_user above loads.
    **User, directly**: searching a name that matches several accounts
    (e.g. multiple artists sharing a stage name) shouldn't require opening
    every single result just to see which ones are already banned or gone.
    """
    user_id = (request.args.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    profile, err = _api('GET', f'/api/admin/user/{user_id}')
    if err:
        return jsonify({'error': err}), 503
    if isinstance(profile, dict) and profile.get('_not_found'):
        return jsonify({'deleted': True, 'is_banned': False})
    user = (profile or {}).get('user') or {}
    return jsonify({'deleted': False, 'is_banned': bool(user.get('is_banned'))})


# ── Admin notes ───────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/note', methods=['PUT'])
def fadmin_put_note():
    """Still used by UserMissionControlPanel.jsx (Tickets' own User panel) —
    the Artists tab moved to the structured local log below, but this
    single-field write is left intact for that other caller."""
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    note    = body.get('note', '')
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400

    data, err = _api('PUT', f'/api/admin/user/{user_id}/notes', json={'note': note})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# Admin notes live ONLY in Freecords' own per-user note field — the same
# field the web admin reads and writes — so every moderator, on every
# machine and in both UIs, sees and edits one shared history.
#
# History of this feature, because it went wrong once: Overlord first kept
# its own append-only log in local SQLite and merely *mirrored* a rebuilt
# blob into Freecords' field. **User, directly**: "the admin notes in Overlord
# are not saved on the web app and vice versa." Both halves were true by
# design: a note written in the web app never reached Overlord (its local log
# was only ever seeded once), and another moderator's Overlord never saw
# mine (the log was per-machine). Fixed by making Freecords' field the single
# source of truth: reading parses that text into entries, writing appends a
# new "[timestamp] author: text" entry to whatever is CURRENTLY there. The
# old local_admin_notes table is left in place but no longer read or written.

_NOTE_HDR = re.compile(r'(?m)^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] ([^\n:]{1,80}): ')


def _fetch_remote_note(user_id):
    """-> (content, updated_by, updated_at, error)"""
    data, err = _api('GET', f'/api/admin/user/{user_id}/notes')
    if err:
        return None, None, None, err
    if isinstance(data, dict) and data.get('_not_found'):
        return None, None, None, 'Account not found (it may have been deleted)'
    note = (data or {}).get('note')
    if isinstance(note, dict):
        return (note.get('content') or ''), (note.get('updated_by') or note.get('created_by')),                (note.get('updated_at') or note.get('created_at')), None
    return (note or ''), None, None, None


# Visible progress of the local-notes rescue, so "did it work on this machine?"
# has an answer (GET /api/fadmin/notes-rescue-status, shown in Settings).
_RESCUE = {'status': 'idle', 'notes_pushed': 0, 'artists_pushed': 0, 'finished_at': None}


def _rescue_local_notes(user_id, content):
    """Retroactive fix for notes written under the old local-only system.
    Any row in the (now unused) local_admin_notes table whose text isn't
    already on Freecords is appended to Freecords' note field with its
    ORIGINAL author and timestamp, once, the first time that artist's notes
    are opened under the new system. Matters on any machine that kept
    local-only notes (e.g. another moderator's install) — those would
    otherwise silently disappear from view now that Overlord reads Freecords
    directly. Idempotent: a row already present in the remote text is
    skipped, so running it again (or on several machines) can't duplicate.
    Returns the (possibly updated) note content."""
    try:
        conn = get_db()
        rows = conn.execute(
            "SELECT author, note, created_at FROM local_admin_notes WHERE user_id=? ORDER BY id ASC",
            (user_id,),
        ).fetchall()
        conn.close()
    except Exception:
        return content
    missing = []
    for r in rows:
        text = (r['note'] or '').strip()
        # Rows seeded from the old mirror already carry their own
        # "[timestamp] author:" prefix — compare on a prefix of the body.
        probe = _NOTE_HDR.sub('', text, count=1).strip()[:80] or text[:80]
        if probe and probe not in (content or ''):
            missing.append(r)
    if not missing:
        return content
    addition = '\n\n'.join(
        (r['note'].strip() if _NOTE_HDR.match(r['note'].strip())
         else f"[{(r['created_at'] or '').replace('T', ' ')[:19]}] {r['author'] or 'Unknown'}: {r['note'].strip()}")
        for r in missing
    )
    blob = (content.rstrip() + '\n\n' if (content or '').strip() else '') + addition
    _d, err = _api('PUT', f'/api/admin/user/{user_id}/notes', json={'note': blob})
    if not err:
        _RESCUE['notes_pushed'] += len(missing)
        _RESCUE['artists_pushed'] += 1
    return content if err else blob


def rescue_all_local_notes_once():
    """Background, once per install: sweep EVERY artist that has local-only
    notes instead of waiting for someone to happen to open that artist. Waits
    (up to ~1h, checking every 2 min) for a working Freecords connection,
    since the notes can only be pushed once this install is signed in. Sets a
    settings flag only after a fully clean pass, so a partial failure retries
    on the next launch. Idempotent (see _rescue_local_notes)."""
    import time as _time
    try:
        conn = get_db()
        done = conn.execute("SELECT value FROM settings WHERE key='local_notes_rescued'").fetchone()
        users = [r['user_id'] for r in conn.execute("SELECT DISTINCT user_id FROM local_admin_notes").fetchall()]
        conn.close()
        if done:
            _RESCUE['status'] = 'done'
            try:
                _RESCUE.update(json.loads(done['value']) if str(done['value']).startswith('{') else {})
            except Exception:
                pass
            return
        _RESCUE['status'] = 'nothing_to_do' if not users else 'waiting_for_login'
        if users:
            for _ in range(30):
                _d, err = _api('GET', '/api/admin/me')
                if not err:
                    break
                _time.sleep(120)
            else:
                _RESCUE['status'] = 'not_connected'
                return
            _RESCUE['status'] = 'running'
            failed = 0
            for uid in users:
                content, _by, _at, err = _fetch_remote_note(uid)
                if err:
                    failed += 1
                    continue
                after = _rescue_local_notes(uid, content)
                # _rescue_local_notes returns the old content on a failed PUT
                if after == content and _local_has_missing(uid, content):
                    failed += 1
            if failed:
                _RESCUE['status'] = 'retry_next_launch'
                return
        _RESCUE['finished_at'] = _dt.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S') + ' UTC'
        _RESCUE['status'] = 'done'
        conn = get_db()
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('local_notes_rescued', ?)",
                     (json.dumps({k: _RESCUE[k] for k in ('notes_pushed', 'artists_pushed', 'finished_at')}),))
        conn.commit()
        conn.close()
    except Exception:
        pass


@bp.route('/api/fadmin/notes-rescue-status')
def notes_rescue_status():
    """Local-only notes found on this machine and how the one-time push to
    Freecords is going. `local_artists`/`local_notes` are what old Overlord
    saved here; `status` is idle/nothing_to_do/waiting_for_login/running/
    not_connected/retry_next_launch/done."""
    try:
        conn = get_db()
        local_notes = conn.execute("SELECT COUNT(*) c FROM local_admin_notes").fetchone()['c']
        local_artists = conn.execute("SELECT COUNT(DISTINCT user_id) c FROM local_admin_notes").fetchone()['c']
        conn.close()
    except Exception:
        local_notes = local_artists = 0
    return jsonify({**_RESCUE, 'local_notes': local_notes, 'local_artists': local_artists})


def _local_has_missing(user_id, content):
    try:
        conn = get_db()
        rows = conn.execute("SELECT note FROM local_admin_notes WHERE user_id=?", (user_id,)).fetchall()
        conn.close()
    except Exception:
        return False
    for r in rows:
        text = (r['note'] or '').strip()
        probe = _NOTE_HDR.sub('', text, count=1).strip()[:80] or text[:80]
        if probe and probe not in (content or ''):
            return True
    return False


def _parse_note_blob(content, fallback_author, fallback_ts):
    """Split the single note field into entries, oldest first. Text before the
    first '[timestamp] author:' header (a note typed by hand in the web admin)
    becomes its own entry, attributed to whoever last updated the field."""
    entries = []
    matches = list(_NOTE_HDR.finditer(content or ''))
    head = (content[:matches[0].start()] if matches else (content or '')).strip()
    if head:
        entries.append({'author': fallback_author or 'Unknown', 'created_at': fallback_ts, 'note': head})
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
        entries.append({
            'author': m.group(2).strip(),
            'created_at': m.group(1).replace(' ', 'T') + 'Z',
            'note': content[m.end():end].strip(),
        })
    for i, e in enumerate(entries):
        e['id'] = i
    return entries


@bp.route('/api/fadmin/notes-log', methods=['GET'])
def fadmin_notes_log():
    user_id = (request.args.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    content, by, at, err = _fetch_remote_note(user_id)
    if err:
        return jsonify({'error': err}), 503
    content = _rescue_local_notes(user_id, content)
    entries = _parse_note_blob(content, by, at)
    return jsonify({'notes': list(reversed(entries))})


@bp.route('/api/fadmin/notes-log', methods=['POST'])
def fadmin_add_note():
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    note    = (body.get('note') or '').strip()
    if not user_id or not note:
        return jsonify({'error': 'user_id and note required'}), 400

    # Read-modify-write against what is on Freecords RIGHT NOW (never a cached
    # or rebuilt copy) so a note someone just added in the web admin isn't
    # overwritten. If the read fails, refuse to write rather than risk
    # replacing real history with a blob built from nothing.
    content, _by, _at, err = _fetch_remote_note(user_id)
    if err:
        return jsonify({'error': err}), 503
    content = _rescue_local_notes(user_id, content)
    import datetime as _dt
    now = _dt.datetime.now(_dt.timezone.utc)
    author = _get_current_admin_name() or 'Unknown'
    entry = f"[{now.strftime('%Y-%m-%d %H:%M:%S')}] {author}: {note}"
    blob = (content.rstrip() + '\n\n' if content.strip() else '') + entry
    _data, werr = _api('PUT', f'/api/admin/user/{user_id}/notes', json={'note': blob})
    if werr:
        return jsonify({'error': werr}), 503
    return jsonify({'note': {
        'id': len(_parse_note_blob(content, _by, _at)),
        'author': author, 'note': note,
        'created_at': now.strftime('%Y-%m-%dT%H:%M:%SZ'),
    }})


# ── Account actions ───────────────────────────────────────────────────────────

@bp.route('/api/fadmin/ban', methods=['POST'])
def fadmin_ban():
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    reason  = (body.get('reason') or 'general').strip()
    details = (body.get('details') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400

    data, err = _api('POST', f'/api/admin/user/{user_id}/ban',
                     json={'reason': reason, 'details': details})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('ban', user_id=user_id, detail=f'{reason}: {details}' if details else reason)
    return jsonify(data or {})


@bp.route('/api/fadmin/warn', methods=['POST'])
def fadmin_warn():
    """
    Warn an artist without banning them — Round 8 item 2. Every escalation
    path before this was a full ban; a warning had no system of record and
    happened manually over email. Writes into the same ban_history table
    as bans/unbans (action: 'warned'), so it shows up in Ban History
    alongside real bans instead of being invisible.
    """
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    reason  = (body.get('reason') or '').strip()
    details = (body.get('details') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    data, err = _api('POST', f'/api/admin/user/{user_id}/warn',
                     json={'reason': reason, 'details': details})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('warn', user_id=user_id, detail=f'{reason}: {details}' if details else reason)
    return jsonify(data or {})


@bp.route('/api/fadmin/unban', methods=['POST'])
def fadmin_unban():
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400

    data, err = _api('POST', f'/api/admin/user/{user_id}/unban')
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('unban', user_id=user_id)
    return jsonify(data or {})


@bp.route('/api/fadmin/delete', methods=['DELETE', 'POST'])
def fadmin_delete():
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400

    data, err = _api('DELETE', f'/api/admin/user/{user_id}/delete-profile')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/deletion-history')
def fadmin_deletion_history():
    """
    Who deleted a song/account and when — Round 8 item 3. Answers "was it
    the user themselves, or one of us, and if so which admin" with real
    data instead of taking anyone's word for it. Unified across both sides
    regardless of which initiated the deletion (`initiated_by: {type:
    'admin'|'user', email}`).
    """
    user_id = request.args.get('user_id', '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    data, err = _api('GET', f'/api/admin/user/{user_id}/deletion-history')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── Song takedown ─────────────────────────────────────────────────────────────

def _takedown_song(song_id):
    """Takedown = TWO things in Freecords, and Overlord only ever did the first:
    (1) POST /api/admin/ddex/nuemeta-dsp-action {deliveryType: TakeDown} sends the
    takedown to the DSPs; (2) the song's `distribution_status` has to be flipped
    to Takedown separately - what the web admin's "Distribution Status" dropdown
    does, i.e. PUT /api/admin/song/{id} {distribution_status: 'Takedown'}. The
    web admin's own Takedown menu item doesn't set the status either (it only
    marks the delivery 'not_sent' in the page). Songs we took down kept
    reverting to Approved a few minutes to days later. **Nik, directly**: the
    route doesn't flip the status, what he flips manually from the admin does,
    "so adjust it in Overlord." Returns (data, error, status_flip_error)."""
    data, err = _api('POST', '/api/admin/ddex/nuemeta-dsp-action',
                     json={'songId': song_id, 'deliveryType': 'TakeDown'})
    if err:
        return None, err, None
    _log_local_moderation_action('takedown', song_id=song_id)
    # Best effort: the DSP takedown already went out, so a failure here is
    # reported to the caller rather than turned into a failed takedown.
    _put, flip_err = _api('PUT', f'/api/admin/song/{song_id}', json={'distribution_status': 'Takedown'})
    return (data or {}), None, flip_err


@bp.route('/api/fadmin/takedown', methods=['POST'])
def fadmin_takedown():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400

    data, err, flip_err = _takedown_song(song_id)
    if err:
        return jsonify({'error': err}), 503
    if flip_err:
        data['status_flip_error'] = flip_err
    return jsonify(data)


# ── Double status: takedown + account ban, per song, in bulk ────────────────
# "Approved - Takedown" / "Banned - Takedown": the song's label, a takedown and the
# account's ban are three separate facts, and Freecords stores only the label. A song
# is TAKEN DOWN when it reads not_sent at NueMeta after real deliveries to the
# services (not_sent alone is also how a never-distributed, Freecords-only song looks)
# or when its label itself is Takedown. Lists (search results, Artists tab, Other
# Songs) ask for many songs at once, so group by artist and cache.
_song_state_cache = {}      # song_id -> (checked_at, taken_down)
_artist_cache = {}          # artist_id -> (checked_at, is_banned, {song_id: song})


def _song_states(items):
    """items: [{'id', 'artist_id'}] -> {song_id: {'taken_down': bool, 'banned': bool}}"""
    import time as _t
    import concurrent.futures
    now = _t.time()
    by_artist = {}
    for it in items:
        if it.get('id') and it.get('artist_id'):
            by_artist.setdefault(it['artist_id'], []).append(it['id'])

    def load_artist(aid):
        hit = _artist_cache.get(aid)
        if hit and now - hit[0] < 120:
            return aid, hit
        d, err = _api('GET', f'/api/admin/user/{aid}')
        if err or not d:
            return aid, None
        entry = (now, bool((d.get('user') or {}).get('is_banned')), {s['id']: s for s in (d.get('songs') or []) if s.get('id')})
        _artist_cache[aid] = entry
        return aid, entry

    def taken_down(song):
        label, nuemeta = song.get('distribution_status'), song.get('nuemeta_delivery_status')
        if nuemeta != 'not_sent' or label not in ('Approved', 'Takedown'):
            return False
        if label == 'Takedown':
            return True
        hit = _song_state_cache.get(song['id'])
        if hit and now - hit[0] < 600:
            return hit[1]
        d, err = _api('GET', f"/api/admin/song/{song['id']}/dsp-deliveries")
        if err or not d:
            return False
        flag = any(x.get('status') in ('sent', 'delivered') for x in (d.get('deliveries') or []))
        _song_state_cache[song['id']] = (now, flag)
        return flag

    out = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        loaded = dict(pool.map(load_artist, list(by_artist)))
        jobs = []
        for aid, ids in by_artist.items():
            entry = loaded.get(aid)
            if not entry:
                continue
            for sid in ids:
                song = entry[2].get(sid)
                if song:
                    jobs.append((sid, entry[1], song))
        for (sid, banned, _song), flag in zip(jobs, pool.map(lambda j: taken_down(j[2]), jobs)):
            out[sid] = {'taken_down': flag, 'banned': banned}
    return out


@bp.route('/api/fadmin/song-states', methods=['POST'])
def fadmin_song_states():
    body = request.get_json(force=True) or {}
    items = (body.get('songs') or [])[:60]
    return jsonify({'states': _song_states(items)})


# ── Moderation queue ──────────────────────────────────────────────────────────

@bp.route('/api/fadmin/mod-queue')
def fadmin_mod_queue():
    data, err = _api('GET', '/api/admin/moderation/queue')
    if err:
        return jsonify({'error': err}), 503
    return jsonify({'songs': (data or {}).get('songs', [])})


@bp.route('/api/fadmin/bulk-approval-candidates')
def fadmin_bulk_approval_candidates():
    # Nik confirmed (round 5 response, item 5) the real, already-live endpoint
    # is bulk-approval-accounts, not -candidates (which 404s — that name was
    # never actually deployed). Same one the web admin's Bulk Approval Review
    # screen already calls successfully.
    page = request.args.get('page', '1')
    data, err = _api('GET', '/api/admin/moderation/bulk-approval-accounts', params={'page': page})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── Moderation actions ────────────────────────────────────────────────────────

@bp.route('/api/fadmin/mod-approve', methods=['POST'])
def fadmin_mod_approve():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('POST', '/api/admin/moderation/approve-song-only', json={'songId': song_id})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('approve', song_id=song_id)
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-approve-ada', methods=['POST'])
def fadmin_mod_approve_ada():
    body         = request.get_json(force=True) or {}
    song_id      = (body.get('song_id') or '').strip()
    approval_type = (body.get('approval_type') or 'ada').strip()
    album_id     = body.get('album_id')
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('POST', '/api/admin/moderation/approve-album',
                     json={'albumId': album_id, 'approvalType': approval_type, 'songIds': [song_id]})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('approve_ada', song_id=song_id, detail=approval_type)
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-deny', methods=['POST'])
def fadmin_mod_deny():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    reason  = (body.get('reason') or 'distribution_guidelines').strip()
    custom  = (body.get('custom_message') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    payload = {'songId': song_id, 'reason': reason}
    if reason == 'custom':
        payload['customMessage'] = custom
    data, err = _api('POST', '/api/admin/moderation/deny', json=payload)
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('deny', song_id=song_id, detail=custom if reason == 'custom' else reason)
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-deny-silent', methods=['POST'])
def fadmin_mod_deny_silent():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    reason  = (body.get('reason') or 'distribution_guidelines').strip()
    custom  = (body.get('custom_message') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    payload = {'songId': song_id, 'reason': reason}
    if reason == 'custom':
        payload['customMessage'] = custom
    data, err = _api('POST', '/api/admin/moderation/deny-silent', json=payload)
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('deny_silent', song_id=song_id, detail=custom if reason == 'custom' else reason)
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-deny-all-ai', methods=['POST'])
def fadmin_mod_deny_all_ai():
    body      = request.get_json(force=True) or {}
    artist_id = (body.get('artist_id') or '').strip()
    if not artist_id:
        return jsonify({'error': 'artist_id required'}), 400
    data, err = _api('POST', '/api/admin/moderation/deny-all-ai', json={'artistId': artist_id})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('deny_all_ai', user_id=artist_id)
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-ban', methods=['POST'])
def fadmin_mod_ban():
    body      = request.get_json(force=True) or {}
    artist_id = (body.get('artist_id') or '').strip()
    ban_reason = (body.get('ban_reason') or '').strip()
    if not artist_id:
        return jsonify({'error': 'artist_id required'}), 400
    data, err = _api('POST', '/api/admin/moderation/ban-and-deny-all',
                     json={'artistId': artist_id, 'banReason': ban_reason})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('ban_and_deny_all', user_id=artist_id, detail=ban_reason)
    return jsonify(data or {})


# ── Analysis ──────────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/mod-acr-results')
def fadmin_mod_acr_results():
    """Read-only — the web admin's compact review calls this automatically
    on load (POST /api/admin/moderation/display-acr-results, keyed by the
    song's own `acrid`) and shows the result with no button press, because
    Freecords already runs ACR at submission time; every song has an
    `acrid` from the moment it's uploaded. **User, directly**: "the ACRCloud
    checkup and Shazam already come in auto-checked by default, so
    tokens/money are already spent for this" — Overlord only ever had the
    paid trigger (mod-acr below, POST analyze-copyright) and no way to read
    the result that submission-time run already paid for, so every manual
    "Run ACR Analysis" click was re-paying for an analysis that already
    existed. Confirmed live (2026-09-30, real web admin network capture):
    POST /api/admin/moderation/display-acr-results {acrid} returns
    {success, results: {violation_detected, song_duration,
    total_match_duration, match_percentage, matches, acr_response}} at no
    extra cost — this proxies that, GET-style since it's read-only despite
    the upstream method."""
    acrid = request.args.get('acrid', '').strip()
    if not acrid:
        return jsonify({'error': 'acrid required'}), 400
    data, err = _api('POST', '/api/admin/moderation/display-acr-results', json={'acrid': acrid})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-acr', methods=['POST'])
def fadmin_mod_acr():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    # Synchronous, compute-heavy on the Freecords side (real audio fingerprint
    # analysis) — confirmed via live testing to reliably take slightly over
    # the default 10s timeout, which made this always fail with a generic
    # "connection_error" (requests.Timeout is caught by the same except
    # branch as an actual connection failure). 60s gives it real room.
    # NOTE: this re-runs (and re-pays for) the analysis — only call it when
    # mod-acr-results above has confirmed no existing result exists, or the
    # user explicitly wants a fresh check (song changed since last analysis).
    data, err = _api('POST', '/api/admin/moderation/analyze-copyright', json={'songId': song_id}, timeout=60)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-shazam', methods=['POST'])
def fadmin_mod_shazam():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    payload = {
        'songId':          song_id,
        'audioUrl':        body.get('audio_url', ''),
        'songName':        body.get('song_name', ''),
        'artistUsername':  body.get('artist_username', ''),
    }
    data, err = _api('POST', '/api/admin/moderation/trigger-shazam', json=payload)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-shazam-results')
def fadmin_mod_shazam_results():
    song_id = request.args.get('song_id', '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('GET', f'/api/admin/moderation/shazam-results/{song_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/mod-aimd', methods=['POST'])
def fadmin_mod_aimd():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('POST', '/api/analysis/submit-aimd',
                     json={'song_id': song_id, 'admin_notification_enabled': True})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── Moderation stats ──────────────────────────────────────────────────────────

@bp.route('/api/fadmin/mod-stats')
def fadmin_mod_stats():
    data, err = _api('GET', '/api/admin/moderation/stats')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── FP curation ───────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/fp-list')
def fadmin_fp_list():
    """
    The real FP queue — FPCuration's song list was PLACEHOLDER_FP_QUEUE
    (hardcoded mock data, audio_url always null) until now, which is why
    playback never worked in that sub-tab: there was never a real song
    behind any row. See FREECORDS_API_REFERENCE.md §2 for the shape —
    same fields as the moderation queue (song_file_url/aac_file_url for
    playback, cover_photo_url for artwork), plus FP's own genre_bucket.
    """
    params = {k: v for k, v in request.args.items() if k in ('page', 'limit', 'sort', 'genreBucket')}
    data, err = _api('GET', '/api/admin/fp/list', params=params)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/fp-assign-genre', methods=['POST'])
def fadmin_fp_assign_genre():
    """
    Was never wired — FPCuration's assignGenre() only updated local React
    state ("no dedicated genre-assignment endpoint in API yet"), which was
    stale: it exists, just never connected. Without this, every assignment
    was silently lost on refresh/re-fetch.
    """
    body        = request.get_json(force=True) or {}
    song_id     = (body.get('song_id') or '').strip()
    genre_bucket = (body.get('genre_bucket') or '').strip()
    if not song_id or not genre_bucket:
        return jsonify({'error': 'song_id and genre_bucket required'}), 400
    data, err = _api('POST', '/api/admin/fp/assign-genre', json={'songId': song_id, 'genreBucket': genre_bucket})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/fp-remove', methods=['POST'])
def fadmin_fp_remove():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('song_id') or '').strip()
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('POST', '/api/admin/fp/remove', json={'songId': song_id})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('fp_remove', song_id=song_id)
    return jsonify(data or {})


@bp.route('/api/fadmin/fp-add', methods=['POST'])
def fadmin_fp_add():
    body         = request.get_json(force=True) or {}
    song_id      = (body.get('song_id') or '').strip()
    skip_approval = body.get('skip_approval', True)
    if not song_id:
        return jsonify({'error': 'song_id required'}), 400
    data, err = _api('POST', '/api/admin/moderation/add-to-fp',
                     json={'songId': song_id, 'skipApproval': skip_approval})
    if err:
        return jsonify({'error': err}), 503
    _log_local_moderation_action('fp_add', song_id=song_id)
    return jsonify(data or {})


# ── Delete all songs ──────────────────────────────────────────────────────────

@bp.route('/api/fadmin/delete-songs', methods=['DELETE', 'POST'])
def fadmin_delete_songs():
    body    = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    data, err = _api('DELETE', f'/api/admin/user/{user_id}/delete-songs')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── DSP delivery status & actions ────────────────────────────────────────────

@bp.route('/api/fadmin/ddex-status')
def fadmin_ddex_status():
    """
    DDEX delivery checkup for one ISRC — the same four channel states the
    web admin's DDEX tab ("Single ISRC Delivery") shows, surfaced inside
    Overlord instead of a separate tab. **User asked for exactly this
    shape**: "we need to implement an ISRC DDEX checkup ... not ... a
    separate tab like we have it in admin, but ... a collapsible block
    inside each Individual Search".

    No dedicated lookup endpoint exists in the admin API for this (probed
    several /api/admin/ddex/* candidates live, all 404) — but the artist
    profile's songs[] entries carry the four flags directly:
    tuned_global_delivered (the DDEX tab's "Label Grid" row),
    boomplay_delivered, youtube_delivery_status, nuemeta_delivery_status.
    Confirmed live against the exact ISRC from the user's screenshot: all
    four states matched the web tab 1:1. So: moderation-search the ISRC →
    load the artist profile → pluck the matching song's flags.
    """
    isrc = request.args.get('isrc', '').strip()
    if not isrc:
        return jsonify({'error': 'isrc required'}), 400

    sr, err = _api('GET', '/api/admin/moderation/search', params={'q': isrc})
    if err:
        return jsonify({'error': err}), 503
    results = (sr or {}).get('results', [])
    match = next((r for r in results
                  if (r.get('metadata', {}).get('isrc') or '').strip().upper() == isrc.upper()
                  and r.get('artist_id')), None)
    if not match:
        return jsonify({'found': False})

    profile, err = _api('GET', f'/api/admin/user/{match["artist_id"]}')
    if err:
        return jsonify({'error': err}), 503
    song = next((s for s in (profile or {}).get('songs', [])
                 if (s.get('isrc') or '').strip().upper() == isrc.upper()), None)
    if not song:
        return jsonify({'found': False})

    return jsonify({
        'found': True,
        'name': song.get('name'),
        'upc': song.get('upc_code'),
        'audio_available': bool(song.get('song_file_url')),
        'label_grid_delivered': bool(song.get('tuned_global_delivered')),
        'boomplay_delivered': bool(song.get('boomplay_delivered')),
        'youtube_status': song.get('youtube_delivery_status') or 'not_sent',
        'nuemeta_status': song.get('nuemeta_delivery_status') or 'not_sent',
        'song_id': song.get('id'),
    })


@bp.route('/api/fadmin/song-dsp-deliveries')
def fadmin_song_dsp_deliveries():
    song_id = (request.args.get('songId') or '').strip()
    if not song_id:
        return jsonify({'error': 'songId required'}), 400
    data, err = _api('GET', f'/api/admin/song/{song_id}/dsp-deliveries')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/song-redeliver-store', methods=['POST'])
def fadmin_song_redeliver_store():
    """Confirmed live (2026-09-08, deliberate one-off test against a real
    song on a real DSP, explicitly authorized and scoped by the user to a
    disposable test account/song/store): this remote endpoint has no
    per-store takedown capability. Passing an extra `deliveryType: 'TakeDown'`
    field is silently ignored — the call still just performs a normal
    redelivery (confirmed: the delivery's status became 'redelivery_sent',
    not anything takedown-related). A per-store Takedown button is not
    buildable against this endpoint as it exists today; only the song-wide
    Takedown (fadmin_song_takedown below, a different remote endpoint) is
    real. Do not re-add a deliveryType passthrough here without a genuinely
    new remote endpoint to point it at.
    """
    body        = request.get_json(force=True) or {}
    song_id     = (body.get('songId') or '').strip()
    delivery_id = (body.get('deliveryId') or '').strip()
    if not song_id or not delivery_id:
        return jsonify({'error': 'songId and deliveryId required'}), 400
    data, err = _api('POST', '/api/admin/ddex/deliver-nuemeta-store',
                     json={'songId': song_id, 'deliveryId': delivery_id})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/song-takedown', methods=['POST'])
def fadmin_song_takedown():
    body    = request.get_json(force=True) or {}
    song_id = (body.get('songId') or '').strip()
    if not song_id:
        return jsonify({'error': 'songId required'}), 400
    data, err, flip_err = _takedown_song(song_id)
    if err:
        return jsonify({'error': err}), 503
    if flip_err:
        data['status_flip_error'] = flip_err
    return jsonify(data)


# Freecords' own web admin has a "Nuemeta Actions" dropdown (Re-deliver All,
# Full Update, Metadata Update, Takedown) that Moderation never had — only
# single-store Re-send (song-redeliver-store above) and Takedown existed
# here. Same underlying endpoint as Takedown, just a different
# deliveryType. Confirmed live via a deliberate validation-error probe
# (invalid deliveryType + a fake songId, so nothing real ever ran) the
# accepted enum: InitialDelivery, FullUpdate, MetadataOnlyUpdate, TakeDown.
# Takedown keeps its own dedicated route above (existing confirm-overlay
# flow depends on it); this covers the three that were missing.
_NUEMETA_DELIVERY_TYPES = {'InitialDelivery', 'FullUpdate', 'MetadataOnlyUpdate', 'TakeDown'}

@bp.route('/api/fadmin/song-dsp-action', methods=['POST'])
def fadmin_song_dsp_action():
    body          = request.get_json(force=True) or {}
    song_id       = (body.get('songId') or '').strip()
    delivery_type = (body.get('deliveryType') or '').strip()
    if not song_id:
        return jsonify({'error': 'songId required'}), 400
    if delivery_type not in _NUEMETA_DELIVERY_TYPES:
        return jsonify({'error': f'deliveryType must be one of: {", ".join(sorted(_NUEMETA_DELIVERY_TYPES))}'}), 400
    if delivery_type == 'TakeDown':
        data, err, flip_err = _takedown_song(song_id)   # also flips the status - see _takedown_song
        if err:
            return jsonify({'error': err}), 503
        if flip_err:
            data['status_flip_error'] = flip_err
        return jsonify(data)
    data, err = _api('POST', '/api/admin/ddex/nuemeta-dsp-action',
                     json={'songId': song_id, 'deliveryType': delivery_type})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/song-delete', methods=['DELETE', 'POST'])
def fadmin_song_delete():
    """
    Deletes a single song — distinct from fadmin_delete_songs above, which
    nukes every song a user has. Needed for songs that were never actually
    distributed (still Pending/Needs Action): "Takedown" issues a real DDEX
    takedown against DSPs, which is meaningless for a song that was never
    delivered anywhere — those need a plain delete instead.

    `DELETE /api/admin/song/{songId}/delete` (per
    ~/Downloads/OVERLORD_ADMIN_API_GUIDE.md) — no body, moves the song to
    removed songs (soft delete, not a hard delete). Response:
    `{"song": {"name": "..."}}`.
    """
    body    = request.get_json(force=True) or {}
    song_id = (body.get('songId') or '').strip()
    if not song_id:
        return jsonify({'error': 'songId required'}), 400
    data, err = _api('DELETE', f'/api/admin/song/{song_id}/delete')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── Documents ──────────────────────────────────────────────────────────────────

@bp.route('/api/fadmin/docs', methods=['GET'])
def fadmin_docs_list():
    user_id = request.args.get('user_id', '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    data, err = _api('GET', f'/api/admin/user/{user_id}/docs')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {'song': [], 'identity': [], 'other': []})


@bp.route('/api/fadmin/docs', methods=['POST'])
def fadmin_docs_upload():
    user_id = request.form.get('user_id', '').strip()
    category = request.form.get('category', '').strip()
    if not user_id or not category:
        return jsonify({'error': 'user_id and category required'}), 400
    if 'file' not in request.files:
        return jsonify({'error': 'file required'}), 400

    f = request.files['file']
    form = {'category': category}
    song_id = request.form.get('song_id', '').strip()
    label = request.form.get('label', '').strip()
    if song_id:
        form['songId'] = song_id
    if label:
        form['label'] = label

    data, err = _api(
        'POST', f'/api/admin/user/{user_id}/docs',
        timeout=30,
        data=form,
        files={'file': (f.filename, f.stream, f.mimetype)},
    )
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# Shared cap for every route that fetches a remote URL server-side and hands
# it back (download-to-disk, inline preview, import-into-docs) — raised from
# 10MB to 100MB **user, directly**: "it should be up to 100 mb or whatever
# is our upload limit", after the Moderation per-track download button hit
# this on a full-quality WAV master. Distinct from MAX_ATTACHMENTS_BYTES
# below (25MB) — that one caps outbound ticket-reply attachments, a
# different resource-cost tradeoff (send once vs. store+deliver to
# recipients) and not the same limit despite the similar name.
DOWNLOAD_FETCH_MAX_BYTES = 100 * 1024 * 1024


@bp.route('/api/fadmin/download-file', methods=['POST'])
def fadmin_download_file():
    """
    Save a signed URL (a CRM attachment, a profile doc, etc.) to the user's
    Downloads folder — server-side, not via the browser. Overlord's desktop
    window is a WKWebView, which does not reliably honor the HTML5 `download`
    attribute even for blob: URLs — clicking a download link just displays
    the file inline in the window with no way back (no browser chrome, no
    tab to close). Doing the fetch in Python and writing straight to disk
    sidesteps the webview entirely.
    """
    body = request.get_json(force=True) or {}
    url = (body.get('url') or '').strip()
    filename = (body.get('filename') or 'download').strip()
    save_path = (body.get('save_path') or '').strip()  # set only on Windows, via a real Save As dialog
    if not _url_is_fetchable(url):
        return jsonify({'error': 'url must be https'}), 400

    try:
        # 60s, up from 20s — a 100MB file (this route's own new cap, raised
        # from 10MB for the Moderation per-track download button) can
        # genuinely take longer than 20s on an ordinary connection.
        resp = http.get(url, timeout=60)
        resp.raise_for_status()
    except Exception as e:
        return jsonify({'error': f'could not fetch file: {e}'}), 502

    if len(resp.content) > DOWNLOAD_FETCH_MAX_BYTES:
        return jsonify({'error': f'file exceeds {DOWNLOAD_FETCH_MAX_BYTES // (1024 * 1024)}MB limit'}), 400

    if save_path:
        dest = Path(save_path)
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(resp.content)
        except Exception as e:
            return jsonify({'error': f'could not save file: {e}'}), 500
        return jsonify({'success': True, 'path': str(dest), 'filename': dest.name})

    safe_name = re.sub(r'[/\\:*?"<>|]', '_', filename) or 'download'
    downloads = Path.home() / 'Downloads'
    dest = downloads / safe_name
    stem, suffix = dest.stem, dest.suffix
    n = 1
    while dest.exists():
        dest = downloads / f'{stem} ({n}){suffix}'
        n += 1

    try:
        dest.write_bytes(resp.content)
    except Exception as e:
        return jsonify({'error': f'could not save file: {e}'}), 500

    # The download itself is otherwise completely silent — no browser download
    # bar, no in-app toast — so a successful save looked identical to nothing
    # happening at all. Revealing it in Finder is the standard macOS signal
    # that a download actually landed.
    if sys.platform == 'darwin':
        try:
            subprocess.run(['open', '-R', str(dest)], timeout=5)
        except Exception:
            pass

    return jsonify({'success': True, 'path': str(dest), 'filename': dest.name})


@bp.route('/api/fadmin/tickets/export', methods=['POST'])
def fadmin_tickets_export():
    """
    Save a bulk selection of tickets to Downloads as a single JSON file —
    picked over wiring tickets into the personal-email "Send to Claude"
    bulk flow, which is hardcoded to the IMAP message_cache shape (uid/
    folder/account) and has no equivalent for ticket data. A plain JSON
    export is simpler and doesn't need a fake tier system.

    Body: { tickets: [ {...} ] } — whatever ticket fields the frontend
    already has loaded (no extra per-ticket fetch needed).
    """
    body = request.get_json(force=True) or {}
    tickets = body.get('tickets') or []
    if not tickets:
        return jsonify({'error': 'no tickets selected'}), 400

    import json as _json
    from datetime import datetime as _dt

    downloads = Path.home() / 'Downloads'
    stamp = _dt.now().strftime('%Y-%m-%d_%H%M%S')
    dest = downloads / f'tickets-export-{stamp}.json'
    n = 1
    while dest.exists():
        dest = downloads / f'tickets-export-{stamp} ({n}).json'
        n += 1

    try:
        dest.write_text(_json.dumps(tickets, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception as e:
        return jsonify({'error': f'could not save file: {e}'}), 500

    if sys.platform == 'darwin':
        try:
            subprocess.run(['open', '-R', str(dest)], timeout=5)
        except Exception:
            pass

    return jsonify({'success': True, 'path': str(dest), 'filename': dest.name, 'count': len(tickets)})


TICKET_BULK_MAX = 300  # was 30 — raised now that progress is visible instead of one blind blocking request

_bulk_classify_status = {'state': 'idle', 'phase': '', 'checked': 0, 'total': 0, 'results': [], 'error': None, 'cancelled': False}
_bulk_classify_lock = threading.Lock()


def _run_fadmin_bulk_classify(ticket_ids, instruction):
    # Whole body wrapped in try/except — same fix as freshdesk.py's
    # _run_bulk_classify: an exception thrown anywhere before the final
    # status update otherwise kills this background thread silently,
    # leaving the frontend's poll loop spinning on state='running' forever
    # with no error ever surfacing (confirmed live: classify_and_draft's
    # `import anthropic` failing when the package wasn't installed did
    # exactly this).
    try:
        from concurrent.futures import ThreadPoolExecutor

        def fetch_one(tid):
            data, err = _api('GET', f'/api/admin/tickets/{tid}')
            with _bulk_classify_lock:
                _bulk_classify_status['checked'] += 1
            return tid, data, err

        tickets = []
        with ThreadPoolExecutor(max_workers=4) as pool:
            for tid, data, err in pool.map(fetch_one, ticket_ids):
                if err or not data:
                    continue
                t = data.get('ticket') or {}
                messages = data.get('messages') or []
                # Full thread text, not just the ticket's own fields — a
                # classification like "confirmed takedown with ISRC info" is
                # as likely to be in a reply as in the original message.
                convo = '\n'.join(
                    f"{m.get('from_email', '?')}: {(m.get('body') or '').strip()[:1500]}"
                    for m in messages
                )
                tickets.append({
                    'id': t.get('id') or tid,
                    'subject': t.get('subject', ''),
                    'tags': t.get('tags') or [],
                    'description': convo.strip(),
                })

        with _bulk_classify_lock:
            _bulk_classify_status.update(phase='classifying', checked=0, total=len(tickets))

        def on_progress(done):
            with _bulk_classify_lock:
                _bulk_classify_status['checked'] = done

        def should_cancel():
            with _bulk_classify_lock:
                return _bulk_classify_status['cancelled']

        results, err = classify_and_draft(tickets, instruction, on_progress=on_progress, should_cancel=should_cancel)
        if err and err != CANCELLED_CODE:
            with _bulk_classify_lock:
                _bulk_classify_status['state'] = 'done'
                _bulk_classify_status['results'] = []
                _bulk_classify_status['error'] = err
            return
        if err == CANCELLED_CODE:
            # Cancelled mid-classify — whatever's been classified so far is
            # real and worth keeping, it just never got a distribution
            # check. Skip resolve_buckets entirely and finish now rather
            # than starting a second phase the user already asked to stop.
            for r in results:
                r['bucket'] = 'not_relevant' if not r.get('qualifies') else 'manual_resolution'
                if r['bucket'] == 'manual_resolution':
                    r['reasoning'] = (r.get('reasoning') or '').rstrip('.') + '. Cancelled before the distribution check ran for this ticket.'
            with _bulk_classify_lock:
                _bulk_classify_status['state'] = 'done'
                _bulk_classify_status['results'] = results
                _bulk_classify_status['error'] = None
            return

        with _bulk_classify_lock:
            _bulk_classify_status.update(phase='resolving_distribution', checked=0, total=len(results))

        def on_bucket_progress(done):
            with _bulk_classify_lock:
                _bulk_classify_status['checked'] = done

        resolve_buckets(results, on_progress=on_bucket_progress, should_cancel=should_cancel)
        with _bulk_classify_lock:
            _bulk_classify_status['state'] = 'done'
            _bulk_classify_status['results'] = results
            _bulk_classify_status['error'] = None
    except Exception as e:
        with _bulk_classify_lock:
            _bulk_classify_status['state'] = 'done'
            _bulk_classify_status['results'] = []
            _bulk_classify_status['error'] = str(e)


@bp.route('/api/fadmin/tickets/bulk-claude-classify', methods=['POST'])
def fadmin_tickets_bulk_claude_classify():
    """
    Native-CRM equivalent of freshdesk.py's bulk-claude-classify — same
    background-thread-with-pollable-progress pattern, fetching each
    ticket's full conversation thread (not just its own fields) before
    batching through claude_bulk_classify.classify_and_draft.

    Body: {ticket_ids: [...], instruction: str}
    """
    body = request.get_json(force=True) or {}
    ticket_ids = [str(i) for i in (body.get('ticket_ids') or [])]
    instruction = (body.get('instruction') or '').strip()
    if not ticket_ids:
        return jsonify({'error': 'no tickets selected'}), 400
    if not instruction:
        return jsonify({'error': 'instruction required'}), 400
    if len(ticket_ids) > TICKET_BULK_MAX:
        return jsonify({'error': f'too many tickets selected ({len(ticket_ids)} > {TICKET_BULK_MAX} limit)'}), 400

    with _bulk_classify_lock:
        if _bulk_classify_status['state'] == 'running':
            return jsonify({'error': 'a classification run is already in progress'}), 409
        _bulk_classify_status.update(state='running', phase='fetching', checked=0, total=len(ticket_ids), results=[], error=None, cancelled=False)

    threading.Thread(target=_run_fadmin_bulk_classify, args=(ticket_ids, instruction), daemon=True).start()
    return jsonify({'ok': True, 'started': True})


@bp.route('/api/fadmin/tickets/bulk-claude-classify/cancel', methods=['POST'])
def fadmin_tickets_bulk_claude_classify_cancel():
    with _bulk_classify_lock:
        if _bulk_classify_status['state'] != 'running':
            return jsonify({'ok': True, 'already_stopped': True})
        _bulk_classify_status['cancelled'] = True
    return jsonify({'ok': True})


@bp.route('/api/fadmin/tickets/bulk-claude-classify/status')
def fadmin_tickets_bulk_claude_classify_status():
    with _bulk_classify_lock:
        return jsonify(dict(_bulk_classify_status))


_bulk_reply_status = {'state': 'idle', 'checked': 0, 'total': 0, 'errors': [], 'error': None}
_bulk_reply_lock = threading.Lock()


def _run_fadmin_bulk_reply(items, close_after):
    """Native-CRM mirror of freshdesk.py's _run_bulk_reply — see its
    docstring. Sequential, not threaded, for the same reason: real
    customer-facing mail, one bad request shouldn't race a retry-worthy
    failure on another."""
    errors = []
    for item in items:
        tid = item['ticket_id']
        _, err = _api('POST', f'/api/admin/tickets/{tid}/reply', json={'body': item['body']})
        if err:
            errors.append({'ticket_id': tid, 'error': err})
        elif close_after:
            _api('PATCH', f'/api/admin/tickets/{tid}', json={'status': 'closed'})
        with _bulk_reply_lock:
            _bulk_reply_status['checked'] += 1
            _bulk_reply_status['errors'] = errors
    with _bulk_reply_lock:
        _bulk_reply_status['state'] = 'done'


@bp.route('/api/fadmin/tickets/bulk-reply', methods=['POST'])
def fadmin_tickets_bulk_reply():
    """Native-CRM mirror of freshdesk.py's /api/freshdesk/tickets/bulk-reply.
    Body: {items: [{ticket_id, body}], close_after: bool}"""
    body = request.get_json(force=True) or {}
    items = body.get('items') or []
    if not items:
        return jsonify({'error': 'no tickets selected'}), 400
    if len(items) > TICKET_BULK_MAX:
        return jsonify({'error': f'Too many tickets selected ({len(items)} > {TICKET_BULK_MAX} limit)'}), 400
    close_after = bool(body.get('close_after', False))

    with _bulk_reply_lock:
        if _bulk_reply_status['state'] == 'running':
            return jsonify({'error': 'a bulk reply is already running'}), 409
        _bulk_reply_status.update(state='running', checked=0, total=len(items), errors=[], error=None)

    threading.Thread(target=_run_fadmin_bulk_reply, args=(items, close_after), daemon=True).start()
    return jsonify({'ok': True, 'started': True})


@bp.route('/api/fadmin/tickets/bulk-reply/status')
def fadmin_tickets_bulk_reply_status():
    with _bulk_reply_lock:
        return jsonify(dict(_bulk_reply_status))


@bp.route('/api/fadmin/tickets/suggest-instructions', methods=['POST'])
def fadmin_tickets_suggest_instructions():
    """
    Native-CRM equivalent of freshdesk.py's suggest-instructions. Body:
    {tag: str, subjects: [str, ...]}
    """
    body = request.get_json(force=True) or {}
    tag = body.get('tag', '')
    subjects = body.get('subjects') or []
    suggestions, err = suggest_instructions(tag, subjects)
    if err:
        return jsonify({'error': err}), 502
    return jsonify({'suggestions': suggestions})


@bp.route('/api/fadmin/preview-file', methods=['POST'])
def fadmin_preview_file():
    """
    Fetch a signed attachment URL server-side and return the raw bytes so the
    frontend can preview it in a modal (blob URL) instead of downloading it —
    clicking an attachment to look at it shouldn't silently drop a file in
    Downloads every time. Many of these signed URLs (S3, Freshdesk) aren't
    reliably fetchable cross-origin straight from the browser, so this mirrors
    /api/fadmin/download-file's server-side fetch rather than adding a new
    fetch path.
    """
    body = request.get_json(force=True) or {}
    url = (body.get('url') or '').strip()
    if not _url_is_fetchable(url):
        return jsonify({'error': 'url must be https'}), 400

    try:
        resp = http.get(url, timeout=60)  # see download-file's own comment on the 60s bump
        resp.raise_for_status()
    except Exception as e:
        return jsonify({'error': f'could not fetch file: {e}'}), 502

    if len(resp.content) > DOWNLOAD_FETCH_MAX_BYTES:
        return jsonify({'error': f'file exceeds {DOWNLOAD_FETCH_MAX_BYTES // (1024 * 1024)}MB limit'}), 400

    content_type = resp.headers.get('Content-Type', 'application/octet-stream')
    return Response(resp.content, mimetype=content_type)


@bp.route('/api/fadmin/preview-file-table', methods=['POST'])
def fadmin_preview_file_table():
    """
    URL-based sibling of messages.py's /api/messages/<uid>/attachment/table —
    same inline xlsx/docx preview, but for CRM attachments (a signed URL)
    instead of an IMAP-fetched email attachment. Parsing logic lives in
    helpers.py so both blueprints share it without importing each other.
    """
    body = request.get_json(force=True) or {}
    url = (body.get('url') or '').strip()
    filename = (body.get('filename') or '').strip()
    if not _url_is_fetchable(url):
        return jsonify({'error': 'url must be https'}), 400

    try:
        resp = http.get(url, timeout=20)
        resp.raise_for_status()
    except Exception as e:
        return jsonify({'error': f'could not fetch file: {e}'}), 502

    if len(resp.content) > 15 * 1024 * 1024:
        return jsonify({'error': 'file too large to preview'}), 400

    ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
    try:
        if ext in ('xlsx', 'xlsm'):
            return jsonify(render_xlsx_table(resp.content))
        elif ext == 'docx':
            return jsonify(render_docx_table(resp.content))
        else:
            return jsonify({'error': 'unsupported file type for inline preview'}), 400
    except Exception as e:
        return jsonify({'error': f'could not parse file: {e}'}), 500


@bp.route('/api/fadmin/docs/from-url', methods=['POST'])
def fadmin_docs_from_url():
    """
    Attach a document already sitting in the CRM (a ticket attachment) to the
    artist's Freecords profile — downloads it server-side from wherever it's
    hosted (Freshdesk's signed URL, etc.) and re-uploads it through the same
    admin docs endpoint, so the browser never has to touch the file or deal
    with a third-party host's CORS policy.
    """
    body = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    category = (body.get('category') or '').strip()
    source_url = (body.get('source_url') or '').strip()
    filename = (body.get('filename') or 'attachment').strip()
    song_id = (body.get('song_id') or '').strip()
    label = (body.get('label') or '').strip()

    if not user_id or not category or not source_url:
        return jsonify({'error': 'user_id, category and source_url required'}), 400
    if not _url_is_fetchable(source_url):
        return jsonify({'error': 'source_url must be https'}), 400

    try:
        src = http.get(source_url, timeout=60)  # see download-file's own comment on the 60s bump
        src.raise_for_status()
    except Exception as e:
        return jsonify({'error': f'could not fetch attachment: {e}'}), 502

    if len(src.content) > DOWNLOAD_FETCH_MAX_BYTES:
        return jsonify({'error': f'file exceeds {DOWNLOAD_FETCH_MAX_BYTES // (1024 * 1024)}MB limit'}), 400

    form = {'category': category}
    if song_id:
        form['songId'] = song_id
    if label:
        form['label'] = label

    # Freecords' profile-DOCS endpoint takes ONE PDF/JPEG/PNG/GIF/WebP (max 10MB) and rejects
    # everything else ("Only PDF and image files are allowed" for a .zip). **Nik** built the
    # any-file-type route for exactly this - "I specifically made you the endpoint which uploads
    # everything" (support.attachments: presign-upload -> PUT -> confirm). So anything that is
    # not a PDF/image goes there, tied to the user, and is listed by /api/fadmin/user-attachments.
    if os.path.splitext(filename)[1].lower() not in _PROFILE_DOC_TYPES:
        att, aerr = _upload_attachment(filename, src.headers.get('Content-Type', '').split(';')[0], src.content, user_id=user_id)
        if aerr:
            return jsonify({'error': aerr}), 503
        return jsonify({'ok': True, 'stored_as': 'attachment', 'attachment': att})

    mime = src.headers.get('Content-Type', 'application/octet-stream').split(';')[0]
    data, err = _api(
        'POST', f'/api/admin/user/{user_id}/docs',
        timeout=30,
        data=form,
        files={'file': (filename, src.content, mime)},
    )
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


_PROFILE_DOC_TYPES = {
    '.pdf': 'application/pdf', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
    '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp',
}


def _upload_attachment(filename, content_type, data, user_id=None, ticket_id=None):
    """Nik's support.attachments flow (any file type): presign-upload (needs ticketId and/or
    userId) -> PUT the bytes to the signed Spaces URL -> confirm. Returns (attachment, error)."""
    import mimetypes
    ctype = (content_type or '').strip() or mimetypes.guess_type(filename)[0] or 'application/octet-stream'
    # fileSize is declared so the 1GB cap is checked up front (the signed URL itself enforces none);
    # the PUT below must send the SAME Content-Type that is signed into the URL here.
    body = {'filename': filename, 'contentType': ctype, 'fileSize': len(data)}
    if ticket_id:
        body['ticketId'] = ticket_id
    if user_id:
        body['userId'] = user_id
    pre, err = _api('POST', '/api/admin/attachments/presign-upload', json=body)
    if err or not pre or not pre.get('uploadUrl'):
        return None, err or 'storage did not return an upload address'
    try:
        put = http.put(pre['uploadUrl'], data=data, headers={'Content-Type': ctype}, timeout=300)
    except Exception as e:
        return None, f'upload to storage failed: {e}'
    if put.status_code not in (200, 204):
        return None, f'upload to storage failed (HTTP {put.status_code})'
    conf, err = _api('POST', '/api/admin/attachments/confirm', json={'key': pre['key']})
    if err:
        return None, err
    return (conf or {}).get('attachment') or {}, None


@bp.route('/api/fadmin/user-attachments')
def fadmin_user_attachments():
    """Files attached directly to an account through the any-file-type route."""
    user_id = (request.args.get('user_id') or '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    d, err = _api('GET', f'/api/admin/user/{user_id}/attachments')
    if err:
        return jsonify({'error': err}), 503
    return jsonify({'attachments': [_attachment_row(a) for a in (d or {}).get('attachments', [])]})


def _attachment_row(a):
    return {
        'id': a.get('id'), 'name': a.get('original_filename'), 'content_type': a.get('content_type'),
        'size': int(a['size_bytes']) if str(a.get('size_bytes') or '').isdigit() else None,
        'uploaded_by': a.get('uploaded_by'), 'created_at': a.get('created_at'),
        'attachment_url': f"{request.host_url.rstrip('/')}/api/fadmin/attachment-file?key={urllib.parse.quote(a.get('key') or '')}",
    }


@bp.route('/api/fadmin/attachment-file')
def fadmin_attachment_file():
    """Streams a stored attachment (presign-download, then fetched server-side so the in-app
    previewer and downloads never touch the storage host's CORS rules)."""
    key = (request.args.get('key') or '').strip()
    if not key:
        return jsonify({'error': 'key required'}), 400
    pre, err = _api('POST', '/api/admin/attachments/presign-download', json={'key': key})
    if err or not pre or not pre.get('downloadUrl'):
        return jsonify({'error': err or 'no download address'}), 503
    try:
        r = http.get(pre['downloadUrl'], timeout=120)
        r.raise_for_status()
    except Exception as e:
        return jsonify({'error': f'could not fetch the file: {e}'}), 502
    name = (pre.get('filename') or 'file').replace('\r', '').replace('\n', '').replace('"', "'")
    return Response(r.content, headers={
        'Content-Type': pre.get('contentType') or 'application/octet-stream',
        'Content-Disposition': f'attachment; filename="{name}"',
    })


@bp.route('/api/fadmin/docs', methods=['DELETE'])
def fadmin_docs_delete():
    body = request.get_json(force=True) or {}
    user_id = (body.get('user_id') or '').strip()
    doc_id = (body.get('doc_id') or '').strip()
    if not user_id or not doc_id:
        return jsonify({'error': 'user_id and doc_id required'}), 400
    data, err = _api('DELETE', f'/api/admin/user/{user_id}/docs', params={'docId': doc_id})
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


# ── Native CRM — Tickets ──────────────────────────────────────────────────────

def _sort_native_tickets_by_date(results, order):
    """Same rationale as freshdesk.py's _sort_tickets_by_date: sort in
    Overlord's own backend rather than trusting an upstream sort param
    Freecords' own admin API doesn't document at all. ISO 8601 strings
    sort correctly as plain strings. order='asc' = oldest first,
    anything else (including missing/'desc') = newest first."""
    return sorted(results, key=lambda t: t.get('created_at') or '', reverse=(order != 'asc'))


@bp.route('/api/fadmin/tickets', methods=['GET'])
def fadmin_tickets_list():
    """
    Was: fetch one native page, sort only that page. Freecords' own admin
    API documents no sort/order param at all (_sort_native_tickets_by_date's
    own docstring), so "page 1" under "Oldest first" showed the oldest of
    whichever ~100 tickets happened to be on Freecords' own page 1 — not
    genuinely old tickets. Worse than the equivalent Freshdesk bug this
    mirrors (freshdesk.py's list_tickets): wrong even on page 1, and wrong
    on every status view, since none of them carry an upstream order.
    **User, directly**: "why do we need Nik to do something in the API if
    we are building a CRM ourselves on top of a mail inbox" — right that
    this doesn't need a platform change, just applying the same
    fetch-full-set-then-sort-then-slice pattern _fadmin_tickets_untagged
    and fadmin_tickets_tag_counts already use elsewhere in this file, to
    the one route that actually powers the ticket list.

    Bounded to MAX_PAGES (same cap this file already uses for those other
    two routes) rather than an unconditional full scan — Freecords' own
    `total` is a real, accurate count (confirmed live: no cap/drift like
    Freshdesk's unreliable Search API total), but "All Tickets" with no
    status filter can be tens of thousands of rows; scanning all of it on
    every list-view request isn't a reasonable per-request cost. Sort
    correctness is exact up to the cap, same known tradeoff as every other
    bounded scan in this file — `capped` in the response says when that
    ceiling was actually hit, no silent truncation.
    """
    params = {k: v for k, v in request.args.items()}
    order = params.pop('order', 'desc')
    if params.get('tag') == '__untagged__':
        return _fadmin_tickets_untagged(params, order)
    if params.get('sent') == '1':
        return _fadmin_tickets_sent(params, order)
    if params.get('status') == 'closed' and params.get('date_from'):
        return _fadmin_tickets_closed_since(params, order)
    if params.get('history') == '1':
        return _fadmin_tickets_history(params, order)
    try:
        page = int(params.get('page', 1))
        limit = int(params.get('limit', 30))
    except ValueError:
        page, limit = 1, 30
    upstream_params = {k: v for k, v in params.items() if k not in ('page', 'limit')}

    # "Closed" means closed — **user, directly**: "there is no Resolved
    # category anywhere and I specifically told you I am against it. All
    # resolved = closed. They are the same thing." Freecords' status field
    # disagrees (a real, separate 'resolved' value the platform sets on its
    # own — confirmed live, ~90 tickets, no OR-status support on this
    # endpoint to ask for both at once), so a plain status=closed filter
    # was silently missing every resolved ticket, not just displaying them
    # with the wrong label. Whenever closed is asked for, fetch resolved
    # too and merge — same shape either way from here on, no special case
    # for the caller.
    statuses = ['closed', 'resolved'] if upstream_params.get('status') == 'closed' else [upstream_params.get('status', '')]

    all_tickets, total, capped = [], 0, False
    errors = []
    for status in statuses:
        s_params = dict(upstream_params)
        if status:
            s_params['status'] = status
        elif 'status' in s_params:
            del s_params['status']
        tickets, s_total, s_capped, s_err = _fetch_all_matching_tickets(s_params)
        all_tickets.extend(tickets)
        total += s_total
        capped = capped or s_capped
        if s_err:
            errors.append(s_err)

    # A genuine fetch failure (session expired, connection error, etc.) on
    # page 1 previously came back as `capped: True` with an empty tickets
    # array — indistinguishable from "this view genuinely has zero
    # tickets". **User-reported, live screenshot (2026-09-24)**: Open
    # showed "0 tickets" / "No tickets found" with zero indication the
    # connection had actually failed (token had expired). Only treat this
    # as a real error when every status attempted actually failed — a
    # partial failure (e.g. 'closed' succeeded but 'resolved' didn't in
    # the merge above) still has real tickets to show, same as a
    # mid-pagination page failure already does via `capped`.
    if errors and len(errors) == len(statuses) and not all_tickets:
        return jsonify({'error': errors[0]}), 503

    all_tickets = _sort_native_tickets_by_date(all_tickets, order)
    start = (page - 1) * limit
    return jsonify({
        'tickets': all_tickets[start:start + limit],
        'pagination': {'total': total, 'page': page, 'limit': limit, 'capped': capped},
    })


def _fetch_all_matching_tickets(upstream_params):
    """Bounded, paginated, parallel fetch of every ticket matching
    upstream_params — pulled out of fadmin_tickets_list so a caller that
    needs to merge two distinct status values (see the Resolved==Closed
    merge above) can run this once per status instead of duplicating the
    pagination logic. Returns (tickets, total, capped, error) — same
    MAX_PAGES/concurrency shape as before this was split out; `error` is
    new (was silently discarded before — see fadmin_tickets_list's own
    comment on why that mattered), None unless page 1 itself failed.
    """
    # Page 1 first and alone — `total` (needed to know how many more pages
    # even exist) isn't known until this response comes back, so it can't
    # be parallelized with the rest.
    MAX_PAGES = 40
    data, err = _api('GET', '/api/admin/tickets', params={**upstream_params, 'page': 1, 'limit': 100})
    if err or not data:
        return [], 0, True, (err or 'Failed to load tickets')
    all_tickets = list(data.get('tickets', []))
    total = data.get('pagination', {}).get('total', 0)
    pages_needed = min(MAX_PAGES, -(-total // 100))  # ceil(total / 100)
    capped = pages_needed >= MAX_PAGES and total > MAX_PAGES * 100

    # Was sequential (page 2, wait, page 3, wait, ...) — up to 39 more
    # round-trips, one at a time, confirmed live to take 7+ seconds for a
    # single list-view request on a view with a few thousand matching
    # tickets. **User, directly**: "nothing can load slowly, this is a
    # native CRM." Fetched concurrently instead, same
    # ThreadPoolExecutor pattern already used elsewhere in this file for
    # requester-attachments. Capped at 8 workers — this API has real,
    # confirmed rate-limit sensitivity to request bursts (see _api()'s own
    # docstring), unbounded parallelism would trade one problem for another.
    if pages_needed > 1:
        import concurrent.futures
        def _fetch_page(p):
            d, e = _api('GET', '/api/admin/tickets', params={**upstream_params, 'page': p, 'limit': 100})
            return p, d, e
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(_fetch_page, range(2, pages_needed + 1)))
        for p, d, e in sorted(results, key=lambda r: r[0]):
            if e or not d:
                capped = True  # a page failed — the sorted result is incomplete, same signal as hitting MAX_PAGES
                continue
            all_tickets.extend(d.get('tickets', []))

    return all_tickets, total, capped, None


def _fadmin_tickets_closed_since(params, order='desc'):
    """
    "Closed" view + a date filter: must mean "closed in this window", not
    "created in this window and currently closed" — Freecords' API has no
    close/update-time filter at all, and scanning the entire closed-ticket
    catalog to fake one client-side (an earlier version of this fix) still
    came back `capped` short of the real total even at a 150-page/15,000-
    ticket scan, several seconds slower on top of that.

    **User, directly**: "why the fuck would we need any of the things you
    said [...] we are building a CRM ourselves on top of a mail inbox" —
    right: every close action already goes through this app's own single
    PATCH proxy (fadmin_ticket_patch), which now records the real moment
    locally in ticket_closed_at the instant it happens. This is an exact,
    instant local lookup instead of a remote guess — no scanning, no cap,
    no dependency on Freecords adding anything.

    Tickets closed before ticket_closed_at existed (2026-09-08) have no
    row here and won't appear in this view for old windows — a real,
    accepted gap for history predating this fix, not a bug in it.
    """
    import concurrent.futures
    date_from = params.get('date_from', '')
    try:
        page = int(params.get('page', 1))
        limit = int(params.get('limit', 30))
    except ValueError:
        page, limit = 1, 30

    conn = get_db()
    rows = conn.execute(
        "SELECT ticket_number, closed_at FROM ticket_closed_at WHERE closed_at >= ? ORDER BY closed_at "
        + ("ASC" if order == 'asc' else "DESC"),
        (date_from,),
    ).fetchall()
    closed_at_by_number = {r['ticket_number']: r['closed_at'] for r in rows}
    if not closed_at_by_number:
        conn.close()
        return jsonify({'tickets': [], 'pagination': {'total': 0, 'page': page, 'limit': limit, 'capped': False}})

    placeholders = ','.join('?' * len(closed_at_by_number))
    uuid_by_number = {
        r['ticket_number']: r['native_id']
        for r in conn.execute(
            f"SELECT ticket_number, native_id FROM native_ticket_index WHERE ticket_number IN ({placeholders})",
            list(closed_at_by_number),
        ).fetchall()
    }
    conn.close()

    # Same concurrent-fetch pattern already used by _fadmin_tickets_sent for
    # an identical shape of problem (a handful of known ticket_numbers whose
    # UUIDs are already known, needing the real ticket object each).
    def _fetch_one(num):
        uuid = uuid_by_number.get(num)
        if not uuid:
            return num, None
        data, err = _api('GET', f'/api/admin/tickets/{uuid}')
        if err or not data or not data.get('ticket'):
            return num, None
        return num, data['ticket']

    tickets_by_number = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for num, ticket in pool.map(_fetch_one, closed_at_by_number):
            if ticket:
                tickets_by_number[num] = ticket

    ordered_numbers = [n for n in closed_at_by_number if n in tickets_by_number]

    # Resolved == Closed, same as the general fadmin_tickets_list path —
    # but this view is scoped to "closed IN this window", and resolved
    # tickets have no local ticket_closed_at row (Freecords sets that
    # status itself, never through this app's own PATCH proxy, so there's
    # nothing local to have recorded the moment). Their own updated_at is
    # a reasonable stand-in: every resolved ticket checked live ends its
    # thread with our own outbound reply, so updated_at already reflects
    # roughly when it actually wrapped up, not some unrelated later touch.
    resolved_tickets, _, _, _ = _fetch_all_matching_tickets({'status': 'resolved', 'date_from': date_from})
    resolved_by_number = {t.get('ticket_number'): t for t in resolved_tickets if t.get('ticket_number') not in tickets_by_number}
    tickets_by_number.update(resolved_by_number)
    resolved_numbers_sorted = sorted(
        resolved_by_number,
        key=lambda n: resolved_by_number[n].get('updated_at') or '',
        reverse=(order != 'asc'),
    )

    # Merge the two already-individually-sorted lists by their respective
    # timestamps rather than concatenating — a straight concatenation would
    # put every resolved ticket after every closed one (or vice versa)
    # regardless of actual date, wrong the moment both kinds exist in the
    # same window.
    def _ts(n):
        return closed_at_by_number.get(n) or resolved_by_number.get(n, {}).get('updated_at') or ''
    ordered_numbers = sorted(
        ordered_numbers + resolved_numbers_sorted,
        key=_ts,
        reverse=(order != 'asc'),
    )

    total = len(ordered_numbers)
    start = (page - 1) * limit
    page_numbers = ordered_numbers[start:start + limit]
    return jsonify({
        'tickets': [tickets_by_number[n] for n in page_numbers],
        'pagination': {'total': total, 'page': page, 'limit': limit, 'capped': False},
    })


def _fadmin_tickets_history(params, order='desc'):
    """
    "History": every ticket any agent has replied to or changed the status
    of — open or closed, most-recent-activity first, tagged with who did
    it and what. Deliberately distinct from "Closed": an Open or Pending
    ticket someone already replied to belongs here too, not just ones that
    reached Closed status. Backed by ticket_activity (one row per event,
    written by fadmin_ticket_patch and fadmin_ticket_reply) — same local-
    log-instead-of-remote-guess approach as ticket_closed_at, for the same
    reason (Freecords' API has no activity/touched-by feed to query at
    all). Starts empty like ticket_closed_at — no retroactive history for
    activity before this table existed.

    Each returned ticket carries `_lastActivity: {action, agent_name, at}`
    for the frontend to show who touched it and how.
    """
    import concurrent.futures
    try:
        page = int(params.get('page', 1))
        limit = int(params.get('limit', 30))
    except ValueError:
        page, limit = 1, 30

    conn = get_db()
    rows = conn.execute(
        "SELECT ticket_number, action, agent_name, at FROM ticket_activity ORDER BY at "
        + ("ASC" if order == 'asc' else "DESC")
    ).fetchall()
    last_activity_by_number = {}
    for r in rows:
        if r['ticket_number'] not in last_activity_by_number:
            last_activity_by_number[r['ticket_number']] = dict(r)
    if not last_activity_by_number:
        conn.close()
        return jsonify({'tickets': [], 'pagination': {'total': 0, 'page': page, 'limit': limit, 'capped': False}})

    placeholders = ','.join('?' * len(last_activity_by_number))
    uuid_by_number = {
        r['ticket_number']: r['native_id']
        for r in conn.execute(
            f"SELECT ticket_number, native_id FROM native_ticket_index WHERE ticket_number IN ({placeholders})",
            list(last_activity_by_number),
        ).fetchall()
    }
    conn.close()

    def _fetch_one(num):
        uuid = uuid_by_number.get(num)
        if not uuid:
            return num, None
        data, err = _api('GET', f'/api/admin/tickets/{uuid}')
        if err or not data or not data.get('ticket'):
            return num, None
        return num, data['ticket']

    tickets_by_number = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        for num, ticket in pool.map(_fetch_one, last_activity_by_number):
            if ticket:
                tickets_by_number[num] = ticket

    ordered_numbers = [n for n in last_activity_by_number if n in tickets_by_number]
    total = len(ordered_numbers)
    start = (page - 1) * limit
    page_numbers = ordered_numbers[start:start + limit]
    page_tickets = []
    for n in page_numbers:
        t = dict(tickets_by_number[n])
        act = last_activity_by_number[n]
        t['_lastActivity'] = {'action': act['action'], 'agent_name': act['agent_name'], 'at': act['at']}
        page_tickets.append(t)
    return jsonify({
        'tickets': page_tickets,
        'pagination': {'total': total, 'page': page, 'limit': limit, 'capped': False},
    })


def _fadmin_tickets_sent(params, order='desc'):
    """
    "Sent" view — tickets manually created via Overlord's own New Ticket
    compose (fadmin_tickets_create above), not a customer writing in.
    Tickets' equivalent of Support's Sent view (freshdesk.py's
    _freshdesk_tickets_sent), which relied on a Freshdesk-only signal
    (unset-source API ticket defaults to Freshdesk's source=2 "Portal")
    with no native equivalent — tracked locally instead (see
    db.py's ticket_manually_created), and unambiguously, since that table
    is only ever written by the one code path a manual compose goes
    through.

    Real bug found live (2026-09-08, user-reported: "I still don't see the
    Sent tickets that are in Support in the Sent tickets that are in
    Tickets"): the old scan-then-filter shape below assumed a Sent ticket
    is always recent enough to sit within the first MAX_PAGES of "newest
    tickets" — true for one manually composed just now, false for one that
    was a Freshdesk "Sent" ticket weeks ago and only got its local
    ticket_manually_created row backfilled later. Confirmed live: with
    63,000+ total tickets and heavy daily volume, a 4000-ticket scan window
    (MAX_PAGES=40 × 100) didn't even reach back 3 days, let alone the
    3+ weeks to an older bulk-sent batch — those tickets could never be
    found no matter how correct the local sent_numbers set was.

    Fixed by looking up each sent ticket_number's native UUID directly
    first — from freshdesk_sync_map (tickets synced by the live loop) or
    native_ticket_index (the one-time historical bulk migration) — and
    fetching it with a single GET /api/admin/tickets/<uuid> instead of
    hoping to stumble across it in a scan. Only ticket_numbers with no
    cached UUID anywhere (a ticket composed directly in Overlord, never
    synced from Freshdesk at all — the one case with no local UUID record)
    still fall back to the scan-then-filter shape below; those are always
    genuinely recent (created by this app, just now), so the same bounded
    MAX_PAGES scan that was already here remains correct for that subset.
    """
    conn = get_db()
    sent_numbers = {r['ticket_number'] for r in conn.execute(
        "SELECT ticket_number FROM ticket_manually_created"
    ).fetchall()}
    if not sent_numbers:
        conn.close()
        try:
            page = int(params.get('page', 1))
            limit = int(params.get('limit', 30))
        except ValueError:
            page, limit = 1, 30
        return jsonify({'tickets': [], 'pagination': {'total': 0, 'page': page, 'limit': limit, 'capped': False}})

    placeholders = ','.join('?' * len(sent_numbers))
    uuid_by_number = {}
    for row in conn.execute(
        f"SELECT freshdesk_id AS num, native_ticket_id AS uuid FROM freshdesk_sync_map WHERE freshdesk_id IN ({placeholders})",
        list(sent_numbers)
    ).fetchall():
        uuid_by_number[row['num']] = row['uuid']
    for row in conn.execute(
        f"SELECT ticket_number AS num, native_id AS uuid FROM native_ticket_index WHERE ticket_number IN ({placeholders})",
        list(sent_numbers)
    ).fetchall():
        uuid_by_number.setdefault(row['num'], row['uuid'])
    conn.close()

    try:
        page = int(params.get('page', 1))
        limit = int(params.get('limit', 30))
    except ValueError:
        page, limit = 1, 30

    # Real, user-reported slowness (2026-09-08, "slow loading issues
    # again"): one _api GET per sent ticket, fully sequential — same shape
    # already fixed elsewhere in this file (tag-counts, closed-since,
    # history). Order doesn't matter here; everything gets re-sorted by
    # _sort_native_tickets_by_date below regardless of fetch order.
    import concurrent.futures
    sent_tickets = []
    if uuid_by_number:
        def _fetch_sent(item):
            num, uuid = item
            data, err = _api('GET', f'/api/admin/tickets/{uuid}')
            return data['ticket'] if not err and data and data.get('ticket') else None
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            sent_tickets.extend(t for t in pool.map(_fetch_sent, uuid_by_number.items()) if t)

    remaining = sent_numbers - set(uuid_by_number.keys())
    capped = False
    if remaining:
        upstream_params = {k: v for k, v in params.items() if k not in ('tag', 'page', 'limit', 'sent')}
        MAX_PAGES = 40
        data, err = _api('GET', '/api/admin/tickets', params={**upstream_params, 'page': 1, 'limit': 100})
        scanned_pages = [data] if not err and data else []
        total = (data or {}).get('pagination', {}).get('total', 0) if not err else 0
        pages_needed = min(MAX_PAGES, -(-total // 100)) if total else 0
        if pages_needed > 1:
            def _fetch_remaining_page(p):
                d, e = _api('GET', '/api/admin/tickets', params={**upstream_params, 'page': p, 'limit': 100})
                return None if e else d
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
                scanned_pages.extend(d for d in pool.map(_fetch_remaining_page, range(2, pages_needed + 1)) if d)
        if pages_needed >= MAX_PAGES and total > MAX_PAGES * 100:
            capped = True
        for page_data in scanned_pages:
            for t in page_data.get('tickets', []):
                if t.get('ticket_number') in remaining:
                    sent_tickets.append(t)

    sent_tickets = _sort_native_tickets_by_date(sent_tickets, order)
    start = (page - 1) * limit
    return jsonify({
        'tickets': sent_tickets[start:start + limit],
        'pagination': {'total': len(sent_tickets), 'page': page, 'limit': limit, 'capped': capped},
    })


def _fadmin_tickets_untagged(params, order='desc'):
    """
    Synthetic "no tags" filter for the group-browse panel's Untagged tile —
    Freecords' own API has no such filter, so scan server-side (same
    MAX_PAGES / cap as /tickets/tag-counts, same tradeoff — see that
    route's docstring for the full "Untagged showed exactly 2000" story;
    same real fix applies here since this is what actually powers the
    ticket list once you click into that tile) and paginate the untagged
    subset ourselves. `tag`/`page`/`limit` are stripped before forwarding;
    every other filter (status, assignee, etc.) still applies upstream.
    """
    try:
        page = int(params.get('page', 1))
        limit = int(params.get('limit', 30))
    except ValueError:
        page, limit = 1, 30
    upstream_params = {k: v for k, v in params.items() if k not in ('tag', 'page', 'limit')}
    upstream_params.setdefault('status', 'open')

    untagged = []
    p = 1
    MAX_PAGES = 40
    while p <= MAX_PAGES:
        data, err = _api('GET', '/api/admin/tickets', params={**upstream_params, 'page': p, 'limit': 100})
        if err or not data:
            break
        for t in data.get('tickets', []):
            if not (t.get('tags') or []):
                untagged.append(t)
        total = data.get('pagination', {}).get('total', 0)
        if p * 100 >= total:
            break
        p += 1

    untagged = _sort_native_tickets_by_date(untagged, order)
    start = (page - 1) * limit
    return jsonify({
        'tickets': untagged[start:start + limit],
        'pagination': {'total': len(untagged), 'page': page, 'limit': limit},
    })


# ── Outbound ticket mail sent by Overlord itself ─────────────────────────────
# Freecords' own ticket endpoints are JSON-only: POST /api/admin/tickets
# records a ticket (and, confirmed live 2026-09-05 with a self-addressed probe,
# emails nobody — the body lands as an *inbound* message from the requester),
# and POST .../reply takes { subject?, body } with no way to carry a file. So
# anything that needs an attachment — and every newly composed ticket, which
# otherwise never reaches the person it's addressed to — is sent here through
# the same SMTP path personal mail uses (helpers._do_send), from
# support@freecords.com with Reply-To set to the ticket's own thread address so
# the customer's answer routes back into the thread exactly like a Freecords-
# sent reply would, then recorded on the ticket via .../message.

SUPPORT_ACCOUNT = 'support@freecords.com'
MAX_ATTACHMENTS_BYTES = 25 * 1024 * 1024


def _attachments_from_body(body):
    """Validate the request's `attachments` ([{filename, data_base64}]).
    Returns (list, None) or (None, error)."""
    raw = body.get('attachments') or []
    if not isinstance(raw, list):
        return None, 'attachments must be a list'
    out, total = [], 0
    for a in raw:
        if not isinstance(a, dict) or not a.get('data_base64'):
            continue
        name = str(a.get('filename') or 'attachment').replace('\r', '').replace('\n', '')
        try:
            size = len(base64.b64decode(a['data_base64']))
        except Exception:
            return None, f'attachment "{name}" is not valid base64'
        total += size
        out.append({'filename': name, 'data_base64': a['data_base64'], 'size': size})
    if total > MAX_ATTACHMENTS_BYTES:
        return None, f'attachments total {total // (1024 * 1024)} MB — the limit is {MAX_ATTACHMENTS_BYTES // (1024 * 1024)} MB per message'
    return out, None


def _fmt_size(n):
    if n < 1024:
        return f'{n} B'
    if n < 1024 * 1024:
        return f'{n // 1024} KB'
    return f'{n / (1024 * 1024):.1f} MB'


def _attachments_note_html(attachments):
    """What the ticket *thread* records about files that went out in the email
    (the thread itself can't hold files)."""
    if not attachments:
        return ''
    items = ''.join(f'<li>{_html.escape(a["filename"])} ({_fmt_size(a["size"])})</li>' for a in attachments)
    return f'<p style="margin-top:12px"><em>Attachments sent with this message:</em></p><ul>{items}</ul>'


def _ticket_field(ticket, *names):
    for n in names:
        if ticket.get(n):
            return ticket[n]
    return ''


_my_identity_cache = {'name': None, 'at': 0}


def _my_agent_name():
    """This Overlord install's own logged-in agent name, for attributing
    local activity log entries (ticket_activity, see db.py). Each install
    is its own real, distinct Freecords login (confirmed live via
    /api/admin/me), so whichever install performs an action is exactly the
    right attribution — no per-request identity to resolve. Cached for 5
    minutes; this is called on every reply/status-change, not worth a
    network round-trip each time for something that never changes within
    a session."""
    import time as _time
    if _my_identity_cache['name'] and _time.time() - _my_identity_cache['at'] < 300:
        return _my_identity_cache['name']
    data, err = _api('GET', '/api/admin/me')
    name = (data or {}).get('username') or (data or {}).get('email') if not err else None
    if name:
        _my_identity_cache['name'] = name
        _my_identity_cache['at'] = _time.time()
    return name


def _record_activity(ticket_number, action):
    """One row per event in ticket_activity — see db.py's table comment
    for why per-event rather than per-ticket. Best-effort: a failure here
    must never break the reply/status-change it's attached to."""
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO ticket_activity (ticket_number, action, agent_name) VALUES (?, ?, ?)",
            (ticket_number, action, _my_agent_name()),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def _index_native_ticket(ticket):
    """Upsert one ticket into native_ticket_index immediately, instead of
    waiting for main.py's _build_native_ticket_index — that backfill only
    runs once per app launch, and (confirmed live, 2026-09-08) can fail to
    complete a full pass across 62,000+ tickets before giving up for the
    run (10 consecutive page failures), so a ticket created or imported
    mid-session can stay invisible to every local-index read (by-number,
    by-requester, tag-counts overflow) across several app restarts — this
    exact gap caused 6 genuinely-imported tickets to wrongly look missing
    hours later. Tolerant of either the create response's camelCase ticket
    shape or GET/list's snake_case one, via the same _ticket_field helper
    used elsewhere in this file. No-ops silently if ticket_number or the
    native id isn't present — better to leave a row for the next backfill
    to fill in than to write a garbage record now."""
    ticket_number = _ticket_field(ticket, 'ticket_number', 'ticketNumber')
    native_id = _ticket_field(ticket, 'id', 'nativeId')
    if not ticket_number or not native_id:
        return
    conn = get_db()
    conn.execute(
        """INSERT OR REPLACE INTO native_ticket_index
           (ticket_number, native_id, requester_email, subject, created_at, status, thread_ref)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (ticket_number, native_id,
         _ticket_field(ticket, 'requester_email', 'requesterEmail'),
         _ticket_field(ticket, 'subject', 'subject'),
         _ticket_field(ticket, 'created_at', 'createdAt'),
         _ticket_field(ticket, 'status', 'status'),
         _ticket_field(ticket, 'thread_ref', 'threadRef')),
    )
    conn.commit()
    conn.close()


def _send_ticket_mail(ticket, subject, html_body, attachments, in_reply_to=None):
    """Send one ticket email from support@ via SMTP. Returns (message_id, None)
    or (None, error). Accepts either the create response's camelCase ticket or
    GET's snake_case one."""
    if SUPPORT_ACCOUNT not in get_all_accounts():
        return None, f'{SUPPORT_ACCOUNT} is not set up as a mail account in Overlord, so this email cannot be sent from here'
    to = _ticket_field(ticket, 'requester_email', 'requesterEmail')
    if not to:
        return None, 'ticket has no requester email'
    reply_to = _ticket_field(ticket, 'replyAddress', 'reply_address')
    if not reply_to:
        ref = _ticket_field(ticket, 'thread_ref', 'threadRef')
        reply_to = f'support+{ref}@freecords.com' if ref else ''
    message_id = email.utils.make_msgid(domain='freecords.com')
    payload = {
        'account': SUPPORT_ACCOUNT,
        'to': to,
        'subject': subject,
        'body': html_body,
        'message_id': message_id,
        'reply_to': reply_to,
        'attachments': [{'filename': a['filename'], 'data_base64': a['data_base64']} for a in attachments],
    }
    if in_reply_to:
        payload['in_reply_to'] = in_reply_to
        payload['references'] = in_reply_to
    ok, err, _code = _do_send(payload)
    if not ok:
        return None, err or 'send failed'
    return message_id, None


def _log_outbound_message(ticket_id, html_body, message_id):
    """Record an email Overlord already sent onto the ticket thread. Returns
    True/False; never raises — the email is out regardless."""
    # `message_id` (snake_case) is what this endpoint actually requires —
    # see main.py's reply-append path, confirmed live 2026-09-04.
    data, err = _api('POST', f'/api/admin/tickets/{ticket_id}/message', json={
        'direction': 'outbound',
        'body': html_body[:20000],
        'fromEmail': SUPPORT_ACCOUNT,
        'message_id': message_id,
    })
    return not err and not (data or {}).get('_not_found')


def _reply_subject(ticket_subject):
    subj = (ticket_subject or '').strip()
    return subj if re.match(r'^re\s*:', subj, re.I) else f'Re: {subj}'


@bp.route('/api/fadmin/tickets', methods=['POST'])
def fadmin_tickets_create():
    body = request.get_json(force=True) or {}
    attachments, att_err = _attachments_from_body(body)
    if att_err:
        return jsonify({'error': att_err}), 400
    send_email = bool(body.get('send_email')) or bool(attachments)
    if send_email and SUPPORT_ACCOUNT not in get_all_accounts():
        # Fail before creating anything — a ticket record with no email
        # behind it is exactly the silent outcome this path exists to avoid.
        return jsonify({'error': f'{SUPPORT_ACCOUNT} is not set up as a mail account in Overlord, so this ticket cannot be emailed from here'}), 400
    upstream = {k: v for k, v in body.items() if k not in ('attachments', 'send_email')}
    email_body = upstream.get('body', '')
    if attachments:
        # The thread record notes the files; the email carries the real ones.
        upstream['body'] = email_body + _attachments_note_html(attachments)
    data, err = _api('POST', '/api/admin/tickets', json=upstream)
    if err:
        return jsonify({'error': err}), 503
    ticket = (data or {}).get('ticket') or {}
    if send_email and ticket.get('id'):
        message_id, send_err = _send_ticket_mail(ticket, upstream.get('subject', ''), email_body, attachments)
        if send_err:
            # Don't leave a ticket that claims a message went out when it didn't.
            _api('DELETE', f"/api/admin/tickets/{ticket['id']}")
            return jsonify({'error': f'Ticket not created — the email could not be sent: {send_err}'}), 502
        data['sentMessageId'] = message_id
        data['sentVia'] = 'overlord'
    _index_native_ticket(ticket)
    if ticket.get('id'):
        apply_ticket_rules(ticket['id'], upstream.get('subject', ''), upstream.get('requesterEmail', ''))
    # This route is the one and only path a manually-composed ticket ever
    # goes through (see db.py's ticket_manually_created) — the direct-IMAP
    # inbound path never calls it. Safe, unambiguous signal for the "Sent"
    # view below.
    if ticket.get('ticketNumber'):
        conn = get_db()
        conn.execute(
            "INSERT OR REPLACE INTO ticket_manually_created (ticket_number, created_at) VALUES (?, datetime('now'))",
            (ticket['ticketNumber'],),
        )
        conn.commit()
        conn.close()
    return jsonify(data or {}), 201


@bp.route('/api/fadmin/tickets/<ticket_id>', methods=['GET'])
def fadmin_ticket_get(ticket_id):
    data, err = _api('GET', f'/api/admin/tickets/{ticket_id}')
    if err:
        return jsonify({'error': err}), 503
    # Real, confirmed live bug (2026-09-08, ticket #9824): _api() returns a
    # real 404 as ({'_not_found': True}, None) — err is None, so this used
    # to fall through to `jsonify(data or {})` below, returning 200 with a
    # body that has no messages/notes/error key at all. The frontend then
    # rendered this identically to a genuinely-empty-but-real ticket ("no
    # messages captured"), when what actually happened is the ticket itself
    # no longer exists remotely (deleted, or merged into another ticket by
    # Freecords' own dedup tooling) — a completely different, much more
    # confusing situation to silently misrepresent. The local
    # native_ticket_index that fed this id (by-number/search/by-requester)
    # has no way to learn a ticket was deleted after it was indexed, so a
    # stale-but-plausible-looking cached UUID pointing at a since-deleted
    # ticket is expected to keep happening — surface it clearly instead.
    if isinstance(data, dict) and data.get('_not_found'):
        return jsonify({'error': 'This ticket no longer exists on Freecords — it may have been deleted or merged into another ticket.'}), 404

    # Native tickets have no read/unread concept anywhere upstream — opening
    # the thread is the natural "mark read" moment, same as every mail view.
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO ticket_read_state (ticket_id, read_at) VALUES (?, datetime('now'))",
        (ticket_id,),
    )

    # Confirmed live (2026-09-09): Freecords' own POST .../message endpoint
    # refuses to log a message onto a ticket that currently has zero
    # messages ("Failed to log inbound message") — succeeds only when a
    # message already exists there, which the duplicate+blank incident's
    # tickets by definition don't have. That's Freecords' own limitation to
    # work around, not a reason to leave tickets permanently blank — serve
    # a locally-recovered copy transparently instead (see
    # ticket_message_backfill in db.py). Synthesized into the same shape
    # GET .../{id} already returns for a real message so the frontend
    # needs zero changes.
    if not ((data or {}).get('messages') or []):
        ticket_number = ((data or {}).get('ticket') or {}).get('ticket_number')
        if ticket_number:
            row = conn.execute(
                "SELECT * FROM ticket_message_backfill WHERE ticket_number = ?",
                (ticket_number,),
            ).fetchone()
            if row:
                data = dict(data or {})
                data['messages'] = [{
                    'id': f'local-backfill-{ticket_number}',
                    'direction': 'inbound',
                    'message_id': row['message_id'],
                    'in_reply_to': None,
                    'from_email': row['from_email'],
                    'to_email': None,
                    'subject': (data.get('ticket') or {}).get('subject'),
                    'body': row['body'],
                    'sent_by_admin_id': None,
                    'created_at': row['message_date'] or row['backfilled_at'],
                }]

    conn.commit()
    conn.close()

    # Real, confirmed live bug (2026-09-18, ticket #10005): the sidebar
    # User panel (account tickets/files/Claude context) was built on the
    # ticket's raw requester_email -- correct for a normal ticket, but for
    # these auto-generated system tickets that's freecords@freecords.com
    # itself, so the panel showed *Freecords' own* account (hundreds of
    # unrelated tickets, zero files) instead of the real artist's.
    # **User, directly**: "Users panel should show data about the sender,
    # not Freecords@freecords = that's 100% worthless." Same extraction
    # already built for reply-routing (_extract_real_requester_email)
    # reused here rather than duplicated -- a new resolved_requester_email
    # field, so requester_email itself stays untouched for whatever else
    # depends on its raw value (e.g. this same reply-routing check).
    ticket_obj = (data or {}).get('ticket') or {}
    req_email = (_ticket_field(ticket_obj, 'requester_email', 'requesterEmail') or '').lower()
    if req_email == 'freecords@freecords.com':
        real_email = _extract_real_requester_email((data or {}).get('messages') or [])
        if real_email:
            data = dict(data or {})
            data['ticket'] = dict(ticket_obj)
            data['ticket']['resolved_requester_email'] = real_email

    return jsonify(data or {})


@bp.route('/api/fadmin/tickets/read-state')
def fadmin_tickets_read_state():
    """
    Bulk-read local read-state for a set of native ticket ids — cheap,
    local-only. Ids not present in the response are unread.

    Query params:
      ticket_ids  str  — comma-separated native ticket UUIDs
    """
    raw = request.args.get('ticket_ids', '')
    ids = [i for i in raw.split(',') if i.strip()]
    if not ids:
        return jsonify(read={})

    conn = get_db()
    placeholders = ','.join('?' * len(ids))
    rows = conn.execute(
        f"SELECT ticket_id FROM ticket_read_state WHERE ticket_id IN ({placeholders})",
        ids,
    ).fetchall()
    conn.close()
    return jsonify(read={r['ticket_id']: True for r in rows})


@bp.route('/api/fadmin/tickets/awaiting-reply')
def fadmin_tickets_awaiting_reply():
    """
    Bulk-read the local "awaiting reply" flag (see db.py's
    ticket_awaiting_reply) for a set of ticket_numbers — cheap, local-only,
    same pattern as read-state above. Numbers not present in the response
    are not awaiting a reply.

    Query params:
      ticket_numbers  str  — comma-separated ticket_number values
    """
    raw = request.args.get('ticket_numbers', '')
    numbers = [n for n in raw.split(',') if n.strip()]
    if not numbers:
        return jsonify(awaiting={})

    conn = get_db()
    placeholders = ','.join('?' * len(numbers))
    rows = conn.execute(
        f"SELECT ticket_number FROM ticket_awaiting_reply WHERE ticket_number IN ({placeholders})",
        numbers,
    ).fetchall()
    conn.close()
    awaiting = {str(r['ticket_number']): True for r in rows}
    # The local table was only ever filled by Overlord's own mail intake, which moved
    # to the cloud on 22 Sep — so nothing lit the dot for new replies. For OPEN tickets
    # (the caller says which) read the thread itself: the customer has the last word
    # after we had already replied.
    open_numbers = [n for n in request.args.get('open', '').split(',') if n.strip() and n not in awaiting]
    if open_numbers:
        for num, flag in _live_awaiting(open_numbers).items():
            if flag:
                awaiting[num] = True
    return jsonify(awaiting=awaiting)


_awaiting_live_cache = {}   # ticket_number -> (checked_at, updated_at_seen, flag)


def _live_awaiting(numbers, max_calls=60):
    import time as _t
    import concurrent.futures
    conn = get_db()
    placeholders = ','.join('?' * len(numbers))
    idx = {str(r['ticket_number']): r['native_id'] for r in conn.execute(
        f"SELECT ticket_number, native_id FROM native_ticket_index WHERE ticket_number IN ({placeholders})", numbers).fetchall()}
    conn.close()
    now, out, todo = _t.time(), {}, []
    for n in numbers:
        hit = _awaiting_live_cache.get(n)
        if hit and now - hit[0] < 120:
            out[n] = hit[2]
        elif n in idx:
            todo.append(n)

    def check(n):
        d, err = _api('GET', f'/api/admin/tickets/{idx[n]}')
        if err or not d:
            return n, None
        msgs = sorted(d.get('messages') or [], key=lambda m: m.get('created_at') or '')
        flag = bool(msgs) and msgs[-1].get('direction') == 'inbound' and             any(m.get('direction') == 'outbound' for m in msgs[:-1])
        return n, flag

    if todo:
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            for n, flag in pool.map(check, todo[:max_calls]):
                if flag is not None:
                    _awaiting_live_cache[n] = (now, None, flag)
                    out[n] = flag
    return out


@bp.route('/api/fadmin/tickets/mark-read', methods=['POST'])
def fadmin_tickets_mark_read():
    """
    Bulk mark/unmark local read-state — same idea as the personal-email
    inbox's bulk mark read/unread, applied to ticket_read_state instead of
    IMAP flags (native tickets have no server-side read/unread concept).

    Body: { ticket_ids: [...], read: true|false }
    """
    body = request.get_json(force=True) or {}
    ticket_ids = [str(i) for i in (body.get('ticket_ids') or [])]
    read = bool(body.get('read', True))
    if not ticket_ids:
        return jsonify({'error': 'no tickets selected'}), 400

    conn = get_db()
    if read:
        conn.executemany(
            "INSERT OR REPLACE INTO ticket_read_state (ticket_id, read_at) VALUES (?, datetime('now'))",
            [(tid,) for tid in ticket_ids],
        )
    else:
        placeholders = ','.join('?' * len(ticket_ids))
        conn.execute(f"DELETE FROM ticket_read_state WHERE ticket_id IN ({placeholders})", ticket_ids)
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'count': len(ticket_ids)})


@bp.route('/api/fadmin/tickets/matching-ids')
def fadmin_tickets_matching_ids():
    """
    Resolve every ticket id (+ minimal summary fields, for JSON export)
    matching the current list filters — used by "select all N" in the
    Tickets bulk-selection bar, the same role /api/messages/uids plays for
    the personal-email inbox's "select all N pages / all" expansion.

    Scans up to 30 pages (3000 tickets) server-side; same tradeoff as
    /tag-counts — cheap here, would be many round-trips from the browser.
    Accepts the same filter query params as GET /api/fadmin/tickets.
    """
    params = {k: v for k, v in request.args.items() if k not in ('limit', 'page')}
    # The list route special-cases the synthetic Untagged group (Freecords has
    # no such filter and silently matches NOTHING for tag=__untagged__), but
    # this route forwarded `tag` verbatim — so "select all N" inside the
    # Untagged group resolved to an empty set (live: ids=[]), and anything
    # built on it (bulk actions, Auto-tag across every page) did nothing.
    # **User, directly**: "why is our group tagging now dead?"
    if params.get('tag') == '__untagged__':
        found = (_fadmin_tickets_untagged({**params, 'page': 1, 'limit': 100000}).get_json() or {}).get('tickets', [])
        return jsonify({'ids': [t.get('id') for t in found], 'tickets': found, 'capped': False})
    ids = []
    tickets = []
    page = 1
    MAX_PAGES = 30
    capped = False
    while page <= MAX_PAGES:
        data, err = _api('GET', '/api/admin/tickets', params={**params, 'page': page, 'limit': 100})
        # A transient failure on page 1 used to fall straight through to the
        # `return` below with ids=[] and no error field — indistinguishable
        # from "this group is genuinely empty" to the caller. Same bug class
        # confirmed live on Freshdesk's equivalent (matching_ids there hit a
        # transient Search API failure and silently reported a real 3-ticket
        # group as empty) — surface it here instead of swallowing it, even
        # though this endpoint hits Freecords' native admin API rather than
        # Freshdesk's flakier Search API.
        if err and page == 1:
            return jsonify(error=err), 502
        if err or not data:
            break
        for t in data.get('tickets', []):
            ids.append(t.get('id'))
            tickets.append(t)
        total = data.get('pagination', {}).get('total', 0)
        if page * 100 >= total:
            break
        page += 1
    else:
        capped = True

    return jsonify({'ids': ids, 'tickets': tickets, 'capped': capped})


@bp.route('/api/fadmin/tickets/<ticket_id>', methods=['PATCH'])
def fadmin_ticket_patch(ticket_id):
    body = request.get_json(force=True) or {}
    data, err = _api('PATCH', f'/api/admin/tickets/{ticket_id}', json=body)
    if err:
        return jsonify({'error': err}), 503
    # This is the one and only PATCH path a ticket ever goes through —
    # single-ticket status dropdown, bulk-close, and Ticket Rules'
    # set_status action all call this same route — so it's the one place
    # that can reliably record "closed_at" the instant it actually happens,
    # locally, with zero dependency on Freecords' API ever exposing a
    # close/update timestamp. See db.py's ticket_closed_at for why.
    if 'status' in body:
        conn = get_db()
        row = conn.execute(
            "SELECT ticket_number FROM native_ticket_index WHERE native_id=?", (ticket_id,)
        ).fetchone()
        ticket_number = row['ticket_number'] if row else None
        if not ticket_number:
            # Real, confirmed live gap (2026-09-08): this used to just skip
            # recording closed_at entirely when native_ticket_index didn't
            # already have the ticket — exactly the tickets most likely to
            # be missing here (a ticket closed soon after creation, before
            # any backfill or prior read ever indexed it) are the ones a
            # "closed in the last N hours" view most needs. Resolve it live
            # instead of giving up, and index it while we're here so the
            # next lookup (of any kind) doesn't hit the same gap.
            detail, detail_err = _api('GET', f'/api/admin/tickets/{ticket_id}')
            if not detail_err and detail and detail.get('ticket'):
                ticket_number = detail['ticket'].get('ticket_number')
                _index_native_ticket(detail['ticket'])
        if ticket_number:
            # Real, confirmed live bug (2026-09-08, user-reported): bulk
            # 'Close N selected tickets' from the User panel didn't remove
            # them from Open cases, while closing one-by-one did. Traced
            # to: Open/Past cases is driven by /api/fadmin/tickets/by-
            # requester, which reads status straight from
            # native_ticket_index — a column this route never touched, so
            # it went stale the instant any status PATCH happened and
            # stayed stale forever after (not just for bulk-close; ANY
            # status change via this route had the same gap, one-by-one
            # close only happened to look right because the *currently
            # selected* ticket's status comes from live component state,
            # not this index, and only that one ticket is ever selected at
            # a time). Keep it current here instead.
            conn.execute("UPDATE native_ticket_index SET status=? WHERE ticket_number=?", (body['status'], ticket_number))
            if body['status'] == 'closed':
                conn.execute(
                    "INSERT OR REPLACE INTO ticket_closed_at (ticket_number, closed_at) VALUES (?, datetime('now'))",
                    (ticket_number,),
                )
            else:
                # Reopened (or moved to any other status) — it's no longer
                # "recently closed", regardless of what it used to be.
                conn.execute("DELETE FROM ticket_closed_at WHERE ticket_number=?", (ticket_number,))
            conn.commit()
        conn.close()
        if ticket_number:
            _record_activity(ticket_number, f"status_changed:{body['status']}")
    return jsonify(data or {})


_TAKEDOWN_ARTIST_RE = re.compile(r'Artist:\s*.*?\(([^()\s]+@[^()\s]+)\)', re.IGNORECASE)
# Account Deletion Request tickets are a second, differently-shaped
# auto-generated notification that also carries requester_email =
# freecords@freecords.com — real body (#10561, #10517, confirmed
# 2026-09-14): "- Email: name@example.com" under "User Details:".
_ACCOUNT_EMAIL_RE = re.compile(r'Email:\s*([^\s()]+@[^\s()]+)', re.IGNORECASE)
# Last resort for any other freecords@freecords.com-originated automated
# notification format not yet seen: the first email address in the body
# that isn't the system address itself or the support inbox.
_ANY_EMAIL_RE = re.compile(r'[\w.+-]+@[\w.-]+\.\w+')


def _extract_real_requester_email(messages):
    """
    Auto-generated tickets (takedown requests, account deletion requests —
    artist clicks a button on the Freecords site) always carry
    requester_email = freecords@freecords.com, intentionally, on Freecords'
    own side — but the real artist's email is reliably embedded in the
    ticket's own auto-generated body. Different notification types use
    different body formats (see the two regexes above), so try each in
    turn, then fall back to the first non-freecords.com email address
    found anywhere in the body. Scans oldest-first so the original
    auto-generated message wins over anything a reply might coincidentally
    also contain a matching pattern in.
    """
    for m in sorted(messages, key=lambda m: m.get('created_at') or ''):
        body = m.get('body') or ''
        for pattern in (_TAKEDOWN_ARTIST_RE, _ACCOUNT_EMAIL_RE):
            match = pattern.search(body)
            if match:
                return match.group(1)
        for candidate in _ANY_EMAIL_RE.findall(body):
            if not candidate.lower().endswith('@freecords.com'):
                return candidate
    return None


@bp.route('/api/fadmin/tickets/<ticket_id>/reply', methods=['POST'])
def fadmin_ticket_reply(ticket_id):
    body = request.get_json(force=True) or {}
    attachments, att_err = _attachments_from_body(body)
    if att_err:
        return jsonify({'error': att_err}), 400

    # Fetched unconditionally now (previously only fetched in the
    # attachments branch) — needed to check requester_email and, for a
    # takedown ticket, pull the real artist email out of the body. Real,
    # confirmed bug (2026-09-09): replying to one of these tickets went to
    # requester_email — freecords@freecords.com, a system address nobody
    # reads — so the artist never actually saw the response. **User,
    # directly**: "responding to such emails should send a response to
    # those artists as well." Neither send path (Freecords' hosted reply
    # endpoint, or Overlord's own SMTP send) lets the recipient be
    # anything other than requester_email, so this forces the send through
    # Overlord's own SMTP path (the only one where it can be overridden)
    # whenever a real artist email was recovered from the body.
    detail, detail_err = _api('GET', f'/api/admin/tickets/{ticket_id}')
    if detail_err:
        return jsonify({'error': detail_err}), 503
    if not detail or detail.get('_not_found') or not detail.get('ticket'):
        return jsonify({'error': 'ticket not found'}), 404
    ticket = detail['ticket']
    messages = detail.get('messages') or []

    override_to = None
    req_email = (_ticket_field(ticket, 'requester_email', 'requesterEmail') or '').lower()
    if req_email == 'freecords@freecords.com':
        override_to = _extract_real_requester_email(messages)

    if attachments or override_to:
        newest = max(messages, key=lambda m: m.get('created_at') or '') if messages else {}
        subject = (body.get('subject') or '').strip() or _reply_subject(ticket.get('subject'))
        html_body = body.get('body', '')
        send_ticket = dict(ticket)
        if override_to:
            send_ticket['requester_email'] = override_to
        message_id, send_err = _send_ticket_mail(send_ticket, subject, html_body, attachments,
                                                 in_reply_to=newest.get('message_id'))
        if send_err:
            return jsonify({'error': send_err}), 502
        logged_body = html_body + (_attachments_note_html(attachments) if attachments else '')
        logged = _log_outbound_message(ticket_id, logged_body, message_id)
        data = {'success': True, 'messageId': message_id, 'sentVia': 'overlord', 'logged': logged}
        if override_to:
            data['sentTo'] = override_to
    else:
        upstream = {k: v for k, v in body.items() if k != 'attachments'}
        data, err = _api('POST', f'/api/admin/tickets/{ticket_id}/reply', json=upstream)
        if err:
            return jsonify({'error': err}), 503
    # We just replied — the ball is back in the customer's court. See
    # db.py's ticket_awaiting_reply for the full rationale (the Tickets
    # equivalent of Support's old blue "customer responded" dot). Resolved
    # from native_ticket_index rather than requiring the frontend to pass
    # ticket_number — keeps this endpoint's documented {subject?, body}
    # request shape untouched.
    _conn = get_db()
    _row = _conn.execute("SELECT ticket_number FROM native_ticket_index WHERE native_id=?", (ticket_id,)).fetchone()
    _conn.close()
    if _row and _row['ticket_number']:
        clear_ticket_awaiting_reply(_row['ticket_number'])
        _record_activity(_row['ticket_number'], 'replied')
    return jsonify(data or {})


_tag_counts_cache = {'at': 0, 'key': None, 'counts': {}}
_tag_counts_lock = threading.Lock()


@bp.route('/api/fadmin/tickets/tag-counts')
def fadmin_tickets_tag_counts():
    """
    Tag counts for a given status (+ optional date_from), so the Tickets
    view can offer "browse by group" (take-down request, copyright, misc,
    etc.) instead of a blank "Select a ticket" placeholder.

    Two passes:
    1. Scan up to MAX_PAGES pages of /api/admin/tickets to discover which
       tags actually exist on Open tickets AND tally __untagged__ directly
       (there's no server-side "no tag" filter to get an exact untagged
       count any other way — see the __untagged__ comment below).
    2. For each REAL tag found, one lightweight follow-up request with the
       server's own tag filter and limit=1, reading pagination.total for
       the exact count — this step is what makes real tags' counts exact
       regardless of scan window size; __untagged__ has no equivalent
       follow-up, so it depends entirely on the scan actually covering the
       real total.

    **MAX_PAGES was 20 (2000 tickets) — user-reported, again, with a
    screenshot: "Untagged" showed exactly 2000, a suspiciously round number.
    Confirmed live, not assumed: real total open tickets on this account is
    3,390 (`/api/admin/tickets?status=open&limit=1` → pagination.total).
    2000 was the scan window saturating, not the real count — nearly every
    ticket in the scanned window had no tags, so the tally hit the window's
    ceiling exactly. Raised to 40 pages (4,000 tickets), matching this
    codebase's other exact-count scan ceiling (`_EXACT_SCAN_MAX_PAGES` in
    freshdesk.py) — comfortably covers the current real total with room to
    grow. Real tags were never actually wrong from this cap (they get the
    exact follow-up query regardless) — only __untagged__, which has no
    such follow-up, was silently truncated.

    Tiles are scoped to whatever date_from is active in the list — same
    fix applied to Freshdesk's equivalent endpoint, ported here for
    consistency: an unscoped all-time total disagrees with a date-filtered
    list the same way it did there, just less dramatically since this
    account's native ticket backlog is smaller.

    Cached in-memory for 2 minutes per (status, date_from) pair — pass
    force=1 to bypass the cache (the list view's manual Refresh button does
    this).
    """
    import time as _time
    status = request.args.get('status', 'open')
    date_from = request.args.get('date_from', '')
    cache_key = (status, date_from)
    force = request.args.get('force') == '1'

    with _tag_counts_lock:
        cached = _tag_counts_cache
        if not force and cached['key'] == cache_key and _time.time() - cached['at'] < 120:
            return jsonify(counts=cached['counts'])

    base_params = {'status': status}
    if date_from:
        base_params['date_from'] = date_from

    # Real, user-reported slowness (2026-09-08, "slow loading issues
    # again"): both passes below used to run one request at a time — up to
    # 40 sequential page fetches for the scan, then one more sequential
    # request per discovered tag on top — confirmed live to take 3.3s on a
    # cold cache. Every other multi-request path in this file already
    # fixed the identical shape of problem this same way (see
    # fadmin_tickets_list's own docstring: "Was sequential... Fetched
    # concurrently instead"); this route had just never gotten the same
    # treatment. Capped at 8 workers, matching the rate-limit-conscious cap
    # used everywhere else here.
    import concurrent.futures
    tag_names = set()
    untagged_count = 0
    MAX_PAGES = 40
    data, err = _api('GET', '/api/admin/tickets', params={**base_params, 'page': 1, 'limit': 100})
    pages = [data] if not err and data else []
    total = (data or {}).get('pagination', {}).get('total', 0) if not err else 0
    pages_needed = min(MAX_PAGES, -(-total // 100)) if total else 0
    if pages_needed > 1:
        def _fetch_page(p):
            d, e = _api('GET', '/api/admin/tickets', params={**base_params, 'page': p, 'limit': 100})
            return None if e else d
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            pages.extend(d for d in pool.map(_fetch_page, range(2, pages_needed + 1)) if d)
    for page_data in pages:
        for t in page_data.get('tickets', []):
            tags = t.get('tags') or []
            if not tags:
                untagged_count += 1
            for tag in tags:
                tag_names.add(tag)

    def _fetch_tag_count(tag):
        d, e = _api('GET', '/api/admin/tickets', params={**base_params, 'tag': tag, 'page': 1, 'limit': 1})
        return tag, (d.get('pagination', {}).get('total', 0) if not e and d else None)

    counts = {}
    if tag_names:
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for tag, count in pool.map(_fetch_tag_count, tag_names):
                if count is not None:
                    counts[tag] = count

    # Tallied directly during the scan above (not `total - sum(counts)`,
    # which would be wrong the moment a ticket carries more than one tag —
    # confirmed live this dataset happens to have zero multi-tag tickets,
    # but that's not guaranteed to stay true). Sentinel key, not a real
    # Freecords tag; the frontend renders it as "Untagged" and the list
    # route below special-cases it since Freecords has no "no tag" filter.
    if untagged_count:
        counts['__untagged__'] = untagged_count

    with _tag_counts_lock:
        _tag_counts_cache.update(at=_time.time(), key=cache_key, counts=counts)

    return jsonify(counts=counts)


@bp.route('/api/fadmin/db-migration-stats')
def fadmin_db_migration_stats():
    """
    Read-only row counts for every local table that would need to move to
    a shared server-side DB to stop being per-desktop-install state (see
    2026-09-08 planning: native_ticket_index's staleness across app
    restarts, Sent-view/read-state/awaiting-reply not being visible to
    colleagues' own installs). Exists purely to size a migration — no
    schema or credentials exposed, just table name -> row count.
    """
    tables = [
        'native_ticket_index', 'ticket_manually_created', 'ticket_read_state',
        'ticket_awaiting_reply', 'ticket_attachment_files', 'freshdesk_sync_map',
        'ticket_rules', 'ticket_attachment_cache', 'ticket_attachment_backfill_done',
        'freshdesk_ticket_read_state', 'ticket_closed_at', 'ticket_activity',
        'ticket_message_backfill',
    ]
    conn = get_db()
    counts = {}
    for t in tables:
        try:
            counts[t] = conn.execute(f'SELECT COUNT(*) AS n FROM {t}').fetchone()['n']
        except Exception as e:
            counts[t] = f'error: {e}'
    conn.close()
    return jsonify(counts)


@bp.route('/api/fadmin/db-migration-export')
def fadmin_db_migration_export():
    """
    Full row dump (not just counts) of every local table that needs to move
    to the shared server-side DB per the 2026-09-08/09 migration plan — one
    JSON array per table, every row as a plain dict. Same table list as
    fadmin_db_migration_stats. Read-only, no writes, no credentials or
    schema info beyond what's already in the migration brief.

    Row content only — the ~1,500 files referenced by
    ticket_attachment_files.file_path are NOT included here (those are
    actual file bytes on local disk, not DB rows); they need a separate
    bundle/upload once a shared storage location exists.
    """
    tables = [
        'native_ticket_index', 'ticket_manually_created', 'ticket_read_state',
        'ticket_awaiting_reply', 'ticket_attachment_files', 'freshdesk_sync_map',
        'ticket_rules', 'ticket_attachment_cache', 'ticket_attachment_backfill_done',
        'freshdesk_ticket_read_state', 'ticket_closed_at', 'ticket_activity',
        'ticket_message_backfill',
    ]
    conn = get_db()
    dump = {}
    for t in tables:
        try:
            rows = conn.execute(f'SELECT * FROM {t}').fetchall()
            dump[t] = [dict(r) for r in rows]
        except Exception as e:
            dump[t] = {'error': str(e)}
    conn.close()
    return jsonify(dump)


@bp.route('/api/fadmin/db-migration-attachments-zip')
def fadmin_db_migration_attachments_zip():
    """
    Zips APP_SUPPORT/ticket_attachments (the actual downloaded attachment
    files backing ticket_attachment_files' file_path column — Freshdesk's
    own links are short-lived signed URLs, so this local copy is the only
    durable one) and streams it back over HTTP. Built inside this process
    so it resolves the real, OS-virtualized app-data path directly — no
    external tool guessing at APPDATA locations from outside the app.
    """
    import io
    import zipfile

    src_dir = APP_SUPPORT / 'ticket_attachments'
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        if src_dir.exists():
            for path in src_dir.rglob('*'):
                if path.is_file():
                    zf.write(path, path.relative_to(src_dir))
    buf.seek(0)
    return send_file(buf, mimetype='application/zip', as_attachment=True,
                      download_name='ticket_attachments.zip')


@bp.route('/api/fadmin/tickets/backfill-blank', methods=['POST'])
def fadmin_tickets_backfill_blank():
    """
    One-off repair for the confirmed duplicate+blank ticket incident
    (2026-09-09, root-caused and fixed in main.py's notification_loop —
    see that file's cursor-advance comment). Every affected ticket was
    created from a genuine inbound email to support@freecords.com (that's
    the only entry point for the code path that had the bug), so the
    original content is still sitting in that mailbox — this re-finds it
    and re-attaches it via the same idempotent /message endpoint the live
    sync loop already uses (ON CONFLICT DO NOTHING server-side on
    messageId, so this can never double up a message).

    Body: { tickets: [{ id, ticket_number, requester_email, subject,
    created_at }, ...] } — the exact list to repair, not re-derived here,
    so scope is always whatever was already confirmed blank by the
    caller. Matches each ticket to a mailbox message by sender + subject
    (substring either direction, to tolerate Re:/Fwd: prefixes) +
    closest timestamp; anything without a same-sender, same-subject
    candidate within 6 hours is left alone and reported as unmatched
    rather than guessed at.
    """
    import datetime as _dt2
    import email.header as _eh
    import sqlite3 as _sqlite3
    import time as _time3
    from imap import imap_connect
    from parsing import extract_plain_body, _decode_env

    def _commit_with_retry(conn, tries=5):
        # Same class of bug as main.py's _commit_with_retry (get_db() opens
        # plain sqlite3 connections with no busy_timeout, and several
        # background loops write to the same file concurrently): confirmed
        # live (2026-09-23) that a bare conn.commit() here silently failed
        # for ~30% of a 266-ticket repair batch — the endpoint reported
        # every one as 'repaired', but a fresh check minutes later found
        # ~80 of them still genuinely empty. A second, otherwise-identical
        # run against just the failures fixed all of them, pointing at lock
        # contention rather than a real matching failure.
        for attempt in range(tries):
            try:
                conn.commit()
                return
            except _sqlite3.OperationalError:
                if attempt == tries - 1:
                    raise
                _time3.sleep(0.3 * (attempt + 1))

    body = request.get_json(force=True) or {}
    tickets = body.get('tickets') or []
    if not tickets:
        return jsonify({'error': 'tickets required'}), 400

    def _parse_dt(s):
        try:
            return _dt2.datetime.fromisoformat((s or '').replace('Z', '+00:00'))
        except Exception:
            return None

    dates = [d for d in (_parse_dt(t.get('created_at')) for t in tickets) if d]
    since = (min(dates) - _dt2.timedelta(days=1)).strftime('%d-%b-%Y') if dates else None

    client = imap_connect('support@freecords.com')
    if not client:
        return jsonify({'error': 'could not connect to support@freecords.com'}), 503
    client.select_folder('INBOX')
    uids = client.search(['SINCE', since] if since else ['ALL'])
    envs = client.fetch(uids, ['ENVELOPE'])

    def _norm(s):
        return re.sub(r'\s+', ' ', (s or '')).strip().lower()

    candidates = []
    for uid, data in envs.items():
        env = data.get(b'ENVELOPE')
        if not env:
            continue
        from_email = ''
        if env.from_ and env.from_[0].mailbox:
            mb = _decode_env(env.from_[0].mailbox.decode('utf-8', 'replace'))
            host = _decode_env((env.from_[0].host or b'').decode('utf-8', 'replace'))
            from_email = f'{mb}@{host}'.lower()
        subj = ''
        if env.subject:
            decoded = _eh.decode_header(env.subject.decode('utf-8', 'replace'))
            subj = ''.join((p.decode(enc or 'utf-8', 'replace') if isinstance(p, bytes) else p) for p, enc in decoded)
        candidates.append({'uid': uid, 'from_email': from_email, 'subject_n': _norm(subj), 'date': env.date})

    results = []
    for t in tickets:
        num = t.get('ticket_number')
        req_email = (t.get('requester_email') or '').lower()
        subj_n = _norm(t.get('subject'))
        ticket_dt = _parse_dt(t.get('created_at'))

        scored = []
        for c in candidates:
            if c['from_email'] != req_email:
                continue
            if not subj_n or not (subj_n in c['subject_n'] or c['subject_n'] in subj_n):
                continue
            if ticket_dt and c['date']:
                try:
                    # env.date from imapclient's ENVELOPE isn't reliably
                    # timezone-aware — mixing it with ticket_dt (always
                    # UTC-aware, parsed from an ISO 'Z' timestamp) raised
                    # "can't subtract offset-naive and offset-aware
                    # datetimes" for every single candidate on first run,
                    # silently caught below as delta=inf, which then failed
                    # every match against the 6h window. Normalize both to
                    # UTC-aware before comparing.
                    cd = c['date']
                    if cd.tzinfo is None:
                        cd = cd.replace(tzinfo=_dt2.timezone.utc)
                    td = ticket_dt
                    if td.tzinfo is None:
                        td = td.replace(tzinfo=_dt2.timezone.utc)
                    delta = abs((cd - td).total_seconds())
                except Exception:
                    delta = float('inf')
            else:
                delta = float('inf')
            scored.append((delta, c))
        scored.sort(key=lambda x: x[0])

        if not scored:
            results.append({'ticket_number': num, 'status': 'no_match'})
            continue
        best_delta, best = scored[0]
        # 48h, not a few hours: the whole reason these tickets are blank is
        # mail sitting unprocessed for a while before a delayed/restarted
        # sync loop finally created them (the root cause this backfill
        # exists to clean up after) — a multi-hour gap between the email's
        # real Date header and the ticket's created_at is expected, not a
        # sign of a wrong match. Sender + subject already have to match
        # first for a candidate to reach this point at all.
        if best_delta > 48 * 3600:
            results.append({'ticket_number': num, 'status': 'no_confident_match', 'closest_delta_s': best_delta})
            continue

        raw = client.fetch([best['uid']], ['RFC822', 'ENVELOPE'])
        data = raw.get(best['uid'], {})
        try:
            msg_body = extract_plain_body(data.get(b'RFC822', b''))
        except Exception as e:
            results.append({'ticket_number': num, 'status': 'extract_failed', 'error': str(e)})
            continue
        if not msg_body:
            results.append({'ticket_number': num, 'status': 'empty_body'})
            continue

        env2 = data.get(b'ENVELOPE')
        msg_id = env2.message_id.decode('utf-8', 'replace') if (env2 and env2.message_id) else f"<imap-{best['uid']}@freecords.com>"
        created_at_iso = None
        if env2 and env2.date:
            cd2 = env2.date
            if cd2.tzinfo is None:
                cd2 = cd2.replace(tzinfo=_dt2.timezone.utc)
            created_at_iso = cd2.astimezone(_dt2.timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')

        # Confirmed live: Freecords' own POST .../message endpoint refuses
        # to log a message on a ticket that currently has zero messages —
        # every blank ticket, by definition. Own this locally instead
        # (ticket_message_backfill, served transparently by
        # fadmin_ticket_get) rather than depend on a remote endpoint that
        # can't do the one thing needed here.
        conn = get_db()
        conn.execute(
            "INSERT OR REPLACE INTO ticket_message_backfill (ticket_number, body, from_email, message_id, message_date) VALUES (?, ?, ?, ?, ?)",
            (num, msg_body[:20000], req_email, msg_id, created_at_iso),
        )
        _commit_with_retry(conn)
        conn.close()
        results.append({'ticket_number': num, 'status': 'repaired', 'matched_uid': best['uid'], 'delta_s': best_delta})

    return jsonify({'results': results})


@bp.route('/api/fadmin/ticket-rules', methods=['GET', 'POST', 'OPTIONS'])
def fadmin_ticket_rules():
    """Ticket-side equivalent of /api/rules (backend/rules.py) — same shape
    (one condition, one action, first-match-wins), applied to tickets at
    creation time via ticket_rules_engine.py instead of to email at
    arrival time via rules_engine.py."""
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'GET':
        rows = conn.execute('SELECT * FROM ticket_rules ORDER BY id').fetchall()
        conn.close()
        return jsonify([dict(r) for r in rows])
    body = request.get_json() or {}
    conn.execute(
        '''INSERT INTO ticket_rules (name,condition_field,condition_op,condition_value,action,action_value,active)
           VALUES (?,?,?,?,?,?,?)''',
        (body.get('name', ''), body.get('condition_field', 'subject'), body.get('condition_op', 'contains'),
         body.get('condition_value', ''), body.get('action', 'add_tag'), body.get('action_value', ''), 1),
    )
    conn.commit()
    row = conn.execute('SELECT * FROM ticket_rules WHERE id=last_insert_rowid()').fetchone()
    conn.close()
    return jsonify(dict(row))


@bp.route('/api/fadmin/ticket-rules/<int:rule_id>', methods=['PATCH', 'DELETE', 'OPTIONS'])
def fadmin_ticket_rule(rule_id):
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM ticket_rules WHERE id=?', (rule_id,))
        conn.commit(); conn.close()
        return jsonify(ok=True)
    body = request.get_json() or {}
    fields = ['name', 'condition_field', 'condition_op', 'condition_value', 'action', 'action_value', 'active']
    updates = {k: body[k] for k in fields if k in body}
    if updates:
        set_clause = ', '.join(f'{k}=?' for k in updates)
        conn.execute(f'UPDATE ticket_rules SET {set_clause} WHERE id=?', (*updates.values(), rule_id))
        conn.commit()
    row = conn.execute('SELECT * FROM ticket_rules WHERE id=?', (rule_id,)).fetchone()
    conn.close()
    return jsonify(dict(row) if row else {})


@bp.route('/api/fadmin/tickets/auto-tag/suggest', methods=['POST'])
def fadmin_tickets_auto_tag_suggest():
    """
    Read-only: runs ticket_tagger.suggest_tag over a batch of tickets the
    caller already has loaded (e.g. the current page of the Untagged group
    view) and returns a suggestion per ticket that matched a rule. Writes
    nothing — the frontend shows these for review before /apply is called.
    Body: {"tickets": [{"id": ..., "subject": ..., "ticket_number": ...}, ...]}
    """
    body = request.get_json(force=True) or {}
    tickets = body.get('tickets') or []
    suggestions = []
    for t in tickets:
        tag = suggest_tag(t.get('subject'))
        if tag:
            suggestions.append({
                'id': t.get('id'),
                'ticket_number': t.get('ticket_number'),
                'subject': t.get('subject'),
                'tag': tag,
            })
    return jsonify({'suggestions': suggestions})


def _auto_tag_one(item):
    ticket_id = item.get('id')
    tag = item.get('tag')
    if not ticket_id or not tag:
        return None
    _data, err = _api('PATCH', f'/api/admin/tickets/{ticket_id}', json={'tags': [tag]})
    return {'id': ticket_id, 'ok': err is None, 'error': err}


def _auto_tag_apply_parallel(items, on_progress=None):
    """One PATCH per ticket (Freecords has no bulk-tag endpoint), run 4 at a
    time. Done one by one this measured ~2.2s per ticket — 21 tags took most
    of a minute behind a dead-looking disabled button, and tagging a whole
    group would have taken the better part of an hour. **User, directly**:
    "why is our group tagging now dead?" Kept to 4 workers: _api already
    backs off on 429s, and more than that risks tripping Freecords' limiter."""
    from concurrent.futures import ThreadPoolExecutor
    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for r in pool.map(_auto_tag_one, items):
            if r is None:
                continue
            results.append(r)
            if on_progress:
                on_progress(r)
    if any(r['ok'] for r in results):
        with _tag_counts_lock:
            _tag_counts_cache['at'] = 0   # group tiles would otherwise show pre-apply counts for ~2 min
    return results


@bp.route('/api/fadmin/tickets/auto-tag/apply', methods=['POST'])
def fadmin_tickets_auto_tag_apply():
    """
    Applies confirmed tag suggestions from the review step (synchronously —
    kept for older frontends; the Tickets view now uses /apply-async below so
    large batches show progress). Reports per-ticket success/failure so a
    partial failure is visible instead of silently dropped.
    Body: {"items": [{"id": ..., "tag": ...}, ...]}
    """
    body = request.get_json(force=True) or {}
    return jsonify({'results': _auto_tag_apply_parallel(body.get('items') or [])})


_auto_tag_job = {'state': 'idle', 'total': 0, 'done': 0, 'ok': 0, 'failed': 0, 'last_error': None}
_auto_tag_job_lock = threading.Lock()


@bp.route('/api/fadmin/tickets/auto-tag/apply-async', methods=['POST'])
def fadmin_tickets_auto_tag_apply_async():
    """Starts the same apply as a background job and returns at once; poll
    /apply-async/status for progress. One job at a time."""
    body = request.get_json(force=True) or {}
    items = [i for i in (body.get('items') or []) if i.get('id') and i.get('tag')]
    with _auto_tag_job_lock:
        if _auto_tag_job['state'] == 'running':
            return jsonify({'error': 'A tagging job is already running'}), 409
        _auto_tag_job.update(state='running', total=len(items), done=0, ok=0, failed=0, last_error=None)

    def progress(r):
        with _auto_tag_job_lock:
            _auto_tag_job['done'] += 1
            if r['ok']:
                _auto_tag_job['ok'] += 1
            else:
                _auto_tag_job['failed'] += 1
                _auto_tag_job['last_error'] = r['error']

    def run():
        try:
            _auto_tag_apply_parallel(items, progress)
        except Exception as e:
            with _auto_tag_job_lock:
                _auto_tag_job['last_error'] = str(e)
        finally:
            with _auto_tag_job_lock:
                _auto_tag_job['state'] = 'done'

    threading.Thread(target=run, daemon=True).start()
    return jsonify({'started': True, 'total': len(items)})


@bp.route('/api/fadmin/tickets/auto-tag/apply-async/status')
def fadmin_tickets_auto_tag_apply_status():
    with _auto_tag_job_lock:
        return jsonify(dict(_auto_tag_job))


@bp.route('/api/fadmin/tickets/search')
def fadmin_tickets_search():
    """
    Real ticket search — replaces TicketsView.jsx's old approach of live-
    scanning up to 3000 (30 pages x 100) of the most recent tickets and
    substring-matching subject/requester_email/ticket_number client-side.
    That missed anything older than the scan window entirely, and never
    matched on a person's name at all (only email/subject text).

    Two sources, merged:
    1. Local native_ticket_index (built by main.py's full-catalog backfill) —
       substring match on subject/requester_email/ticket_number, unbounded,
       instant (SQL, no live paging).
    2. Nik's /api/admin/search — resolves a name/username query (e.g. "paul
       t clark") to a real user's email, then pulls that person's full
       ticket history from the same local index. Confirmed live: "paul t
       clark" resolves to paul.timothy.clark@gmail.com via /api/admin/search,
       which the old client-side scan could never have matched since that
       string never appears in any ticket's subject or email field.

    Query params:
      q  str  — search text (required)
    """
    q = request.args.get('q', '').strip()
    if not q:
        return jsonify({'tickets': [], 'total': 0})

    conn = get_db()
    like = f'%{q}%'
    rows = conn.execute(
        "SELECT ticket_number, native_id, subject, created_at, status, requester_email "
        "FROM native_ticket_index "
        "WHERE subject LIKE ? OR requester_email LIKE ? OR CAST(ticket_number AS TEXT) LIKE ? "
        "ORDER BY created_at DESC LIMIT 200",
        (like, like, like),
    ).fetchall()
    by_id = {r['native_id']: dict(r) for r in rows}

    # Name/username resolution via Nik's real user search — only worth
    # trying for query strings that don't already look like an email or a
    # bare ticket number (cheap short-circuit, avoids a pointless API call).
    if not q.isdigit() and '@' not in q:
        data, err = _api('GET', '/api/admin/search', params={'q': q})
        if not err and data:
            emails = {
                r.get('metadata', {}).get('email')
                for r in (data.get('results') or [])
                if r.get('type') == 'user' and r.get('metadata', {}).get('email')
            }
            for email in emails:
                extra = conn.execute(
                    "SELECT ticket_number, native_id, subject, created_at, status, requester_email "
                    "FROM native_ticket_index WHERE requester_email = ? ORDER BY created_at DESC LIMIT 100",
                    (email,),
                ).fetchall()
                for r in extra:
                    by_id[r['native_id']] = dict(r)
    conn.close()

    tickets = sorted(by_id.values(), key=lambda t: t.get('created_at') or '', reverse=True)
    # Shape matches /api/fadmin/tickets' list items exactly (id = native UUID)
    # since search results render through the same TicketRow/CardRow
    # components and get opened the same way as the regular paginated list —
    # priority/assignee/tags aren't in the local index, so they're left null,
    # which those components already render defensively either way.
    return jsonify({
        'tickets': [
            {'id': t['native_id'], 'ticket_number': t['ticket_number'], 'subject': t['subject'],
             'created_at': t['created_at'], 'status': t['status'], 'requester_email': t['requester_email'],
             'assignee_id': None, 'assignee_email': None, 'assignee_username': None, 'priority': None, 'tags': []}
            for t in tickets
        ],
        'total': len(tickets),
    })


@bp.route('/api/fadmin/tickets/by-number/<int:ticket_number>')
def fadmin_ticket_by_number(ticket_number):
    """
    Resolve a Freshdesk ticket_number to its native UUID, via the same local
    native_ticket_index used by by-requester below — needed to jump straight
    to a ticket in-app from a bare ticket-number reference (e.g. the Auto
    Ticket Merger App's "merged into ticket NNNNN" note) without knowing the
    requester ahead of time, since that note can reference any ticket, not
    just ones from the currently-open ticket's own requester.
    """
    conn = get_db()
    row = conn.execute(
        "SELECT ticket_number, native_id, subject, created_at, status, requester_email "
        "FROM native_ticket_index WHERE ticket_number = ?",
        (ticket_number,),
    ).fetchone()
    conn.close()
    if not row:
        return jsonify({'error': 'not_found'}), 404
    return jsonify({
        'id': row['native_id'], 'ticket_number': row['ticket_number'],
        'subject': row['subject'], 'created_at': row['created_at'],
        'status': row['status'], 'requester_email': row['requester_email'],
    })


@bp.route('/api/fadmin/tickets/by-requester')
def fadmin_tickets_by_requester():
    """
    All of a requester's native tickets, from the local native_ticket_index —
    not a live Freecords API call. Nik's /api/admin/tickets has no server-side
    filter by requester (confirmed: email=/q= params are silently ignored),
    so the only way to find "all tickets for this person" without paging
    through the entire catalog on every ticket open is a local index built by
    _build_native_ticket_index's one-time full-catalog scan in main.py.
    Previously TicketsView.jsx fetched only the global first 100 tickets and
    filtered client-side — anyone whose older tickets didn't fall in that
    window had them silently missing from "past tickets".
    """
    email = request.args.get('email', '').strip()
    if not email:
        return jsonify({'error': 'email required'}), 400
    exclude_id = request.args.get('exclude_id', '').strip()

    conn = get_db()
    rows = conn.execute(
        "SELECT ticket_number, native_id, subject, created_at, status, requester_email, thread_ref "
        "FROM native_ticket_index WHERE requester_email = ? ORDER BY created_at DESC",
        (email,),
    ).fetchall()
    conn.close()

    # Real bug, confirmed live 2026-09-23: never returned requester_email
    # (or thread_ref) at all, despite every row here matching the exact
    # email just queried by definition. TicketsView.jsx's related-tickets
    # click handler hands whatever a row here carries straight to
    # openReplyCompose when navigating to one of these — with no email on
    # the row, Reply/Full compose showed a completely empty "To" field
    # (`<>`) and a generic "Hi there," greeting instead of the real
    # artist's address, even though the ticket itself has one.
    tickets = [
        {
            'id': r['ticket_number'], 'subject': r['subject'],
            'created_at': r['created_at'], 'status': r['status'],
            '_nativeId': r['native_id'], 'requester_email': r['requester_email'],
            'thread_ref': r['thread_ref'],
        }
        for r in rows if str(r['native_id']) != exclude_id
    ]
    return jsonify({'tickets': tickets, 'total': len(tickets)})


@bp.route('/api/fadmin/requester-attachments-local')
def fadmin_requester_attachments_local():
    """
    Native-CRM equivalent of /api/freshdesk/requester-attachments — the User
    panel's "past attachments" list defaulted to the Freshdesk version even
    when opened from the Tickets tab (every other prop on that panel —
    ticketsApi, userContextApi, contactUrlBase — was already redirected to a
    native equivalent; this one was simply missed). Backed by
    ticket_attachment_files (see helpers.store_ticket_attachment_files),
    joined against native_ticket_index for the requester filter and subject
    — both local, zero Freshdesk calls.
    """
    email = (request.args.get('email') or '').strip()
    exclude_id = request.args.get('exclude_id', '').strip()
    if not email:
        return jsonify(attachments=[])

    conn = get_db()
    rows = conn.execute("""
        SELECT taf.ticket_number, taf.filename, taf.content_type, taf.size,
               nti.subject, nti.native_id
        FROM ticket_attachment_files taf
        JOIN native_ticket_index nti ON nti.ticket_number = taf.ticket_number
        WHERE nti.requester_email = ?
        ORDER BY taf.downloaded_at DESC
        LIMIT 100
    """, (email,)).fetchall()
    conn.close()

    attachments = [{
        'name': r['filename'],
        'content_type': r['content_type'],
        'size': r['size'],
        'attachment_url': f"{request.host_url.rstrip('/')}/api/fadmin/ticket-attachment/{r['ticket_number']}/{r['filename']}",
        '_ticket_id': r['ticket_number'],
        '_ticket_subject': r['subject'],
    } for r in rows if str(r['native_id']) != exclude_id]
    return jsonify(attachments=attachments)


@bp.route('/api/fadmin/tickets/client-context')
def fadmin_tickets_client_context():
    """
    Native-CRM equivalent of /api/freshdesk/client-context — a formatted text
    block of full ticket thread content for a requester, for the Tickets
    tab's in-panel "Ask Claude" box. This never existed before: TicketsView.jsx
    passed clientContextApi={None}, so Claude only ever saw Freecords account
    data (songs, ban history) and never any actual ticket conversation
    content when used from Tickets.

    Query params:
      email       str        — requester email (required)
      ticket_ids  int (multi) — whitelist of ticket_numbers to include; if
                                omitted, all of the requester's tickets
                                (from the local native_ticket_index)
    """
    email = request.args.get('email', '').strip()
    if not email:
        return jsonify(context='')

    ticket_ids_raw = request.args.getlist('ticket_ids')
    allowed_numbers = {int(x) for x in ticket_ids_raw if x.lstrip('-').isdigit()} if ticket_ids_raw else None

    conn = get_db()
    rows = conn.execute(
        "SELECT ticket_number, native_id, subject, created_at, status "
        "FROM native_ticket_index WHERE requester_email = ? ORDER BY created_at DESC",
        (email,),
    ).fetchall()
    conn.close()

    tickets = [dict(r) for r in rows]
    if allowed_numbers is not None:
        tickets = [t for t in tickets if t['ticket_number'] in allowed_numbers]

    lines = [
        f'CLIENT: {email}',
        f'Total tickets in context: {len(tickets)}',
        '',
    ]

    # Budget: fetch full message content for the first 10 tickets — the local
    # index has metadata for all of them (cheap), but each full thread is a
    # live API call, same tradeoff Freshdesk's version makes.
    # Real, user-reported slowness (2026-09-08, "slow loading issues
    # again"): these 10 fetches ran one at a time, directly in the path of
    # the interactive "Ask Claude" box — same shape already fixed
    # elsewhere in this file. Text order still matches `tickets`' order
    # (decided upfront, fetched concurrently, assembled back in order) —
    # only the fetching itself is concurrent, not the resulting document.
    import concurrent.futures
    conv_budget = 10
    DESC_LIMIT = 8000
    MSG_LIMIT = 4000
    to_fetch = [t['native_id'] for t in tickets if t.get('native_id')][:conv_budget]

    def _fetch_detail(native_id):
        detail, err = _api('GET', f"/api/admin/tickets/{native_id}")
        return native_id, (detail if not err and detail else None)

    detail_by_id = {}
    if to_fetch:
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for native_id, detail in pool.map(_fetch_detail, to_fetch):
                if detail:
                    detail_by_id[native_id] = detail

    for t in tickets:
        lines.append(f"--- Ticket #{t['ticket_number']}: {t.get('subject') or '(no subject)'} ---")
        lines.append(f"Status: {t.get('status') or '?'}  Created: {t.get('created_at') or '?'}")

        detail = detail_by_id.get(t.get('native_id'))
        if detail:
            desc = (detail.get('ticket') or {}).get('description') or ''
            if desc:
                truncated = len(desc) > DESC_LIMIT
                lines.append(f'Description:\n{desc[:DESC_LIMIT]}{"  [… TRUNCATED]" if truncated else ""}')
            for m in (detail.get('messages') or []):
                body = (m.get('body') or '').strip()
                if body:
                    truncated = len(body) > MSG_LIMIT
                    who = 'Agent' if m.get('direction') == 'outbound' else 'Client'
                    lines.append(f"  [{m.get('created_at', '?')}] {who}:\n  {body[:MSG_LIMIT]}{'  [… TRUNCATED]' if truncated else ''}")
        lines.append('')

    return jsonify(context='\n'.join(lines))


@bp.route('/api/fadmin/tickets/<ticket_id>/note', methods=['POST'])
def fadmin_ticket_note(ticket_id):
    body = request.get_json(force=True) or {}
    data, err = _api('POST', f'/api/admin/tickets/{ticket_id}/note', json=body)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {}), 201


@bp.route('/api/fadmin/tickets/<ticket_id>/message', methods=['POST'])
def fadmin_ticket_message(ticket_id):
    """Log a message (inbound or outbound) that already happened — no side effects."""
    body = request.get_json(force=True) or {}
    data, err = _api('POST', f'/api/admin/tickets/{ticket_id}/message', json=body)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {}), 201


@bp.route('/api/fadmin/tickets/<ticket_id>', methods=['DELETE'])
def fadmin_ticket_delete(ticket_id):
    data, err = _api('DELETE', f'/api/admin/tickets/{ticket_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/tickets/<ticket_id>/presence', methods=['GET'])
def fadmin_ticket_presence_get(ticket_id):
    data, err = _api('GET', f'/api/admin/tickets/{ticket_id}/presence')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/tickets/<ticket_id>/presence', methods=['POST'])
def fadmin_ticket_presence_ping(ticket_id):
    data, err = _api('POST', f'/api/admin/tickets/{ticket_id}/presence')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/tickets/import', methods=['POST'])
def fadmin_tickets_import():
    """Bulk historical import (Freshdesk migration) — no side effects server-side."""
    body = request.get_json(force=True) or {}
    data, err = _api('POST', '/api/admin/tickets/import', json=body)
    if err:
        return jsonify({'error': err}), 503
    _index_imported_tickets(body, data or {})
    return jsonify(data or {})


def _index_imported_tickets(request_body, response):
    """
    The import response (see FREECORDS_API_REFERENCE.md) gives back
    ticket_number + status per row but never the native UUID, so there's no
    cheap way to upsert native_ticket_index straight from it the way
    _index_native_ticket's other callers can. Resolve each ticket_number to
    its UUID with a date_from/date_to window narrowed around the createdAt
    already in our own request body, rather than scanning "newest" —
    confirmed live (2026-09-08) that a batch of imported tickets sat
    unindexed across several app restarts because the once-per-launch
    backfill in main.py never completed a full pass over 62,000+ tickets.
    Runs for every ticket_number in the request, not just ones the response
    marks 'imported' — a re-run against an already-imported batch (exactly
    what surfaced the bug above) is a legitimate way to repair a stale
    index entry, and import itself is idempotent either way.

    Each ticket_number's resolution is fully independent of every other's
    (own date window, own page scan) — parallelized across tickets in the
    batch (2026-09-08, "make anything faster"). The inner up-to-5-page scan
    per ticket stays sequential-with-early-exit as-is: it usually finds its
    match on page 1-2, so blindly firing all 5 pages per ticket would waste
    calls in the common case, unlike the fully-independent outer loop.
    """
    import concurrent.futures
    tickets_sent = request_body.get('tickets') if 'tickets' in request_body else [request_body]

    def _resolve_one(t):
        num = t.get('ticketNumber')
        if not num:
            return
        created_at = t.get('createdAt')
        params = {'limit': 100}
        if created_at:
            try:
                dt0 = _dt.datetime.fromisoformat(created_at.replace('Z', '+00:00'))
                params['date_from'] = (dt0 - _dt.timedelta(hours=12)).isoformat()
                params['date_to'] = (dt0 + _dt.timedelta(hours=12)).isoformat()
            except Exception:
                pass
        found = None
        page = 1
        while page <= 5:
            d, e = _api('GET', '/api/admin/tickets', params={**params, 'page': page})
            if e or not d:
                break
            rows = d.get('tickets', [])
            for row in rows:
                if row.get('ticket_number') == num:
                    found = row
                    break
            if found or len(rows) < params['limit']:
                break
            page += 1
        if found:
            _index_native_ticket(found)

    if len(tickets_sent) > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            list(pool.map(_resolve_one, tickets_sent))
    else:
        for t in tickets_sent:
            _resolve_one(t)


# ── Local attachment serving (moved from freshdesk.py — Freshdesk retired,
# this table (ticket_attachment_files, see helpers.store_ticket_attachment_files)
# is local-only and never depended on the Freshdesk API to begin with) ────────

def _local_attachments(ticket_number):
    """filename -> relative file_path for every locally-stored attachment of
    this ticket."""
    conn = get_db()
    rows = conn.execute(
        "SELECT filename, content_type, size, file_path FROM ticket_attachment_files WHERE ticket_number=?",
        (ticket_number,),
    ).fetchall()
    conn.close()
    return rows


@bp.route('/api/fadmin/ticket-attachment/<int:ticket_number>/<path:filename>')
def fadmin_ticket_attachment(ticket_number, filename):
    """Serves a locally-stored ticket attachment's actual bytes."""
    for row in _local_attachments(ticket_number):
        if row['filename'] == filename:
            path = APP_SUPPORT / row['file_path']
            if not path.exists():
                return jsonify(error='file missing on disk'), 404
            return send_file(str(path), download_name=filename)
    return jsonify(error='not found locally'), 404


@bp.route('/api/fadmin/attachment-cache')
def fadmin_attachment_cache():
    """
    Bulk-read the local attachment-presence cache for a set of ticket
    numbers, for the Tickets list's paperclip icon — cheap, local-only.
    Tickets never checked are simply absent from the response; the
    frontend treats that as "unknown", not "no attachments" (moved from
    freshdesk.py — Freshdesk retired; that version also kicked off a
    background live-Freshdesk enrichment for uncached tickets, gated
    behind a setting that defaulted off and can never do anything useful
    now, so it's dropped rather than moved).

    Query params:
      ticket_numbers  str  — comma-separated ticket numbers
    """
    raw = request.args.get('ticket_numbers', '')
    try:
        numbers = [int(n) for n in raw.split(',') if n.strip()]
    except ValueError:
        return jsonify(error='ticket_numbers must be comma-separated integers'), 400
    if not numbers:
        return jsonify(cache={})

    conn = get_db()
    placeholders = ','.join('?' * len(numbers))
    local_rows = conn.execute(
        f"SELECT DISTINCT ticket_number FROM ticket_attachment_files WHERE ticket_number IN ({placeholders})",
        numbers,
    ).fetchall()
    has_local = {r['ticket_number'] for r in local_rows}
    backfilled_rows = conn.execute(
        f"SELECT ticket_number FROM ticket_attachment_backfill_done WHERE ticket_number IN ({placeholders})",
        numbers,
    ).fetchall()
    backfilled = {r['ticket_number'] for r in backfilled_rows}
    native_only_rows = conn.execute(
        f"SELECT ticket_number FROM native_ticket_index WHERE ticket_number IN ({placeholders}) "
        f"AND thread_ref IS NOT NULL AND thread_ref != ''",
        numbers,
    ).fetchall()
    native_only = {r['ticket_number'] for r in native_only_rows}
    old_cache_rows = conn.execute(
        f"SELECT ticket_number, has_attachments FROM ticket_attachment_cache "
        f"WHERE ticket_number IN ({placeholders})",
        numbers,
    ).fetchall()
    conn.close()

    result = {n: bool(n in has_local) for n in numbers if n in backfilled}
    for r in old_cache_rows:
        result.setdefault(r['ticket_number'], bool(r['has_attachments']))
    for n in native_only:
        result.setdefault(n, n in has_local)

    return jsonify(cache=result)


def _mailbox_attachments(ticket_number):
    """Files the customer actually emailed for this ticket, read straight from the
    support@ mailbox cache. **Nguyen**: "cannot locate any files/links/docs in the
    reply of this ticket" (#68696). Since the Freshdesk sync loops were removed and
    mail intake moved to the cloud, NOTHING stores a native ticket's attachments any
    more (the thread messages carry text only), so customers' screenshots/PDFs sent in
    a reply were invisible anywhere in Tickets. The mail itself still has them.

    A mail belongs to the ticket if (a) it was sent to support+<thread_ref>@ (every
    reply), or (b) it is the opening email: same sender as the requester, within 15
    minutes of the ticket's creation. message_cache.date is the machine's LOCAL time."""
    import mimetypes
    import time as _t
    conn = get_db()
    row = conn.execute(
        "SELECT thread_ref, requester_email, created_at FROM native_ticket_index WHERE ticket_number=?",
        (ticket_number,)).fetchone()
    if not row:
        conn.close()
        return []
    ref, requester = (row['thread_ref'] or '').strip(), (row['requester_email'] or '').strip().lower()
    try:
        created = _parse_iso_ts(row['created_at'])
    except Exception:
        created = None
    cond, args = [], [SUPPORT_ACCOUNT]
    if ref:
        cond.append("to_addrs LIKE ? OR cc LIKE ?")
        args += [f'%+{ref}@%', f'%+{ref}@%']
    if requester and created:
        cond.append("LOWER(from_addr)=?")
        args.append(requester)
    if not cond:
        conn.close()
        return []
    mails = conn.execute(
        "SELECT uid, date, from_addr, to_addrs, cc, attachment_names FROM message_cache "
        f"WHERE account=? AND folder='INBOX' AND has_attachment=1 AND ({' OR '.join('(' + c + ')' for c in cond)}) "
        "ORDER BY date DESC LIMIT 60", args).fetchall()
    conn.close()
    out = []
    for m in mails:
        is_reply = bool(ref) and f'+{ref}@' in f"{m['to_addrs'] or ''} {m['cc'] or ''}"
        if not is_reply:
            try:
                local_ts = _t.mktime(_t.strptime(str(m['date'])[:19], '%Y-%m-%d %H:%M:%S'))
            except Exception:
                continue
            if created is None or abs(local_ts - created) > 15 * 60:
                continue
        for name in [n for n in (m['attachment_names'] or '').split('\n') if n]:
            out.append({
                'name': name,
                'content_type': mimetypes.guess_type(name)[0] or 'application/octet-stream',
                'size': None,
                'attachment_url': (f"{request.host_url.rstrip('/')}/api/messages/{m['uid']}/attachment"
                                   f"?folder=INBOX&account={SUPPORT_ACCOUNT}&filename={urllib.parse.quote(name)}"),
                '_received': str(m['date'])[:16],
                '_from_mailbox': True,
            })
    return out


def _parse_iso_ts(s):
    return _dt.datetime.fromisoformat((s or '').replace('Z', '+00:00')).timestamp()


@bp.route('/api/fadmin/ticket-attachments-local/<int:ticket_number>')
def fadmin_ticket_attachments_local(ticket_number):
    """Attachment listing for a ticket: files stored locally (imported Freshdesk
    tickets) plus, for native tickets, whatever the customer emailed (see
    _mailbox_attachments)."""
    rows = _local_attachments(ticket_number)
    attachments = [{
        'name': r['filename'],
        'content_type': r['content_type'],
        'size': r['size'],
        'attachment_url': f"{request.host_url.rstrip('/')}/api/fadmin/ticket-attachment/{ticket_number}/{r['filename']}",
    } for r in rows]
    try:
        conn = get_db()
        row = conn.execute("SELECT native_id FROM native_ticket_index WHERE ticket_number=?", (ticket_number,)).fetchone()
        conn.close()
        if row:
            cloud, cerr = _api('GET', f"/api/admin/tickets/{row['native_id']}/attachments")
            if not cerr and cloud:
                attachments += [_attachment_row(a) for a in cloud.get('attachments', [])]
    except Exception:
        pass
    try:
        have = {a['name'] for a in attachments}
        attachments += [a for a in _mailbox_attachments(ticket_number) if a['name'] not in have]
    except Exception:
        pass
    return jsonify(attachments=attachments, backfilled=True)


# ── Anthropic key management + in-app Claude chat (moved from freshdesk.py —
# used app-wide by BulkReplyPanel/ComposeOverlay/SupportCompose/
# UserMissionControlPanel/AccountBar/Settings, not Freshdesk-specific) ────────

@bp.route('/api/fadmin/anthropic-key', methods=['POST'])
def fadmin_save_anthropic_key():
    """Store Anthropic API key (and optional workspace ID) in keychain."""
    data = request.get_json(silent=True) or {}
    key = (data.get('key') or '').strip()
    if not key:
        return jsonify(error='key required'), 400
    # The frontend re-sends the masked '••••••••' placeholder as `key` when
    # only the workspace ID field is being saved (it never has the real
    # key value to resend) — must not overwrite the real stored key with
    # this literal string.
    if key != '••••••••':
        keyring.set_password(ANTHROPIC_KEYRING, 'api_key', key)
    # Anthropic requires every request from an organization account to
    # declare which workspace it belongs to. Not a secret — a workspace id,
    # not a credential — but stored the same way for simplicity.
    # `workspace_id` is only touched when the field is actually present in
    # the request, so saving just the key never wipes a previously-set one.
    if 'workspace_id' in data:
        workspace_id = (data.get('workspace_id') or '').strip()
        if workspace_id:
            keyring.set_password(ANTHROPIC_KEYRING, 'workspace_id', workspace_id)
        else:
            try:
                keyring.delete_password(ANTHROPIC_KEYRING, 'workspace_id')
            except Exception:
                pass
    return jsonify(ok=True)


@bp.route('/api/fadmin/anthropic-key')
def fadmin_get_anthropic_key_status():
    """Whether an Anthropic key is stored, plus the workspace ID if set —
    not a secret, so safe to echo back for the Settings UI to show/edit
    (unlike the key itself, which is never returned)."""
    key = keyring.get_password(ANTHROPIC_KEYRING, 'api_key')
    workspace_id = keyring.get_password(ANTHROPIC_KEYRING, 'workspace_id') or ''
    return jsonify(configured=bool(key), workspace_id=workspace_id)


_ATTACH_MEDIA_MAX = 5              # cap per request — cost/latency, not an API hard limit
_ATTACH_MEDIA_MAX_BYTES = 5 * 1024 * 1024  # Claude's own per-image limit; conservative for PDFs too


def _fetch_media_blocks(urls):
    """
    Fetch attachment URLs server-side and return them as Claude content
    blocks (base64 image or PDF document) — used so the Claude suggestion
    can actually see what's in a screenshot or read a PDF, not just know a
    file with that name exists. Silently skips anything that fails to
    fetch, isn't an image/PDF, or is oversized, rather than failing the
    whole suggestion over one bad attachment.
    """
    blocks = []
    for url in (urls or [])[:_ATTACH_MEDIA_MAX]:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Overlord/1.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                content_type = (resp.headers.get('Content-Type', '') or '').split(';')[0]
                data = resp.read(_ATTACH_MEDIA_MAX_BYTES + 1)
            if len(data) > _ATTACH_MEDIA_MAX_BYTES:
                continue
            if content_type.startswith('image/'):
                block_type = 'image'
            elif content_type == 'application/pdf':
                block_type = 'document'
            else:
                continue
            blocks.append({
                'type': block_type,
                'source': {'type': 'base64', 'media_type': content_type, 'data': base64.b64encode(data).decode('ascii')},
            })
        except Exception:
            continue
    return blocks


@bp.route('/api/fadmin/claude-ask', methods=['POST'])
def fadmin_claude_ask():
    """
    Send a message + optional context to Claude and return the response inline.

    Body: {
      messages: [{role:'user'|'assistant', content:'...'}],   # full history
      system:   '...',   # optional system prompt / client context
      media_urls: ['...']   # optional — image/PDF attachment URLs, fetched
                             # server-side and attached as real content to
                             # the first user message.
    }
    """
    client, client_err = get_anthropic_client()
    if client_err:
        return jsonify(error=client_err), 503

    data = request.get_json(silent=True) or {}
    messages = data.get('messages') or []
    system   = (data.get('system') or '').strip()
    media_urls = data.get('media_urls') or data.get('image_urls') or []

    if not messages:
        return jsonify(error='messages required'), 400

    if media_urls:
        media_blocks = _fetch_media_blocks(media_urls)
        if media_blocks:
            first = messages[0]
            existing = first.get('content')
            if isinstance(existing, str):
                first['content'] = [{'type': 'text', 'text': existing}] + media_blocks
            elif isinstance(existing, list):
                first['content'] = existing + media_blocks

    try:
        kwargs = dict(
            model='claude-sonnet-5',
            # A lower ceiling produced a genuinely empty completion with no
            # error before (claude-sonnet-5 can emit a ThinkingBlock, and
            # thinking tokens count against max_tokens same as output). This
            # endpoint's real output is one email body, normally a few
            # hundred tokens, so 4096 is generous headroom against
            # reasoning overhead, not an expectation of long output.
            max_tokens=4096,
            messages=messages,
        )
        if system:
            # The frontend builds this once per conversation (ticket history +
            # account data + reference context) but the API is stateless, so
            # without caching every turn of a multi-turn chat re-bills the
            # full block again. cache_control lets Anthropic reuse it for
            # ~5 minutes instead.
            kwargs['system'] = [{'type': 'text', 'text': system, 'cache_control': {'type': 'ephemeral'}}]
        resp = client.messages.create(**kwargs)
        # resp.content[0] isn't reliably the text block — claude-sonnet-5 can
        # return a ThinkingBlock first (no .text attribute). Concatenate
        # every actual text block instead of assuming position.
        reply = ''.join(block.text for block in (resp.content or []) if getattr(block, 'type', None) == 'text')
        if not reply:
            import logging
            logging.error('claude-ask: empty reply, stop_reason=%s, content=%r', getattr(resp, 'stop_reason', None), resp.content)
        return jsonify(reply=reply)
    except Exception as e:
        import logging
        logging.error('claude-ask error: %s', e)
        if is_credit_error(e):
            return jsonify(error=CREDIT_ERROR_CODE), 402
        return jsonify(error=str(e)), 502


# ── Artist web search (label representation / impersonation check) ────────────
# Native Freecords feature (Nik's round-5 response, item 11) — replaces the
# earlier Overlord-side version that spent our own Claude tokens per song.
# This one is artist-keyed (not song-keyed), runs on Freecords' own Claude
# key via their backend ($0.07-0.15/run, none of it ours), persists its own
# history server-side, and supports a persistent clean-mark. Client timeout
# kept just above their own 85s self-imposed cap (DigitalOcean App Platform's
# hard, unconfigurable 100s edge timeout) so we get their real response/error
# instead of timing out first.

@bp.route('/api/fadmin/artist-search', methods=['POST'])
def fadmin_trigger_artist_search():
    body            = request.get_json(force=True) or {}
    artist_id       = (body.get('artist_id') or '').strip()
    artist_username = (body.get('artist_username') or '').strip()
    song_id         = (body.get('song_id') or '').strip()
    if not artist_id:
        return jsonify({'error': 'artist_id required'}), 400
    payload = {'artistId': artist_id, 'artistUsername': artist_username}
    if song_id:
        payload['songId'] = song_id
    data, err = _api('POST', '/api/admin/moderation/trigger-artist-search', json=payload, timeout=95)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/artist-search/<artist_id>')
def fadmin_get_artist_search(artist_id):
    data, err = _api('GET', f'/api/admin/moderation/artist-search/{artist_id}')
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})


@bp.route('/api/fadmin/artist-clean-status/<artist_id>', methods=['PUT'])
def fadmin_set_artist_clean_status(artist_id):
    body = request.get_json(force=True) or {}
    data, err = _api('PUT', f'/api/admin/moderation/artist-clean-status/{artist_id}', json=body)
    if err:
        return jsonify({'error': err}), 503
    return jsonify(data or {})
