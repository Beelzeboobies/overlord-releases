import re as _re
import threading

from flask import Blueprint, request, jsonify

from db import get_db
from imap import (imap_connect, _build_folder_map, resolve_folder, get_delimiter,
                  _folder_cache, _unread_cache_lock, _refresh_unread_counts)

bp = Blueprint('folders', __name__)


@bp.route('/api/folders')
def list_folders():
    account  = request.args.get('account') or None
    acct_key = (account or 'default')

    with _unread_cache_lock:
        cached = list(_folder_cache.get(acct_key, []))

    # Always kick off a background refresh so counts stay fresh
    threading.Thread(target=_refresh_unread_counts, args=(account,), daemon=True).start()

    if cached:
        return jsonify(cached)

    # First ever call — do a quick synchronous fetch (folder names only, no status)
    # Use pool connection but do NOT logout — the pool owns its lifetime
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    folders = []
    for flags, delimiter, name in client.list_folders():
        flags_list = [f.decode() if isinstance(f, bytes) else f for f in flags]
        folders.append({'name': name, 'flags': flags_list, 'unread': 0})
    return jsonify(folders)


# ── Folder management ─────────────────────────────────────────────────────────

# Validates NEW typed folder names (create / rename).  Intentionally stricter
# than safe_folder() in imap.py, which validates existing server-assigned paths
# (where '/', '.', brackets etc. are legitimate IMAP-assigned characters).
# '.' is excluded here: Dovecot uses it as the hierarchy separator, so a leaf
# name containing '.' would silently create an extra nesting level on rename.
SAFE_FOLDER_NAME_RE = _re.compile(r'^[a-zA-Z0-9 _\-]{1,100}$')

def _validate_folder_name(name: str) -> bool:
    """Only allow safe characters in new folder names to prevent IMAP injection
    and accidental hierarchy creation via the Dovecot '.' separator."""
    return bool(SAFE_FOLDER_NAME_RE.match(name))


@bp.route('/api/folders/create', methods=['POST', 'OPTIONS'])
def create_folder_api():
    if request.method == 'OPTIONS': return '', 204
    b = request.get_json()
    account = b.get('account', '')
    parent  = b.get('parent', '')   # e.g. 'INBOX.Work' — empty means top-level
    name    = b.get('name', '').strip()
    if not _validate_folder_name(name):
        return jsonify(error='Invalid folder name. Use letters, numbers, spaces, _ and - only.'), 400
    delim = get_delimiter(account)
    full_name = f'{parent}{delim}{name}' if parent else name
    try:
        client = imap_connect(account)
        client.create_folder(full_name)
        _build_folder_map(account)   # refresh cache
        return jsonify(ok=True, name=full_name)
    except Exception as e:
        msg = str(e)
        if 'already exists' in msg.lower(): return jsonify(error='Folder already exists'), 409
        return jsonify(error=msg), 500


@bp.route('/api/folders/rename', methods=['POST', 'OPTIONS'])
def rename_folder_api():
    if request.method == 'OPTIONS': return '', 204
    b = request.get_json()
    account  = b.get('account', '')
    old_name = b.get('old_name', '').strip()
    new_leaf  = b.get('new_name', '').strip()   # just the leaf, not the full path
    if not old_name or not _validate_folder_name(new_leaf):
        return jsonify(error='Invalid folder name.'), 400
    # Build new full path (same parent, new leaf) using the account's IMAP
    # hierarchy separator — '.' on Dovecot, '/' on Gmail, etc.
    delim    = get_delimiter(account)
    parts    = old_name.split(delim)
    parts[-1] = new_leaf
    new_name = delim.join(parts)
    try:
        client = imap_connect(account)
        client.rename_folder(old_name, new_name)
        # Update message cache to point at new folder name
        conn = get_db()
        conn.execute('UPDATE message_cache SET folder=? WHERE folder=? AND account=?', (new_name, old_name, account))
        conn.commit(); conn.close()
        _build_folder_map(account)
        return jsonify(ok=True, name=new_name)
    except Exception as e:
        return jsonify(error=str(e)), 500


@bp.route('/api/folders/delete', methods=['POST', 'OPTIONS'])
def delete_folder_api():
    if request.method == 'OPTIONS': return '', 204
    b = request.get_json()
    account = b.get('account', '')
    name    = b.get('name', '').strip()
    # Never allow deleting system folders
    PROTECTED = {'INBOX', 'Sent', 'Drafts', 'Trash', 'Archive', 'Spam', 'Junk'}
    if not name or name.upper() in {p.upper() for p in PROTECTED}:
        return jsonify(error='Cannot delete system folders.'), 400
    try:
        client = imap_connect(account)
        # Move all messages to Trash first so we don't lose them silently
        try:
            trash = resolve_folder('Trash', account)
            client.select_folder(name)
            uids = client.search(['ALL'])
            if uids:
                client.move(uids, trash)
        except Exception:
            pass
        client.delete_folder(name)
        conn = get_db()
        conn.execute('DELETE FROM message_cache WHERE folder=? AND account=?', (name, account))
        conn.commit(); conn.close()
        _build_folder_map(account)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=str(e)), 500
