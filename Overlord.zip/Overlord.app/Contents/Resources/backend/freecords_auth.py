"""
freecords_auth.py — Freecords admin authentication for Overlord.

Flow
----
1. login() picks a free localhost port, generates a random `state`,
   starts a temporary local HTTP server, and opens the system browser to
   https://dev.freecords.com/admin/overlord-auth?port=<port>&state=<state>
2. The admin logs into Freecords in the browser (if not already) and clicks
   "Authorize Overlord on this device".
3. Freecords redirects the browser to
   http://127.0.0.1:<port>/callback?token=<jwt>&state=<state>
4. This module verifies `state` matches, stores the token in the OS keychain
   via `keyring`, and shuts the local server down.

The token is a JWT tied to the admin's Freecords account, valid for 7 days.
Send it on every API request as:  Authorization: Bearer <token>

Dependencies:  pip install keyring requests
(requests is only needed for the api_request helper / example usage)

Security notes
--------------
- The token is stored ONLY in the OS keychain (never in files, env vars,
  or logs). Do not print or log the token.
- On HTTP 401 the token has expired or been revoked — call login() again.
- Revocation is server-side: Freecords can kill all access instantly.
"""

from __future__ import annotations

import http.server
import secrets
import socket
import threading
import urllib.parse
import webbrowser

import keyring

FREECORDS_BASE_URL = "https://dev.freecords.com"
# Both the admin API and the /admin/overlord-auth login page live on dev.
# www.freecords.com is the marketing site (Webflow-hosted) and has neither —
# confirmed directly: www.freecords.com/admin/overlord-auth returns 404 (a
# Webflow "Not Found" page), dev.freecords.com/admin/overlord-auth returns a
# real 307 redirect. An earlier version of this file split these into two
# hosts based on a colleague report that turned out to be wrong (or stale);
# if login ever needs a different host than the API again, confirm with a
# direct curl test like the one above before changing this, not from a
# secondhand report.
FREECORDS_AUTH_BASE_URL = FREECORDS_BASE_URL
AUTH_PAGE_PATH = "/admin/overlord-auth"
KEYRING_SERVICE = "overlord"
KEYRING_USERNAME = "freecords_token"
AUTH_TIMEOUT_SECONDS = 180  # how long to wait for the browser authorization


class AuthError(Exception):
    """Raised when the browser authorization flow fails or times out."""


def get_token() -> str | None:
    """Return the stored token from the OS keychain, or None if absent."""
    return keyring.get_password(KEYRING_SERVICE, KEYRING_USERNAME)


def clear_token() -> None:
    """Delete the stored token from the OS keychain (ignore if absent)."""
    try:
        keyring.delete_password(KEYRING_SERVICE, KEYRING_USERNAME)
    except keyring.errors.PasswordDeleteError:
        pass


def auth_headers() -> dict:
    """Return the Authorization header dict for API requests.

    Raises AuthError if no token is stored — call login() first.
    """
    token = get_token()
    if not token:
        raise AuthError("No Freecords token stored. Call login() first.")
    return {"Authorization": f"Bearer {token}"}


def _find_free_port() -> int:
    """Ask the OS for a free localhost port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def login(timeout: int = AUTH_TIMEOUT_SECONDS) -> str:
    """Run the full browser authorization flow.

    Opens the system browser to Freecords, waits for the callback, verifies
    the `state` parameter, stores the token in the OS keychain, and returns it.

    Raises AuthError on timeout or state mismatch.
    """
    port = _find_free_port()
    expected_state = secrets.token_urlsafe(32)

    result: dict = {"token": None, "error": None}
    done = threading.Event()

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802 (stdlib naming)
            parsed = urllib.parse.urlparse(self.path)

            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return

            params = urllib.parse.parse_qs(parsed.query)
            token = params.get("token", [None])[0]
            state = params.get("state", [None])[0]

            if state != expected_state:
                result["error"] = "State mismatch — possible token injection. Aborted."
                self._respond(400, "Authorization failed: state mismatch. "
                                   "Please try again from Overlord.")
            elif not token:
                result["error"] = "Callback received without a token."
                self._respond(400, "Authorization failed: no token received.")
            else:
                result["token"] = token
                self._respond(200, "Overlord is now connected to Freecords. "
                                   "You can close this window.")

            done.set()

        def _respond(self, code: int, message: str):
            body = (
                "<html><head><title>Overlord</title></head>"
                "<body style=\"font-family: Rubik, sans-serif; background:#152A55; "
                "color:#fff; display:flex; align-items:center; justify-content:center; "
                "height:100vh; margin:0;\">"
                f"<div style=\"text-align:center;\"><h2 style=\"color:#C5B358;\">"
                f"{'Connected' if code == 200 else 'Authorization failed'}</h2>"
                f"<p>{message}</p></div></body></html>"
            ).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format, *args):  # noqa: A002
            pass  # silence default request logging (never log the token URL)

    server = http.server.HTTPServer(("127.0.0.1", port), CallbackHandler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    try:
        query = urllib.parse.urlencode({"port": port, "state": expected_state})
        webbrowser.open(f"{FREECORDS_AUTH_BASE_URL}{AUTH_PAGE_PATH}?{query}")

        if not done.wait(timeout):
            raise AuthError(
                f"Timed out after {timeout}s waiting for browser authorization."
            )
    finally:
        server.shutdown()
        server.server_close()

    if result["error"]:
        raise AuthError(result["error"])

    token = result["token"]
    keyring.set_password(KEYRING_SERVICE, KEYRING_USERNAME, token)
    return token


def api_request(method: str, path: str, **kwargs):
    """Convenience wrapper: authenticated request with automatic re-login on 401.

    Example:
        resp = api_request("GET", "/api/admin/tickets")
        resp = api_request("POST", "/api/admin/moderation/deny",
                           json={"songId": "...", "reason": "copyright"})
    """
    import requests  # local import so the module works without requests installed

    if get_token() is None:
        login()

    url = f"{FREECORDS_BASE_URL}{path}"
    headers = {**kwargs.pop("headers", {}), **auth_headers()}
    response = requests.request(method, url, headers=headers, **kwargs)

    if response.status_code == 401:
        # Token expired or revoked — clear it, re-run the browser flow, retry once
        clear_token()
        login()
        headers = {**headers, **auth_headers()}
        response = requests.request(method, url, headers=headers, **kwargs)

    return response


if __name__ == "__main__":
    # Manual test: run `python freecords_auth.py` to trigger the browser flow.
    print("Opening browser for Freecords authorization…")
    login()
    print("Connected. Token stored in the OS keychain.")
