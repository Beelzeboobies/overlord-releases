import sys
from pathlib import Path


def _app_data_dir():
    """Per-user app data directory, OS-appropriate. Single source of truth —
    window.py must import this rather than hardcoding its own copy."""
    if sys.platform == 'darwin':
        return Path.home() / 'Library' / 'Application Support' / 'Overlord'
    if sys.platform == 'win32':
        import os
        return Path(os.environ.get('APPDATA', Path.home())) / 'Overlord'
    return Path.home() / '.local' / 'share' / 'Overlord'  # Linux/other


# User data lives in an OS-appropriate per-user directory.
# On macOS this survives app updates (drag new .app over old one in /Applications).
APP_SUPPORT = _app_data_dir()
APP_SUPPORT.mkdir(parents=True, exist_ok=True)

# Uploads directory (signature images, fonts)
SETTINGS_PATH = APP_SUPPORT / 'uploads'
SETTINGS_PATH.mkdir(exist_ok=True)

# Frontend build output — config.py is in backend/, so .parent.parent == repo
# root in dev mode. In a PyInstaller-frozen build, __file__ for a bundled
# module does NOT resolve to a real on-disk path the same way, so
# .parent.parent lands somewhere that doesn't contain frontend/dist at all —
# confirmed live: send_from_directory 404'd on index.html in a fresh install
# despite the file genuinely existing under _MEIPASS, because this computed
# the wrong base directory. sys._MEIPASS is PyInstaller's own pointer to
# wherever --add-data assets actually land (see windows/build_windows.py),
# and is already used correctly elsewhere (updates.py's
# _read_local_version()) — this just hadn't been updated to match.
_FRONTEND_BASE = Path(sys._MEIPASS) if getattr(sys, 'frozen', False) else Path(__file__).parent.parent
FRONTEND_DIST   = _FRONTEND_BASE / 'frontend' / 'dist'
FRONTEND_PUBLIC = _FRONTEND_BASE / 'frontend' / 'public'

# ── Keychain service names ────────────────────────────────────────────────────
KEYRING_SERVICE     = 'freecords-mail'
ANTHROPIC_KEYRING      = 'freecords-anthropic'
FREECORDS_ADMIN_KEYRING = 'freecords-admin'

# ── Default server (Freecords hosting) ───────────────────────────────────────
# Used as fallback if no per-account config exists
DEFAULT_IMAP_HOST = 'premium79.web-hosting.com'
DEFAULT_IMAP_PORT = 993
DEFAULT_SMTP_HOST = 'premium79.web-hosting.com'
DEFAULT_SMTP_PORT = 465

# ── Known provider configs ────────────────────────────────────────────────────
PROVIDER_CONFIGS = {
    'gmail.com':        {'imap_host':'imap.gmail.com',            'imap_port':993,  'smtp_host':'smtp.gmail.com',            'smtp_port':465},
    'googlemail.com':   {'imap_host':'imap.gmail.com',            'imap_port':993,  'smtp_host':'smtp.gmail.com',            'smtp_port':465},
    'outlook.com':      {'imap_host':'outlook.office365.com',     'imap_port':993,  'smtp_host':'smtp.office365.com',        'smtp_port':587},
    'hotmail.com':      {'imap_host':'outlook.office365.com',     'imap_port':993,  'smtp_host':'smtp.office365.com',        'smtp_port':587},
    'live.com':         {'imap_host':'outlook.office365.com',     'imap_port':993,  'smtp_host':'smtp.office365.com',        'smtp_port':587},
    'msn.com':          {'imap_host':'outlook.office365.com',     'imap_port':993,  'smtp_host':'smtp.office365.com',        'smtp_port':587},
    'yahoo.com':        {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',       'smtp_port':465},
    'yahoo.co.uk':      {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',       'smtp_port':465},
    'ymail.com':        {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',       'smtp_port':465},
    'icloud.com':       {'imap_host':'imap.mail.me.com',          'imap_port':993,  'smtp_host':'smtp.mail.me.com',         'smtp_port':587},
    'me.com':           {'imap_host':'imap.mail.me.com',          'imap_port':993,  'smtp_host':'smtp.mail.me.com',         'smtp_port':587},
    'mac.com':          {'imap_host':'imap.mail.me.com',          'imap_port':993,  'smtp_host':'smtp.mail.me.com',         'smtp_port':587},
    # Zoho — US, EU, India, Australia data centres
    'zoho.com':         {'imap_host':'imap.zoho.com',             'imap_port':993,  'smtp_host':'smtp.zoho.com',            'smtp_port':465},
    'zohomail.com':     {'imap_host':'imap.zoho.com',             'imap_port':993,  'smtp_host':'smtp.zoho.com',            'smtp_port':465},
    'zoho.eu':          {'imap_host':'imappro.zoho.eu',           'imap_port':993,  'smtp_host':'smtppro.zoho.eu',          'smtp_port':465},
    'zoho.in':          {'imap_host':'imap.zoho.in',              'imap_port':993,  'smtp_host':'smtp.zoho.in',             'smtp_port':465},
    'zoho.com.au':      {'imap_host':'imap.zoho.com.au',          'imap_port':993,  'smtp_host':'smtp.zoho.com.au',         'smtp_port':465},
    # Fastmail — all TLDs route to the same servers
    'fastmail.com':     {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.fm':      {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.net':     {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.to':      {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.org':     {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.cn':      {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.jp':      {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.es':      {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fastmail.de':      {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'fmailbox.com':     {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    'ftml.net':         {'imap_host':'imap.fastmail.com',         'imap_port':993,  'smtp_host':'smtp.fastmail.com',        'smtp_port':465},
    # Yahoo international (all use the same IMAP/SMTP endpoints as yahoo.com)
    'yahoo.fr':         {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.de':         {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.es':         {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.it':         {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.com.au':     {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.ca':         {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.com.br':     {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.com.mx':     {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.com.ar':     {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    'yahoo.in':         {'imap_host':'imap.mail.yahoo.com',       'imap_port':993,  'smtp_host':'smtp.mail.yahoo.com',      'smtp_port':465},
    # AOL
    'aol.com':          {'imap_host':'imap.aol.com',              'imap_port':993,  'smtp_host':'smtp.aol.com',             'smtp_port':465},
    # Freecords (default hosting)
    'freecords.com':    {'imap_host':'premium79.web-hosting.com', 'imap_port':993,  'smtp_host':'premium79.web-hosting.com','smtp_port':465},
}

def provider_config_for(email_addr):
    """Return IMAP/SMTP config for a given email address, auto-detecting by domain."""
    domain = email_addr.split('@')[-1].lower() if '@' in email_addr else ''
    return PROVIDER_CONFIGS.get(domain, {
        'imap_host': DEFAULT_IMAP_HOST, 'imap_port': DEFAULT_IMAP_PORT,
        'smtp_host': DEFAULT_SMTP_HOST, 'smtp_port': DEFAULT_SMTP_PORT,
    })
