from flask import Blueprint, request, jsonify

from db import get_db

bp = Blueprint('labels', __name__)


@bp.route('/api/labels', methods=['GET', 'POST', 'OPTIONS'])
def labels():
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    if request.method == 'GET':
        rows = conn.execute("SELECT id, name, color FROM labels ORDER BY name").fetchall()
        conn.close()
        return jsonify([dict(r) for r in rows])
    b = request.get_json() or {}
    name  = (b.get('name') or '').strip()
    color = (b.get('color') or '#e8a020').strip()
    if not name: return jsonify({'ok': False, 'error': 'name required'}), 400
    try:
        cur = conn.execute("INSERT INTO labels (name, color) VALUES (?, ?)", (name, color))
        conn.commit()
        label_id = cur.lastrowid
        conn.close()
        return jsonify({'ok': True, 'id': label_id, 'name': name, 'color': color})
    except Exception as ex:
        conn.close()
        return jsonify({'ok': False, 'error': str(ex)}), 400

@bp.route('/api/labels/<int:lid>', methods=['PATCH', 'DELETE', 'OPTIONS'])
def label_item(lid):
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute("DELETE FROM labels WHERE id=?", (lid,))
        conn.commit(); conn.close()
        return jsonify({'ok': True})
    b = request.get_json() or {}
    fields = {k: v for k, v in b.items() if k in ('name', 'color')}
    if fields:
        sets = ', '.join(f"{k}=?" for k in fields)
        conn.execute(f"UPDATE labels SET {sets} WHERE id=?", (*fields.values(), lid))
        conn.commit()
    conn.close()
    return jsonify({'ok': True})

@bp.route('/api/email-labels', methods=['GET', 'OPTIONS'])
def get_email_labels():
    """Return label IDs for a given account+uid, or all labels for an account."""
    if request.method == 'OPTIONS': return '', 204
    account = request.args.get('account') or ''
    uid     = request.args.get('uid') or ''
    conn = get_db()
    if uid:
        rows = conn.execute(
            "SELECT l.id, l.name, l.color FROM email_labels el JOIN labels l ON l.id=el.label_id WHERE el.account=? AND el.uid=?",
            (account, uid)).fetchall()
        conn.close()
        return jsonify([dict(r) for r in rows])
    # Return {uid: [labels]} for all emails in account (for bulk display)
    rows = conn.execute(
        "SELECT el.uid, l.id, l.name, l.color FROM email_labels el JOIN labels l ON l.id=el.label_id WHERE el.account=?",
        (account,)).fetchall()
    conn.close()
    result = {}
    for r in rows:
        result.setdefault(r['uid'], []).append({'id': r['id'], 'name': r['name'], 'color': r['color']})
    return jsonify(result)

@bp.route('/api/email-labels', methods=['POST', 'DELETE'])
def mutate_email_labels():
    b = request.get_json() or {}
    account  = b.get('account') or ''
    uid      = str(b.get('uid') or '')
    label_id = b.get('label_id')
    if not account or not uid or not label_id:
        return jsonify({'ok': False, 'error': 'account, uid, label_id required'}), 400
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute("DELETE FROM email_labels WHERE account=? AND uid=? AND label_id=?", (account, uid, label_id))
    else:
        conn.execute("INSERT OR IGNORE INTO email_labels (account, uid, label_id) VALUES (?, ?, ?)", (account, uid, label_id))
    conn.commit(); conn.close()
    return jsonify({'ok': True})
