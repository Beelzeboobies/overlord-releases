import json
import keyring

from flask import Blueprint, request, jsonify
from imapclient import IMAPClient
from tls import tls_context

from config import KEYRING_SERVICE, provider_config_for
from imap import (get_all_accounts, _invalidate_accounts_cache,
                  save_account_config, imap_disconnect)

bp = Blueprint('auth', __name__)


@bp.route('/api/provider-config', methods=['GET'])
def get_provider_config():
    email_addr = request.args.get('email', '')
    cfg = provider_config_for(email_addr)
    return jsonify(cfg)

@bp.route('/api/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json()
    email_addr = body.get('email', '').strip()
    password   = body.get('password', '').strip()

    # Get connection settings — from request body or auto-detect
    auto = provider_config_for(email_addr)
    imap_host = body.get('imap_host') or auto['imap_host']
    imap_port = int(body.get('imap_port') or auto['imap_port'])
    smtp_host = body.get('smtp_host') or auto['smtp_host']
    smtp_port = int(body.get('smtp_port') or auto['smtp_port'])

    use_ssl = True
    _probe = None
    _login_error = None
    # Intentionally bypass imap_connect: we probe exactly the host/port/credentials
    # supplied in the request body so that provider_config_for auto-detection or
    # get_account_config returning stale values don't silently mask bad credentials.
    try:
        # timeout: without it, an unreachable server hung this probe (and the
        # whole /api/login request) indefinitely — the frontend sat on
        # "Connecting…" with no error and no way to cancel. Confirmed live
        # during the premium79.web-hosting.com outage. See imap.py's
        # IMAP_TIMEOUT for the general-connection version of the same fix.
        _probe = IMAPClient(imap_host, port=imap_port, ssl=use_ssl, ssl_context=tls_context() if use_ssl else None, timeout=15)
        _probe.login(email_addr, password)
    except Exception as e:
        _login_error = e
    finally:
        # Always close the probe socket — whether login succeeded, failed, or
        # the constructor raised.  Without this, a failed login leaves the TCP
        # connection open until GC or server-side timeout.
        if _probe is not None:
            try:
                _probe.logout()
            except Exception:
                pass

    if _login_error is not None:
        e = _login_error
        # Clean up raw bytes repr like b'[AUTHENTICATIONFAILED] ...'
        msg = str(e)
        if msg.startswith("b'") or msg.startswith('b"'):
            try: msg = msg[2:-1]
            except: pass
        # Friendly messages for common failures
        if 'AUTHENTICATIONFAILED' in msg or 'Authentication failed' in msg:
            msg = 'Authentication failed. Check your email and password. Gmail, Yahoo, and iCloud require an app-specific password — not your regular login.'
        elif 'timed out' in msg.lower() or 'timeout' in msg.lower():
            msg = f'The mail server {imap_host}:{imap_port} is not responding — it may be down or unreachable from this network. Your password was not checked; try again later.'
        elif 'Connection refused' in msg or 'connect' in msg.lower():
            msg = f'Could not connect to {imap_host}:{imap_port}. Check your network or server settings.'
        return jsonify(ok=False, error=msg), 401

    # Persist connection config
    save_account_config(email_addr, imap_host, imap_port, smtp_host, smtp_port)

    # Store per-account in Keychain
    accounts = get_all_accounts()
    if email_addr not in accounts:
        accounts.append(email_addr)
    keyring.set_password(KEYRING_SERVICE, 'accounts', json.dumps(accounts)); _invalidate_accounts_cache()
    keyring.set_password(f'{KEYRING_SERVICE}:{email_addr}', 'password', password)
    keyring.set_password(KEYRING_SERVICE, 'email', email_addr)
    keyring.set_password(KEYRING_SERVICE, 'password', password)
    return jsonify(ok=True, accounts=accounts)

@bp.route('/api/logout', methods=['POST', 'OPTIONS'])
def logout():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json() or {}
    target = body.get('email', '')
    accounts = get_all_accounts()
    if target and target in accounts:
        accounts = [a for a in accounts if a != target]
        keyring.set_password(KEYRING_SERVICE, 'accounts', json.dumps(accounts)); _invalidate_accounts_cache()
        try:
            keyring.delete_password(f'{KEYRING_SERVICE}:{target}', 'password')
        except Exception:
            pass
        imap_disconnect(target)
    else:
        # Log out all
        for a in accounts:
            try:
                keyring.delete_password(f'{KEYRING_SERVICE}:{a}', 'password')
            except Exception:
                pass
            imap_disconnect(a)
        accounts = []
        keyring.set_password(KEYRING_SERVICE, 'accounts', '[]'); _invalidate_accounts_cache()
        try:
            keyring.delete_password(KEYRING_SERVICE, 'email')
            keyring.delete_password(KEYRING_SERVICE, 'password')
        except Exception:
            pass
    return jsonify(ok=True, accounts=accounts)

@bp.route('/api/auth-status')
def auth_status():
    accounts = get_all_accounts()
    return jsonify(logged_in=bool(accounts), email=accounts[0] if accounts else None, accounts=accounts)

@bp.route('/api/accounts')
def list_accounts():
    return jsonify(accounts=get_all_accounts())
