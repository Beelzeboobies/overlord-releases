from datetime import datetime as _dt, timedelta as _td, timezone as _tz

from flask import Blueprint, request, jsonify

from db import get_db
from helpers import _find_conf_url, _parse_reminder, _sync_gcal_url

bp = Blueprint('events', __name__)


def _serialize_reminder(value):
    """Serialize reminder_minutes for DB storage as JSON text."""
    import json as _json
    if isinstance(value, list):
        return _json.dumps(value)
    if isinstance(value, (int, float)):
        return _json.dumps([int(value)]) if value > 0 else _json.dumps([])
    return _json.dumps([10])


def _event_row(row) -> dict:
    import json as _json
    sessions_raw = row['sessions'] if 'sessions' in row.keys() else '[]'
    try:
        sessions = _json.loads(sessions_raw or '[]')
        if not isinstance(sessions, list): sessions = []
    except Exception:
        sessions = []
    recurrence_raw = row['recurrence'] or ''
    return {
        'id':               row['id'],
        'title':            row['title'],
        'start_dt':         row['start_dt'],
        'end_dt':           row['end_dt'],
        'all_day':          bool(row['all_day']),
        'location':         row['location'] or '',
        'description':      row['description'] or '',
        'meet_url':         row['meet_url'] or '',
        'color':            row['color'] or '#e8a020',
        'reminder_minutes': _parse_reminder(row['reminder_minutes']),
        'ical_uid':         row['ical_uid'] or '',
        'recurrence':       recurrence_raw,
        'sessions':         sessions,
        'deadline_dt':      row['deadline_dt'] if 'deadline_dt' in row.keys() else '',
    }


@bp.route('/api/events', methods=['GET', 'OPTIONS'])
def get_events():
    if request.method == 'OPTIONS': return '', 204
    start = request.args.get('start', '')
    end   = request.args.get('end', '')
    conn  = get_db()
    if start and end:
        rows = conn.execute(
            'SELECT * FROM events WHERE start_dt < ? AND end_dt > ? ORDER BY start_dt',
            (end, start)
        ).fetchall()
    else:
        rows = conn.execute('SELECT * FROM events ORDER BY start_dt').fetchall()
    conn.close()
    return jsonify([_event_row(r) for r in rows])


@bp.route('/api/events', methods=['POST'])
def create_event():
    import json as _json
    b = request.get_json()
    title    = str(b.get('title', '')).strip()[:500]
    start_dt = str(b.get('start_dt', ''))[:32]
    end_dt   = str(b.get('end_dt', ''))[:32]
    if not title or not start_dt or not end_dt:
        return jsonify(error='title, start_dt and end_dt required'), 400

    desc        = str(b.get('description', ''))[:4000]
    location    = str(b.get('location', ''))[:500]
    meet_url    = _find_conf_url(str(b.get('meet_url', '')) + ' ' + desc + ' ' + location)
    color       = str(b.get('color', '#e8a020'))[:20]
    reminder    = _serialize_reminder(b.get('reminder_minutes', [10]))
    all_day     = 1 if b.get('all_day') else 0
    recurrence  = _json.dumps(b.get('recurrence', {})) if isinstance(b.get('recurrence'), dict) else str(b.get('recurrence', ''))
    sessions    = _json.dumps(b.get('sessions', [])) if isinstance(b.get('sessions'), list) else '[]'
    deadline_dt = str(b.get('deadline_dt', ''))[:32]

    conn = get_db()
    cur  = conn.execute(
        '''INSERT INTO events (title,start_dt,end_dt,all_day,location,description,meet_url,color,reminder_minutes,recurrence,sessions,deadline_dt)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
        (title, start_dt, end_dt, all_day, location, desc, meet_url, color, reminder, recurrence, sessions, deadline_dt)
    )
    conn.commit()
    row = conn.execute('SELECT * FROM events WHERE id=?', (cur.lastrowid,)).fetchone()
    conn.close()
    return jsonify(_event_row(row))


@bp.route('/api/events/<int:eid>', methods=['PUT', 'PATCH', 'OPTIONS'])
def update_event(eid):
    import json as _json
    if request.method == 'OPTIONS': return '', 204
    b = request.get_json()
    conn = get_db()
    row  = conn.execute('SELECT * FROM events WHERE id=?', (eid,)).fetchone()
    if not row:
        conn.close()
        return jsonify(error='not found'), 404

    title       = str(b.get('title',    row['title']))[:500]
    start_dt    = str(b.get('start_dt', row['start_dt']))[:32]
    end_dt      = str(b.get('end_dt',   row['end_dt']))[:32]
    desc        = str(b.get('description', row['description'] or ''))[:4000]
    location    = str(b.get('location', row['location'] or ''))[:500]
    meet_url    = _find_conf_url(str(b.get('meet_url', row['meet_url'] or '')) + ' ' + desc + ' ' + location)
    color       = str(b.get('color',    row['color'] or '#e8a020'))[:20]
    reminder    = _serialize_reminder(b.get('reminder_minutes', _parse_reminder(row['reminder_minutes'])))
    all_day     = 1 if b.get('all_day', row['all_day']) else 0
    notified    = 0
    recurrence  = _json.dumps(b['recurrence']) if 'recurrence' in b and isinstance(b['recurrence'], dict) else (str(b.get('recurrence', '')) if 'recurrence' in b else (row['recurrence'] or ''))
    sessions    = _json.dumps(b['sessions']) if 'sessions' in b and isinstance(b['sessions'], list) else (row['sessions'] if 'sessions' in row.keys() else '[]')
    deadline_dt = str(b.get('deadline_dt', row['deadline_dt'] if 'deadline_dt' in row.keys() else ''))[:32]

    conn.execute(
        '''UPDATE events SET title=?,start_dt=?,end_dt=?,all_day=?,location=?,description=?,
           meet_url=?,color=?,reminder_minutes=?,notified=?,recurrence=?,sessions=?,deadline_dt=? WHERE id=?''',
        (title, start_dt, end_dt, all_day, location, desc, meet_url, color, reminder, notified,
         recurrence, sessions, deadline_dt, eid)
    )
    conn.commit()
    row = conn.execute('SELECT * FROM events WHERE id=?', (eid,)).fetchone()
    conn.close()
    return jsonify(_event_row(row))


@bp.route('/api/events/<int:eid>', methods=['DELETE', 'OPTIONS'])
def delete_event(eid):
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    conn.execute('DELETE FROM events WHERE id=?', (eid,))
    conn.commit()
    conn.close()
    return jsonify(ok=True)


@bp.route('/api/events/import-ics', methods=['POST', 'OPTIONS'])
def import_ics():
    """Parse an uploaded .ics file and upsert events into DB."""
    if request.method == 'OPTIONS': return '', 204
    if 'file' not in request.files:
        return jsonify(error='no file'), 400
    f = request.files['file']
    if not f.filename.lower().endswith('.ics'):
        return jsonify(error='only .ics files accepted'), 400

    raw = f.read(10 * 1024 * 1024)  # max 10 MB
    try:
        from icalendar import Calendar as _Cal
        cal = _Cal.from_ical(raw)
    except Exception as e:
        return jsonify(error=f'Could not parse ICS: {e}'), 400

    from ics_parse import ics_events, upsert_ics_events
    conn = get_db()
    imported, skipped = upsert_ics_events(conn, ics_events(cal), _find_conf_url)
    conn.commit()
    conn.close()
    return jsonify(ok=True, imported=imported, updated=skipped)


@bp.route('/api/gcal/sync-now', methods=['POST', 'OPTIONS'])
def gcal_sync_now():
    """Manually trigger a Google Calendar sync."""
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key='gcal_ics_url'").fetchone()
    conn.close()
    url = row['value'].strip() if row and row['value'] else ''
    if not url or not url.startswith('https://'):
        return jsonify(ok=False, error='No Google Calendar URL configured')
    imported, updated = _sync_gcal_url(url)
    return jsonify(ok=True, imported=imported, updated=updated)
