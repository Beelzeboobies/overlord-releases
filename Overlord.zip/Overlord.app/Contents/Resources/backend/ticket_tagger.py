"""
ticket_tagger.py — conservative keyword-rule classifier for suggesting a
Freecords tag on an untagged ticket, used by the Tickets "Auto-tag" button.

Deliberately high-precision, not high-recall: each rule was only added
after sampling real tickets already carrying that tag and confirming the
subject pattern is unambiguous for it (see MAC_TO_WINDOWS_CHANGES.md for
how these were derived). A ticket that matches nothing gets no suggestion
rather than a guessed one — under-suggesting is safe, mis-tagging a real
support ticket isn't. In particular "Copyright Verification Appeal" (very
common in the untagged set) is deliberately NOT mapped to the "Verification"
tag — that tag's only existing example was an identity-verification
request, a different thing, and guessing would be worse than leaving it
untagged for a human to decide.

Extend this list only after checking a new pattern against the existing
tagged population the same way — don't add a rule off a single example.
"""

import re

_RULES = [
    (re.compile(r'^takedown request', re.I), 'artist_content_takedown'),
    (re.compile(r'cover art issue', re.I), 'Cover Art'),
    (re.compile(r'official artist channel|\boac\b', re.I), 'YouTube OAC'),
    (re.compile(r'infringement|infringing', re.I), 'artist_content_infringement'),
    (re.compile(r'\bid verification\b', re.I), 'Verification'),
    (re.compile(r'needs action', re.I), 'artist_needs_action'),
]


def suggest_tag(subject):
    """Returns a tag string, or None if no rule matches."""
    subject = subject or ''
    for pattern, tag in _RULES:
        if pattern.search(subject):
            return tag
    return None
