"""
mobile_dev_server.py — standalone dev server for iterating on mobile_api.py
without restarting the real Overlord desktop app (which runs the full
main.py app on port 8000, serving the live IMAP/UI session).

Shares the same OAuth token (freecords_auth reads/writes the same keyring
entry regardless of which process asks), so no separate login needed —
just run this alongside the desktop app, not instead of it.

    python3 mobile_dev_server.py
"""

from flask import Flask
import mobile_api

app = Flask(__name__)
app.register_blueprint(mobile_api.bp)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8010, debug=True, use_reloader=True)
