from flask import Blueprint, request, jsonify

from db import get_db

bp = Blueprint('rules', __name__)


@bp.route('/api/rules', methods=['GET', 'POST', 'OPTIONS'])
def rules():
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    if request.method == 'GET':
        rows = conn.execute('SELECT * FROM rules ORDER BY id').fetchall()
        conn.close()
        return jsonify([dict(r) for r in rows])
    body = request.get_json()
    conn.execute('''INSERT INTO rules (name,condition_field,condition_op,condition_value,action,action_value,active)
                    VALUES (?,?,?,?,?,?,?)''',
        (body.get('name',''), body.get('condition_field','subject'), body.get('condition_op','contains'),
         body.get('condition_value',''), body.get('action','move'), body.get('action_value',''), 1))
    conn.commit()
    row = conn.execute('SELECT * FROM rules WHERE id=last_insert_rowid()').fetchone()
    conn.close()
    return jsonify(dict(row))


@bp.route('/api/rules/<int:rid>', methods=['PATCH', 'DELETE', 'OPTIONS'])
def rule(rid):
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM rules WHERE id=?', (rid,))
        conn.commit(); conn.close()
        return jsonify(ok=True)
    body = request.get_json()
    fields = ['name','condition_field','condition_op','condition_value','action','action_value','active']
    updates = {k: body[k] for k in fields if k in body}
    if updates:
        set_clause = ', '.join(f'{k}=?' for k in updates)
        conn.execute(f'UPDATE rules SET {set_clause} WHERE id=?', (*updates.values(), rid))
        conn.commit()
    row = conn.execute('SELECT * FROM rules WHERE id=?', (rid,)).fetchone()
    conn.close()
    return jsonify(dict(row) if row else {})
