import json
import threading
import email.header
import keyring
from contextlib import contextmanager
from imapclient import IMAPClient
from db import get_db
from config import KEYRING_SERVICE, DEFAULT_IMAP_HOST, DEFAULT_IMAP_PORT, provider_config_for
from parsing import _addr, _addr_list, _decode_env, check_attachment

# ── Account / credential helpers ─────────────────────────────────────────────

_accounts_cache = None
_accounts_cache_lock = threading.Lock()

def get_all_accounts():
    global _accounts_cache
    with _accounts_cache_lock:
        if _accounts_cache is not None:
            return _accounts_cache
    accounts_json = keyring.get_password(KEYRING_SERVICE, 'accounts')
    if accounts_json:
        try:
            result = json.loads(accounts_json)
            with _accounts_cache_lock:
                _accounts_cache = result
            return result
        except Exception:
            pass
    # Migrate legacy single-account
    legacy = keyring.get_password(KEYRING_SERVICE, 'email')
    result = [legacy] if legacy else []
    with _accounts_cache_lock:
        _accounts_cache = result
    return result

def _invalidate_accounts_cache():
    global _accounts_cache
    with _accounts_cache_lock:
        _accounts_cache = None

def get_account_password(email_addr):
    pw = keyring.get_password(f'{KEYRING_SERVICE}:{email_addr}', 'password')
    if pw:
        return pw
    # Legacy fallback
    return keyring.get_password(KEYRING_SERVICE, 'password')

def get_creds():
    accounts = get_all_accounts()
    if not accounts:
        return None
    e = accounts[0]
    p = get_account_password(e)
    return {'email': e, 'password': p} if p else None

def get_account_config(email_addr):
    """Return imap/smtp config for an account — DB first, then auto-detect."""
    conn = get_db()
    row = conn.execute('SELECT * FROM account_configs WHERE email=?', (email_addr,)).fetchone()
    conn.close()
    if row:
        return dict(row)
    return provider_config_for(email_addr)

def save_account_config(email_addr, imap_host, imap_port, smtp_host, smtp_port):
    conn = get_db()
    conn.execute('''INSERT OR REPLACE INTO account_configs (email,imap_host,imap_port,smtp_host,smtp_port)
                    VALUES (?,?,?,?,?)''', (email_addr, imap_host, int(imap_port), smtp_host, int(smtp_port)))
    conn.commit()
    conn.close()

# ── IMAP connection pool ──────────────────────────────────────────────────────

# Socket timeout for every IMAP connection (connect + each subsequent socket
# read/write). Without one, an unreachable mail server hangs a connection
# attempt indefinitely — confirmed live: with premium79.web-hosting.com:993
# down, an account-connect attempt sat on "Connecting…" with no status, no
# way to cancel, and even removing the account hung, because /api/logout's
# IMAP logout blocked on the same dead socket. Per-recv, not per-operation:
# a large fetch that keeps data flowing never trips it.
IMAP_TIMEOUT = 15

_thread_local = threading.local()   # per-thread IMAP connections — no sharing, no locking

def _tl_attr(email_addr):
    """Thread-local attribute name for an email account's IMAP connection."""
    return 'imap_' + email_addr.replace('@', '_at_').replace('.', '_dot_')

def imap_connect(account=None, force_new=False):
    """Return a thread-local IMAPClient.  Each Flask worker thread has its own
    connection so concurrent requests never share the same socket."""
    accounts = get_all_accounts()
    if not accounts:
        return None
    email_addr = account if (account and account in accounts) else accounts[0]
    attr = _tl_attr(email_addr)

    if not force_new:
        existing = getattr(_thread_local, attr, None)
        if existing is not None:
            try:
                existing.noop()
                return existing
            except Exception:
                setattr(_thread_local, attr, None)

    password = get_account_password(email_addr)
    if not password:
        return None
    cfg = get_account_config(email_addr)
    imap_host = cfg.get('imap_host', DEFAULT_IMAP_HOST)
    imap_port = int(cfg.get('imap_port', DEFAULT_IMAP_PORT))

    for _attempt in range(2):
        try:
            client = IMAPClient(imap_host, port=imap_port, ssl=True, timeout=IMAP_TIMEOUT)
            client.login(email_addr, password)
            setattr(_thread_local, attr, client)
            return client
        except Exception:
            pass
    return None

def select_folder_once(client, folder, email_addr, readonly=True):
    """Select *folder* on *client* only if it isn't already selected.
    Saves one IMAP round-trip per message fetch when the folder hasn't changed."""
    attr = 'sel_' + _tl_attr(email_addr)
    if getattr(_thread_local, attr, None) != folder:
        client.select_folder(folder, readonly=readonly)
        setattr(_thread_local, attr, folder)

def imap_release(account=None):
    """No-op — thread-local connections need no explicit release."""
    pass

@contextmanager
def imap_client(account=None, force_new=False):
    """Thin context-manager wrapper around imap_connect (kept for call-site compatibility)."""
    yield imap_connect(account, force_new)

def imap_disconnect(email_addr):
    """Close the current thread's connection for email_addr (called on logout)."""
    attr = _tl_attr(email_addr)
    existing = getattr(_thread_local, attr, None)
    if existing:
        try:
            existing.logout()
        except Exception:
            pass
        setattr(_thread_local, attr, None)

# ── Persistent background IMAP connections ────────────────────────────────────

_bg_imap_clients = {}
_bg_imap_lock = threading.Lock()

# Per-account locks that serialise IMAP APPEND commands issued through the
# shared background connection.  save_draft (request thread) and
# do_sent_append (daemon thread) both write to _bg_imap_clients[account]; without
# a lock they can interleave commands on the same socket and corrupt the session.
_bg_append_locks = {}
_bg_append_locks_guard = threading.Lock()

def bg_append_lock(key):
    """Return the per-account Lock used to serialise bg-client APPEND calls.

    Creates the Lock on first access and returns the same object on every
    subsequent call for the same key, so callers in different threads always
    contend on the same mutex.
    """
    with _bg_append_locks_guard:
        return _bg_append_locks.setdefault(key, threading.Lock())


def _get_bg_imap(account):
    """Return a persistent background IMAPClient for the given account, creating one if needed.

    IMPORTANT — key consistency contract:
    _bg_imap_clients is keyed by the raw `account` argument, with NO internal
    resolution (e.g. None → accounts[0]).  If imap_connect() resolves None to the
    default email, the resulting client is still stored under None — so
    _bg_imap_clients[None] and _bg_imap_clients['user@example.com'] are two
    SEPARATE sockets, even if they connect to the same server.

    Consequence for bg_append_lock: callers MUST pass the same raw key to both
    _get_bg_imap and bg_append_lock.  If one call site passes None and another
    passes the resolved email, they take different locks against different sockets —
    the race is not serialised.  Current callers (save_draft and do_sent_append)
    both derive `account = body.get('account') or None` and pass it unchanged to
    both functions, so they are consistent.  Do not resolve the key differently at
    a new call site without updating both.
    """
    with _bg_imap_lock:
        client = _bg_imap_clients.get(account)
        if client is not None:
            try:
                client.noop()
                return client
            except Exception:
                _bg_imap_clients.pop(account, None)
        client = imap_connect(account, force_new=True)
        if client:
            _bg_imap_clients[account] = client
        return client

def drop_bg_client(account):
    """Evict a stale background connection for account so _get_bg_imap recreates it."""
    with _bg_imap_lock:
        _bg_imap_clients.pop(account, None)


# ── Folder name helpers ───────────────────────────────────────────────────────

# Validates existing server-assigned folder paths (used when routing requests to
# IMAP).  Allows '/', '.', brackets etc. because the server may use any of them
# as hierarchy separators or decoration.  For new typed names use
# _validate_folder_name() in folders.py, which is intentionally stricter.
SAFE_FOLDER_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ._-/[]{}()')

def safe_folder(name):
    return all(c in SAFE_FOLDER_CHARS for c in name)


_folder_maps = {}         # email -> {lower_name -> actual_imap_name}
_folder_delimiters = {}   # email -> str  (the IMAP hierarchy separator for this account)

def get_delimiter(account_key):
    """Return the IMAP hierarchy separator for account_key (e.g. '.' or '/').

    Reads from the per-account cache populated by _build_folder_map.  If the
    cache is empty (first call), triggers _build_folder_map to fill it.
    Always returns a str (never bytes).

    Fallback semantics: returns '.' when no folder list is available (empty
    folder list, failed imap_connect, or account not yet cached).  '.' is
    correct for Dovecot — the only server currently in scope — so a cold-cache
    miss produces a valid result.  For servers using a different separator
    (e.g. '/' on Gmail), a cold miss would silently produce wrong paths;
    if those servers are ever added, replace the fallback with a raised
    exception so callers get an explicit failure instead of a mangled rename.
    """
    if account_key not in _folder_delimiters:
        _build_folder_map(account_key)
    return _folder_delimiters.get(account_key, '.')


def _build_folder_map(account_key):
    """Fetch folder list and build a name→IMAP-name mapping."""
    client = imap_connect(account_key)
    if not client:
        return {}
    mapping = {}
    # Special-use flag → canonical name (used as fallback keys)
    SPECIAL_USE = {
        '\\sent':    'Sent',
        '\\drafts':  'Drafts',
        '\\trash':   'Trash',
        '\\junk':    'Spam',
        '\\spam':    'Spam',
        '\\archive': 'Archive',
        '\\flagged': 'Flagged',
        '\\all':     'All Mail',
    }
    special_map = {}  # canonical → actual IMAP name (from flags)
    raw_folders = list(client.list_folders())
    # Capture the account's IMAP hierarchy separator from the first folder that
    # reports one.  imapclient returns delim as bytes (parse_response does not
    # decode it), so normalise to str here so _folder_delimiters always holds a
    # str and the fallback '.' in get_delimiter() is the same type.
    for _, delim, _ in raw_folders:
        if delim:
            d = delim.decode() if isinstance(delim, bytes) else delim
            _folder_delimiters[account_key] = d
            break
    for flags, delim, name in raw_folders:
        # Map both full name and last path component
        mapping[name.lower()] = name
        short = name.split('/')[-1].split('.')[-1].lower()
        if short not in mapping:
            mapping[short] = name
        # Detect special-use attributes
        for flag in (flags or []):
            canonical = SPECIAL_USE.get(flag.lower())
            if canonical:
                special_map[canonical.lower()] = name
    # Add special-use mappings (don't overwrite exact matches already found)
    for canonical, imap_name in special_map.items():
        if canonical not in mapping:
            mapping[canonical] = imap_name
    _folder_maps[account_key] = mapping
    return mapping

def resolve_folder(folder, account_key):
    """Translate user-facing folder name to actual IMAP folder name."""
    fmap = _folder_maps.get(account_key) or _build_folder_map(account_key)
    # Exact match first
    if folder.lower() in fmap:
        return fmap[folder.lower()]
    # Last component match (e.g. "Sent" → "INBOX.Sent")
    short = folder.split('.')[-1].lower()
    if short in fmap:
        return fmap[short]
    return folder  # pass through unchanged


# ── Unread / folder / search caches ──────────────────────────────────────────
# NOTE: route handlers in the messages, folders, and send blueprints mutate
# these globals directly across module boundaries — functional and cycle-free,
# but looser than the function-mediated pattern used for _bg_imap_clients.
# Logged as a known compromise; a wrapping-accessor pass can tighten this later.

_unread_cache = {}
_total_cache = {}       # folder → total from folder_status (approximate)
_search_total_cache = {}  # (acct_key, folder) → total from SEARCH ALL (authoritative)
_folder_cache = {}      # acct_key → list of {name, flags, unread}
_draft_folder_cache = {}  # acct_key → draft folder name
_sent_folder_cache  = {}  # acct_key → sent folder name
_unread_cache_lock = threading.Lock()


def _refresh_unread_counts(account):
    """Fetch folder list + UNSEEN/MESSAGES counts.

    Splits folders across a small pool of IMAP connections so all STATUS
    calls run concurrently — total latency ≈ 1 round-trip instead of N.
    """
    import concurrent.futures, math

    try:
        accounts_list = get_all_accounts()
        email_addr = account if (account and account in accounts_list) else (accounts_list[0] if accounts_list else '')
        if not email_addr:
            return
        password = get_account_password(email_addr)
        if not password:
            return
        cfg = get_account_config(email_addr)
        imap_host = cfg.get('imap_host', DEFAULT_IMAP_HOST)
        imap_port = int(cfg.get('imap_port', DEFAULT_IMAP_PORT))

        # First: list folders with one quick connection
        list_client = IMAPClient(imap_host, port=imap_port, ssl=True, timeout=IMAP_TIMEOUT)
        list_client.login(email_addr, password)
        raw_folders = list(list_client.list_folders())
        list_client.logout()

        acct_key = email_addr
        folder_meta = []
        for flags, delimiter, name in raw_folders:
            flags_list = [f.decode() if isinstance(f, bytes) else f for f in flags]
            folder_meta.append((name, flags_list))

        # Split folder list into N_WORKERS chunks; each worker handles its chunk
        # on a single reused connection (one auth per worker, many STATUS per conn)
        N_WORKERS = min(5, len(folder_meta)) if folder_meta else 1
        chunk_size = math.ceil(len(folder_meta) / N_WORKERS)
        chunks = [folder_meta[i:i+chunk_size] for i in range(0, len(folder_meta), chunk_size)]

        def fetch_chunk(chunk):
            results = {}
            c = None
            try:
                c = IMAPClient(imap_host, port=imap_port, ssl=True, timeout=IMAP_TIMEOUT)
                c.login(email_addr, password)
                for name, _ in chunk:
                    try:
                        st = c.folder_status(name, ['UNSEEN', 'MESSAGES'])
                        results[name] = (int(st.get(b'UNSEEN', 0)), int(st.get(b'MESSAGES', 0)))
                    except Exception:
                        results[name] = (0, 0)
            except Exception:
                for name, _ in chunk:
                    results[name] = (0, 0)
            finally:
                if c:
                    try: c.logout()
                    except Exception: pass
            return results

        combined = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=N_WORKERS) as pool:
            for partial in pool.map(fetch_chunk, chunks):
                combined.update(partial)

        counts = {}
        totals = {}
        folders = []
        for name, flags_list in folder_meta:
            unread, total = combined.get(name, (0, 0))
            counts[name] = unread
            totals[name] = total
            folders.append({'name': name, 'flags': flags_list, 'unread': unread, 'total': total})

        with _unread_cache_lock:
            _unread_cache[acct_key] = counts
            _total_cache[acct_key]  = totals
            _folder_cache[acct_key] = folders

    except Exception:
        pass


def fetch_and_cache(client, folder, uids, account_key):
    """Fetch envelopes from IMAP and write to SQLite cache. Returns list of dicts."""
    import time
    from imapclient.exceptions import ProtocolError as ImapProtocolError
    try:
        data = client.fetch(uids, ['ENVELOPE', 'FLAGS', 'BODYSTRUCTURE'])
    except (ImapProtocolError, Exception) as e:
        if len(uids) == 1:
            print(f"[fetch_and_cache] Skipping UID {uids[0]} due to error: {e}", flush=True)
            return []
        # Retry in small batches of 5, skipping only the bad ones
        print(f"[fetch_and_cache] Batch fetch failed, retrying {len(uids)} UIDs in mini-batches…", flush=True)
        data = {}
        MINI = 5
        for i in range(0, len(uids), MINI):
            chunk = uids[i:i+MINI]
            try:
                data.update(client.fetch(chunk, ['ENVELOPE', 'FLAGS', 'BODYSTRUCTURE']))
            except Exception:
                # chunk failed — reconnect and try one by one
                try:
                    # Force fresh connection to clear corrupt state on next call
                    # (thread-local — just clear the stored reference)
                    for _acct in get_all_accounts():
                        attr = _tl_attr(_acct)
                        if getattr(_thread_local, attr, None) is client:
                            setattr(_thread_local, attr, None)
                            break
                except Exception:
                    pass
                for uid in chunk:
                    try:
                        data.update(client.fetch([uid], ['ENVELOPE', 'FLAGS', 'BODYSTRUCTURE']))
                    except Exception as e2:
                        print(f"[fetch_and_cache] Skipping UID {uid}: {e2}", flush=True)
    now  = time.time()
    conn = get_db()
    results = []
    rows = []
    for uid, msg_data in data.items():
        env   = msg_data.get(b'ENVELOPE')
        flags = msg_data.get(b'FLAGS', ())
        bstr  = msg_data.get(b'BODYSTRUCTURE')

        from_name, from_addr = _addr(env.from_) if env else ('', '')
        _, reply_to_addr = _addr(env.reply_to) if env else ('', '')
        cc_str    = _addr_list(env.cc)   if env else ''
        to_str    = _addr_list(env.to)   if env else ''
        subject = ''
        if env and env.subject:
            raw_subj = env.subject if isinstance(env.subject, str) else env.subject.decode('utf-8', errors='replace')
            try:
                parts = email.header.decode_header(raw_subj)
                subject = ''.join(
                    p.decode(c or 'utf-8', errors='replace') if isinstance(p, bytes) else p
                    for p, c in parts
                )
            except Exception:
                subject = raw_subj
        date_str = _decode_env(env.date) if env else ''
        is_read   = b'\\Seen' in flags
        is_flagged = b'\\Flagged' in flags
        has_att, att_names = check_attachment(bstr)
        att_names_str = '\n'.join(att_names)

        rows.append((account_key, folder, str(uid), from_name, from_addr,
                     subject, date_str, int(is_read), int(is_flagged), int(has_att), att_names_str, now,
                     cc_str, to_str, reply_to_addr))
        results.append({
            'uid': str(uid), 'from_name': from_name or from_addr, 'from_addr': from_addr,
            'reply_to': reply_to_addr,
            'subject': subject or '(no subject)', 'date': date_str,
            'read': is_read, 'flagged_imap': is_flagged, 'has_attachment': has_att,
            'attachment_names': att_names, 'cc': cc_str, 'to_addrs': to_str,
        })

    conn.executemany("""
        INSERT OR REPLACE INTO message_cache
        (account, folder, uid, from_name, from_addr, subject, date, read, flagged_imap, has_attachment, attachment_names, cached_at, cc, to_addrs, reply_to)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, rows)
    conn.commit()
    conn.close()
    return results
