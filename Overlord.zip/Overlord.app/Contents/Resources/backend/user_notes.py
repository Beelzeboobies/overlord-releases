"""Per-user AI notes — persistent context for Claude Suggest."""
from flask import Blueprint, request, jsonify
from db import get_db

bp = Blueprint('user_notes', __name__)


@bp.route('/api/user-notes', methods=['GET', 'OPTIONS'])
def get_user_notes():
    if request.method == 'OPTIONS':
        return '', 204
    user_id = request.args.get('user_id', '').strip()
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    conn = get_db()
    row = conn.execute(
        'SELECT notes, updated_at FROM user_ai_notes WHERE user_id = ?', (user_id,)
    ).fetchone()
    conn.close()
    if row:
        return jsonify({'user_id': user_id, 'notes': row['notes'], 'updated_at': row['updated_at']})
    return jsonify({'user_id': user_id, 'notes': '', 'updated_at': None})


@bp.route('/api/user-notes', methods=['POST', 'OPTIONS'])
def save_user_notes():
    if request.method == 'OPTIONS':
        return '', 204
    data = request.get_json(force=True) or {}
    user_id = str(data.get('user_id', '')).strip()
    notes = str(data.get('notes', ''))
    if not user_id:
        return jsonify({'error': 'user_id required'}), 400
    conn = get_db()
    conn.execute(
        """INSERT INTO user_ai_notes (user_id, notes, updated_at)
           VALUES (?, ?, datetime('now'))
           ON CONFLICT(user_id) DO UPDATE SET notes=excluded.notes, updated_at=excluded.updated_at""",
        (user_id, notes)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
