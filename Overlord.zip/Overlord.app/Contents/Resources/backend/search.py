from flask import Blueprint, request, jsonify

from imap import get_all_accounts, imap_connect, resolve_folder, fetch_and_cache, select_folder_once

bp = Blueprint('search', __name__)


def _imap_search(client, criteria, charset=None):
    """Run an IMAP search, returning a set of UIDs. Returns empty set on failure."""
    try:
        if charset:
            return set(client.search(criteria, charset=charset))
        return set(client.search(criteria))
    except Exception:
        return set()


def _rank(msg, q_lower):
    """Return a relevance score (higher = more relevant) for a message vs a query string."""
    from_str  = ((msg.get('from_name') or '') + ' ' + (msg.get('from_addr') or '')).lower()
    to_str    = (msg.get('to') or '').lower()
    subj_str  = (msg.get('subject') or '').lower()
    if q_lower in from_str:   return 3
    if q_lower in subj_str:   return 2
    if q_lower in to_str:     return 1
    return 0


@bp.route('/api/search', methods=['GET', 'OPTIONS'])
def search_messages():
    if request.method == 'OPTIONS':
        return '', 204
    q       = request.args.get('q', '').strip()
    account = request.args.get('account') or None
    folder  = request.args.get('folder', 'INBOX')
    if not q:
        return jsonify(messages=[])

    from datetime import date, timedelta

    # Parse filter tokens out of the query string
    field_criteria = []   # explicit field: tokens → always go straight to IMAP
    want_attachment = False
    filename_filter = None
    text_parts = []       # bare words → smart header-first search

    for token in q.split():
        tl = token.lower()
        if tl.startswith('from:'):
            field_criteria += ['FROM', token[5:]]
        elif tl.startswith('to:'):
            field_criteria += ['TO', token[3:]]
        elif tl.startswith('subject:'):
            field_criteria += ['SUBJECT', token[8:]]
        elif tl == 'has:attachment':
            want_attachment = True
        elif tl.startswith('filename:'):
            filename_filter = token[9:].lower()
            want_attachment = True
        elif tl.startswith('date:'):
            val = tl[5:]
            if val == 'today':
                field_criteria += ['ON', date.today().strftime('%d-%b-%Y')]
            elif val in ('week', '7d'):
                field_criteria += ['SINCE', (date.today() - timedelta(days=7)).strftime('%d-%b-%Y')]
            elif val in ('month', '30d'):
                field_criteria += ['SINCE', (date.today() - timedelta(days=30)).strftime('%d-%b-%Y')]
        else:
            text_parts.append(token)

    try:
        accounts = get_all_accounts()
        acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
        client = imap_connect(account)
        if not client:
            return jsonify(error='not logged in'), 401
        resolved = resolve_folder(folder, acct_key)
        select_folder_once(client, resolved, acct_key, readonly=True)
        has_non_ascii = any(ord(c) > 127 for c in q)
        charset = 'UTF-8' if has_non_ascii else None

        uid_set = set()
        # Track which UIDs came from which source so we can rank them later
        from_uids    = set()
        subject_uids = set()
        to_uids      = set()

        if field_criteria:
            # User used explicit field prefixes — honour them directly
            uid_set = _imap_search(client, field_criteria, charset)
        elif text_parts:
            bare = ' '.join(text_parts)
            # Step 1: fast header-only searches (FROM, SUBJECT, TO)
            from_uids    = _imap_search(client, ['FROM',    bare], charset)
            subject_uids = _imap_search(client, ['SUBJECT', bare], charset)
            to_uids      = _imap_search(client, ['TO',      bare], charset)
            header_uids  = from_uids | subject_uids | to_uids
            uid_set      = header_uids

            # Step 2: fall back to full TEXT only when header search returns few results
            if len(header_uids) < 10:
                text_uids = _imap_search(client, ['TEXT', bare], charset)
                uid_set = header_uids | text_uids
        else:
            uid_set = _imap_search(client, ['ALL'])

        if not uid_set:
            return jsonify(messages=[])

        uids = sorted(uid_set, reverse=True)[:100]
        messages = fetch_and_cache(client, resolved, uids, acct_key)

        if want_attachment:
            messages = [m for m in messages if m.get('has_attachment')]
        if filename_filter:
            messages = [m for m in messages
                        if any(filename_filter in n.lower()
                               for n in (m.get('attachment_names') or []))]

        # Rank by match quality, then date descending within each tier
        q_lower = q.lower()
        # Step 1: sort by date descending (stable)
        messages.sort(key=lambda m: m.get('date') or '', reverse=True)
        # Step 2: stable sort by relevance score descending — preserves date order within tiers
        def relevance(m):
            uid = m.get('uid')
            if field_criteria:
                return _rank(m, q_lower)
            if uid in from_uids:      return 3
            if uid in subject_uids:   return 2
            if uid in to_uids:        return 1
            return _rank(m, q_lower)
        messages.sort(key=relevance, reverse=True)
        return jsonify(messages=messages)
    except Exception as e:
        return jsonify(error=str(e)), 500
