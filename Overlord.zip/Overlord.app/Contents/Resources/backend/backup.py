"""
backup.py — automatic database backups + a silent-data-loss integrity check.

Built after a real incident: canned responses, contacts, and several
settings keys (including sound_inbox/sound_send) went silently empty at
some point across this app's history, with zero warning and zero way to
recover the exact original data. A full investigation (schema, SQLite
rowid write-order forensics, the complete backend.log error history, every
migration ever written) found no destructive code and no logged exception
anywhere — meaning the mechanism is still unknown. Since the cause can't
be fixed, the fix is: never be in a position to need it. Two parts:

1. A real, periodic, rotating backup of the whole database (SQLite's own
   `.backup()` API — safe to run against a live, in-use database, unlike
   a raw file copy). If something empties out again, there's always a
   recent real copy to restore from, independent of ever finding the bug.
2. A cheap integrity check on each backup cycle: compare a handful of
   "this should basically never shrink to zero" fields against the
   previous backup, and log loudly (impossible-to-miss prefix, greppable)
   if something did. Silent is what made the original incident go
   unnoticed for so long — this makes the same class of event loud
   instead, the first time it happens, not after weeks of not knowing.
3. The same two things for every directory Overlord itself writes
   user-uploaded files into (see _PROTECTED_DIRS) — added later, after a
   real signature image incident, then widened again after the user
   pointed out the first version only covered SETTINGS_PATH and missed
   custom sound uploads entirely. The detection half alone
   (check_uploads_integrity) turned out to be only half the fix: it would
   notice a corrupted file but had no real copy to recover from.
   backup_uploads() below closes that — an actual rotating snapshot of
   each protected directory, so "restore from the last good copy" is a
   real option, not just a diagnosis. Deliberately excludes
   ticket_attachments — that's a re-fetchable cache from Freshdesk, not
   irreplaceable user-uploaded content, so it doesn't belong in the same
   "we could lose this forever" category as the rest.

Shared code — this protects Mac too, once pulled. Nothing here is
Windows/Mac-specific; `config.APP_SUPPORT` already resolves correctly on
both.
"""
import json
import shutil
import sqlite3
import time
import datetime
from pathlib import Path

from config import APP_SUPPORT, SETTINGS_PATH
from db import DB_PATH
# settings.py resolves the real sound-upload dirs — every sound (bundled
# default or user-uploaded) lives together in SOUNDS_DIST (served from)
# and SOUNDS_PUBLIC (Vite's own source copy, so an upload survives a
# rebuild). Both are inside the app/repo tree, not Application Support —
# a deliberate choice (see settings.py) — so this backup coverage is what
# actually protects an upload against being lost some other way (a failed
# write, manual deletion, etc.), same reasoning as the uploads dir below.
from settings import SOUNDS_DIST, SOUNDS_PUBLIC

BACKUP_DIR = APP_SUPPORT / 'backups'
KEEP_BACKUPS = 30  # ~a month of daily backups, or a week+ of the 6-hourly cadence below
BACKUP_INTERVAL_SECONDS = 6 * 60 * 60  # 6 hours

# Fields worth watching — cheap to compute, and every one of them is real
# user data that should only ever grow or stay flat, never drop to zero
# once it's been non-zero. Mirrors this session's own snapshot_live.py
# fingerprint, now built into the app permanently instead of a one-off
# diagnostic script.
#
# 'json_array': True fields store a JSON array and are '[]' (2 characters)
# when genuinely empty — raw len(value) would never see that as zero and
# would silently miss the exact regression this module exists to catch.
# Parse and count elements instead for those; plain-text fields (HTML/
# strings) are correctly measured by raw length.
_WATCHED_KEYS = [
    ('canned_responses', False),
    ('account_signatures', False),
    ('sound_inbox', True),
    ('sound_send', True),
    # Claude Context Files/URLs — **user asked directly**: "how about
    # Claude context files and links?" Real gap: the full-DB backup
    # already covers these (they're plain settings rows, no separate
    # upload step), but nothing was watching them for the same silent
    # empty-out that hit account_signatures/sound_inbox originally.
    # context_urls specifically just got real seeded defaults (see
    # db.py) — a regression to empty on a fresh install would now always
    # be a genuine signal, not a "user never set one" false positive.
    # context_excludes deliberately NOT watched — empty is its normal,
    # common, correct state (most users never exclude anything), so
    # watching it would just be noise, not signal.
    ('context_folders_email', True),
    ('context_folders_support', True),
    ('context_files_extra_email', True),
    ('context_files_extra_support', True),
    ('context_urls_email', True),
    ('context_urls_support', True),
]


def _log(msg):
    # Same direct-file-write pattern as main.py's _sync_log — logging.info()
    # from a background thread has silently gone nowhere before in this
    # codebase, more than once.
    try:
        with open(APP_SUPPORT / 'logs' / 'backend.log', 'a') as f:
            f.write(f"[{datetime.datetime.now().isoformat(timespec='seconds')}] {msg}\n")
    except Exception:
        pass


def _fingerprint(conn):
    fp = {}
    for key, is_json_array in _WATCHED_KEYS:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        value = row[0] if row and row[0] else None
        if not value:
            fp[key] = 0
        elif is_json_array:
            try:
                fp[key] = len(json.loads(value))
            except Exception:
                fp[key] = 0  # unparseable counts as empty, not "skip" — err toward catching a real regression
        else:
            fp[key] = len(value)
    fp['contacts_count'] = conn.execute("SELECT COUNT(*) FROM contacts").fetchone()[0]
    return fp


# The gap that let a real signature image silently become a 1x1 black
# pixel with zero detection: everything above watches DB *values*, but an
# uploaded file's bytes live outside the database entirely, so nothing
# ever fingerprinted them. **User**: a signature image had gone from a
# real file to a corrupted 1x1 pixel with no upload event to explain it,
# and no system had caught it — "you have finally implemented sure-fire
# ways to track what actually happened... so what actually happened?" The
# honest answer was: nothing tracked this at all. This closes that gap.
#
# **User, again, after the first version of this only covered
# SETTINGS_PATH**: "did it occur to you that an overlord install needs a
# local folder to store saved settings, context files, signatures and any
# other files that can be uploaded by the users? Audio for inbox and
# outbox, for instance?" — correct, and a real miss: custom sound uploads
# write to SOUNDS_DIST/SOUNDS_PUBLIC (settings.py) — deliberately kept
# inside the app/repo tree, in the same folder as the bundled defaults,
# rather than moved to Application Support (a real storage-location
# tradeoff, made knowingly — see settings.py's docstring). Since they
# live outside APP_SUPPORT's usual data-loss-detection coverage, this
# backup path is what actually protects them. Every directory Overlord
# itself writes user-uploaded files into needs to be here, not just the
# one the original incident happened to involve — hence a real list
# rather than one hardcoded path.
_PROTECTED_DIRS = [
    ('uploads', SETTINGS_PATH),
    ('sounds_dist', SOUNDS_DIST),
    ('sounds_public', SOUNDS_PUBLIC),
]

# Can't diff against a previous DB backup for this (files aren't in the
# DB) — so this fingerprint is persisted to its own sidecar JSON next to
# each backup instead, and diffed against the previous cycle's sidecar.
def _fingerprint_uploads():
    """{"label/filename": size_in_bytes} across every protected directory.
    Cheap — just os.path.getsize(), no need to hash full content to catch
    a collapse like 160KB -> 68 bytes. Namespaced by directory label so a
    same-named file in two different protected dirs can't collide."""
    fp = {}
    for label, d in _PROTECTED_DIRS:
        if not d.is_dir():
            continue
        for p in d.iterdir():
            if p.is_file():
                fp[f'{label}/{p.name}'] = p.stat().st_size
    return fp


def _previous_uploads_fingerprint():
    """The sidecar manifest from the same backup cycle _previous_backup()
    points at — filename pattern mirrors the DB backup's own timestamp so
    the two stay paired without needing to store a cross-reference."""
    prev_db = _previous_backup()
    if prev_db is None:
        return None
    stamp = prev_db.stem.replace('mail-', '')
    manifest_path = BACKUP_DIR / f'uploads-{stamp}.json'
    if not manifest_path.exists():
        return None
    try:
        return json.loads(manifest_path.read_text())
    except Exception:
        return None


def _save_uploads_fingerprint(fp):
    stamp = time.strftime('%Y%m%d-%H%M%S')
    (BACKUP_DIR / f'uploads-{stamp}.json').write_text(json.dumps(fp))


def check_uploads_integrity():
    """Compare the live uploads directory against the previous cycle's
    fingerprint; log loudly if a file that was substantial in size has
    collapsed to a small fraction of that, or disappeared outright. A
    file going to exactly zero bytes is the DB-field pattern; an image
    silently becoming a 1x1 placeholder never hits zero, so this uses a
    >90% size drop as the threshold instead of the DB check's "== 0."
    Also saves this cycle's own fingerprint for the NEXT comparison —
    always runs regardless of whether a previous one existed yet."""
    live_fp = _fingerprint_uploads()
    prev_fp = _previous_uploads_fingerprint()
    if prev_fp is not None:
        regressions = {}
        for name, prev_size in prev_fp.items():
            if prev_size < 500:
                continue  # wasn't substantial to begin with
            live_size = live_fp.get(name, 0)
            if live_size < prev_size * 0.1:
                regressions[name] = {'was_bytes': prev_size, 'now_bytes': live_size}
        if regressions:
            snapshots = sorted(p for p in BACKUP_DIR.glob('uploads-snapshot-*') if p.is_dir())
            prev_snapshot = snapshots[-1] if snapshots else None
            _log(
                '[DATA LOSS DETECTED] one or more uploaded files collapsed in '
                f'size or disappeared: {json.dumps(regressions)}. If this is '
                'unexpected, the last-known-good copy is in '
                f'{prev_snapshot or "(no snapshot exists yet)"} — copy the '
                'affected file(s) back from there rather than re-uploading '
                'from scratch if the original source is gone.'
            )
    _save_uploads_fingerprint(live_fp)


def _prune_old_upload_manifests():
    if not BACKUP_DIR.is_dir():
        return
    manifests = sorted(BACKUP_DIR.glob('uploads-*.json'))
    for old in manifests[:-KEEP_BACKUPS]:
        try:
            old.unlink()
        except Exception:
            pass


def backup_database():
    """Copy the live DB to a timestamped file using SQLite's own backup API
    (transactionally consistent even against a database being written to
    concurrently — a plain file copy is not). Returns the new backup path,
    or None if the source DB doesn't exist yet (e.g. very first launch)."""
    if not Path(DB_PATH).exists():
        return None
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d-%H%M%S')
    dest_path = BACKUP_DIR / f'mail-{stamp}.db'
    src = sqlite3.connect(DB_PATH)
    dest = sqlite3.connect(dest_path)
    try:
        with dest:
            src.backup(dest)
    finally:
        src.close()
        dest.close()
    return dest_path


def backup_uploads():
    """Copy every directory in _PROTECTED_DIRS into a timestamped snapshot
    (one labeled subfolder per protected dir), so a real recoverable copy
    exists if a file is ever silently corrupted or overwritten. **User,
    directly, after the signature-image incident**: "Did you save the
    signature file somewhere so it doesn't get corrupted or 'deleted'
    accidentally in one of the next updates?" — the honest answer at the
    time was no: check_uploads_integrity() above only ever detected a
    collapse, it never kept a copy of the real bytes to recover from (its
    own log message said as much). This is that missing half. Files here
    are small (images/fonts/sounds, not the separate, much larger
    ticket_attachments cache — deliberately excluded, see _PROTECTED_DIRS'
    own reasoning: that's re-fetchable from Freshdesk, not irreplaceable
    user-uploaded content) so a full copy every cycle is cheap."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d-%H%M%S')
    dest_dir = BACKUP_DIR / f'uploads-snapshot-{stamp}'
    copied_any = False
    for label, src in _PROTECTED_DIRS:
        if not src.is_dir():
            continue
        try:
            shutil.copytree(src, dest_dir / label)
            copied_any = True
        except Exception as e:
            _log(f'[backup-uploads-error] {label}: {e}')
    if not copied_any:
        return None
    return dest_dir


def _prune_old_upload_snapshots():
    if not BACKUP_DIR.is_dir():
        return
    snapshots = sorted(p for p in BACKUP_DIR.glob('uploads-snapshot-*') if p.is_dir())
    for old in snapshots[:-KEEP_BACKUPS]:
        try:
            shutil.rmtree(old, ignore_errors=True)
        except Exception:
            pass


def _previous_backup():
    """The most recent backup that isn't the one we're about to create — for
    diffing against, not restoring from (this run's own fresh backup is
    always the newest file, so 'second newest' is the real previous one)."""
    backups = sorted(BACKUP_DIR.glob('mail-*.db')) if BACKUP_DIR.is_dir() else []
    return backups[-2] if len(backups) >= 2 else None


def check_integrity():
    """Compare the live DB against the previous backup; log loudly if
    anything watched went from real data to empty. Best-effort — a failure
    here should never take down the backup itself."""
    prev = _previous_backup()
    if prev is None:
        return  # nothing to compare against yet (first or second run ever)
    # Live and backup connections/fingerprints are tried separately, not in
    # one try block — a failure reading the LIVE db means mail.db itself is
    # broken (strictly worse than any single field going empty, since
    # ensure_db_healthy() in db.py already runs at startup for this exact
    # case but a corruption mid-session wouldn't be caught until the next
    # restart otherwise) and deserves the same loud [DATA LOSS DETECTED]
    # treatment this function already gives an empty-field regression, not
    # the quiet [backup-integrity-check-error] both cases used to share.
    try:
        live_conn = sqlite3.connect(DB_PATH)
        live_fp = _fingerprint(live_conn)
        live_conn.close()
    except Exception as e:
        _log(f'[DATA LOSS DETECTED] mail.db failed a routine integrity check: {e}. '
             f'Most recent backup: {prev}. Restore from there if this is unexpected.')
        return
    try:
        prev_conn = sqlite3.connect(prev)
        prev_fp = _fingerprint(prev_conn)
        prev_conn.close()
    except Exception as e:
        _log(f'[backup-integrity-check-error] could not read previous backup {prev}: {e}')
        return

    regressions = {
        k: (prev_fp[k], live_fp[k])
        for k in live_fp
        if prev_fp.get(k, 0) > 0 and live_fp[k] == 0
    }
    if regressions:
        _log(
            '[DATA LOSS DETECTED] one or more fields that had real data now '
            f'show empty: {json.dumps(regressions)}. Previous backup with the '
            f'real values: {prev}. If this is unexpected, restore the '
            'affected keys/tables from that file rather than assuming this '
            'is intentional.'
        )


def _prune_old_backups():
    if not BACKUP_DIR.is_dir():
        return
    backups = sorted(BACKUP_DIR.glob('mail-*.db'))
    for old in backups[:-KEEP_BACKUPS]:
        try:
            old.unlink()
        except Exception:
            pass


def backup_loop():
    """Runs forever in a daemon thread — first backup shortly after
    startup (so a fresh install/update still gets one same-day), then every
    BACKUP_INTERVAL_SECONDS after that."""
    time.sleep(60)  # let the app finish booting before doing disk I/O
    while True:
        try:
            backup_database()
            check_integrity()
            check_uploads_integrity()
            backup_uploads()
            _prune_old_backups()
            _prune_old_upload_manifests()
            _prune_old_upload_snapshots()
        except Exception as e:
            _log(f'[backup-loop-error] {e}')
        time.sleep(BACKUP_INTERVAL_SECONDS)
