"""Neutral home for the rules execution engine.
Imported by messages.py (list_messages) and main.py (notification daemon).
Neither caller is rules.py, so the engine lives here to avoid blueprint-to-blueprint imports.
"""

from db import get_db
from imap import imap_connect, resolve_folder


def get_active_rules():
    conn = get_db()
    rows = conn.execute('SELECT * FROM rules WHERE active=1').fetchall()
    conn.close()
    return [dict(r) for r in rows]

def apply_rules_to_messages(messages, account, acct_key):
    """Check each message against active rules and apply actions in-place.
    Returns (kept_messages, moved_uids) — moved messages are removed from the list."""
    rules = get_active_rules()
    if not rules:
        return messages, []

    kept, moved_uids = [], []
    for msg in messages:
        matched_rule = None
        for rule in rules:
            field = rule['condition_field']
            op    = rule['condition_op']
            val   = (rule['condition_value'] or '').lower()
            src   = ''
            if field == 'subject':  src = (msg.get('subject') or '').lower()
            elif field == 'from':   src = ((msg.get('from_name') or '') + ' ' + (msg.get('from_addr') or '')).lower()
            elif field == 'to':     src = (msg.get('to') or '').lower()

            hit = False
            if op == 'contains':      hit = val in src
            elif op == 'equals':      hit = src == val
            elif op == 'starts_with': hit = src.startswith(val)
            elif op == 'ends_with':   hit = src.endswith(val)
            elif op == 'not_contains':hit = val not in src

            if hit:
                matched_rule = rule
                break

        if not matched_rule:
            kept.append(msg)
            continue

        action = matched_rule['action']
        if action == 'move':
            dest = matched_rule['action_value']
            if dest:
                try:
                    client = imap_connect(account)
                    src_folder = resolve_folder('INBOX', acct_key)
                    dst_folder = resolve_folder(dest, acct_key)
                    client.select_folder(src_folder)
                    client.move([int(msg['uid'])], dst_folder)
                    moved_uids.append(msg['uid'])
                    # Same fix as messages.py's move_messages(): delete the
                    # now-stale INBOX row from message_cache, or a moved
                    # message keeps showing back up in Inbox on the next
                    # unforced cache-backed load (see that function's comment
                    # for the full mechanism — confirmed live, user-reported).
                    conn = get_db()
                    conn.execute(
                        "DELETE FROM message_cache WHERE account=? AND folder='INBOX' AND uid=?",
                        (acct_key, str(msg['uid'])),
                    )
                    conn.commit()
                    conn.close()
                except Exception:
                    kept.append(msg)
            else:
                kept.append(msg)
        elif action == 'mark_read':
            msg['read'] = True
            kept.append(msg)
        elif action == 'flag':
            msg['flagged_imap'] = True
            kept.append(msg)
        elif action == 'delete':
            try:
                client = imap_connect(account)
                src_folder = resolve_folder('INBOX', acct_key)
                client.select_folder(src_folder)
                client.delete_messages([int(msg['uid'])])
                client.expunge()
                moved_uids.append(msg['uid'])
            except Exception:
                kept.append(msg)
        elif action == 'assign_label':
            tag_name = (matched_rule['action_value'] or '').strip()
            if tag_name:
                try:
                    import json as _json2
                    sender_email = (msg.get('from_addr') or '').strip().lower()
                    sender_name  = (msg.get('from_name') or '').strip()
                    if sender_email:
                        conn2 = get_db()
                        row = conn2.execute(
                            "SELECT id, tags FROM contacts WHERE LOWER(email)=?", (sender_email,)
                        ).fetchone()
                        if row:
                            existing = _json2.loads(row['tags'] or '[]')
                            if tag_name not in existing:
                                existing.append(tag_name)
                                conn2.execute("UPDATE contacts SET tags=? WHERE id=?",
                                              (_json2.dumps(existing), row['id']))
                                conn2.commit()
                        else:
                            # Create contact on-the-fly with this tag
                            conn2.execute(
                                "INSERT INTO contacts (name, email, tags) VALUES (?, ?, ?)",
                                (sender_name or sender_email, sender_email, _json2.dumps([tag_name]))
                            )
                            conn2.commit()
                        conn2.close()
                except Exception:
                    pass
            kept.append(msg)
        else:
            kept.append(msg)

    return kept, moved_uids
