import json
import logging
import threading
import email.utils
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import Blueprint, request, jsonify

from db import get_db
from imap import (get_all_accounts, imap_connect, _get_bg_imap, drop_bg_client,
                  bg_append_lock,
                  _draft_folder_cache, _sent_folder_cache,
                  _unread_cache_lock, _folder_cache)
from helpers import _do_send

bp = Blueprint('send', __name__)


@bp.route('/api/drafts', methods=['POST', 'OPTIONS'])
def save_draft():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json()
    account = body.get('account') or None

    accounts = get_all_accounts()
    if not accounts:
        return jsonify(error='not logged in'), 401
    from_addr = account if (account and account in accounts) else accounts[0]

    msg = MIMEMultipart('alternative')
    msg['From'] = from_addr
    msg['To'] = body.get('to', '')
    if body.get('cc'):
        msg['Cc'] = body['cc']
    if body.get('bcc'):
        msg['Bcc'] = body['bcc']
    msg['Subject'] = body.get('subject', '')
    msg['Date'] = email.utils.formatdate(localtime=True)
    msg['Message-ID'] = email.utils.make_msgid(domain='overlord.local')

    text_body = body.get('body', '')

    # Embed signature into draft body so it displays when reading the draft
    # Signature is NOT embedded in draft body — it's added at send time only.
    # The compose window shows it in the preview panel separately.

    if text_body:
        msg.attach(MIMEText(text_body, 'html', 'utf-8'))

    acct_key = from_addr
    # Find Drafts folder — use a fresh connection so list_folders() never fails due to selected state
    if acct_key not in _draft_folder_cache:
        lf_client = imap_connect(account, force_new=True)
        if not lf_client:
            return jsonify(error='not logged in'), 401
        draft_folder = 'Drafts'
        try:
            for flags, _, name in lf_client.list_folders():
                flags_str = [f.decode() if isinstance(f, bytes) else f for f in flags]
                if '\\Drafts' in flags_str:
                    draft_folder = name
                    break
        except Exception:
            pass
        _draft_folder_cache[acct_key] = draft_folder
    else:
        draft_folder = _draft_folder_cache[acct_key]

    msg_bytes = msg.as_bytes()

    # Invalidate DB cache NOW so any subsequent message fetch goes to IMAP
    try:
        conn_inv = get_db()
        conn_inv.execute("DELETE FROM message_cache WHERE account=? AND folder=?", (acct_key, draft_folder))
        conn_inv.commit()
        conn_inv.close()
    except Exception:
        pass

    # Do the IMAP append synchronously — frontend shows "Saving…" so a 2-3s wait is fine,
    # and this guarantees the draft is on IMAP before we tell the client to reload messages.
    _draft_log = logging.getLogger('overlord.draft')
    bg_client = _get_bg_imap(account)
    if not bg_client:
        return jsonify(error='not logged in'), 401

    # A "proper" autosave failsafe needs each save to overwrite the previous
    # one in place, not accumulate copies — that requires knowing the UID of
    # the draft just created so the *next* save can delete exactly that one.
    # imapclient's append() returns the server's raw APPEND response; when
    # the server supports UIDPLUS (Dovecot does by default) that response
    # includes "[APPENDUID <uidvalidity> <uid>] APPEND completed" — parse it
    # out rather than adding a second round-trip (e.g. a SEARCH) to find it.
    import re as _re
    _appenduid_re = _re.compile(rb'APPENDUID\s+\d+\s+(\d+)')

    def _extract_uid(resp):
        if not resp:
            return None
        m = _appenduid_re.search(resp if isinstance(resp, bytes) else str(resp).encode())
        return int(m.group(1)) if m else None

    success_folder = None
    success_uid = None
    # bg_append_lock(account) serialises this block against do_sent_append, which
    # also writes to the same shared background connection for this account.
    with bg_append_lock(account):
        try:
            resp = bg_client.append(draft_folder, msg_bytes, flags=['\\Draft'])
            success_folder = draft_folder
            success_uid = _extract_uid(resp)
            _draft_log.info('[draft] appended to %s for %s (uid=%s)', draft_folder, acct_key, success_uid)
        except Exception as ex:
            _draft_log.error('[draft] append failed folder=%r: %s', draft_folder, ex)
            # Stale connection — evict and recreate
            drop_bg_client(account)
            bg_client = _get_bg_imap(account)
            if bg_client:
                for alt in ('Drafts', '[Gmail]/Drafts', 'INBOX.Drafts', 'Draft'):
                    if alt == draft_folder:
                        continue
                    try:
                        resp = bg_client.append(alt, msg_bytes, flags=['\\Draft'])
                        success_folder = alt
                        success_uid = _extract_uid(resp)
                        _draft_log.info('[draft] appended to fallback %s (uid=%s)', alt, success_uid)
                        break
                    except Exception:
                        pass

    if not success_folder:
        return jsonify(error='draft save failed'), 500

    # Bump folder total in cache now that append is confirmed
    with _unread_cache_lock:
        if acct_key in _folder_cache:
            for entry in _folder_cache[acct_key]:
                if entry.get('name') == success_folder:
                    entry['total'] = entry.get('total', 0) + 1
                    break

    return jsonify(ok=True, folder=success_folder, uid=success_uid)


# ── Send email ────────────────────────────────────────────────────────────────

@bp.route('/api/schedule-send', methods=['POST', 'OPTIONS'])
def schedule_send():
    if request.method == 'OPTIONS': return '', 204
    body = request.get_json()
    account = body.get('account') or ''
    send_at_utc = body.get('send_at_utc', '')  # ISO UTC string
    if not send_at_utc:
        return jsonify(error='send_at_utc required'), 400
    conn = get_db()
    conn.execute(
        'INSERT INTO scheduled_sends (account, send_at_utc, payload) VALUES (?, ?, ?)',
        (account, send_at_utc, json.dumps(body))
    )
    conn.commit()
    conn.close()
    return jsonify(ok=True)

@bp.route('/api/schedule-send', methods=['GET', 'OPTIONS'])
def list_scheduled():
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    rows = conn.execute("SELECT id, account, send_at_utc, status, payload FROM scheduled_sends ORDER BY send_at_utc").fetchall()
    conn.close()
    return jsonify([{'id': r[0], 'account': r[1], 'send_at_utc': r[2], 'status': r[3],
                     'subject': json.loads(r[4]).get('subject', '')} for r in rows])

@bp.route('/api/schedule-send/<int:sid>', methods=['DELETE', 'OPTIONS'])
def cancel_scheduled(sid):
    if request.method == 'OPTIONS': return '', 204
    conn = get_db()
    conn.execute("DELETE FROM scheduled_sends WHERE id=? AND status='pending'", (sid,))
    conn.commit()
    conn.close()
    # Intentional idempotent-delete contract: ok=True regardless of rows affected.
    # A non-existent or already-sent id is a no-op, not an error — safe to retry.
    return jsonify(ok=True)


@bp.route('/api/send', methods=['POST', 'OPTIONS'])
def send_email():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json()
    ok, err, code = _do_send(body)
    if ok:
        return jsonify(ok=True)
    return jsonify(error=err), code
