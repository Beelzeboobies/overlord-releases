"""
freecords_client.py — shared authenticated-request helper for Freecords'
own admin API.

Pulled out of freecords_admin.py so a second blueprint (mobile_api.py, the
iPhone companion app's read-only API surface) could reuse it without
importing another blueprint — this project's own CLAUDE.md rule: "No
blueprint imports another blueprint. Shared logic between two blueprints
goes in a shared module." freecords_admin.py now imports `_api` from here
too, so there's exactly one implementation, not a fork.
"""

import requests as http
import freecords_auth


def _api(method, path, timeout=10, _retries=2, **kwargs):
    """
    Authenticated request to Freecords admin API.
    Returns (data_dict_or_None, error_string_or_None).
    Never opens the browser — 401 becomes a plain error string.

    timeout defaults to 10s, fine for typical lookups — pass a longer value
    for endpoints known to do slow, synchronous work server-side (e.g.
    analyze-copyright, confirmed to take ~10s+ and get cut off by the
    default before).

    On a 429, retry with backoff rather than silently failing — a burst of
    calls from the sync-reconciliation loop rate-limited this API once
    already, and because callers there didn't check the result, tickets got
    marked "reconciled" (and the sync cursor advanced past them) even though
    the actual status patch never went through. Retrying here fixes it at
    the source instead of relying on every caller to check errors correctly.
    """
    token = freecords_auth.get_token()
    if not token:
        return None, 'Not connected — connect your Freecords account in Settings → Tickets'

    headers = {'Authorization': f'Bearer {token}'}
    # Multipart uploads (kwargs['files']) must NOT get an explicit
    # Content-Type — requests sets the multipart boundary itself. Only
    # force JSON when there's no file payload.
    if 'files' not in kwargs:
        headers['Content-Type'] = 'application/json'
    headers.update(kwargs.pop('headers', {}))

    try:
        resp = http.request(
            method,
            freecords_auth.FREECORDS_BASE_URL + path,
            headers=headers,
            timeout=timeout,
            **kwargs,
        )
    except (http.exceptions.ConnectionError, http.exceptions.Timeout):
        # Previously gave up immediately with no retry at all — confirmed
        # this is what caused ~580 of ~2200 PATCH calls to silently fail
        # during the ticket-status reconciliation sweep (not a 429; the 429
        # path above already retries). A transient connection blip shouldn't
        # permanently skip a status fix — same "files" guard as the 429 path,
        # for the same reason (multipart stream already consumed).
        if _retries > 0 and 'files' not in kwargs:
            import time as _time
            _time.sleep(1)
            return _api(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        return None, "connection_error"
    except Exception as e:
        return None, str(e)

    if resp.status_code == 401:
        # A valid token (7-day JWT) shouldn't 401 — but confirmed live
        # (2026-09-17, user-reported): a single request can come back 401
        # while an immediate follow-up call to the exact same /api/admin/me
        # endpoint succeeds, meaning the token was never actually invalid.
        # Before this, any 401 was reported as permanent "Session expired"
        # with zero retry, unlike the 429/connection-error paths just below
        # — a transient blip sent people down the "go reconnect" path for
        # nothing. One retry, same "files" guard as those two (a multipart
        # stream is already consumed and can't be safely re-sent).
        if _retries > 0 and 'files' not in kwargs:
            import time as _time
            _time.sleep(1)
            return _api(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        return None, 'Session expired — reconnect in Settings → Tickets'
    if resp.status_code == 404:
        return {'_not_found': True}, None
    if resp.status_code == 429:
        if _retries > 0 and 'files' not in kwargs:
            # Skip retry for multipart uploads — the file stream is already
            # consumed by the failed attempt and can't be safely re-sent.
            import time as _time
            wait = int(resp.headers.get('Retry-After', 5))
            _time.sleep(min(wait, 30))
            return _api(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        # Retries exhausted (or a multipart upload that can't be retried).
        # This is Freecords/Freshdesk itself throttling us, not an auth
        # problem — say so plainly instead of falling through to a generic
        # message that reads like "go reconnect your account" and sends
        # people down the wrong troubleshooting path.
        return None, 'Freecords is rate-limiting requests right now — try again in a moment'
    if not resp.ok:
        try:
            body = resp.json()
            msg = body.get('error') or body.get('message') or f'HTTP {resp.status_code}'
        except Exception:
            msg = f'HTTP {resp.status_code}'
        return None, msg

    try:
        return resp.json(), None
    except Exception:
        return {}, None
