"""
freecords_client.py — shared authenticated-request helper for Freecords'
own admin API.

Pulled out of freecords_admin.py so a second blueprint (mobile_api.py, the
iPhone companion app's read-only API surface) could reuse it without
importing another blueprint — this project's own CLAUDE.md rule: "No
blueprint imports another blueprint. Shared logic between two blueprints
goes in a shared module." freecords_admin.py now imports `_api` from here
too, so there's exactly one implementation, not a fork.
"""

import os
import threading
import time as _gate_time

import requests as http
import freecords_auth


# ── Request guard (2026-10-19) ────────────────────────────────────────────────
# A read-only script that fired ~60 requests at once (searches that each fan out
# into several upstream queries) caused a Freecords database incident, and
# **Nik**: "these APIs are not designed for bulk search or anything ... make one
# simultaneously and don't set another until it's finished". Several routes in
# freecords_admin.py also fan out through thread pools of 4-8 workers (ticket
# list scans, tag counts, sent view ...). Rather than trust every call site, the
# ONE function every Freecords call goes through now lets only
# FREECORDS_MAX_INFLIGHT requests (default 1) be in flight at any moment and
# leaves a short gap between them. Thread pools elsewhere still exist but
# can only queue here, so they can no longer hit Freecords in parallel.
_MAX_INFLIGHT = max(1, int(os.environ.get('FREECORDS_MAX_INFLIGHT', '1')))
_GATE_WAIT_SECONDS = float(os.environ.get('FREECORDS_GATE_WAIT', '45'))     # an interactive request may wait this long for its turn
_BG_WAIT_SECONDS = float(os.environ.get('FREECORDS_BG_WAIT', '900'))        # a background request is patient
_MIN_GAP_SECONDS = float(os.environ.get('FREECORDS_MIN_GAP', '0.15'))       # pause between consecutive requests
_gate_state = {'last_end': 0.0}
_gate_lock = threading.Lock()

# ── Two lanes, still ONE request at a time (2026-10-22) ────────────────────────
# The first version of the guard was a plain semaphore with a 45s wait: a ticket-list scan,
# tag counts or a startup index walk (tens of requests) made a user's CLICK - closing a
# ticket, opening one - wait behind all of it and fail with "requests are queued behind other
# work". **User**: "This won't do. It's not workable." So: interactive requests (anything a
# person just did) always go before queued background work, and are first in line the moment
# the request in flight finishes (about half a second). Background work - page scans, bulk
# lookups, the loops in main.py - waits its turn without a short timeout. Freecords still never
# sees more than _MAX_INFLIGHT requests at once.
_LANE_INTERACTIVE, _LANE_BACKGROUND = 0, 1
_cv = threading.Condition()
_busy = 0
_queues = ([], [])
_tl = threading.local()


def set_background_thread():
    """Everything this thread asks Freecords is background work (loops, worker pools)."""
    _tl.lane = _LANE_BACKGROUND


def _lane_for(method, path, kwargs):
    forced = kwargs.pop('lane', None)
    if forced == 'background':
        return _LANE_BACKGROUND
    if forced == 'interactive':
        return _LANE_INTERACTIVE
    if getattr(_tl, 'lane', None) is not None:
        return _tl.lane
    # A list page of the ticket scan: part of a many-request sweep, not a single click.
    if method == 'GET' and path.split('?')[0].rstrip('/') == '/api/admin/tickets' and 'page' in (kwargs.get('params') or {}):
        return _LANE_BACKGROUND
    return _LANE_INTERACTIVE


def _enter(lane, timeout):
    global _busy
    me = object()
    deadline = _gate_time.monotonic() + timeout
    with _cv:
        _queues[lane].append(me)
        while True:
            first = (_queues[0][0] is me) if lane == _LANE_INTERACTIVE else (not _queues[0] and _queues[1][0] is me)
            if _busy < _MAX_INFLIGHT and first:
                _queues[lane].remove(me)
                _busy += 1
                return True
            left = deadline - _gate_time.monotonic()
            if left <= 0:
                _queues[lane].remove(me)
                _cv.notify_all()
                return False
            _cv.wait(min(left, 1.0))


def _leave():
    global _busy
    with _cv:
        _busy -= 1
        _cv.notify_all()


def _api(method, path, timeout=10, _retries=2, **kwargs):
    """Guarded entry point: same contract as before (returns (data, error)),
    but serialised and prioritised. Retries/backoff inside happen while holding the gate, so a
    429 backoff also pauses everyone else instead of letting them pile on.
    Optional lane='interactive'|'background' overrides the automatic choice."""
    lane = _lane_for(method, path, kwargs)
    if not _enter(lane, _GATE_WAIT_SECONDS if lane == _LANE_INTERACTIVE else _BG_WAIT_SECONDS):
        return None, 'Freecords requests are queued behind other work right now — try again in a moment'
    try:
        with _gate_lock:
            gap = _MIN_GAP_SECONDS - (_gate_time.monotonic() - _gate_state['last_end'])
        if gap > 0:
            _gate_time.sleep(gap)
        return _api_inner(method, path, timeout=timeout, _retries=_retries, **kwargs)
    finally:
        with _gate_lock:
            _gate_state['last_end'] = _gate_time.monotonic()
        _leave()


def _api_inner(method, path, timeout=10, _retries=2, **kwargs):
    """
    Authenticated request to Freecords admin API.
    Returns (data_dict_or_None, error_string_or_None).
    Never opens the browser — 401 becomes a plain error string.

    timeout defaults to 10s, fine for typical lookups — pass a longer value
    for endpoints known to do slow, synchronous work server-side (e.g.
    analyze-copyright, confirmed to take ~10s+ and get cut off by the
    default before).

    On a 429, retry with backoff rather than silently failing — a burst of
    calls from the sync-reconciliation loop rate-limited this API once
    already, and because callers there didn't check the result, tickets got
    marked "reconciled" (and the sync cursor advanced past them) even though
    the actual status patch never went through. Retrying here fixes it at
    the source instead of relying on every caller to check errors correctly.
    """
    token = freecords_auth.get_token()
    if not token:
        return None, 'Not connected — connect your Freecords account in Settings → Tickets'

    headers = {'Authorization': f'Bearer {token}'}
    # Multipart uploads (kwargs['files']) must NOT get an explicit
    # Content-Type — requests sets the multipart boundary itself. Only
    # force JSON when there's no file payload.
    if 'files' not in kwargs:
        headers['Content-Type'] = 'application/json'
    headers.update(kwargs.pop('headers', {}))

    try:
        resp = http.request(
            method,
            freecords_auth.FREECORDS_BASE_URL + path,
            headers=headers,
            timeout=timeout,
            **kwargs,
        )
    except (http.exceptions.ConnectionError, http.exceptions.Timeout):
        # Previously gave up immediately with no retry at all — confirmed
        # this is what caused ~580 of ~2200 PATCH calls to silently fail
        # during the ticket-status reconciliation sweep (not a 429; the 429
        # path above already retries). A transient connection blip shouldn't
        # permanently skip a status fix — same "files" guard as the 429 path,
        # for the same reason (multipart stream already consumed).
        if _retries > 0 and 'files' not in kwargs:
            import time as _time
            _time.sleep(1)
            return _api_inner(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        return None, "connection_error"
    except Exception as e:
        return None, str(e)

    if resp.status_code == 401:
        # A valid token (7-day JWT) shouldn't 401 — but confirmed live
        # (2026-09-17, user-reported): a single request can come back 401
        # while an immediate follow-up call to the exact same /api/admin/me
        # endpoint succeeds, meaning the token was never actually invalid.
        # Before this, any 401 was reported as permanent "Session expired"
        # with zero retry, unlike the 429/connection-error paths just below
        # — a transient blip sent people down the "go reconnect" path for
        # nothing. One retry, same "files" guard as those two (a multipart
        # stream is already consumed and can't be safely re-sent).
        if _retries > 0 and 'files' not in kwargs:
            import time as _time
            _time.sleep(1)
            return _api_inner(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        return None, 'Session expired — reconnect in Settings → Tickets'
    if resp.status_code == 404:
        return {'_not_found': True}, None
    if resp.status_code == 429:
        if _retries > 0 and 'files' not in kwargs:
            # Skip retry for multipart uploads — the file stream is already
            # consumed by the failed attempt and can't be safely re-sent.
            import time as _time
            wait = int(resp.headers.get('Retry-After', 5))
            _time.sleep(min(wait, 30))
            return _api_inner(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        # Retries exhausted (or a multipart upload that can't be retried).
        # This is Freecords/Freshdesk itself throttling us, not an auth
        # problem — say so plainly instead of falling through to a generic
        # message that reads like "go reconnect your account" and sends
        # people down the wrong troubleshooting path.
        return None, 'Freecords is rate-limiting requests right now — try again in a moment'
    if not resp.ok:
        try:
            body = resp.json()
            msg = body.get('error') or body.get('message') or f'HTTP {resp.status_code}'
        except Exception:
            msg = f'HTTP {resp.status_code}'
        return None, msg

    try:
        return resp.json(), None
    except Exception:
        return {}, None
