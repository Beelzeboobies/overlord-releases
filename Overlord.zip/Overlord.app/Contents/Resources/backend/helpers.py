import base64
import re as _re
import smtplib
from tls import tls_context
import threading
import urllib.request as _urlreq
from datetime import datetime as _dt, timezone as _tz
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.application import MIMEApplication
import email.utils

from db import get_db
from config import SETTINGS_PATH, DEFAULT_SMTP_HOST, DEFAULT_SMTP_PORT, APP_SUPPORT
from imap import (get_all_accounts, get_account_password, get_account_config,
                  _get_bg_imap, bg_append_lock, _sent_folder_cache,
                  _folder_cache, _unread_cache_lock)

MEET_URL_RE = _re.compile(r'https://meet\.google\.com/[a-z0-9\-]+', _re.I)
ZOOM_URL_RE = _re.compile(r'https://[\w.]*zoom\.us/j/[\w?=&]+', _re.I)

# do_sent_append (below) is a fire-and-forget background thread: the actual
# SMTP send in _do_send already succeeded and returned before this even
# starts, so a failure here is invisible to the sender and, until this was
# added, invisible everywhere else too — the old bare print() only reaches a
# terminal, not a GUI-launched app's log. Real user report: a genuinely sent
# email (recipient received it) never showed up in Sent, with zero trace
# anywhere. This writes to the same backend.log every other subsystem in
# this app already logs to, so a repeat is actually diagnosable next time.
def _log_sent_append_failure(msg):
    line = f'[{_dt.now(_tz.utc).isoformat(timespec="seconds")}] [send] sent-append failed: {msg}'
    try:
        with open(APP_SUPPORT / 'logs' / 'backend.log', 'a') as f:
            f.write(line + '\n')
    except Exception:
        pass
    print(line, flush=True)

# ── Pooled SMTP connections ─────────────────────────────────────────────────
# Every send previously opened a brand-new connection from scratch — DNS +
# TCP + TLS handshake + AUTH login, all as pure synchronous wait before the
# user's "Sending…" UI could resolve. Confirmed live as the dominant chunk of
# a reported 5+ second post-countdown delay. Mirrors _get_bg_imap's pattern
# in imap.py: keep one connection alive per (account, host, port), probe it
# with NOOP before reuse, and transparently reconnect if it's gone stale —
# same shape of fix, same reason (a fresh TLS+AUTH handshake is the
# expensive part, not the actual message transfer).
_smtp_pool = {}
_smtp_pool_lock = threading.Lock()
_smtp_send_locks = {}
_smtp_send_locks_guard = threading.Lock()


def _smtp_send_lock(key):
    """Per-(account,host,port) lock serialising sendmail() calls on the pooled
    connection — an SMTP session isn't safe for two threads to issue commands
    on concurrently (e.g. a scheduled send firing while a live user send is
    in flight), same class of hazard bg_append_lock guards against for IMAP."""
    with _smtp_send_locks_guard:
        return _smtp_send_locks.setdefault(key, threading.Lock())


def _open_smtp(smtp_host, smtp_port, from_addr, password):
    if smtp_port == 587:
        server = smtplib.SMTP(smtp_host, smtp_port, timeout=20)
        server.ehlo()
        server.starttls(context=tls_context())
        server.ehlo()
    else:
        server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=20, context=tls_context())
    server.login(from_addr, password)
    return server


def _get_pooled_smtp(smtp_host, smtp_port, from_addr, password):
    key = (from_addr, smtp_host, smtp_port)
    with _smtp_pool_lock:
        server = _smtp_pool.get(key)
        if server is not None:
            try:
                server.noop()
                return key, server
            except Exception:
                try:
                    server.close()
                except Exception:
                    pass
                _smtp_pool.pop(key, None)
        server = _open_smtp(smtp_host, smtp_port, from_addr, password)
        _smtp_pool[key] = server
        return key, server


def _drop_pooled_smtp(key):
    with _smtp_pool_lock:
        server = _smtp_pool.pop(key, None)
        if server:
            try:
                server.close()
            except Exception:
                pass


def _find_conf_url(text: str) -> str:
    """Extract first Google Meet or Zoom URL from a block of text."""
    if not text:
        return ''
    m = MEET_URL_RE.search(text) or ZOOM_URL_RE.search(text)
    return m.group(0) if m else ''


def _parse_reminder(value):
    """Return reminder_minutes as a list, handling legacy int or JSON array."""
    import json as _json
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, int):
        return [value] if value > 0 else []
    try:
        data = _json.loads(str(value))
        if isinstance(data, list):
            return data
        if isinstance(data, (int, float)) and data > 0:
            return [int(data)]
        return []
    except Exception:
        try:
            v = int(value)
            return [v] if v > 0 else []
        except Exception:
            return []


def _sync_gcal_url(ics_url: str):
    """Fetch a Google Calendar secret ICS URL and upsert events."""
    try:
        req = _urlreq.Request(ics_url, headers={'User-Agent': 'Overlord/1.0'})
        raw = _urlreq.urlopen(req, timeout=15).read(20 * 1024 * 1024)
    except Exception:
        return 0, 0

    try:
        from icalendar import Calendar as _Cal
        cal = _Cal.from_ical(raw)
    except Exception:
        return 0, 0

    from datetime import date as _date
    imported = skipped = 0
    conn = get_db()

    for component in cal.walk():
        if component.name != 'VEVENT':
            continue
        try:
            uid   = str(component.get('UID', ''))
            title = str(component.get('SUMMARY', 'Untitled'))[:500]
            desc  = str(component.get('DESCRIPTION', '') or '')[:4000]
            loc   = str(component.get('LOCATION', '') or '')[:500]
            url   = str(component.get('URL', '') or '')
            meet_url = _find_conf_url(url + ' ' + desc + ' ' + loc)

            dtstart = component.get('DTSTART').dt
            dtend   = component.get('DTEND')
            dtend   = dtend.dt if dtend else dtstart

            all_day = isinstance(dtstart, _date) and not isinstance(dtstart, _dt)

            def _to_iso(d):
                if isinstance(d, _dt):
                    if d.tzinfo is None: return d.isoformat()
                    return d.astimezone(_tz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
                return d.isoformat() + 'T00:00:00Z'

            start_iso = _to_iso(dtstart)
            end_iso   = _to_iso(dtend)

            existing = conn.execute(
                'SELECT id FROM events WHERE ical_uid=? AND ical_uid != ""', (uid,)
            ).fetchone()
            if existing:
                conn.execute(
                    '''UPDATE events SET title=?,start_dt=?,end_dt=?,all_day=?,location=?,
                       description=?,meet_url=?,notified=0 WHERE id=?''',
                    (title, start_iso, end_iso, 1 if all_day else 0, loc, desc, meet_url, existing['id'])
                )
                skipped += 1
            else:
                conn.execute(
                    '''INSERT INTO events (title,start_dt,end_dt,all_day,location,description,meet_url,ical_uid,reminder_minutes)
                       VALUES (?,?,?,?,?,?,?,?,10)''',
                    (title, start_iso, end_iso, 1 if all_day else 0, loc, desc, meet_url, uid)
                )
                imported += 1
        except Exception:
            continue

    conn.commit()
    conn.close()
    return imported, skipped


def html_to_plain(html_text):
    """Readable plain text from the HTML the editor produces: paragraph and line breaks kept, tags removed,
    entities (&quot; &amp; &nbsp;) decoded, links written as "text (url)". Used for the plain-text part of
    every mail we send, and for the hosted-reply fallback, which sends whatever it is given as plain text
    (an artist reported raw <p style=...> markup in our replies, 27 Oct 2026)."""
    import html as _h
    t = html_text or ''
    t = _re.sub(r'<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                lambda m: m.group(2) if m.group(2).strip() in (m.group(1), '') else f'{m.group(2)} ({m.group(1)})',
                t, flags=_re.I | _re.S)
    t = _re.sub(r'<br\s*/?>|</p>|</div>|</li>|</h[1-6]>', '\n', t, flags=_re.I)
    t = _re.sub(r'<[^>]+>', '', t)
    t = _h.unescape(t).replace('\xa0', ' ')
    t = _re.sub(r'[ \t]+\n', '\n', t)
    t = _re.sub(r'\n{3,}', '\n\n', t)
    return t.strip()


def _do_send(body: dict):
    """Core SMTP send logic, extracted from the /api/send route handler.
    Takes the request body as a plain dict (no Flask context required).
    Returns (ok: bool, error: str, status_code: int).
    Route wrapper handles OPTIONS + request.get_json() + Flask response construction.
    Scheduler calls this directly with the stored payload dict.
    """
    account = body.get('account') or None

    accounts = get_all_accounts()
    if not accounts:
        return False, 'not logged in', 401
    from_addr = account if (account and account in accounts) else accounts[0]
    password  = get_account_password(from_addr)
    if not password:
        return False, 'no credentials', 401

    display_name = body.get('display_name', '').strip()
    from_header  = f'{display_name} <{from_addr}>' if display_name else from_addr
    # Callers that must know the Message-ID before the send (the Tickets
    # outbound path logs it to the ticket thread) pass their own; Reply-To
    # lets a send from support@ route the customer's answer back into a
    # specific ticket thread (support+tk<hex>@freecords.com).
    msg_id   = body.get('message_id') or email.utils.make_msgid(domain=from_addr.split('@')[-1])
    reply_to = (body.get('reply_to') or '').strip()

    msg = MIMEMultipart('alternative')
    msg['From']       = from_header
    msg['To']         = body.get('to', '')
    msg['Subject']    = body.get('subject', '')
    msg['Date']       = email.utils.formatdate(localtime=True)
    msg['Message-ID'] = msg_id
    if reply_to:
        msg['Reply-To'] = reply_to
    if body.get('cc'):
        msg['Cc'] = body['cc']
    if body.get('in_reply_to'):
        msg['In-Reply-To'] = body['in_reply_to']
        msg['References']  = body.get('references', body['in_reply_to'])

    text_body      = body.get('body', '')
    sig_html       = body.get('signature_html', '')
    if sig_html and not _re.search(r'<[a-z][\s\S]*?>', sig_html, _re.IGNORECASE):
        sig_html = sig_html.replace('\n', '<br>')
    sig_img_path   = body.get('signature_image', '')  # e.g. /api/uploads/signature.png
    reply_quote    = body.get('reply_quote_html', '')  # quoted thread, goes AFTER signature

    if sig_html or sig_img_path or reply_quote:
        # Build HTML email with embedded signature image (CID)
        conn_s = get_db()
        row_dn = conn_s.execute("SELECT value FROM settings WHERE key='display_name'").fetchone()
        conn_s.close()

        # text_body is already HTML from the rich editor — use it as-is for the HTML part.
        # Strip tags for the plain-text fallback part.
        import re as _re_plain
        plain_text = html_to_plain(text_body)
        html_body_text = text_body  # already valid HTML, no conversion needed

        if sig_img_path:
            # sig_img_path is like /api/uploads/signature.png → resolve to filesystem
            img_filename = sig_img_path.lstrip('/').replace('api/uploads/', '')
            img_path = SETTINGS_PATH / img_filename
            cid = 'sig_image_1'

            # Fetch layout settings to mirror the Settings UI
            conn_layout = get_db()
            layout_row = conn_layout.execute("SELECT value FROM settings WHERE key='sig_img_layout'").fetchone()
            width_row  = conn_layout.execute("SELECT value FROM settings WHERE key='sig_img_width'").fetchone()
            conn_layout.close()
            img_layout = layout_row[0] if layout_row else 'above'
            img_width  = int(width_row[0]) if width_row else 200

            # Build the <img> tag with the CID reference
            img_tag = f'<img src="cid:{cid}" width="{img_width}" style="display:block;max-width:{img_width}px;" alt="signature">'

            # Assemble the signature block: image above or below text
            text_part = sig_html or ''
            if img_layout == 'above':
                sig_combined = f'{img_tag}<br>{text_part}' if text_part else img_tag
            else:
                sig_combined = f'{text_part}<br>{img_tag}' if text_part else img_tag

            sig_block = f'<br><div class="signature">{sig_combined}</div>'
            quote_block = f'<br>{reply_quote}' if reply_quote else ''
            html_full = f'<div>{html_body_text}</div>{sig_block}{quote_block}'

            # outer: mixed (for CID attachment), inner: alternative (plain/html)
            outer = MIMEMultipart('related')
            outer['From']       = from_header
            outer['To']         = body.get('to', '')
            outer['Subject']    = body.get('subject', '')
            outer['Date']       = email.utils.formatdate(localtime=True)
            outer['Message-ID'] = msg_id
            if reply_to:
                outer['Reply-To'] = reply_to
            if body.get('cc'):        outer['Cc'] = body['cc']
            if body.get('in_reply_to'):
                outer['In-Reply-To'] = body['in_reply_to']
                outer['References']  = body.get('references', body['in_reply_to'])

            alt = MIMEMultipart('alternative')
            alt.attach(MIMEText(plain_text, 'plain', 'utf-8'))
            alt.attach(MIMEText(html_full, 'html', 'utf-8'))
            outer.attach(alt)

            try:
                with open(img_path, 'rb') as f:
                    img_data = f.read()
                ext = img_path.suffix.lower().lstrip('.')
                mime_img = MIMEImage(img_data, _subtype=ext)
                mime_img.add_header('Content-ID', f'<{cid}>')
                mime_img.add_header('Content-Disposition', 'inline')
                outer.attach(mime_img)
            except Exception:
                pass  # image missing — send without it

            msg = outer
        else:
            # HTML signature without image
            sig_block = f'<br><div class="signature">{sig_html}</div>' if sig_html else ''
            quote_block = f'<br>{reply_quote}' if reply_quote else ''
            html_full = f'<div>{html_body_text}</div>{sig_block}{quote_block}'
            msg = MIMEMultipart('alternative')
            msg['From']       = from_header
            msg['To']         = body.get('to', '')
            msg['Subject']    = body.get('subject', '')
            msg['Date']       = email.utils.formatdate(localtime=True)
            msg['Message-ID'] = msg_id
            if reply_to:
                msg['Reply-To'] = reply_to
            if body.get('cc'):        msg['Cc'] = body['cc']
            if body.get('in_reply_to'):
                msg['In-Reply-To'] = body['in_reply_to']
                msg['References']  = body.get('references', body['in_reply_to'])
            msg.attach(MIMEText(plain_text, 'plain', 'utf-8'))
            msg.attach(MIMEText(html_full, 'html', 'utf-8'))
    else:
        # No signature and no quoted thread — this branch was attaching
        # text_body (real HTML from the rich-text editor, e.g.
        # '<p style="margin:...">Hi Luis,</p>...') as MIMEText(..., 'plain'),
        # not 'html'. The compose window's Preview renders that same
        # text_body via dangerouslySetInnerHTML and looks completely normal,
        # but the actual SMTP send in this exact case (no signature/quote —
        # e.g. "Omit signature" checked, or a signature-less account) sent
        # the raw markup as literal plain text: the real recipient saw
        # `<p style="margin: 0 0 12px 0">Hi Luis,</p>` etc. as visible text,
        # not a rendered email. Confirmed live against a real sent message.
        # Fixed to match the alternative-part pattern used in every other
        # branch above: a real HTML part (last, so it's the preferred
        # rendering) plus a tag-stripped plain-text fallback.
        if text_body or reply_quote:
            import re as _re_q
            html_full = text_body
            if reply_quote:
                html_full += f'<br>{reply_quote}'
            plain = html_to_plain(text_body)
            if reply_quote:
                plain += '\n\n' + _re_q.sub('<[^>]+>', '', reply_quote)
            msg.attach(MIMEText(plain, 'plain', 'utf-8'))
            msg.attach(MIMEText(html_full, 'html', 'utf-8'))

    # File attachments (distinct from the CID signature image above) — the
    # Compose UI has always collected these into an `attachments` array, but
    # this function silently dropped them: buildPayload() on the frontend
    # never included the key, so a user could add a file, watch it show as a
    # pill in the composer, hit Send, and the file just never went anywhere.
    # Wrap whatever `msg` currently is (plain alternative, or the related/
    # alternative tree built above for a CID signature image) in an outer
    # mixed part so both the body structure and attachments coexist.
    raw_attachments = body.get('attachments') or []
    if raw_attachments:
        mixed = MIMEMultipart('mixed')
        for hdr in ('From', 'To', 'Subject', 'Date', 'Message-ID', 'Reply-To', 'Cc', 'In-Reply-To', 'References'):
            if hdr in msg:
                mixed[hdr] = msg[hdr]
                del msg[hdr]
        mixed.attach(msg)
        for att in raw_attachments:
            try:
                raw_bytes = base64.b64decode(att.get('data_base64', ''))
            except Exception:
                continue
            # filename is user-supplied (their own local file) but still
            # sanitized the same way as the download side — never trust a
            # filename going into a raw header value.
            att_filename = (att.get('filename') or 'attachment').replace('\r', '').replace('\n', '')
            part = MIMEApplication(raw_bytes, Name=att_filename)
            part['Content-Disposition'] = f'attachment; filename="{att_filename}"'
            mixed.attach(part)
        msg = mixed

    # Collect all recipients (exclude bcc from headers but include in envelope)
    def parse_addrs(field):
        return [a.strip() for a in field.split(',') if a.strip()]

    recipients = (parse_addrs(body.get('to', '')) +
                  parse_addrs(body.get('cc', '')) +
                  parse_addrs(body.get('bcc', '')))
    if not recipients:
        return False, 'no recipients', 400

    cfg = get_account_config(from_addr)
    smtp_host = cfg.get('smtp_host', DEFAULT_SMTP_HOST)
    smtp_port = int(cfg.get('smtp_port', DEFAULT_SMTP_PORT))

    try:
        key, server = _get_pooled_smtp(smtp_host, smtp_port, from_addr, password)
    except smtplib.SMTPAuthenticationError:
        return False, 'SMTP authentication failed — check credentials or use an app password', 401
    except Exception as e:
        return False, f'Send failed: {e}', 500

    with _smtp_send_lock(key):
        try:
            server.sendmail(from_addr, recipients, msg.as_bytes())
        except Exception:
            # Pooled connection may have gone stale between the NOOP check and
            # this call (e.g. server-side idle timeout) — drop it and retry
            # once with a fresh one rather than failing a real send over a
            # dead reused socket.
            _drop_pooled_smtp(key)
            try:
                key, server = _get_pooled_smtp(smtp_host, smtp_port, from_addr, password)
                server.sendmail(from_addr, recipients, msg.as_bytes())
            except smtplib.SMTPAuthenticationError:
                return False, 'SMTP authentication failed — check credentials or use an app password', 401
            except Exception as e2:
                return False, f'Send failed: {e2}', 500

    # Append to Sent folder in background — don't block the response
    msg_bytes = msg.as_bytes()
    def do_sent_append(acct=account, addr=from_addr, data=msg_bytes):
        try:
            bg = _get_bg_imap(acct)
            if not bg:
                # A send whose Sent-append fails at this very first check was
                # previously 100% silent — no exception is raised here, so
                # the bare except-block logging below never ran either. Real
                # symptom: user sent a real email (recipient got it, SMTP
                # succeeded independently in _do_send above) that then never
                # appeared in Sent, with zero trace anywhere — not even
                # backend.log, since this whole function only ever used a
                # bare print(), which a GUI-launched (not terminal-launched)
                # app doesn't route anywhere durable. Log this path too, not
                # just the except branch below.
                _log_sent_append_failure(f'no bg IMAP client for {addr} — send succeeded, Sent-folder append skipped entirely')
                return
            # bg_append_lock(acct) serialises this block against save_draft, which
            # also issues IMAP APPEND commands on the same shared bg connection.
            with bg_append_lock(acct):
                if addr not in _sent_folder_cache:
                    sent_folder = 'Sent'
                    for flags, _, name in bg.list_folders():
                        flags_str = [f.decode() if isinstance(f, bytes) else f for f in flags]
                        if '\\Sent' in flags_str:
                            sent_folder = name
                            break
                    _sent_folder_cache[addr] = sent_folder
                bg.append(_sent_folder_cache[addr], data, flags=['\\Seen'])
                # Bump Sent folder total in memory so sidebar updates immediately
                sent_name = _sent_folder_cache[addr]
                with _unread_cache_lock:
                    if addr in _folder_cache:
                        for entry in _folder_cache[addr]:
                            if entry.get('name') in ('Sent', sent_name):
                                entry['total'] = entry.get('total', 0) + 1
        except Exception as ex:
            _log_sent_append_failure(f'to={addr!r} subject={body.get("subject", "")!r} — {ex}')

    threading.Thread(target=do_sent_append, daemon=True).start()

    # Invalidate Sent folder cache immediately so the next fetch goes to IMAP
    sent_folder_name = _sent_folder_cache.get(from_addr, 'Sent')
    try:
        conn_inv = get_db()
        conn_inv.execute("DELETE FROM message_cache WHERE account=? AND folder=?", (from_addr, sent_folder_name))
        conn_inv.commit()
        conn_inv.close()
    except Exception:
        pass

    return True, '', 0


# ── Shared attachment-preview parsing (messages.py + freecords_admin.py) ──────
# Both blueprints need to turn xlsx/docx bytes into safe, structured JSON for
# AttachmentPreviewModal — messages.py reads the bytes from IMAP,
# freecords_admin.py fetches them from a signed CRM URL. Lives here, not in
# either blueprint, per this project's own rule: no blueprint imports another.

def render_xlsx_table(payload):
    """Parses an .xlsx/.xlsm attachment into plain rows for inline preview.
    Deliberately server-side: the obvious client-side option (the `xlsx`
    npm package) has an open, unpatched prototype-pollution/ReDoS advisory
    with no fix on the npm registry, and this parses sender-controlled
    bytes from an email/CRM attachment — exactly the class of input that
    matters for that CVE. openpyxl has no such history and runs in the
    same trusted backend process that already handles every other
    attachment operation."""
    import io
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(payload), data_only=True, read_only=True)
    sheets = []
    for ws in wb.worksheets[:5]:
        rows = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= 500:
                break
            rows.append(['' if c is None else str(c) for c in row[:50]])
        sheets.append({'name': ws.title, 'rows': rows})
    return {'type': 'sheet', 'sheets': sheets}


def render_docx_table(payload):
    """Parses a .docx attachment into plain paragraphs/tables for inline
    preview — same rationale as render_xlsx_table above (parse
    sender-controlled bytes server-side, not in the browser), but hand-
    rolled with stdlib zipfile/ElementTree instead of python-docx: that
    library hard-depends on lxml, whose compiled extension can't be loaded
    at all inside this app's signed embedded Python (hardened-runtime
    library validation rejects it — a real, pre-existing gap, confirmed
    live, same class of code-signing fragility this project's CLAUDE.md
    already documents for the Swift launcher; see claude.py's
    _read_context_file for the other place this bit). A .docx is just a
    zip with word/document.xml inside; paragraphs/runs/tables are simple
    enough to walk directly.
    """
    import io
    import zipfile
    import xml.etree.ElementTree as ET
    W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'

    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        xml_bytes = z.read('word/document.xml')
    root = ET.fromstring(xml_bytes)
    body = root.find(f'{W}body')

    def para_text(p):
        return ''.join(t.text or '' for t in p.iter(f'{W}t'))

    def para_is_bold(p):
        return any(r.find(f'{W}rPr/{W}b') is not None for r in p.findall(f'{W}r'))

    def para_style(p):
        pPr = p.find(f'{W}pPr')
        if pPr is None:
            return ''
        style = pPr.find(f'{W}pStyle')
        return style.get(f'{W}val', '') if style is not None else ''

    paragraphs, tables = [], []
    if body is not None:
        for el in body:
            if el.tag == f'{W}p' and len(paragraphs) < 1000:
                text = para_text(el)
                if text.strip():
                    paragraphs.append({
                        'text': text,
                        'bold': para_is_bold(el),
                        'heading': para_style(el).lower().startswith('heading'),
                    })
            elif el.tag == f'{W}tbl' and len(tables) < 20:
                rows = []
                for tr in el.findall(f'{W}tr')[:200]:
                    row = [''.join(para_text(p) for p in tc.findall(f'{W}p'))
                           for tc in tr.findall(f'{W}tc')[:50]]
                    rows.append(row)
                tables.append(rows)

    return {'type': 'doc', 'paragraphs': paragraphs, 'tables': tables}


# ── Local ticket-attachment storage ────────────────────────────────────────────
# Real, permanent local copies of CRM ticket attachment files — not just the
# has_attachments boolean in ticket_attachment_cache. Freshdesk's attachment
# URLs are short-lived signed S3 links, and the remote Freecords ticket-import
# schema drops attachment data entirely on import, so until this existed there
# was no copy of any ticket attachment anywhere Overlord controls. Used by both
# main.py's _freshdesk_sync_loop (capture at import time, going forward) and
# freshdesk.py's backfill loop (catch up on tickets imported before this
# existed).

def store_ticket_attachment_files(ticket_number, attachments):
    """
    attachments: list of Freshdesk attachment dicts ({'name', 'attachment_url',
    'content_type', ...} — same shape whether they came from the ticket object
    or a conversation). Downloads each not already stored for this ticket and
    saves it under APP_SUPPORT/ticket_attachments/<ticket_number>/, recording
    metadata in ticket_attachment_files. Best-effort per file: one failure
    (network, oversized, disk) skips just that file, not the whole ticket.
    Returns the count of newly-stored files.
    """
    import requests as _http
    from config import APP_SUPPORT

    if not attachments:
        return 0

    conn = get_db()
    existing = {r['filename'] for r in conn.execute(
        "SELECT filename FROM ticket_attachment_files WHERE ticket_number=?", (ticket_number,)
    ).fetchall()}

    dest_dir = APP_SUPPORT / 'ticket_attachments' / str(ticket_number)
    stored = 0
    for att in attachments:
        name = att.get('name')
        url = att.get('attachment_url')
        if not name or not url or name in existing:
            continue
        try:
            resp = _http.get(url, timeout=20)
            resp.raise_for_status()
        except Exception:
            continue
        if len(resp.content) > 20 * 1024 * 1024:  # skip anything absurd
            continue
        try:
            dest_dir.mkdir(parents=True, exist_ok=True)
            safe_name = _re.sub(r'[/\\:*?"<>|]', '_', name.replace('\r', '').replace('\n', ''))
            dest = dest_dir / safe_name
            dest.write_bytes(resp.content)
        except Exception:
            continue
        conn.execute(
            "INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
            "VALUES (?, ?, ?, ?, ?)",
            (ticket_number, name, att.get('content_type'), len(resp.content), str(dest.relative_to(APP_SUPPORT))),
        )
        conn.commit()
        stored += 1
        existing.add(name)
    conn.close()
    return stored


_INLINE_ATTACHMENT_RE = _re.compile(
    r'<img[^>]+src="(https://eucattachment\.freshdesk\.com/inline/attachment\?[^"]+)"[^>]*data-id="(\d+)"'
)


def extract_inline_attachments(bodies):
    """
    Real, confirmed live gap (2026-09-15, ticket #67206): a customer's
    screenshot was embedded inline via Freshdesk's own
    eucattachment.freshdesk.com/inline/attachment mechanism, with the
    ticket's own `attachments` array empty -- store_ticket_attachment_files
    only ever reads that array, so inline-only content was never captured
    at all, by either the live sync or the backfill loop.

    `bodies`: iterable of raw HTML message bodies (ticket description +
    every conversation body) to scan. Each inline <img> tag's src is itself
    a redirect (302) to the real, time-limited signed attachment URL --
    resolved here with one GET per image (small, infrequent: most tickets
    have zero or one inline image). Returns a list of dicts in the same
    shape store_ticket_attachment_files already expects
    ({'name', 'attachment_url', 'content_type'}), synthesizing a filename
    since inline images carry no filename of their own, only a numeric id.
    """
    import requests as _http

    found = {}
    for body in bodies:
        if not body:
            continue
        for url, data_id in _INLINE_ATTACHMENT_RE.findall(body):
            found[data_id] = url

    results = []
    for data_id, url in found.items():
        try:
            resp = _http.get(url, timeout=20, allow_redirects=True)
            resp.raise_for_status()
        except Exception:
            continue
        if len(resp.content) > 20 * 1024 * 1024:
            continue
        ctype = resp.headers.get('Content-Type', 'application/octet-stream').split(';')[0].strip()
        ext = {'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp'}.get(ctype, 'bin')
        results.append({
            'name': f'inline_{data_id}.{ext}',
            'content_type': ctype,
            '_bytes': resp.content,  # already downloaded -- store_ticket_attachment_files normally does its own GET, this skips a second round-trip
        })
    return results


def store_inline_attachments(ticket_number, inline_attachments):
    """Same storage convention as store_ticket_attachment_files, but for
    extract_inline_attachments' output, which already carries the
    downloaded bytes (no attachment_url to re-fetch)."""
    from config import APP_SUPPORT

    if not inline_attachments:
        return 0

    conn = get_db()
    existing = {r['filename'] for r in conn.execute(
        "SELECT filename FROM ticket_attachment_files WHERE ticket_number=?", (ticket_number,)
    ).fetchall()}

    dest_dir = APP_SUPPORT / 'ticket_attachments' / str(ticket_number)
    stored = 0
    for att in inline_attachments:
        name = att.get('name')
        content = att.get('_bytes')
        if not name or not content or name in existing:
            continue
        try:
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / name
            dest.write_bytes(content)
        except Exception:
            continue
        conn.execute(
            "INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
            "VALUES (?, ?, ?, ?, ?)",
            (ticket_number, name, att.get('content_type'), len(content), str(dest.relative_to(APP_SUPPORT))),
        )
        conn.commit()
        stored += 1
        existing.add(name)
    conn.close()
    return stored


def reindex_ticket_attachments_from_disk():
    """
    Re-creates ticket_attachment_files rows for files that exist under
    APP_SUPPORT/ticket_attachments/<ticket_number>/ but have no row. The app lists
    a ticket's local attachments from that table only, and between the 30 Sep
    09:07 and 09:56 backups it fell from 6,291 rows to 1,494 (the 14 Aug state)
    while the files stayed on disk: 7,094 files in 4,066 tickets were invisible
    (user, 3 Nov: tickets "missing attachments despite all the fixes", e.g. #70310's
    older siblings). Idempotent; a file that already has a row, by stored name or by
    the name in its file_path, is left alone. Returns the number of rows added.
    """
    import mimetypes
    import time as _time

    root = APP_SUPPORT / 'ticket_attachments'
    if not root.is_dir():
        return 0
    conn = get_db()
    # Names are compared case-insensitively: Windows and macOS file systems are, and a row saying
    # "Screenshot_1.png" for a file listed as "screenshot_1.png" is the same file.
    have = set()
    for r in conn.execute("SELECT ticket_number, filename, file_path FROM ticket_attachment_files").fetchall():
        have.add((r['ticket_number'], r['filename'].lower()))
        have.add((r['ticket_number'], (r['file_path'] or '').replace('\\', '/').rsplit('/', 1)[-1].lower()))

    def _commit():
        for attempt in range(5):
            try:
                conn.commit()
                return
            except Exception:
                if attempt == 4:
                    raise
                _time.sleep(0.3 * (attempt + 1))

    added = 0
    for tdir in root.iterdir():
        if not (tdir.is_dir() and tdir.name.isdigit()):
            continue
        number = int(tdir.name)
        for f in tdir.iterdir():
            if not f.is_file() or f.name.startswith('.') or f.name.lower() in ('desktop.ini', 'thumbs.db'):
                continue
            if (number, f.name.lower()) in have:
                continue
            conn.execute(
                "INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
                "VALUES (?, ?, ?, ?, ?)",
                (number, f.name, mimetypes.guess_type(f.name)[0] or 'application/octet-stream',
                 f.stat().st_size, str(f.relative_to(APP_SUPPORT))),
            )
            have.add((number, f.name.lower()))
            added += 1
            if added % 500 == 0:
                _commit()
    _commit()
    conn.close()
    return added


# ── Tickets "awaiting reply" — the single blue-dot signal ────────────────────
# See db.py's ticket_awaiting_reply table for the full rationale. Two tiny
# helpers so both call sites (main.py's direct-IMAP path, freecords_admin.py's
# reply endpoint) share one implementation instead of duplicating the SQL.

def mark_ticket_awaiting_reply(ticket_number):
    if not ticket_number:
        return
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO ticket_awaiting_reply (ticket_number, marked_at) VALUES (?, datetime('now'))",
        (ticket_number,),
    )
    conn.commit()
    conn.close()


def clear_ticket_awaiting_reply(ticket_number):
    if not ticket_number:
        return
    conn = get_db()
    conn.execute("DELETE FROM ticket_awaiting_reply WHERE ticket_number=?", (ticket_number,))
    conn.commit()
    conn.close()
