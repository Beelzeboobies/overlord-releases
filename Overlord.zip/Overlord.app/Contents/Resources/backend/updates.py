import os
import sys
import datetime
import tempfile
import subprocess
import threading
from pathlib import Path

from flask import Blueprint, request, jsonify

from config import APP_SUPPORT

bp = Blueprint('updates', __name__)

# install_update() used to fire-and-forget: it returned {ok: True} the
# instant the background thread *started*, before the download even began,
# and any failure only went to a bare logging.error() call with no attached
# handler — invisible. That's why "Update now" could get stuck on
# "Installing…" forever with no error and no way to tell what happened.
# This dict + /api/update-status let the frontend poll real progress.
# downloaded/total (bytes) added so the frontend can show a real progress
# bar instead of a static "Downloading…" label with no indication of size
# or how much longer it'll take — user asked for this directly.
_update_status = {'state': 'idle', 'error': None, 'downloaded': 0, 'total': 0}  # idle|downloading|installing|cancelled|error
_UPDATE_LOG = APP_SUPPORT / 'logs' / 'backend.log'

# Cooperative cancellation: checked once per downloaded chunk in
# _download_with_progress. Only effective during the download phase —
# once do_install_mac/do_install_windows moves on to installing (renaming
# the live app / handing off to the Restart Manager helper), that's
# already committing to disk and isn't safely reversible, so cancel is
# deliberately not offered once the button reads "Installing…".
_update_cancel_event = threading.Event()


class _UpdateCancelled(Exception):
    pass


def _download_with_progress(url, dest_path, chunk_size=256 * 1024):
    """Stream a download to dest_path, updating _update_status['downloaded']/
    ['total'] as it goes and raising _UpdateCancelled if
    _update_cancel_event gets set mid-download. Replaces the old
    urllib.request.urlretrieve(...) call, which downloaded silently in one
    blocking hop with no progress callback and no way to interrupt it."""
    import urllib.request
    req = urllib.request.Request(url, headers={'User-Agent': 'Overlord'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        total = int(resp.headers.get('Content-Length') or 0)
        _update_status['total'] = total
        _update_status['downloaded'] = 0
        downloaded = 0
        with open(dest_path, 'wb') as f:
            while True:
                if _update_cancel_event.is_set():
                    raise _UpdateCancelled()
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                _update_status['downloaded'] = downloaded
    return downloaded

def _log_update(msg):
    line = f'[{datetime.datetime.utcnow().isoformat()}Z] [update] {msg}'
    try:
        with open(_UPDATE_LOG, 'a') as f:
            f.write(line + '\n')
    except Exception:
        pass


def _read_local_version():
    """Read version from a VERSION file next to the app bundle or repo root.

    Same class of bug `check_update()` already works around for the remote
    version.json (see the big comment there): VERSION was a single file
    shared between the Mac and Windows checkouts of this repo. Since
    there's no git sync between the two machines, whichever platform's
    session committed it last silently overwrote the other platform's own
    version — confirmed live: a Windows session bumped VERSION to '2.3',
    then a later Mac commit (release.sh writing its own '2.31') overwrote
    it on pull, and the *next* Windows rebuild from that checkout would
    have silently embedded Mac's version number into a Windows build.
    Split into VERSION_WINDOWS / VERSION_MAC, same split as
    windows_version/mac_version in version.json, each written only by
    that platform's own build script (windows/build_windows.py,
    release.sh). Falls back to the old shared VERSION for any
    already-built app that predates this split — same reasoning as
    check_update()'s fallback to version.json's old `version` field.
    """
    filename = 'VERSION_WINDOWS' if sys.platform == 'win32' else 'VERSION_MAC'
    candidates = []
    # PyInstaller-frozen Windows build — sys._MEIPASS is PyInstaller's own
    # pointer to wherever --add-data assets actually land (see
    # windows/build_windows.py). Must be checked first and separately from
    # the Mac candidates below: __file__.parent.parent doesn't resolve to a
    # real on-disk path for a bundled module the same way it does in dev
    # mode, and the four-parent .app-bundle candidate is Mac-specific
    # nesting that doesn't exist in a Windows onedir build at all. Without
    # this, every candidate below misses and this silently falls through to
    # '0.0.0' — confirmed live: check-update reported current="0.0.0" on a
    # real Windows install that demonstrably had VERSION="1.2.11" on disk.
    if getattr(sys, 'frozen', False) and getattr(sys, '_MEIPASS', None):
        candidates.append(Path(sys._MEIPASS) / filename)
        candidates.append(Path(sys._MEIPASS) / 'VERSION')
    candidates += [
        Path(__file__).parent.parent / filename,            # repo / bundle layout
        Path(__file__).parent.parent / 'VERSION',
        Path(sys.executable).parent.parent.parent.parent / filename,  # inside .app
        Path(sys.executable).parent.parent.parent.parent / 'VERSION',
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate.read_text().strip()
    return '0.0.0'

@bp.route('/api/version', methods=['GET', 'OPTIONS'])
def get_version():
    if request.method == 'OPTIONS': return '', 204
    return jsonify(version=_read_local_version())

@bp.route('/api/check-update', methods=['GET', 'OPTIONS'])
def check_update():
    """Check GitHub releases for a newer version. Returns {update_available, latest, current, download_url}."""
    if request.method == 'OPTIONS': return '', 204
    import urllib.request, json as _json
    current = _read_local_version()
    try:
        # version.json hosted on GitHub Pages or as a release asset
        update_url = 'https://raw.githubusercontent.com/Beelzeboobies/overlord-releases/main/version.json'
        req = urllib.request.Request(update_url, headers={'Cache-Control': 'no-cache', 'User-Agent': 'Overlord'})
        with urllib.request.urlopen(req, timeout=8) as r:
            meta = _json.loads(r.read())
        # Mac and Windows are built and published on genuinely independent
        # schedules (confirmed live, repeatedly — Mac at 2.31 while Windows
        # was still on 1.0.2) — a single shared `version` field meant
        # publishing *either* platform's release told *both* platforms'
        # installs "there's an update," even when only one side had
        # actually shipped anything new. Concretely dangerous, not just
        # untidy: it could point a newer Windows install at an older
        # `windows_installer_url` and call that an "update" — a real
        # downgrade. `mac_version`/`windows_version` are separate fields
        # now; `version` is read as a fallback only for a stale
        # version.json that predates this split, so old cached copies (or
        # a fetch that races a mid-publish edit) don't just silently break.
        # `notes` had the exact same shared-field bug `mac_version`/
        # `windows_version` were split apart for — release.sh clobbers the
        # single shared `notes` field on every Mac release with no
        # Windows equivalent existing at all, so whichever platform
        # published most recently had its release text shown to BOTH
        # platforms' update banners. windows_notes/mac_notes now mirror
        # the version split exactly, falling back to legacy `notes` (kept
        # in sync with mac_notes, same as `version` mirrors `mac_version`)
        # for old version.json snapshots that predate this.
        if sys.platform == 'win32':
            latest = meta.get('windows_version') or meta.get('version', '0.0.0')
            download_url = meta.get('windows_installer_url', '')
            release_notes = meta.get('windows_notes') or meta.get('notes', '')
        else:
            latest = meta.get('mac_version') or meta.get('version', '0.0.0')
            download_url = meta.get('download_url', '')
            release_notes = meta.get('mac_notes') or meta.get('notes', '')

        def ver_tuple(v):
            try: return tuple(int(x) for x in v.split('.'))
            except: return (0,)

        update_available = ver_tuple(latest) > ver_tuple(current)
        return jsonify(update_available=update_available, latest=latest,
                       current=current, download_url=download_url, notes=release_notes)
    except Exception as exc:
        return jsonify(update_available=False, current=current, error=str(exc))

@bp.route('/api/update-status', methods=['GET', 'OPTIONS'])
def update_status():
    if request.method == 'OPTIONS': return '', 204
    return jsonify(_update_status)

@bp.route('/api/install-update', methods=['POST', 'OPTIONS'])
def install_update():
    """Download the platform-appropriate update artifact and install it.
    Mac: zip -> extract .app -> replace /Applications/Overlord.app -> relaunch.
    Windows: Inno Setup installer -> detached helper -> Restart Manager closes
    this process -> helper asks to restart (see do_install_windows())."""
    if request.method == 'OPTIONS': return '', 204
    import urllib.request, shutil, time

    data = request.get_json(force=True) or {}
    download_url = data.get('download_url', '')
    if not download_url.startswith('https://'):
        return jsonify(ok=False, error='Invalid download URL'), 400

    if _update_status['state'] in ('downloading', 'installing'):
        return jsonify(ok=False, error='An update is already in progress'), 409

    def do_install_mac():
        """
        Both extraction and the final copy use `ditto`, not Python's zipfile/
        shutil — confirmed live (2026-08-16) that this was the actual cause of
        a real "Overlord cannot Open" bricked install after a colleague
        updated: zipfile.ZipFile.extractall() does not restore Unix
        permission bits from the zip (a known, long-standing stdlib
        limitation), so the extracted Overlord binary came out `-rw-r--r--`
        instead of the original `-rwxr-xr-x` — no longer executable. `spctl`
        still reports the result as "accepted" (the code *signature* itself
        is untouched, this is a plain POSIX permissions issue, not a
        Gatekeeper/signing one), so nothing here even hints at a signing
        problem — LaunchServices just silently can't exec the binary and
        macOS reports the generic "Overlord cannot Open." Since the process
        never starts, TCC never gets a chance to re-prompt for Accessibility/
        Automation either, which is exactly what was reported.
        `ditto -xk` (extraction) and `ditto` (bundle copy) are Apple's own
        tools for exactly this job — they preserve permissions, resource
        forks, extended attributes, and (irrelevant here, but also correct)
        symlinks. Verified live: comparing zipfile.extractall() vs ditto
        against the real 2.37 Overlord.zip, ditto reproduces the original
        `-rwxr-xr-x` bit-for-bit; zipfile does not.
        """
        tmp_dir = Path(tempfile.mkdtemp(prefix='overlord_update_'))
        zip_path = tmp_dir / 'Overlord.zip'

        try:
            _download_with_progress(download_url, zip_path)
        except _UpdateCancelled:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise
        _log_update(f'download complete, {zip_path.stat().st_size} bytes')

        _update_status['state'] = 'installing'
        extracted_dir = tmp_dir / 'extracted'
        extracted_dir.mkdir()
        result = subprocess.run(['ditto', '-xk', str(zip_path), str(extracted_dir)],
                                capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f'ditto extraction failed: {result.stderr.strip()}')

        candidates = list(extracted_dir.rglob('Overlord.app'))
        if not candidates:
            raise RuntimeError('Downloaded zip had no Overlord.app inside it')
        src_app = candidates[0]

        dest_app = Path('/Applications/Overlord.app')
        backup = Path('/Applications/Overlord.app.bak')

        if dest_app.exists():
            if backup.exists(): shutil.rmtree(backup)
            shutil.move(str(dest_app), str(backup))
        result = subprocess.run(['ditto', str(src_app), str(dest_app)],
                                capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f'ditto copy to /Applications failed: {result.stderr.strip()}')
        shutil.rmtree(tmp_dir, ignore_errors=True)

        subprocess.run(['xattr', '-rd', 'com.apple.quarantine', str(dest_app)],
                       capture_output=True)

        _log_update('install complete, relaunching')
        time.sleep(1)
        subprocess.Popen(['open', '-a', 'Overlord'])
        time.sleep(2)
        os.kill(os.getpid(), 9)

    def do_install_windows():
        """Download the Inno Setup installer and hand it off to a detached
        helper process (windows/update_helper.py, built as its own
        UpdateHelper.exe — see windows/build_windows.py) rather than
        launching it directly.

        Why not launch it directly: windows/installer.iss's
        CloseApplications=yes (Restart Manager integration) forcibly closes
        THIS very process partway through the install, to release the lock
        on Overlord.exe/its DLLs before they get overwritten. That means
        whichever process kicked off the install is dead before it
        finishes — it can't be the one to show a "restart now?" prompt
        afterward, unlike Mac's self-kill-then-reopen above where the
        relaunch command runs *before* this process dies. The helper is
        spawned detached specifically so its lifetime isn't tied to this
        process's; it survives to run the installer, wait for it, and ask.

        This flow went through two real bugs before working: UpdateHelper.exe
        killing its own process tree via a self-referential `taskkill /T`,
        then a PowerShell `$pid` variable collision, then a --windowed
        build having no stdin/stdout/stderr for the console subprocesses it
        spawns (both the kill step and the installer launch needed
        `stdin=subprocess.DEVNULL`, see windows/update_helper.py). Verified
        in an isolated harness against a real Overlord.exe: the kill step
        completes and takes down every WebView2 child, and the helper
        reaches and displays the native restart prompt. Not yet verified
        with the real Inno Setup installer or a real download — that needs
        a full end-to-end run through the actual update flow.
        """
        tmp_dir = Path(tempfile.mkdtemp(prefix='overlord_update_'))
        installer_path = tmp_dir / 'Overlord-Setup.exe'

        try:
            _download_with_progress(download_url, installer_path)
        except _UpdateCancelled:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise
        _log_update(f'download complete, {installer_path.stat().st_size} bytes')

        _update_status['state'] = 'installing'

        if not getattr(sys, 'frozen', False):
            # Dev mode — no packaged Overlord.exe/UpdateHelper.exe to hand
            # off to, and nothing sensible to relaunch. Just run the
            # installer directly so the flow is still testable, minus the
            # restart prompt.
            subprocess.Popen([str(installer_path), '/SILENT', '/NORESTART', '/CLOSEAPPLICATIONS'])
            _log_update('dev mode: ran installer directly, no restart helper')
            return

        exe_path = Path(sys.executable)
        # Copy the helper out of {app} before running it, rather than
        # launching it in place. installer.iss's `Source: "{#SourceDir}\*"`
        # wildcard covers every file in the install directory, UpdateHelper.exe
        # included — so the copy living inside {app} is one of the files
        # Setup needs to overwrite. Launching that copy directly meant the
        # very process driving the update held a file lock Setup could never
        # clear, no matter how thoroughly Overlord.exe itself was killed
        # first. **Confirmed live**: Overlord.exe and all its WebView2
        # children were verified dead, yet Setup still stalled on "Closing
        # applications..." with a Restart Manager retry dialog behind it —
        # traced to this exact self-lock via a live window-tree dump, not
        # guessed. Running a copy from the installer's own tmp_dir sidesteps
        # it entirely: that copy isn't a file Setup ever touches.
        helper_src = exe_path.parent / 'UpdateHelper.exe'
        helper_path = tmp_dir / 'UpdateHelper.exe'
        shutil.copy2(helper_src, helper_path)
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        subprocess.Popen(
            [str(helper_path), str(installer_path), str(exe_path)],
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            close_fds=True,
        )
        _log_update('handed off to UpdateHelper.exe, this process will be closed by Restart Manager shortly')

    def do_install():
        try:
            _update_cancel_event.clear()
            _update_status['state'] = 'downloading'
            _update_status['error'] = None
            _update_status['downloaded'] = 0
            _update_status['total'] = 0
            _log_update(f'starting download from {download_url}')

            if sys.platform == 'win32':
                do_install_windows()
            else:
                do_install_mac()
        except _UpdateCancelled:
            _update_status['state'] = 'cancelled'
            _log_update('download cancelled by user')
        except Exception as e:
            _update_status['state'] = 'error'
            _update_status['error'] = str(e)
            _log_update(f'FAILED: {e}')

    threading.Thread(target=do_install, daemon=True).start()
    return jsonify(ok=True, message='Downloading update…')


@bp.route('/api/cancel-update', methods=['POST', 'OPTIONS'])
def cancel_update():
    """Cancel an in-progress update download. Only effective while
    _update_status['state'] == 'downloading' — once installation has
    actually started (file replacement on Mac, handed off to the Restart
    Manager helper on Windows), that's no longer safely reversible, so the
    frontend only shows the Cancel button during the download phase."""
    if request.method == 'OPTIONS': return '', 204
    if _update_status['state'] != 'downloading':
        return jsonify(ok=False, error='No download in progress to cancel'), 409
    _update_cancel_event.set()
    return jsonify(ok=True)
