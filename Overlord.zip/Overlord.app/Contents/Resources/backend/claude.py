import json
from pathlib import Path

from flask import Blueprint, request, jsonify

from db import get_db
from imap import get_all_accounts, imap_connect, resolve_folder, fetch_and_cache

bp = Blueprint('claude', __name__)


# ── Claude context builder ────────────────────────────────────────────────────

# ── Context folder: browse + read ─────────────────────────────────────────────

# Only these extensions are read for context — no executables, no binaries
CONTEXT_ALLOWED_EXTS = {'.txt', '.md', '.csv', '.rtf', '.pdf', '.docx', '.doc'}
CONTEXT_MAX_FILE_BYTES = 200 * 1024   # 200 KB per file
CONTEXT_MAX_TOTAL_CHARS = 40_000      # total chars sent to Claude

_url_cache: dict = {}   # url → {'text': str, 'ts': float}
_URL_CACHE_TTL = 3600   # re-fetch after 1 hour

# Apple Music Style Guide crawler — cached separately with a longer TTL
_apple_guide_cache: dict = {'text': None, 'ts': 0.0}
_APPLE_GUIDE_TTL = 86400  # re-crawl once per day


def fetch_apple_music_style_guide() -> str:
    """
    Crawl the Apple Music Style Guide by fetching the navigation JSON,
    then fetching each topic's HTML page. Cached for 24 hours.
    """
    import time as _time, urllib.request as _req, json as _json
    from html.parser import HTMLParser as _HP

    now = _time.time()
    if _apple_guide_cache['text'] and now - _apple_guide_cache['ts'] < _APPLE_GUIDE_TTL:
        return _apple_guide_cache['text']

    HEADERS = {
        'User-Agent': (
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
            'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        )
    }
    BASE = 'https://help.apple.com/itc/musicstyleguide/en.lproj/'

    class _TextExtractor(_HP):
        def __init__(self):
            super().__init__()
            self._parts = []
            self._skip  = False
        def handle_starttag(self, tag, attrs):
            if tag in ('script', 'style', 'nav', 'header', 'footer'):
                self._skip = True
        def handle_endtag(self, tag):
            if tag in ('script', 'style', 'nav', 'header', 'footer'):
                self._skip = False
            if tag in ('p', 'h1', 'h2', 'h3', 'h4', 'li', 'td', 'th', 'tr'):
                self._parts.append('\n')
        def handle_data(self, data):
            if not self._skip:
                self._parts.append(data)
        def get_text(self):
            return ''.join(self._parts).strip()

    try:
        nav_req  = _req.Request(BASE + 'navigation.json', headers=HEADERS)
        nav      = _json.loads(_req.urlopen(nav_req, timeout=15).read())
        topics   = nav.get('topics', {})

        # Build ordered list following the TOC structure
        def _flatten(node_id, sections, topics, seen):
            if node_id in seen:
                return []
            seen.add(node_id)
            if node_id in sections:
                result = []
                for child in sections[node_id].get('children', []):
                    result.extend(_flatten(child, sections, topics, seen))
                return result
            if node_id in topics:
                return [node_id]
            return []

        sections = nav.get('sections', {})
        seen     = set()
        ordered  = []
        for toc_id in nav.get('toc', []):
            ordered.extend(_flatten(toc_id, sections, topics, seen))
        # Any topics not reached via TOC
        for tid in topics:
            if tid not in seen:
                ordered.append(tid)

        parts = ['# Apple Music Style Guide 2.4\n']
        for tid in ordered:
            t    = topics[tid]
            href = t.get('href', '')
            name = t.get('name', tid)
            if not href:
                continue
            try:
                page_req = _req.Request(BASE + href, headers=HEADERS)
                html     = _req.urlopen(page_req, timeout=10).read().decode('utf-8')
                parser   = _TextExtractor()
                parser.feed(html)
                text = parser.get_text()
                if text:
                    parts.append(f'## {name}\n{text}')
            except Exception:
                pass  # skip pages that fail; don't abort the whole crawl

        result = '\n\n'.join(parts)
        # The real guide runs ~107k chars once the nav-URL bug above (fixed
        # 2026-08-26 — a literal '../en.lproj/' in the request URL was
        # getting a 403, so this silently returned '' on every single call
        # before now) stopped masking it. Uncapped, that would dwarf every
        # other piece of context (folders/files are already budgeted to
        # CONTEXT_MAX_TOTAL_CHARS) on every single reply draft. Same cap,
        # for the same reason — a style reference doesn't need to be
        # complete to be useful, just not empty.
        if len(result) > CONTEXT_MAX_TOTAL_CHARS:
            result = result[:CONTEXT_MAX_TOTAL_CHARS] + '\n\n[Style guide truncated]'
        _apple_guide_cache['text'] = result
        _apple_guide_cache['ts']   = now
        return result

    except Exception:
        return _apple_guide_cache.get('text') or ''

# Freecords policy & help pages — always included in every Claude context
FREECORDS_POLICY_URLS = [
    'https://www.freecords.com/terms-of-use',
    'https://www.freecords.com/privacy-policy',
    'https://www.freecords.com/terms-of-use-distribution',
    'https://www.freecords.com/artist-privacy-policy',
    'https://www.freecords.com/anti-fraud-policy',
    'https://www.freecords.com/faqs',
    'https://www.freecords.com/distribution-faqs',
]


def fetch_context_url(url: str) -> str:
    """Fetch a URL and return its text content, with a 1-hour in-memory cache."""
    import time as _time, urllib.request as _req, html.parser as _hp
    now = _time.time()
    cached = _url_cache.get(url)
    if cached and now - cached['ts'] < _URL_CACHE_TTL:
        return cached['text']
    try:
        req = _req.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Overlord context fetcher)'})
        with _req.urlopen(req, timeout=10) as resp:
            raw = resp.read(512_000).decode('utf-8', errors='replace')
    except Exception as e:
        return f'[Could not fetch {url}: {e}]'

    # Strip HTML tags to plain text
    class _Stripper(_hp.HTMLParser):
        def __init__(self):
            super().__init__()
            self.parts = []
            self._skip = False
        def handle_starttag(self, tag, attrs):
            if tag in ('script', 'style', 'head', 'noscript'):
                self._skip = True
        def handle_endtag(self, tag):
            if tag in ('script', 'style', 'head', 'noscript'):
                self._skip = False
            if tag in ('p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'tr'):
                self.parts.append('\n')
        def handle_data(self, data):
            if not self._skip:
                self.parts.append(data)

    stripper = _Stripper()
    stripper.feed(raw)
    text = ' '.join(''.join(stripper.parts).split())[:CONTEXT_MAX_FILE_BYTES]
    _url_cache[url] = {'text': text, 'ts': now}
    return text


def _read_context_file(path: Path) -> str:
    """Extract plain text from a file. Supports txt/md/csv/pdf/docx."""
    ext = path.suffix.lower()
    try:
        if ext in ('.txt', '.md', '.csv', '.rtf'):
            return path.read_text(encoding='utf-8', errors='replace')[:CONTEXT_MAX_FILE_BYTES]
        elif ext == '.pdf':
            import PyPDF2
            text_parts = []
            with open(path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages[:20]:   # first 20 pages max
                    text_parts.append(page.extract_text() or '')
            return '\n'.join(text_parts)[:CONTEXT_MAX_FILE_BYTES]
        elif ext == '.docx':
            # python-docx hard-depends on lxml, whose compiled extension
            # can't load at all inside this app's signed embedded Python
            # (hardened-runtime library validation rejects it — confirmed
            # live; see messages.py's _render_docx_table for the same fix).
            # This silently returned '' for every .docx file before —
            # wrapped in the bare except below, so it never crashed, it
            # just meant Claude got nothing from any attached Word doc.
            import zipfile
            import xml.etree.ElementTree as ET
            W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
            with zipfile.ZipFile(str(path)) as z:
                xml_bytes = z.read('word/document.xml')
            root = ET.fromstring(xml_bytes)
            paragraphs = [
                ''.join(t.text or '' for t in p.iter(f'{W}t'))
                for p in root.iter(f'{W}p')
            ]
            return '\n'.join(paragraphs)[:CONTEXT_MAX_FILE_BYTES]
    except Exception:
        return ''
    return ''


def read_context_folder(folder: str, is_excluded=None) -> dict:
    """
    Read all allowed files in the context folder.
    Returns {'files': [{'name':..., 'ext':..., 'snippet':...}], 'full_text': str}
    is_excluded: optional callable(Path) -> bool to skip files/sub-folders
    """
    base = Path(folder).resolve()
    if not base.is_dir():
        return {'files': [], 'full_text': ''}

    result_files = []
    total_text = []
    total_chars = 0

    # Walk entire directory tree, skip hidden dirs (e.g. .git)
    all_files = sorted(
        e for e in base.rglob('*')
        if e.is_file()
        and e.suffix.lower() in CONTEXT_ALLOWED_EXTS
        and not any(part.startswith('.') for part in e.parts)
    )

    for entry in all_files:
        if is_excluded and is_excluded(entry):
            continue
        # Validate no symlink escape
        try:
            entry.resolve().relative_to(base)
        except ValueError:
            continue

        rel = entry.relative_to(base)
        content = _read_context_file(entry)
        snippet = content[:300].replace('\n', ' ').strip()
        result_files.append({'name': str(rel), 'ext': entry.suffix.lower(), 'snippet': snippet})

        remaining = CONTEXT_MAX_TOTAL_CHARS - total_chars
        if remaining <= 0:
            result_files[-1]['truncated'] = True
            break
        if len(content) > remaining:
            chunk = content[:remaining]
            total_text.append(f'=== {rel} ===\n{chunk}')
            total_chars += len(chunk)
            result_files[-1]['truncated'] = True
        else:
            total_text.append(f'=== {rel} ===\n{content}')
            total_chars += len(content)

    truncated = any(f.get('truncated') for f in result_files)
    return {
        'files': result_files,
        'full_text': '\n\n'.join(total_text),
        'truncated': truncated,
        'total_chars': total_chars,
        'limit_chars': CONTEXT_MAX_TOTAL_CHARS,
    }


def _build_context_text(account=None, scope='email'):
    """Return a formatted context string (bio + docs + URLs) suitable for prepending to any prompt.

    `scope` selects which tab's own Context Files to read — 'email' or
    'support' (Support and Tickets share the 'support' scope; both are
    Freshdesk/native-CRM ticket replies, never the Email tab). **Real,
    user-reported gap, not a style preference**: Context Files only ever
    applied to Email — Support/Tickets' own Claude drafts
    (SupportCompose.jsx) never fetched this at all, so a user's configured
    company docs/policies never reached a single ticket reply. Each scope
    is stored under its own suffixed keys (context_folders_email vs
    context_folders_support, etc.) — see db.py's _migrate_schema() for the
    one-time seed from the old shared keys. Falls back to the legacy
    unscoped keys only if a scoped row genuinely doesn't exist yet (should
    only matter transiently, right after this shipped, before the
    migration runs on next app start).
    """
    parts = []

    # Bio
    ctx_path = Path(__file__).parent.parent / 'context.md'
    try:
        bio = ctx_path.read_text(encoding='utf-8').strip()
        if bio:
            parts.append(f'## About Me\n{bio}')
    except Exception:
        pass

    def _scoped(conn, base_key):
        row = conn.execute("SELECT value FROM settings WHERE key=?", (f'{base_key}_{scope}',)).fetchone()
        if row is None:
            row = conn.execute("SELECT value FROM settings WHERE key=?", (base_key,)).fetchone()
        return row

    # Folders, extra files, and URLs — reuse the same DB reads as claude_context()
    conn = get_db()
    row_multi  = _scoped(conn, 'context_folders')
    row_single = conn.execute("SELECT value FROM settings WHERE key='context_folder'").fetchone()
    row_extra  = _scoped(conn, 'context_files_extra')
    row_excl   = _scoped(conn, 'context_excludes')
    row_urls   = _scoped(conn, 'context_urls')
    conn.close()

    excludes = set()
    if row_excl and row_excl['value']:
        try:
            for ep in json.loads(row_excl['value']):
                if ep:
                    excludes.add(str(Path(ep).resolve()))
        except Exception:
            pass

    def _excl(p: Path):
        rp = str(p.resolve())
        return any(rp == ex or rp.startswith(ex + '/') for ex in excludes)

    folders_to_read = []
    if row_multi and row_multi['value']:
        try:
            folders_to_read = [f for f in json.loads(row_multi['value']) if f and Path(f).is_dir()]
        except Exception:
            pass
    if not folders_to_read and row_single and row_single['value']:
        if Path(row_single['value']).is_dir():
            folders_to_read = [row_single['value']]

    doc_parts = []
    for folder_path in folders_to_read:
        if _excl(Path(folder_path)):
            continue
        fc = read_context_folder(folder_path, _excl)
        if fc['full_text']:
            doc_parts.append(f'--- Folder: {Path(folder_path).name} ---\n{fc["full_text"]}')

    extra_file_paths = []
    if row_extra and row_extra['value']:
        try:
            extra_file_paths = [f for f in json.loads(row_extra['value']) if f and Path(f).is_file()]
        except Exception:
            pass
    for fpath in extra_file_paths:
        p = Path(fpath)
        if _excl(p) or p.suffix.lower() not in CONTEXT_ALLOWED_EXTS:
            continue
        text = _read_context_file(p)
        if text:
            doc_parts.append(f'--- File: {p.name} ---\n{text}')

    # Web URLs (user-configured) — skips the Apple Music Style Guide's own
    # URL if present: that one's handled by the specialized crawler below
    # (multi-page, following the guide's real nav structure), not this
    # generic single-page fetch. It's still seeded as a visible entry in
    # context_urls (see db.py) so it shows up in Settings; fetching it
    # again here would just be redundant, lower-quality duplicate work.
    if row_urls and row_urls['value']:
        try:
            for url in json.loads(row_urls['value']):
                if url and url.startswith('http') and 'help.apple.com/itc/musicstyleguide' not in url:
                    text = fetch_context_url(url)
                    if text:
                        doc_parts.append(f'--- URL: {url} ---\n{text}')
        except Exception:
            pass

    # Freecords policy & help pages — always included
    policy_parts = []
    for url in FREECORDS_POLICY_URLS:
        try:
            text = fetch_context_url(url)
            if text:
                policy_parts.append(f'--- {url} ---\n{text}')
        except Exception:
            pass
    if policy_parts:
        doc_parts.append('## Freecords Policies & Help\n' + '\n\n'.join(policy_parts))

    # Apple Music Style Guide — crawled fresh once per day
    try:
        apple_guide = fetch_apple_music_style_guide()
        if apple_guide:
            doc_parts.append(apple_guide)
    except Exception:
        pass

    if doc_parts:
        parts.append('## Company & Context Documents\n' + '\n\n'.join(doc_parts))

    return '\n\n'.join(parts)


@bp.route('/api/claude/freecords-policies', methods=['GET', 'OPTIONS'])
def freecords_policies():
    """Return cached Freecords policy & FAQ content + Apple Music Style Guide for any Claude system prompt."""
    if request.method == 'OPTIONS':
        return '', 204
    parts = []
    for url in FREECORDS_POLICY_URLS:
        try:
            text = fetch_context_url(url)
            if text:
                parts.append(f'--- {url} ---\n{text}')
        except Exception:
            pass
    try:
        apple_guide = fetch_apple_music_style_guide()
        if apple_guide:
            parts.append(apple_guide)
    except Exception:
        pass
    return jsonify({'content': '\n\n'.join(parts)})


@bp.route('/api/claude/context-text', methods=['GET', 'OPTIONS'])
def claude_context_text():
    """
    Plain-text version of _build_context_text() (bio + configured context
    folders/files/URLs + Freecords policies) for callers that build their own
    system prompt directly.

    `scope` ('email' default, or 'support') picks which tab's own Context
    Files to read — see _build_context_text's docstring. Support/Tickets'
    own Claude drafts (SupportCompose.jsx) now call this with scope=support
    where they never called it at all before.
    """
    if request.method == 'OPTIONS':
        return '', 204
    account = request.args.get('account') or None
    scope = request.args.get('scope') or 'email'
    return jsonify({'content': _build_context_text(account, scope)})

