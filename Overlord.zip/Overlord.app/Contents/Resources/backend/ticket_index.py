"""
ticket_index.py — startup backfill of native_ticket_index (ticket_number -> native id
etc.), pulled out of main.py so it can be tested and so it stops re-walking the whole
catalogue on every start.

Why this exists (2026-10-19, Freecords database incident; **Nik**: these APIs are
"not designed for bulk search or anything" — "one at a time"): the old backfill, on
EVERY app start of EVERY install, re-read the ticket list from page 1 to the last page
(~660 requests for ~66,000 tickets) whenever the local index was even one ticket behind
the total — i.e. after any day of new tickets.

Now: probe page 1. If Freecords returns tickets newest-first (verified from the data
itself, not assumed), only walk until two consecutive pages contain nothing new (or the
index has caught up to the total) — usually 1-3 pages. If the order is not verifiably
newest-first, or rows are missing newly-added columns, fall back to the full walk, same
as before but slower. Requests are strictly sequential with a pause.

9 Nov 2026: the old "is the index up to date?" test compared ROW COUNTS (index rows >= Freecords' total). The index
never forgets a ticket that was later deleted or merged away, so after the duplicate cleanups its count passed the
total and every launch said "already up to date" while the newest ~255 tickets (#72157-#72411, 4-9 Nov) were never
added: customers' newest tickets were missing from the sidebar's Open cases, from lookup by number, and from search.
Now the only question asked is "is the newest page of tickets already in the index?" (still a single request).
"""
import time as _time
import sqlite3 as _sqlite3

PACE_SECONDS = 1.5            # pause between pages
MAX_INCREMENTAL_PAGES = 40    # safety stop for incremental mode (4,000 newest tickets)
KNOWN_PAGES_TO_STOP = 2       # consecutive pages with nothing new => caught up


def _newest_first(rows):
    """True only if created_at strictly never increases down the page (>= 2 rows)."""
    ts = [r.get('created_at') for r in rows if r.get('created_at')]
    return len(ts) >= 2 and all(ts[i] >= ts[i + 1] for i in range(len(ts) - 1))


def run(api_get, get_db, sleep=_time.sleep, log=lambda m: None, pace=PACE_SECONDS):
    """api_get(params) -> (data, err) for GET /api/admin/tickets. Returns a short status string."""

    def commit_with_retry(conn, tries=5):
        for attempt in range(tries):
            try:
                conn.commit()
                return
            except _sqlite3.OperationalError:
                if attempt == tries - 1:
                    raise
                sleep(0.3 * (attempt + 1))

    conn = get_db()
    # requester_email/subject/etc. were added after ticket_number/native_id existed; rows
    # missing them force one full rescan (NULL = "predates the column, never checked").
    needs_full = conn.execute(
        "SELECT COUNT(*) AS n FROM native_ticket_index WHERE requester_email IS NULL OR thread_ref IS NULL"
    ).fetchone()['n'] > 0
    conn.close()

    page = 1
    total = 0
    new_total = 0
    known_pages = 0
    consecutive_failures = 0
    incremental = not needs_full      # decided for real once page 1's order has been checked
    status = 'full scan' if needs_full else 'incremental'
    while True:
        data, err = None, None
        for attempt in range(3):
            data, err = api_get({'page': page, 'limit': 100})
            if not err and data:
                break
            sleep(1 * (attempt + 1))
        if err or not data:
            log(f'native_ticket_index: page {page} failed after retries: {err}')
            consecutive_failures += 1
            if consecutive_failures >= 10 or incremental:
                # incremental mode never keeps pushing through failures: stop, try again next start
                log('native_ticket_index: stopping for this run')
                return status + ' (stopped on failure)'
            page += 1
            sleep(2)
            continue
        consecutive_failures = 0

        rows = data.get('tickets', [])
        if not rows:
            break
        if page == 1 and incremental and not _newest_first(rows):
            incremental = False                       # cannot trust the order: do the full walk instead
            status = 'full scan (order not newest-first)'
            log('native_ticket_index: page 1 is not newest-first; falling back to a full scan')

        conn = get_db()
        nums = [t['ticket_number'] for t in rows if t.get('ticket_number') is not None]
        known = {r['ticket_number'] for r in conn.execute(
            f"SELECT ticket_number FROM native_ticket_index WHERE ticket_number IN ({','.join('?' * len(nums))})",
            nums)} if nums else set()
        new_here = 0
        for t in rows:
            if t.get('ticket_number') is not None and t.get('id'):
                if t['ticket_number'] not in known:
                    new_here += 1
                # thread_ref stored as '' (not NULL) when genuinely absent — NULL is reserved for
                # "row predates this column", which is what needs_full above tests for.
                conn.execute(
                    """INSERT OR REPLACE INTO native_ticket_index
                       (ticket_number, native_id, requester_email, subject, created_at, status, thread_ref)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (t['ticket_number'], t['id'], t.get('requester_email'),
                     t.get('subject'), t.get('created_at'), t.get('status'), t.get('thread_ref') or ''),
                )
        commit_with_retry(conn)
        conn.close()
        new_total += new_here

        total = data.get('pagination', {}).get('total', total)
        if incremental and page == 1 and new_here == 0:
            log('native_ticket_index: already up to date')
            return 'already up to date'              # the newest 100 tickets were all known: a single request
        if page * 100 >= total:
            break
        if incremental:
            known_pages = known_pages + 1 if new_here == 0 else 0
            if known_pages >= KNOWN_PAGES_TO_STOP:
                status = f'incremental: caught up after {page} pages'
                break
            if page >= MAX_INCREMENTAL_PAGES:
                status = f'incremental: stopped at {page} pages (will continue next start)'
                break
        page += 1
        sleep(pace)
    log(f'native_ticket_index: {status}; {new_total} new tickets indexed')
    return status
