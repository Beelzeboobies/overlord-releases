import email
import email.header
import email.utils
import base64
import html
import re


def decode_header(value):
    if not value:
        return ''
    parts = email.header.decode_header(value)
    result = []
    for part, charset in parts:
        if isinstance(part, bytes):
            result.append(part.decode(charset or 'utf-8', errors='replace'))
        else:
            result.append(part)
    return ''.join(result)

def parse_envelope(uid, msg_data):
    raw = msg_data.get(b'RFC822.HEADER') or msg_data.get(b'BODY[HEADER]', b'')
    msg = email.message_from_bytes(raw)
    flags = msg_data.get(b'FLAGS', ())
    has_att, att_names = check_attachment(msg_data.get(b'BODYSTRUCTURE'))
    from_name, from_addr = email.utils.parseaddr(msg.get('From', ''))
    _, reply_to_addr = email.utils.parseaddr(msg.get('Reply-To', ''))
    return {
        'uid': str(uid),
        'from_name': decode_header(from_name) or from_addr,
        'from_addr': from_addr,
        'reply_to': reply_to_addr,
        'subject': decode_header(msg.get('Subject', '(no subject)')),
        'date': msg.get('Date', ''),
        'read': b'\\Seen' in flags,
        'flagged_imap': b'\\Flagged' in flags,
        'has_attachment': has_att,
        'attachment_names': att_names,
    }

def _decode_mime_str(v):
    """Decode bytes/encoded MIME header strings."""
    if not v:
        return ''
    raw = v.decode('utf-8', errors='replace') if isinstance(v, bytes) else str(v)
    try:
        parts = email.header.decode_header(raw)
        return ''.join(
            p.decode(c or 'utf-8', errors='replace') if isinstance(p, bytes) else p
            for p, c in parts
        )
    except Exception:
        return raw

def check_attachment(structure):
    """Return (has_attachment: bool, names: list[str])."""
    names = []
    _collect_attachment_names(structure, names)
    return bool(names), names

def _collect_attachment_names(structure, names):
    if not isinstance(structure, (list, tuple)) or not structure:
        return
    # Multipart: recurse into children
    if isinstance(structure[0], (list, tuple)):
        for part in structure:
            if isinstance(part, (list, tuple)):
                _collect_attachment_names(part, names)
        return
    def s(v):
        # Must always return a str — some servers hand back an unusually
        # nested BODYSTRUCTURE (e.g. disp[0] itself a tuple instead of a
        # plain type string) for a specific malformed/edge-case message.
        # The old `v or ''` fallback let a non-bytes, non-str value (like
        # that tuple) pass straight through unchanged, so the very next
        # `.upper()` call crashed — confirmed live: one such message took
        # down the ENTIRE message-list fetch for the whole page, not just
        # itself (AttributeError: 'tuple' object has no attribute 'upper'
        # in _collect_attachment_names, 500 on /api/messages, Inbox showed
        # 0 emails). Anything that isn't bytes or str now safely becomes
        # '' instead of leaking through.
        if isinstance(v, bytes):
            return v.decode('utf-8', errors='replace')
        return v if isinstance(v, str) else ''
    main_type = s(structure[0]).upper()

    # Check Content-Disposition (index 8)
    if len(structure) > 8:
        disp = structure[8]
        if isinstance(disp, (list, tuple)) and disp:
            d = s(disp[0]).upper()
            if d == 'INLINE' and main_type in ('TEXT', 'IMAGE'):
                return  # inline content, not an attachment
            if d == 'ATTACHMENT':
                # Try to get filename from disposition params (index 1 of disp)
                fn = _extract_name_from_params(disp[1] if len(disp) > 1 else None, s)
                if fn:
                    names.append(_decode_mime_str(fn))
                    return
                # fall through to check body params

    # Non-text types with a NAME param
    if main_type not in ('TEXT', 'MULTIPART', 'NIL', ''):
        if len(structure) > 2:
            fn = _extract_name_from_params(structure[2], s)
            if fn:
                names.append(_decode_mime_str(fn))

def _extract_name_from_params(params, s):
    """Pull NAME or FILENAME from a BODYSTRUCTURE params list."""
    if not isinstance(params, (list, tuple)):
        return None
    keys = [s(params[i]).upper() for i in range(0, len(params), 2)]
    vals = [params[i] for i in range(1, len(params), 2)]
    for key, val in zip(keys, vals):
        if key in ('NAME', 'FILENAME'):
            return s(val) if val else None
    return None

def parse_body(raw_bytes):
    msg = email.message_from_bytes(raw_bytes)
    text = ''
    html = ''
    attachments = []
    cid_map = {}  # content-id → data URL

    def walk(part):
        nonlocal text, html
        ct = part.get_content_type()
        cd = part.get_content_disposition() or ''
        cid = part.get('Content-ID', '')
        if cid:
            cid = cid.strip('<>').strip()
        # Collect inline images for CID resolution. Real, confirmed live
        # bug (2026-09-08, user-reported: couldn't see an artist's attached
        # screenshots at all): this used to trigger on ANY image with a
        # Content-ID, regardless of its actual Content-Disposition — Gmail
        # (and others) commonly stamps a Content-ID on images even when
        # they're sent as real attachments, not inline-referenced ones.
        # Those got swallowed into cid_map and `return`ed past the
        # attachment check below before it ever ran, so a genuine
        # attachment that happened to carry a Content-ID silently vanished
        # from the attachments list entirely (still correctly detected by
        # the separate BODYSTRUCTURE-based check_attachment() this file
        # also has, used for the message-list view — which is why it
        # showed up there but not once the message was actually opened).
        # Only treat it as inline when disposition isn't explicitly
        # 'attachment'.
        if ct.startswith('image/') and cid and 'attachment' not in cd:
            payload = part.get_payload(decode=True)
            if payload:
                cid_map[cid] = f'data:{ct};base64,{base64.b64encode(payload).decode()}'
            return
        if 'attachment' in cd:
            # Real, confirmed live bug found alongside the fix above
            # (2026-09-08): email.message_from_bytes uses the legacy
            # Message class, whose get_filename() returns the RFC 2047
            # header value as-is — a raw '=?UTF-8?B?...?=' string, not the
            # decoded real name — unlike the BODYSTRUCTURE-based attachment
            # detection elsewhere in this file, which already runs
            # _decode_mime_str on every filename it finds. Same fix here.
            filename = decode_header(part.get_filename()) or 'file'
            attachments.append({
                'filename': filename,
                'type': ct,
                'size': len(part.get_payload(decode=True) or b''),
            })
            return
        if ct == 'text/plain' and not text:
            payload = part.get_payload(decode=True)
            charset = part.get_content_charset() or 'utf-8'
            text = payload.decode(charset, errors='replace') if payload else ''
        elif ct == 'text/html' and not html:
            payload = part.get_payload(decode=True)
            charset = part.get_content_charset() or 'utf-8'
            html = payload.decode(charset, errors='replace') if payload else ''

    if msg.is_multipart():
        for part in msg.walk():
            walk(part)
    else:
        walk(msg)

    # Rewrite cid: references in HTML to inline data URLs
    if html and cid_map:
        def _replace_cid(m):
            cid = m.group(1).strip()
            return f'src="{cid_map.get(cid, m.group(0)[5:])}"'  # keep original if not found
        html = re.sub(r'src="cid:([^"]+)"', lambda m: f'src="{cid_map.get(m.group(1).strip(), "cid:" + m.group(1))}"', html)

    return text, html, attachments


def _html_to_text(html_str):
    """Crude HTML→text fallback for messages with no text/plain part —
    common for templated/automated senders (e.g. AWS SES notifications)
    that only send an HTML alternative."""
    if not html_str:
        return ''
    text = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', '', html_str)
    text = re.sub(r'(?i)<br\s*/?>', '\n', text)
    text = re.sub(r'(?i)</p>', '\n\n', text)
    # Without this, a real bulleted/numbered list (e.g. numbered setup
    # steps in a canned response) collapses into one run-on line — <li>
    # tags just vanish in the generic tag-strip below with nothing to
    # separate what were distinct items, unlike <br>/</p> above. Confirmed
    # live on a real Freshdesk canned reply: "Go to your dashboard
    # Navigate to your Profile on the left  Click the Catalogue tab..."
    # with no separation between steps.
    text = re.sub(r'(?i)<li[^>]*>', '\n', text)
    text = re.sub(r'(?i)</(ul|ol)>', '\n\n', text)
    text = re.sub(r'<[^>]+>', '', text)
    return html.unescape(text).strip()


def extract_plain_body(raw_bytes):
    """Best-effort plain-text body for a raw RFC822 message. Prefers the
    real text/plain part (via parse_body) and falls back to a stripped
    text/html part when no plain-text alternative exists — without this,
    an HTML-only message produces a silently empty body (this is exactly
    what created empty support tickets for some automated senders)."""
    text, html_part, _ = parse_body(raw_bytes)
    return text or _html_to_text(html_part)


def _decode_env(val):
    """Decode imapclient ENVELOPE bytes/string to str."""
    if val is None:
        return ''
    if isinstance(val, bytes):
        try:
            return val.decode('utf-8', errors='replace')
        except Exception:
            return ''
    return str(val)

def _addr(addr_list):
    """First address from ENVELOPE address list → (name, email)."""
    if not addr_list:
        return '', ''
    a = addr_list[0]
    name  = _decode_env(a.name)
    mbox  = _decode_env(a.mailbox)
    host  = _decode_env(a.host)
    email_addr = f'{mbox}@{host}' if mbox and host else ''
    try:
        parts = email.header.decode_header(name)
        name = ''.join(
            p.decode(c or 'utf-8', errors='replace') if isinstance(p, bytes) else p
            for p, c in parts
        )
    except Exception:
        pass
    return name.strip(), email_addr

def _addr_list(addr_list):
    """All addresses from ENVELOPE address list → comma-separated 'Name <email>' string."""
    if not addr_list:
        return ''
    out = []
    for a in addr_list:
        try:
            name = _decode_env(a.name) or ''
            mbox = _decode_env(a.mailbox) or ''
            host = _decode_env(a.host) or ''
            em = f'{mbox}@{host}' if mbox and host else ''
            if not em:
                continue
            try:
                parts = email.header.decode_header(name)
                name = ''.join(
                    p.decode(c or 'utf-8', errors='replace') if isinstance(p, bytes) else p
                    for p, c in parts
                )
            except Exception:
                pass
            out.append(f'{name.strip()} <{em}>' if name.strip() else em)
        except Exception:
            pass
    return ', '.join(out)
