"""Neutral home for the ticket rules execution engine — same shape as
rules_engine.py's email equivalent (single condition, single action,
first-match-wins), applied to native tickets instead of messages. Imported
by freecords_admin.py (manual ticket create) and main.py (mail-to-ticket
creation), so it lives here rather than in freecords_admin.py itself to
keep the same blueprint-import-avoidance pattern rules_engine.py already
established for messages.py/main.py.

Only applied at ticket-creation time, not on every list/detail fetch — a
newly created ticket has no agent-made changes yet to clobber, so this is
the one moment a rule can act without risking overwriting a human's manual
edit later in the ticket's life.
"""

from db import get_db
from freecords_client import _api


def get_active_ticket_rules():
    conn = get_db()
    rows = conn.execute('SELECT * FROM ticket_rules WHERE active=1').fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _match(rule, subject, requester_email):
    field = rule['condition_field']
    op    = rule['condition_op']
    val   = (rule['condition_value'] or '').lower()
    src = (subject or '').lower() if field == 'subject' else (requester_email or '').lower()

    if op == 'contains':      return val in src
    if op == 'equals':        return src == val
    if op == 'starts_with':   return src.startswith(val)
    if op == 'ends_with':     return src.endswith(val)
    if op == 'not_contains':  return val not in src
    return False


def apply_ticket_rules(ticket_id, subject, requester_email):
    """Check a just-created ticket against active rules and apply the first
    match's action via PATCH /api/admin/tickets/{id}. Silently no-ops on
    error — a rule failing to apply shouldn't be allowed to make ticket
    creation itself fail; same tolerance rules_engine.py already has for
    email rules (each action wrapped in its own try/except there too)."""
    for rule in get_active_ticket_rules():
        if not _match(rule, subject, requester_email):
            continue
        action = rule['action']
        value = (rule['action_value'] or '').strip()
        if not value:
            return
        try:
            if action == 'add_tag':
                _api('PATCH', f'/api/admin/tickets/{ticket_id}', json={'tags': [value]})
            elif action == 'set_priority' and value in ('low', 'medium', 'high', 'urgent'):
                _api('PATCH', f'/api/admin/tickets/{ticket_id}', json={'priority': value})
            elif action == 'set_status' and value in ('open', 'pending', 'resolved', 'closed'):
                _api('PATCH', f'/api/admin/tickets/{ticket_id}', json={'status': value})
            elif action == 'assign':
                _api('PATCH', f'/api/admin/tickets/{ticket_id}', json={'assigneeId': value})
        except Exception:
            pass
        return  # first match wins, same as rules_engine.py
