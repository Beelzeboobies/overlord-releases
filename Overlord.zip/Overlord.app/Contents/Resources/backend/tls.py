"""TLS trust for the mail connections (IMAP login, SMTP send).

3 Nov 2026 15:55 GMT the mail host (premium79.web-hosting.com) started serving a certificate that
chains to "SSL.com TLS RSA Root CA 2022". Python on Windows only trusts what is already in the Windows
certificate store, which does not always have that root, so every IMAP login and every SMTP send failed
with "certificate verify failed: unable to get local issuer certificate" - from the ticket view that
looked like "not logged in" (attachments could not be fetched from the support@ mailbox).
The OS store is still used; the CA bundle that ships with Overlord (certifi, already used for every
Freecords request) is added on top. Certificates are still fully verified.
"""
import ssl


def tls_context():
    ctx = ssl.create_default_context()
    try:
        import certifi
        ctx.load_verify_locations(certifi.where())
    except Exception:
        pass   # no bundle available: behave exactly as before
    return ctx
