"""Cross-platform clipboard write, isolated behind one function.

macOS uses the `pbcopy` CLI tool (unchanged from the original call sites in
claude.py). Windows uses raw Win32 API calls via ctypes — no `pywin32`
dependency needed, and it keeps the Windows build's dependency list free of
packages that only matter for this one call. WRITTEN BUT UNVERIFIED: this
was scaffolded without access to a Windows machine — exercise
copy_to_clipboard() first thing on the first real Windows run before relying
on it (the paste automation in claude.py depends on it working correctly).

Every call site goes through copy_to_clipboard() rather than shelling out
directly, so Windows support is a one-function fill-in, not an N-site
search-and-replace.
"""
import subprocess
import sys


def copy_to_clipboard(data, timeout=5):
    """Write text or raw bytes to the system clipboard. Raises on failure
    (matching the original pbcopy subprocess.run(..., check=True) call sites
    — callers that need best-effort behavior already wrap this in a try/except)."""
    payload = data.encode('utf-8') if isinstance(data, str) else data
    if sys.platform == 'darwin':
        subprocess.run(['pbcopy'], input=payload, timeout=timeout, check=True)
    elif sys.platform == 'win32':
        _win_copy_to_clipboard(payload)
    else:
        raise NotImplementedError(f'Clipboard write not implemented for {sys.platform}')


def _win_copy_to_clipboard(payload: bytes):
    """Windows clipboard write: ctypes Win32 path first, clip.exe fallback.

    The ctypes path needed two real fixes on first live Windows exercise
    (the old UNVERIFIED warning here was right to worry):
    - argtypes/restype declarations are load-bearing, not boilerplate:
      ctypes defaults every return value to a 32-bit c_int, which silently
      truncates the 64-bit HGLOBAL GlobalAlloc returns on 64-bit Python —
      GlobalLock then received a mangled handle and failed every time.
    - Even fixed, clipboard calls can transiently fail inside the packaged
      app (the Flask thread shares a process with the WinForms/WebView2
      GUI, which has its own clipboard interactions), so any OSError from
      the ctypes path falls back to piping UTF-16 through clip.exe — the
      Windows equivalent of the pbcopy path Mac uses, spawned with
      CREATE_NO_WINDOW so no console flashes in the windowed build."""
    try:
        _win_copy_ctypes(payload)
    except OSError:
        text = payload.decode('utf-8')
        subprocess.run(
            ['clip'],
            input=b'\xff\xfe' + text.encode('utf-16le'),  # BOM so clip.exe reads unicode
            timeout=5, check=True,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )


def _win_copy_ctypes(payload: bytes):
    import ctypes
    from ctypes import wintypes

    text = payload.decode('utf-8')
    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002

    user32 = ctypes.WinDLL('user32', use_last_error=True)
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

    kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
    kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel32.GlobalLock.restype = wintypes.LPVOID
    kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalFree.argtypes = [wintypes.HGLOBAL]
    user32.SetClipboardData.restype = wintypes.HANDLE
    user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    user32.OpenClipboard.argtypes = [wintypes.HWND]

    def _err(op):
        return OSError(f'{op} failed (WinError {ctypes.get_last_error()})')

    # Another app (or the GUI side of this same process) can hold the
    # clipboard briefly — retry the open a few times before giving up.
    opened = False
    for _ in range(5):
        if user32.OpenClipboard(None):
            opened = True
            break
        import time
        time.sleep(0.05)
    if not opened:
        raise _err('OpenClipboard')
    try:
        user32.EmptyClipboard()
        data = text.encode('utf-16le') + b'\x00\x00'
        hglobal = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not hglobal:
            raise _err('GlobalAlloc')
        ptr = kernel32.GlobalLock(hglobal)
        if not ptr:
            kernel32.GlobalFree(hglobal)
            raise _err('GlobalLock')
        ctypes.memmove(ptr, data, len(data))
        kernel32.GlobalUnlock(hglobal)
        if not user32.SetClipboardData(CF_UNICODETEXT, hglobal):
            kernel32.GlobalFree(hglobal)
            raise _err('SetClipboardData')
        # Ownership of hglobal now belongs to the clipboard — do not free it.
    finally:
        user32.CloseClipboard()
