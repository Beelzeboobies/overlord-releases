"""
standalone_poller.py — headless, always-on extraction of Overlord's
mail-to-ticket creation loop, meant to run on a server (wherever Deshad
hosts it) instead of inside one person's desktop Overlord app.

WHY THIS EXISTS
----------------
The real logic already existed and works — it's main.py's
notification_loop, fixed this session for the duplicate+blank ticket
incident (per-UID cursor advance, verify-and-locally-repair a dropped
message). The problem was never the logic; it's that it only ran while
one specific desktop's Overlord.exe was open. Any crash, PC restart, or
forced app restart stopped ticket creation entirely, and — before this
session's fix — could replay a whole batch of already-processed mail as
duplicates on resume. This file is that same logic, pulled out so it can
run as its own always-on process, independent of anyone's desktop.

WHAT'S DIFFERENT FROM main.py's VERSION
-----------------------------------------
main.py's imap_connect()/get_all_accounts()/freecords_auth.get_token()
all read from the OS credential store (keyring) — Windows Credential
Manager / macOS Keychain. That doesn't exist by default on a headless
Linux server, so none of that could be reused as-is. This script takes
every credential from a plain environment variable instead (see
CONFIG below) and re-implements the two thin API-calling helpers
(_imap_connect, _api) locally rather than importing freecords_auth.py /
imap.py, so this file has no dependency on keyring being installed or
configured at all.

STATE — READ BEFORE DEPLOYING FOR REAL
-----------------------------------------
This script's own cursor ("which UID have I already processed") and its
locally-recovered ticket content (ticket_message_backfill, for the rare
case Freecords' own create-ticket endpoint drops the first message) live
in a local SQLite file (STATE_DB_PATH) by default. That's fine for
testing this script standalone, but it recreates the exact problem this
whole effort exists to fix if left that way in production: state tied to
one machine instead of the shared DB. Once Deshad's Postgres instance is
up, point get_state_conn() at it instead (schema is intentionally the
same shape as db.py's local tables, so this should be a small, mechanical
change — see get_state_conn()'s docstring) rather than leaving this file
running against local SQLite indefinitely.

Ticket Rules (ticket_rules_engine.apply_ticket_rules) are deliberately
NOT wired in here — that feature's config lives in per-desktop local
SQLite too, and was confirmed empty (0 rows) throughout this whole
session, so there's nothing live to apply yet. Wire it in once rules
themselves move to the shared DB.

CONFIG (all via environment variables)
-----------------------------------------
IMAP_HOST                default 'premium79.web-hosting.com' (Overlord's own default)
IMAP_PORT                default 993
IMAP_USER                required, e.g. support@freecords.com
IMAP_PASSWORD            required
FREECORDS_API_BASE_URL   default 'https://dev.freecords.com'
FREECORDS_API_TOKEN      required — a Freecords admin JWT (see note below)
STATE_DB_PATH            default './poller_state.db'
POLL_INTERVAL_SECONDS    default 60

FREECORDS_API_TOKEN note: today, Overlord's desktop app obtains this via
an interactive browser OAuth flow tied to a human admin session
(freecords_auth.py). There is currently no documented service-account /
machine-to-machine auth mode. Someone needs to complete that OAuth flow
once, capture the resulting token, and provide it to this process as
FREECORDS_API_TOKEN — and know that if Freecords expires/rotates that
token, this poller stops working until it's refreshed. Worth raising
with Nik if this needs to run reliably long-term: a real service-account
token would remove that fragility.

Run: python standalone_poller.py
Dry run (connects, reports what it WOULD do, creates nothing):
      python standalone_poller.py --dry-run
"""

import os
import re
import sqlite3
import sys
import time
import email.utils
import email.header as _email_header
import datetime as dt

import requests as http
from imapclient import IMAPClient

from parsing import extract_plain_body

# ── Config ────────────────────────────────────────────────────────────────────
IMAP_HOST = os.environ.get('IMAP_HOST', 'premium79.web-hosting.com')
IMAP_PORT = int(os.environ.get('IMAP_PORT', '993'))
IMAP_USER = os.environ.get('IMAP_USER', '')
IMAP_PASSWORD = os.environ.get('IMAP_PASSWORD', '')
FREECORDS_API_BASE_URL = os.environ.get('FREECORDS_API_BASE_URL', 'https://dev.freecords.com')
FREECORDS_API_TOKEN = os.environ.get('FREECORDS_API_TOKEN', '')
STATE_DB_PATH = os.environ.get('STATE_DB_PATH', './poller_state.db')
POLL_INTERVAL_SECONDS = int(os.environ.get('POLL_INTERVAL_SECONDS', '60'))

DRY_RUN = '--dry-run' in sys.argv

# Real, confirmed bug (2026-09-09, live test): a subject/name with a
# non-ASCII character (e.g. an accented name) crashed the whole poll
# cycle here — Windows' default console codepage (cp1252) can't encode
# it, and stdout wasn't told to use UTF-8. Whatever supervises this
# process (systemd, Docker, etc.) should be UTF-8 by default, but don't
# depend on that — force it explicitly so a customer's name never takes
# the whole poller down.
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

_THREAD_REF_RE = re.compile(r'support\+tk[a-f0-9]+@freecords\.com', re.I)
_TAKEDOWN_ARTIST_RE = re.compile(r'Artist:\s*.*?\(([^()\s]+@[^()\s]+)\)', re.IGNORECASE)


def log(msg):
    print(f"[{dt.datetime.now().isoformat(timespec='seconds')}] {msg}", flush=True)


# ── State (cursor + local backfill) ─────────────────────────────────────────
def get_state_conn():
    """
    Local SQLite by default — see the module docstring's STATE section.
    To point this at the shared Postgres instead: swap this function's
    body for a psycopg2 connection using Deshad's connection details, and
    adjust the two CREATE TABLE statements below to their Postgres
    equivalents (INTEGER PRIMARY KEY AUTOINCREMENT -> SERIAL PRIMARY KEY,
    TEXT DEFAULT (datetime('now')) -> TIMESTAMPTZ DEFAULT now()) — same
    shape as db.py's native_ticket_index-adjacent tables, deliberately,
    so this isn't a redesign later, just a driver swap.
    """
    conn = sqlite3.connect(STATE_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ticket_message_backfill (
            ticket_number  INTEGER PRIMARY KEY,
            body           TEXT NOT NULL,
            from_email     TEXT,
            message_id     TEXT,
            message_date   TEXT,
            backfilled_at  TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.commit()
    return conn


def get_cursor(conn):
    row = conn.execute("SELECT value FROM settings WHERE key='last_seen_uid'").fetchone()
    return int(row['value']) if row else 0


def set_cursor(conn, uid):
    conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('last_seen_uid', ?)", (str(uid),))
    conn.commit()


def record_backfill(conn, ticket_number, body, from_email, message_id):
    conn.execute(
        "INSERT OR REPLACE INTO ticket_message_backfill (ticket_number, body, from_email, message_id) VALUES (?, ?, ?, ?)",
        (ticket_number, body[:20000], from_email, message_id),
    )
    conn.commit()


# ── Freecords admin API ──────────────────────────────────────────────────────
def _api(method, path, timeout=10, _retries=2, **kwargs):
    """Same behavior as freecords_client.py's _api (retry on connection
    error/429, {'_not_found': True} on 404, plain error string otherwise)
    — reimplemented here rather than imported so this file has no
    dependency on freecords_auth.py / keyring."""
    if not FREECORDS_API_TOKEN:
        return None, 'FREECORDS_API_TOKEN not set'
    headers = {'Authorization': f'Bearer {FREECORDS_API_TOKEN}', 'Content-Type': 'application/json'}
    headers.update(kwargs.pop('headers', {}))
    try:
        resp = http.request(method, FREECORDS_API_BASE_URL + path, headers=headers, timeout=timeout, **kwargs)
    except (http.exceptions.ConnectionError, http.exceptions.Timeout):
        if _retries > 0:
            time.sleep(1)
            return _api(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        return None, 'connection_error'
    except Exception as e:
        return None, str(e)
    if resp.status_code == 401:
        return None, 'Freecords API token expired or invalid'
    if resp.status_code == 404:
        return {'_not_found': True}, None
    if resp.status_code == 429:
        if _retries > 0:
            wait = int(resp.headers.get('Retry-After', 5))
            time.sleep(min(wait, 30))
            return _api(method, path, timeout=timeout, _retries=_retries - 1, **kwargs)
        return None, 'Freecords is rate-limiting requests right now'
    if not resp.ok:
        try:
            body = resp.json()
            msg = body.get('error') or body.get('message') or f'HTTP {resp.status_code}'
        except Exception:
            msg = f'HTTP {resp.status_code}'
        return None, msg
    try:
        return resp.json(), None
    except Exception:
        return {}, None


# ── IMAP ──────────────────────────────────────────────────────────────────────
def imap_connect():
    if not IMAP_USER or not IMAP_PASSWORD:
        raise SystemExit('IMAP_USER and IMAP_PASSWORD must be set')
    client = IMAPClient(IMAP_HOST, port=IMAP_PORT, ssl=True, timeout=30)
    client.login(IMAP_USER, IMAP_PASSWORD)
    return client


def _decode_subject(raw):
    if not raw:
        return ''
    decoded = _email_header.decode_header(raw.decode('utf-8', 'replace'))
    return ''.join((p.decode(enc or 'utf-8', 'replace') if isinstance(p, bytes) else p) for p, enc in decoded)


# ── Core loop ─────────────────────────────────────────────────────────────────
def find_native_ticket_by_thread_ref(thread_ref):
    """Ask Freecords directly for a ticket with this thread_ref — no local
    index needed here (that index exists in Overlord to avoid a full-
    catalog scan on lookups elsewhere; this poller only needs the single
    ticket a reply is threading against, which the admin API can filter
    for directly if it supports it, or via a light client-side scan of
    recent tickets as a fallback)."""
    data, err = _api('GET', '/api/admin/tickets', params={'page': 1, 'limit': 50})
    if err or not data:
        return None
    for t in data.get('tickets', []):
        if t.get('thread_ref') == thread_ref:
            return t
    return None


def process_uid(conn, client, uid):
    """One email -> either logged onto an existing ticket's thread, or a
    brand-new ticket created. Mirrors main.py's fixed logic exactly:
    verify a newly-created ticket actually got its message, and if
    Freecords silently dropped it, record the recovered content locally
    rather than depending on Freecords' own /message endpoint (confirmed
    this session: it refuses to log a message on a ticket with zero
    existing messages, no matter how it's called)."""
    fetched = client.fetch([uid], ['ENVELOPE', 'RFC822'])
    data = fetched.get(uid)
    if not data:
        return
    env = data.get(b'ENVELOPE')
    if not env:
        return

    from_email = ''
    if env.from_ and env.from_[0].mailbox:
        mb = env.from_[0].mailbox.decode('utf-8', 'replace')
        host = (env.from_[0].host or b'').decode('utf-8', 'replace')
        from_email = f'{mb}@{host}'
    subject = _decode_subject(env.subject)
    msg_id = env.message_id.decode('utf-8', 'replace') if env.message_id else f'<imap-{uid}@freecords.com>'
    body = extract_plain_body(data.get(b'RFC822', b''))

    addr_fields = []
    for addr_list in (env.to or [], env.cc or []):
        for a in addr_list:
            if a.mailbox and a.host:
                addr_fields.append(f"{a.mailbox.decode('utf-8','replace')}@{a.host.decode('utf-8','replace')}")
    ref_match = _THREAD_REF_RE.search(' '.join(addr_fields))

    if DRY_RUN:
        if ref_match:
            log(f"[dry-run] uid={uid} would append reply to thread {ref_match.group(0)} from {from_email!r} subj={subject!r}")
        else:
            log(f"[dry-run] uid={uid} would create new ticket from {from_email!r} subj={subject!r}")
        return

    if ref_match:
        thread_ref = ref_match.group(0).split('+', 1)[1].split('@', 1)[0]
        native = find_native_ticket_by_thread_ref(thread_ref)
        if native and from_email:
            _data, post_err = _api('POST', f"/api/admin/tickets/{native['id']}/message", json={
                'direction': 'inbound',
                'body': body[:20000],
                'fromEmail': from_email,
                'message_id': msg_id,
            })
            # A customer replying to a closed/resolved/pending ticket must put it
            # back in the open queue. POST .../message only logs the message — it
            # does NOT reopen (confirmed 2026-10-12: 44 closed tickets sitting
            # with an unanswered customer reply, e.g. #69026). Freshdesk did this
            # automatically; native tickets need it done here.
            if not post_err and (native.get('status') or 'open') != 'open':
                _api('PATCH', f"/api/admin/tickets/{native['id']}", json={'status': 'open'})
        return

    payload = {
        'requesterEmail': from_email,
        'subject': subject,
        'body': body[:20000],
        'messageId': msg_id,
    }
    create_data, create_err = _api('POST', '/api/admin/tickets', json=payload)
    if create_err:
        log(f"ticket create failed for {from_email!r} ({subject!r}): {create_err}")
        return

    new_ticket = (create_data or {}).get('ticket') or {}
    if not new_ticket.get('id'):
        return

    verify_data, verify_err = _api('GET', f"/api/admin/tickets/{new_ticket['id']}")
    if not verify_err and not ((verify_data or {}).get('messages') or []):
        record_backfill(conn, new_ticket.get('ticketNumber'), body, from_email, msg_id)
        log(f"ticket #{new_ticket.get('ticketNumber')} created with no message — backfilled locally")


def poll_once(conn, client):
    client.select_folder('INBOX')
    uids = client.search(['ALL'])
    if not uids:
        return
    max_uid = max(uids)
    last_seen = get_cursor(conn)
    new_uids = [u for u in uids if u > last_seen] if last_seen else []

    if not last_seen:
        # First-ever run: don't process the whole mailbox history, just
        # start watching from here — same behavior as main.py's original.
        set_cursor(conn, max_uid)
        log(f"first run — seeded cursor to {max_uid}, no backlog processed")
        return

    for uid in new_uids:
        try:
            process_uid(conn, client, uid)
        except Exception as e:
            log(f"uid={uid} processing failed: {e}")
        finally:
            # Per-UID cursor advance — the actual fix for the
            # duplicate+blank incident. A crash here only ever risks
            # reprocessing the single UID in flight, never the whole
            # batch behind it.
            if not DRY_RUN:
                set_cursor(conn, uid)

    if DRY_RUN and new_uids:
        log(f"[dry-run] cursor not advanced — {len(new_uids)} new email(s) inspected, nothing written")


def main():
    log(f"standalone_poller starting — IMAP {IMAP_USER}@{IMAP_HOST}:{IMAP_PORT}, "
        f"Freecords API {FREECORDS_API_BASE_URL}, state db {STATE_DB_PATH}, "
        f"interval {POLL_INTERVAL_SECONDS}s{' [DRY RUN]' if DRY_RUN else ''}")
    conn = get_state_conn()
    client = imap_connect()
    log("IMAP connected OK")
    while True:
        try:
            poll_once(conn, client)
        except Exception as e:
            log(f"poll_once failed, will retry next interval: {e}")
            try:
                client = imap_connect()
                log("IMAP reconnected after error")
            except Exception as e2:
                log(f"IMAP reconnect also failed: {e2}")
        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == '__main__':
    main()
