import json
import datetime
import re as _re
import sys
import logging
import email
import email.header
import email.utils
import smtplib
import subprocess
import tempfile
import os
import threading
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from flask import Flask, request, jsonify, Response, send_from_directory
from imapclient import IMAPClient
import keyring
from config import (APP_SUPPORT,
                    KEYRING_SERVICE,
                    DEFAULT_IMAP_HOST, DEFAULT_IMAP_PORT,
                    DEFAULT_SMTP_HOST, DEFAULT_SMTP_PORT,
                    provider_config_for,
                    SETTINGS_PATH, FRONTEND_DIST, FRONTEND_PUBLIC)
from db import get_db, init_db, _migrate_schema


def _sync_log(msg):
    """
    Direct file write, bypassing the logging module entirely.

    Twice now, logging.info()/error() calls in the ticket-sync background
    threads have silently gone nowhere — something between window.py's
    handler setup and this module's import chain (Flask/werkzeug's own
    logging config is the likely culprit) resets or overrides the root
    logger before these threads ever run. Rather than debug that a third
    time, write straight to the log file — nothing can silently intercept
    that.
    """
    import datetime as _dt
    try:
        with open(APP_SUPPORT / 'logs' / 'backend.log', 'a') as f:
            f.write(f"[{_dt.datetime.now().isoformat(timespec='seconds')}] {msg}\n")
    except Exception:
        pass
from parsing import (decode_header, parse_envelope, _decode_mime_str,
                     check_attachment, _collect_attachment_names,
                     _extract_name_from_params, parse_body, extract_plain_body,
                     _decode_env, _addr, _addr_list)
from imap import (get_all_accounts, _invalidate_accounts_cache,
                  get_account_password, get_creds,
                  get_account_config, save_account_config,
                  imap_connect, imap_release, imap_client, imap_disconnect,
                  _get_bg_imap, drop_bg_client,
                  SAFE_FOLDER_CHARS, safe_folder,
                  _folder_maps, _build_folder_map, resolve_folder,
                  _unread_cache, _total_cache, _search_total_cache,
                  _folder_cache, _draft_folder_cache, _sent_folder_cache,
                  _unread_cache_lock,
                  _refresh_unread_counts, fetch_and_cache)
import auth as auth_bp_mod
import folders as folders_bp_mod
import search as search_bp_mod
import claude as claude_bp_mod
import contacts as contacts_bp_mod
import labels as labels_bp_mod
import rules as rules_bp_mod
from rules_engine import apply_rules_to_messages, get_active_rules
import settings as settings_bp_mod
import notifications as notifications_bp_mod
import events as events_bp_mod
import updates as updates_bp_mod
import freecords_admin as freecords_admin_bp_mod
import mobile_api as mobile_api_bp_mod
import user_notes as user_notes_bp_mod
import send as send_bp_mod
import messages as messages_bp_mod
from helpers import _parse_reminder, _find_conf_url, _sync_gcal_url, _do_send, store_ticket_attachment_files, mark_ticket_awaiting_reply
from datetime import datetime as _dt, timedelta as _td, timezone as _tz

# ── App setup ─────────────────────────────────────────────────────────────────

# Migrate old data from legacy location if present
_OLD_BACKEND = Path(__file__).parent
for _old, _new in [('mail.db', 'mail.db'), ('uploads', 'uploads'), ('.secret_key', '.secret_key')]:
    _o, _n = _OLD_BACKEND / _old, APP_SUPPORT / _new
    if _o.exists() and not _n.exists():
        import shutil
        shutil.move(str(_o), str(_n))

SECRET_KEY_PATH = APP_SUPPORT / '.secret_key'
if not SECRET_KEY_PATH.exists():
    import secrets as _secrets
    SECRET_KEY_PATH.write_text(_secrets.token_hex(32))

app = Flask(__name__, static_folder=str(FRONTEND_DIST), static_url_path='')
app.secret_key = SECRET_KEY_PATH.read_text().strip()
app.register_blueprint(auth_bp_mod.bp)
app.register_blueprint(folders_bp_mod.bp)
app.register_blueprint(search_bp_mod.bp)
app.register_blueprint(claude_bp_mod.bp)
app.register_blueprint(contacts_bp_mod.bp)
app.register_blueprint(labels_bp_mod.bp)
app.register_blueprint(rules_bp_mod.bp)
app.register_blueprint(settings_bp_mod.bp)
app.register_blueprint(notifications_bp_mod.bp)
app.register_blueprint(events_bp_mod.bp)
app.register_blueprint(updates_bp_mod.bp)
app.register_blueprint(freecords_admin_bp_mod.bp)
app.register_blueprint(mobile_api_bp_mod.bp)
app.register_blueprint(user_notes_bp_mod.bp)
app.register_blueprint(send_bp_mod.bp)
app.register_blueprint(messages_bp_mod.bp)

@app.errorhandler(Exception)
def handle_exception(e):
    import traceback
    from werkzeug.exceptions import HTTPException
    # print() can itself raise in the windowed (console=False) build if
    # stdout/stderr end up unusable — confirmed live: a request that hit this
    # handler was followed by every subsequent request 500ing until the
    # whole process died, consistent with the logging call inside the
    # handler throwing and taking down the request thread with no way to
    # report it (nothing above this handler catches a failure inside it).
    # Log to the same on-disk file every other background error path uses
    # instead, wrapped so a logging failure can never crash the handler.
    try:
        with open(APP_SUPPORT / 'logs' / 'backend.log', 'a') as f:
            f.write(f"[error] {e}\n{traceback.format_exc()}\n")
    except Exception:
        pass
    # Registering on the base Exception class also intercepts ordinary
    # HTTPExceptions (404, etc — they subclass Exception too), which were
    # getting stamped as 500 here regardless of their real status. Confirmed
    # live: a plain 404 from a stray page navigation (a raw ticket link in a
    # Freshdesk note body, opened as a top-level page load instead of inside
    # the SPA) came back as `{"error": "404 Not Found: ..."}` with a 500
    # status, which is what a fully broken page looks like rather than an
    # ordinary "page not found". Preserve the real status for these.
    if isinstance(e, HTTPException):
        return jsonify(error=e.description), e.code
    return jsonify(error=str(e)), 500

# Allowed IMAP folder characters — prevents injection
init_db()

_migrate_schema()

# ── Migrate legacy single-account keyring to new multi-account format ─────────
def migrate_keyring():
    if keyring.get_password(KEYRING_SERVICE, 'accounts'):
        return
    legacy_email = keyring.get_password(KEYRING_SERVICE, 'email')
    legacy_pw    = keyring.get_password(KEYRING_SERVICE, 'password')
    if legacy_email and legacy_pw:
        keyring.set_password(KEYRING_SERVICE, 'accounts', json.dumps([legacy_email])); _invalidate_accounts_cache()
        keyring.set_password(f'{KEYRING_SERVICE}:{legacy_email}', 'password', legacy_pw)

migrate_keyring()

def _background_prefetch():
    """Warm INBOX cache + folder maps for every account so tab-switching is instant."""
    import time as _time
    _time.sleep(3)
    for email_addr in get_all_accounts():
        try:
            client = imap_connect(email_addr)
            if not client:
                continue
            _build_folder_map(email_addr)
            client.select_folder('INBOX', readonly=True)
            uids = list(reversed(client.search(['ALL'])))[:30]
            if uids:
                fetch_and_cache(client, 'INBOX', uids, email_addr)
            # Leave the connection open — it's thread-local and will be reused
        except Exception:
            pass

threading.Thread(target=_background_prefetch, daemon=True).start()

# Automatic rotating backups + a loud, greppable warning if real data ever
# silently goes empty again — see backup.py's module docstring for the
# incident this exists because of. Runs on both platforms; nothing here is
# Windows/Mac-specific.
import backup as backup_mod
threading.Thread(target=backup_mod.backup_loop, daemon=True).start()


# ── CORS ──────────────────────────────────────────────────────────────────────

@app.after_request
def cors(r):
    r.headers['Access-Control-Allow-Origin'] = 'http://localhost:5173'
    r.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    r.headers['Access-Control-Allow-Methods'] = 'GET,POST,PATCH,DELETE,OPTIONS'
    r.headers['Access-Control-Allow-Credentials'] = 'true'
    return r



def _ticket_expiry_loop():
    """Background thread — **user, directly**: "an automation that sends
    an apologetic email to the user who sent a ticket we did not respond
    to for 30 days, explaining that their ticket has unfortunately expired
    and is gone from our request list and that they will have to create a
    new one. Automation should check not to send this email to the same
    [ticket] twice."

    ticket_awaiting_reply already tracks exactly the right signal — a row
    means "the last thing that happened on this ticket was the customer,
    not us", `marked_at` is when that started, and it's cleared the
    instant we reply (see db.py's own comment on that table). A row whose
    marked_at is 30+ days old is precisely "we did not respond for 30
    days" — no separate derivation needed. ticket_expiry_notified is the
    dedup guard: checked before ever sending, so a restart mid-run or a
    later re-scan can't double-send the same notice for the same ticket.
    """
    freecords_admin_bp_mod.set_background_thread_for_loops()
    import time as _time
    _sync_log("ticket_expiry_loop: thread started, sleeping 90s before first pass")
    _time.sleep(90)
    while True:
        try:
            conn = get_db()
            cutoff = (_dt.now(_tz.utc) - _td(days=30)).isoformat()
            rows = conn.execute(
                "SELECT ticket_number FROM ticket_awaiting_reply WHERE marked_at < ? "
                "AND ticket_number NOT IN (SELECT ticket_number FROM ticket_expiry_notified) "
                "ORDER BY marked_at ASC LIMIT 20",
                (cutoff,)
            ).fetchall()
            conn.close()

            import freecords_admin as _fadmin
            for row in rows:
                num = row['ticket_number']
                try:
                    idx_conn = get_db()
                    idx_row = idx_conn.execute(
                        "SELECT native_id FROM native_ticket_index WHERE ticket_number=?", (num,)
                    ).fetchone()
                    idx_conn.close()
                    if not idx_row:
                        continue
                    native_id = idx_row['native_id']

                    detail, err = _fadmin._api('GET', f'/api/admin/tickets/{native_id}')
                    if err:
                        _sync_log(f'ticket_expiry_loop: #{num} detail fetch failed: {err}')
                        continue
                    ticket = (detail or {}).get('ticket') or {}
                    req_email = ticket.get('requester_email') or ''

                    def _mark_notified(sent):
                        c2 = get_db()
                        c2.execute(
                            "INSERT OR REPLACE INTO ticket_expiry_notified "
                            "(ticket_number, requester_email, notified, notified_at) "
                            "VALUES (?, ?, ?, datetime('now'))",
                            (num, req_email, int(sent)),
                        )
                        c2.commit()
                        c2.close()

                    # Already closed by someone/something else in the meantime —
                    # nothing to expire, just stop tracking it as a candidate.
                    if ticket.get('status') == 'closed':
                        _mark_notified(False)
                        continue
                    if not req_email:
                        _mark_notified(False)
                        continue

                    html_body = (
                        '<p style="margin: 0 0 12px 0">Hi there,</p>'
                        '<p style="margin: 0 0 12px 0">We\'re very sorry — your support ticket unfortunately went '
                        'unanswered for longer than we allow, and has now expired and been removed from our '
                        'request list.</p>'
                        '<p style="margin: 0 0 12px 0">If you still need help, please get in touch again by opening '
                        'a new ticket. We apologize for the inconvenience and will do our best to get to it '
                        'promptly this time.</p>'
                        '<br><br>Warmest Regards,<br>Freecords Team'
                    )
                    data, send_err = _fadmin._api('POST', f'/api/admin/tickets/{native_id}/reply', json={
                        'subject': 'Your support ticket has expired',
                        'body': html_body,
                    })
                    if send_err:
                        _sync_log(f'ticket_expiry_loop: #{num} expiry email failed: {send_err}')
                        continue

                    _fadmin._api('PATCH', f'/api/admin/tickets/{native_id}', json={'status': 'closed'})
                    conn3 = get_db()
                    conn3.execute("DELETE FROM ticket_awaiting_reply WHERE ticket_number=?", (num,))
                    conn3.commit()
                    conn3.close()
                    _mark_notified(True)
                    _sync_log(f'ticket_expiry_loop: #{num} expired — notified {req_email} and closed')
                except Exception as e:
                    _sync_log(f'ticket_expiry_loop: #{num} crashed: {e}')
                _time.sleep(2)
        except Exception as e:
            _sync_log(f'ticket_expiry_loop: pass crashed: {e}')
        _time.sleep(3600)  # hourly — this isn't time-sensitive like new mail is


def _duplicate_ticket_cleanup_loop():
    """Background thread, hourly — **user, directly**: "write a cleanup
    cron... to do it every hour", after a live incident (2026-09-11) where
    _notification_loop's mail-to-ticket automation created 231 duplicate
    open tickets (same requester + same subject, created seconds apart).

    Root cause, as best established live: _ticket_creation_from_mail_enabled
    is meant to be on for exactly one designated instance (see that
    function's own comment, and the 2026-09-05 incident it was built for) —
    but the failure signature here (many DIFFERENT tickets, each duplicated
    exactly once, sub-second apart, all day, not just in bursts) matches
    more than one instance currently having it on and independently racing
    to create a ticket for the same new mail. Nothing in this codebase can
    verify or fix another install's local setting from here — that's an
    operational check for whoever administers each instance, not a bug in
    this loop. This is the safety net regardless of whether that gets
    coordinated: find same-requester/same-subject tickets that are both
    still open, keep whichever one actually has real message content, and
    close the rest — never delete, same as every prior duplicate cleanup
    this session. Unlike ticket-creation and ticket-expiry, this is a pure
    read-and-close operation with no side effect a second instance running
    it concurrently could corrupt (closing an already-closed ticket is a
    no-op) — safe to enable on more than one instance if needed, unlike
    those two.
    """
    freecords_admin_bp_mod.set_background_thread_for_loops()
    import time as _time
    _sync_log("duplicate_ticket_cleanup_loop: thread started, sleeping 120s before first pass")
    _time.sleep(120)
    while True:
        try:
            import freecords_admin as _fadmin

            tickets = []
            page = 1
            while True:
                data, err = _fadmin._api('GET', '/api/admin/tickets', params={'status': 'open', 'limit': 100, 'page': page})
                if err:
                    _sync_log(f'duplicate_ticket_cleanup_loop: list page {page} failed: {err}')
                    break
                page_tickets = (data or {}).get('tickets') or []
                if not page_tickets:
                    break
                tickets.extend(page_tickets)
                page += 1
                if page > 30:  # ~3000 tickets — generous ceiling, never expected to hit it
                    break

            groups = {}
            for t in tickets:
                key = (t.get('requester_email'), _re.sub(r'\s+', ' ', (t.get('subject') or '')).strip().lower())
                groups.setdefault(key, []).append(t)

            closed_count = 0
            for key, members in groups.items():
                if len(members) < 2:
                    continue
                details = []
                for t in members:
                    tid = t.get('id')
                    d, err = _fadmin._api('GET', f'/api/admin/tickets/{tid}')
                    if err:
                        continue
                    details.append((t, d or {}))
                    _time.sleep(0.3)
                if len(details) < 2:
                    continue

                def _score(pair):
                    t, d = pair
                    msgs = d.get('messages') or []
                    has_real_msg = any((m.get('direction') == 'inbound') and (m.get('body') or '').strip() for m in msgs)
                    return (1 if has_real_msg else 0, t.get('created_at') or '')

                details.sort(key=_score, reverse=True)
                best_t, best_d = details[0]
                if not any((m.get('body') or '').strip() for m in (best_d.get('messages') or [])):
                    # Every member is content-less — too ambiguous to pick a
                    # primary safely. Leave the whole group open for a human
                    # to look at instead of guessing.
                    continue

                for t, d in details[1:]:
                    tid = t.get('id')
                    tnum = t.get('ticket_number')
                    _, err = _fadmin._api('PATCH', f'/api/admin/tickets/{tid}', json={'status': 'closed'})
                    if err:
                        _sync_log(f'duplicate_ticket_cleanup_loop: failed to close duplicate #{tnum}: {err}')
                    else:
                        closed_count += 1
                    _time.sleep(0.3)

            if closed_count:
                _sync_log(f'duplicate_ticket_cleanup_loop: closed {closed_count} duplicate ticket(s) this pass')
        except Exception as e:
            _sync_log(f'duplicate_ticket_cleanup_loop: pass crashed: {e}')
        _time.sleep(3600)  # hourly, per explicit request


# ── Frontend (serve built React app) ─────────────────────────────────────────
# Bundled default sounds and every user-uploaded sound both live in
# FRONTEND_DIST/sounds (settings.py's upload route writes there directly),
# so this same catch-all already serves /sounds/<file> correctly — no
# separate route needed.

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    if path.startswith('api/'):
        return jsonify(error='not found'), 404
    full = FRONTEND_DIST / path
    if path and full.exists():
        resp = send_from_directory(str(FRONTEND_DIST), path)
    else:
        resp = send_from_directory(str(FRONTEND_DIST), 'index.html')
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    return resp



# ── Notification daemon ────────────────────────────────────────────────────────

def send_notification(title: str, body: str, subtitle: str = ''):
    """Fire a native desktop notification, macOS or Windows.
    WINDOWS PATH UNVERIFIED — scaffolded without a Windows machine to test
    against; exercise this on the first real Windows run."""
    if sys.platform == 'darwin':
        safe = lambda s: s.replace('\\', '\\\\').replace('"', '\\"')[:200]
        parts = [f'display notification "{safe(body)}" with title "{safe(title)}"']
        if subtitle:
            parts[0] += f' subtitle "{safe(subtitle)}"'
        try:
            subprocess.run(['osascript', '-e', parts[0]], timeout=5, capture_output=True)
        except Exception:
            pass
    elif sys.platform == 'win32':
        _send_windows_notification(title, body, subtitle)
    # else: no notification backend for this platform yet


def _send_windows_notification(title: str, body: str, subtitle: str = ''):
    """Balloon-tip toast via a PowerShell one-liner — no extra Python
    dependency (no win10toast/plyer needed), PowerShell ships with Windows.
    UNVERIFIED, see send_notification()."""
    full_body = f'{subtitle}\n{body}' if subtitle else body
    esc = lambda s: s.replace('`', '``').replace('"', '`"').replace('$', '`$')[:200]
    ps_script = (
        'Add-Type -AssemblyName System.Windows.Forms; '
        '$n = New-Object System.Windows.Forms.NotifyIcon; '
        '$n.Icon = [System.Drawing.SystemIcons]::Information; '
        '$n.Visible = $true; '
        f'$n.BalloonTipTitle = "{esc(title)}"; '
        f'$n.BalloonTipText = "{esc(full_body)}"; '
        '$n.ShowBalloonTip(5000); '
        'Start-Sleep -Seconds 6; '
        '$n.Dispose()'
    )
    try:
        # CREATE_NO_WINDOW: without it, spawning a console subsystem exe
        # (powershell.exe) from Overlord.exe pops a real, visible terminal
        # window every time this fires — capture_output=True only
        # redirects the pipes, it does not suppress window creation.
        # **User-reported**: a console window kept appearing while Overlord
        # was just sitting open, tied to nothing they were doing — traced
        # to this exact call via _notification_loop()'s 60s reminder
        # check, the first time this Windows-only path ever ran for real.
        CREATE_NO_WINDOW = 0x08000000
        subprocess.run(['powershell', '-NoProfile', '-Command', ps_script],
                        timeout=10, capture_output=True, creationflags=CREATE_NO_WINDOW)
    except Exception:
        pass


def _notification_loop():
    """Background thread: check every 60 s and fire reminders."""
    import time as _time
    import sqlite3 as _sqlite3

    def _commit_with_retry(conn, tries=5):
        # Bug, confirmed live 2026-09-04: the cursor-update commit below had
        # no retry at all, wrapped in a bare `except Exception: pass`. Under
        # real lock contention (this file's own concurrent background loops,
        # get_db() has no busy_timeout) the commit silently failed, the
        # cursor never advanced past the 2 newest UIDs, and every subsequent
        # 60s poll re-discovered the same "new" thread and created a fresh
        # duplicate ticket — 111 duplicates over 71 minutes before caught.
        # Same retry pattern already used elsewhere in this file (e.g.
        # _freshdesk_sync_loop) for the identical class of failure.
        for attempt in range(tries):
            try:
                conn.commit()
                return
            except _sqlite3.OperationalError:
                if attempt == tries - 1:
                    raise
                _time.sleep(0.3 * (attempt + 1))
    _time.sleep(10)  # let server start first
    # On startup: silence all past events so stale notifications don't fire
    try:
        conn = get_db()
        now_iso = _dt.now(_tz.utc).isoformat()
        conn.execute(
            "UPDATE events SET notified=1 WHERE notified=0 AND start_dt < ?",
            (now_iso,)
        )
        _commit_with_retry(conn)
        conn.close()
    except Exception:
        pass
    while True:
        try:
            conn = get_db()
            row_notif = conn.execute(
                "SELECT value FROM settings WHERE key='calendar_notifications'"
            ).fetchone()
            notifications_on = (row_notif['value'] if row_notif else '1') != '0'

            if notifications_on:
                now = _dt.now(_tz.utc)
                rows = conn.execute(
                    "SELECT * FROM events WHERE notified=0 AND all_day=0"
                ).fetchall()
                for ev in rows:
                    try:
                        start = _dt.fromisoformat(ev['start_dt'].replace('Z', '+00:00'))

                        # Skip events that are already over (started > 1h ago)
                        if start < now - _td(hours=1):
                            conn.execute('UPDATE events SET notified=1 WHERE id=?', (ev['id'],))
                            _commit_with_retry(conn)
                            continue

                        reminders = _parse_reminder(ev['reminder_minutes']) or [10]
                        remind_at = start - _td(minutes=reminders[0])
                        if now >= remind_at:
                            mins = reminders[0]
                            subtitle = f'In {mins} min' if now < start else 'Starting now'
                            loc = ev['location'] or ''
                            raw_desc = (ev['description'] or '')
                            # Strip HTML tags from description
                            import re as _re2
                            plain_desc = _re2.sub(r'<[^>]+>', '', raw_desc).strip()[:80]
                            body_txt = loc if loc else plain_desc
                            send_notification(
                                title    = '📅 ' + (ev['title'] or 'Event'),
                                body     = body_txt or subtitle,
                                subtitle = subtitle if body_txt else '',
                            )
                            conn.execute('UPDATE events SET notified=1 WHERE id=?', (ev['id'],))
                            _commit_with_retry(conn)
                    except Exception:
                        continue
            # ── New mail check & rules ────────────────────────────────────
            try:
                all_accounts = get_all_accounts()
                for acct in all_accounts:
                    acct_key = acct.replace('@', '_').replace('.', '_')
                    conn2 = get_db()
                    last_row = conn2.execute(
                        "SELECT value FROM settings WHERE key=?",
                        (f'last_seen_uid_{acct_key}',)
                    ).fetchone()
                    last_seen = int(last_row['value']) if last_row else 0
                    conn2.close()

                    try:
                        client = imap_connect(acct)
                        if not client:
                            continue
                        client.select_folder('INBOX')
                        uids = client.search(['ALL'])
                        if not uids:
                            continue

                        max_uid = max(uids)
                        new_uids = [u for u in uids if u > last_seen] if last_seen else []

                        # Per-account notification check
                        acct_notif_row = conn.execute(
                            "SELECT value FROM settings WHERE key='account_notifications'"
                        ).fetchone()
                        acct_notif_map = {}
                        try:
                            acct_notif_map = json.loads(acct_notif_row['value']) if acct_notif_row else {}
                        except Exception:
                            pass
                        # Default: inherit global setting; per-account '0' overrides to off
                        this_acct_notif = notifications_on
                        if acct in acct_notif_map:
                            this_acct_notif = acct_notif_map[acct] != '0'

                        # Notify for each new message
                        if new_uids and last_seen > 0 and this_acct_notif:
                            fetch_data = client.fetch(new_uids[-5:], ['ENVELOPE'])
                            for uid2, data in fetch_data.items():
                                env = data.get(b'ENVELOPE')
                                if not env:
                                    continue
                                subj = ''
                                if env.subject:
                                    subj = email.header.decode_header(
                                        env.subject.decode('utf-8', errors='replace')
                                    )[0][0]
                                    if isinstance(subj, bytes):
                                        subj = subj.decode('utf-8', errors='replace')
                                sender = ''
                                if env.from_ and env.from_[0].mailbox:
                                    mb = env.from_[0].mailbox.decode('utf-8', errors='replace')
                                    host = (env.from_[0].host or b'').decode('utf-8', errors='replace')
                                    sender = f'{mb}@{host}'
                                send_notification(
                                    title=f'New email — {acct}',
                                    body=str(subj)[:120],
                                    subtitle=sender[:80],
                                )


                        # Apply rules to new messages
                        if new_uids:
                            fetch_data2 = client.fetch(new_uids, ['ENVELOPE', 'FLAGS', 'RFC822.SIZE'])
                            msgs_for_rules = []
                            for uid2, data in fetch_data2.items():
                                env = data.get(b'ENVELOPE')
                                if not env:
                                    continue
                                subj = ''
                                if env.subject:
                                    decoded = email.header.decode_header(
                                        env.subject.decode('utf-8', errors='replace')
                                    )
                                    subj = ''.join(
                                        (p.decode(enc or 'utf-8') if isinstance(p, bytes) else p)
                                        for p, enc in decoded
                                    )
                                from_addr2 = ''
                                if env.from_ and env.from_[0].mailbox:
                                    mb = env.from_[0].mailbox.decode('utf-8', errors='replace')
                                    host = (env.from_[0].host or b'').decode('utf-8', errors='replace')
                                    from_addr2 = f'{mb}@{host}'
                                msgs_for_rules.append({
                                    'uid': uid2, 'subject': subj,
                                    'from_addr': from_addr2, 'from_name': '',
                                    'date': '', 'read': False, 'flagged': False,
                                    'has_attachment': False,
                                })
                            if msgs_for_rules:
                                apply_rules_to_messages(msgs_for_rules, acct, acct_key)

                        # Update last seen UID — retried, and logged (not
                        # silently swallowed) on failure, so a stuck cursor
                        # shows up in backend.log instead of quietly
                        # reprocessing the same "new" thread every pass.
                        try:
                            conn3 = get_db()
                            conn3.execute(
                                "INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)",
                                (f'last_seen_uid_{acct_key}', str(max_uid))
                            )
                            _commit_with_retry(conn3)
                            conn3.close()
                        except Exception as _cursor_err:
                            _sync_log(f'notification_loop: FAILED to advance last_seen_uid for {acct} to {max_uid}: {_cursor_err}')
                        # thread-local connection — leave open for next iteration
                    except Exception:
                        pass
            except Exception:
                pass

            conn.close()
        except Exception:
            pass
        _time.sleep(60)


threading.Thread(target=_notification_loop, daemon=True).start()


def _gcal_sync_loop():
    import time as _time
    _time.sleep(15)
    while True:
        try:
            conn = get_db()
            row = conn.execute("SELECT value FROM settings WHERE key='gcal_ics_url'").fetchone()
            interval_row = conn.execute("SELECT value FROM settings WHERE key='gcal_sync_interval'").fetchone()
            conn.close()
            url = row['value'].strip() if row and row['value'] else ''
            interval = int(interval_row['value']) if interval_row and interval_row['value'] else 15
            if url and url.startswith('https://'):
                _sync_gcal_url(url)
        except Exception:
            pass
        _time.sleep(max(5, interval) * 60)


threading.Thread(target=_gcal_sync_loop, daemon=True).start()


def _build_native_ticket_index():
    """
    Keeps native_ticket_index (ticket_number -> native id, requester, subject,
    status ...) current. Runs once at startup, ~15s after launch.

    2026-10-19 (Freecords database incident; Nik: "one at a time", these APIs are not
    built for bulk requests): this used to re-walk the WHOLE ticket list (~660 pages)
    on every start of every install whenever the index was even one ticket behind.
    The logic now lives in ticket_index.py: incremental (only the newest pages, until
    it reaches tickets it already has) when Freecords returns newest-first, full walk
    only as a slow fallback. All requests sequential, with a pause.
    """
    freecords_admin_bp_mod.set_background_thread_for_loops()
    import time as _time
    import ticket_index
    _time.sleep(15)
    try:
        result = ticket_index.run(
            api_get=lambda params: freecords_admin_bp_mod._api('GET', '/api/admin/tickets', params=params),
            get_db=get_db,
            sleep=_time.sleep,
            log=_sync_log,
        )
        _sync_log(f"native_ticket_index: {result}")
    except Exception:
        import traceback as _tb
        _sync_log(f"native_ticket_index: backfill crashed: {_tb.format_exc()}")



def _ticket_expiry_enabled():
    # _ticket_expiry_loop sends a real customer-facing email and closes the
    # ticket, with no per-instance coordination beyond a live remote status
    # re-check right before acting — same shape of risk as the mail-to-
    # ticket duplicate incident that _ticket_creation_from_mail_enabled
    # above already had to be gated for (multiple installs, one shared
    # mailbox/ticket set, no single owner). Windows shipped this thread
    # running unconditionally; gated here the same way before ever
    # restarting Mac on this pulled code — **user, directly**: "make sure
    # no other user or computer other than Eugene's original windows
    # desktop does it." Defaults to OFF (no settings row = off) on every
    # instance, including this one — exactly one designated instance
    # should ever have this on.
    try:
        conn = get_db()
        row = conn.execute("SELECT value FROM settings WHERE key='ticket_expiry_enabled'").fetchone()
        conn.close()
        return bool(row) and row['value'] == '1'
    except Exception:
        return False


def _duplicate_ticket_cleanup_enabled():
    # Gate for _duplicate_ticket_cleanup_loop — **user, directly**: "write a
    # cleanup cron... to do it every hour", 2026-09-11. Unlike
    # ticket_creation_from_mail_enabled/ticket_expiry_enabled above, this
    # loop only reads and closes already-open duplicate tickets — no
    # customer email, no new ticket creation — so it's safe for more than
    # one instance to run at once (closing an already-closed ticket is a
    # no-op). Still off by default like every other background loop in this
    # file, so turning it on is always a deliberate choice.
    try:
        conn = get_db()
        row = conn.execute("SELECT value FROM settings WHERE key='duplicate_ticket_cleanup_enabled'").fetchone()
        conn.close()
        return bool(row) and row['value'] == '1'
    except Exception:
        return False


threading.Thread(target=_build_native_ticket_index, daemon=True).start()
# Push any notes this install wrote under the old local-only admin-notes system up to Freecords, once.
threading.Thread(target=freecords_admin_bp_mod.rescue_all_local_notes_once, daemon=True).start()
if _ticket_expiry_enabled():
    threading.Thread(target=_ticket_expiry_loop, daemon=True).start()
else:
    print('[startup] 30-day ticket expiry automation disabled (ticket_expiry_enabled setting not set) — exactly one designated instance should have this on', flush=True)
if _duplicate_ticket_cleanup_enabled():
    threading.Thread(target=_duplicate_ticket_cleanup_loop, daemon=True).start()
else:
    print('[startup] Hourly duplicate-ticket cleanup disabled (duplicate_ticket_cleanup_enabled setting not set)', flush=True)
print('[startup] Freshdesk sync/reconcile/attachment-backfill loops removed — Freshdesk account is permanently suspended, confirmed live (account_suspended on every call, 2026-09-25/26), nothing left to backfill from', flush=True)


if __name__ == '__main__':
    app.run(port=8000, debug=False, threaded=True)
