"""A customer's other tickets must show in "Open cases" from every one of their tickets (7 Nov:
#71395 listed #72241, but #72241 did not list #71395)."""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("DELETE FROM ticket_read_state")
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.commit()


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _row(number, native_id, email, status='open'):
    _mem.execute(
        "INSERT INTO native_ticket_index (ticket_number, native_id, requester_email, subject, created_at, status) "
        "VALUES (?, ?, ?, 'Copyright Verification Appeal', '2026-11-07', ?)", (number, native_id, email, status))
    _mem.commit()


def _numbers(r):
    return sorted(t['id'] for t in r.get_json()['tickets'])


def test_same_address_in_other_capitals_or_with_spaces_is_the_same_customer(fclient):
    _row(71395, 'a', 'jamilylemos23@gmail.com')
    _row(72241, 'b', 'Jamilylemos23@Gmail.com ')
    r = fclient.get('/api/fadmin/tickets/by-requester?email=jamilylemos23@gmail.com&exclude_id=a')
    assert _numbers(r) == [72241]
    r = fclient.get('/api/fadmin/tickets/by-requester?email=Jamilylemos23@Gmail.com&exclude_id=b')
    assert _numbers(r) == [71395]


def test_the_ticket_itself_is_still_left_out(fclient):
    _row(71395, 'a', 'x@y.com')
    r = fclient.get('/api/fadmin/tickets/by-requester?email=x@y.com&exclude_id=a')
    assert _numbers(r) == []


def test_opening_a_ticket_records_it_in_the_index(fclient):
    detail = {'ticket': {'id': 'a', 'ticket_number': 71395, 'requester_email': 'jamilylemos23@gmail.com',
                         'subject': 'Copyright Verification Appeal', 'created_at': '2026-10-24', 'status': 'open'},
              'messages': [{'id': 'm'}], 'notes': []}
    with patch.object(fa, '_api', return_value=(detail, None)):
        assert fclient.get('/api/fadmin/tickets/a').status_code == 200
    _row(72241, 'b', 'jamilylemos23@gmail.com')
    r = fclient.get('/api/fadmin/tickets/by-requester?email=jamilylemos23@gmail.com&exclude_id=b')
    assert _numbers(r) == [71395]


def test_opening_a_ticket_refreshes_its_status_in_the_index(fclient):
    _row(71395, 'a', 'x@y.com', status='open')
    detail = {'ticket': {'id': 'a', 'ticket_number': 71395, 'requester_email': 'x@y.com',
                         'subject': 's', 'created_at': '2026-10-24', 'status': 'closed'}, 'messages': [{'id': 'm'}]}
    with patch.object(fa, '_api', return_value=(detail, None)):
        fclient.get('/api/fadmin/tickets/a')
    assert _mem.execute("SELECT status FROM native_ticket_index WHERE ticket_number=71395").fetchone()[0] == 'closed'


def test_a_reply_without_the_requester_never_overwrites_a_good_row(fclient):
    _row(71395, 'a', 'x@y.com')
    detail = {'ticket': {'id': 'a', 'ticket_number': 71395}, 'messages': [{'id': 'm'}]}
    with patch.object(fa, '_api', return_value=(detail, None)):
        assert fclient.get('/api/fadmin/tickets/a').status_code == 200
    assert _mem.execute("SELECT requester_email FROM native_ticket_index WHERE ticket_number=71395").fetchone()[0] == 'x@y.com'


def test_tickets_in_the_list_are_recorded_in_the_index(fclient):
    listed = [
        {'id': 'b', 'ticket_number': 72241, 'requester_email': 'jamilylemos23@gmail.com',
         'subject': 's', 'created_at': '2026-11-07', 'status': 'open'},
        {'id': 'c', 'ticket_number': 71303, 'requester_email': 'projectnvrmusic@gmail.com',
         'subject': 's', 'created_at': '2026-10-22', 'status': 'open', 'thread_ref': 'abc'},
        {'id': 'd', 'ticket_number': 5},   # no requester: left out
    ]
    with patch.object(fa, '_fetch_all_matching_tickets', return_value=(listed, 3, False, None)):
        assert fclient.get('/api/fadmin/tickets?status=open').status_code == 200
    rows = {r[0]: r for r in _mem.execute("SELECT ticket_number, native_id, thread_ref FROM native_ticket_index")}
    assert set(rows) == {72241, 71303}
    assert rows[72241][2] == ''          # '' not NULL: NULL would make the next start scan every page
    assert rows[71303][2] == 'abc'


def test_an_opened_ticket_without_a_thread_ref_is_stored_with_an_empty_one(fclient):
    detail = {'ticket': {'id': 'a', 'ticket_number': 71395, 'requester_email': 'x@y.com', 'status': 'open'},
              'messages': [{'id': 'm'}]}
    with patch.object(fa, '_api', return_value=(detail, None)):
        fclient.get('/api/fadmin/tickets/a')
    assert _mem.execute("SELECT thread_ref FROM native_ticket_index WHERE ticket_number=71395").fetchone()[0] == ''
