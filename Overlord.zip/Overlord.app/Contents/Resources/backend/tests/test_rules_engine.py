"""
R1–R5  Rules-engine unit characterization tests.

Tests call rules_engine functions directly (no HTTP).
"""
from unittest.mock import patch, MagicMock

import rules_engine
from test_support import TEST_ACCT, _mem


def _insert_rule(name='Test rule', field='subject', op='contains',
                 value='newsletter', action='mark_read', action_value='',
                 active=1):
    cur = _mem.execute(
        """INSERT INTO rules
           (name, condition_field, condition_op, condition_value,
            action, action_value, active)
           VALUES (?,?,?,?,?,?,?)""",
        (name, field, op, value, action, action_value, active)
    )
    _mem.commit()
    return cur.lastrowid


def _msg(uid='1', subject='Hello', from_name='Alice',
         from_addr='alice@example.com', read=False, flagged_imap=False):
    return {
        'uid': uid, 'subject': subject,
        'from_name': from_name, 'from_addr': from_addr,
        'read': read, 'flagged_imap': flagged_imap,
        'has_attachment': False,
    }


class TestRulesEngine:

    def test_R1_no_rules_returns_empty_list(self):
        """R1 — no rules in DB → get_active_rules() returns []."""
        assert rules_engine.get_active_rules() == []

    def test_R2_inactive_rules_excluded(self):
        """R2 — only active=1 rules returned; active=0 excluded."""
        _insert_rule(name='Active', active=1)
        _insert_rule(name='Inactive', active=0)

        result = rules_engine.get_active_rules()
        assert len(result) == 1
        assert result[0]['name'] == 'Active'

    def test_R3_no_rules_messages_unchanged(self):
        """R3 — no active rules → apply_rules returns all messages, moved=[]."""
        msgs = [_msg(uid='1'), _msg(uid='2')]
        kept, moved = rules_engine.apply_rules_to_messages(
            msgs, TEST_ACCT, TEST_ACCT)
        assert len(kept) == 2
        assert moved == []

    def test_R4_mark_read_rule_sets_flag(self):
        """R4 — mark_read action → matching message has read=True, stays in kept."""
        _insert_rule(field='subject', op='contains', value='newsletter',
                     action='mark_read')
        msgs = [
            _msg(uid='10', subject='Daily newsletter digest'),
            _msg(uid='11', subject='Hello from Alice'),
        ]
        kept, moved = rules_engine.apply_rules_to_messages(
            msgs, TEST_ACCT, TEST_ACCT)
        uid_map = {m['uid']: m for m in kept}
        assert uid_map['10']['read'] is True    # matched → mark_read
        assert uid_map['11']['read'] is False   # did not match

    def test_R5_move_rule_removes_message_from_kept(self):
        """R5 — move action with mocked IMAP → matched uid in moved_uids, not in kept."""
        _insert_rule(field='from', op='contains', value='spam@',
                     action='move', action_value='Spam')

        msgs = [
            _msg(uid='20', from_addr='spam@bad.example.com'),
            _msg(uid='21', from_addr='friend@example.com'),
        ]

        mock_client = MagicMock()
        mock_client.select_folder.return_value = {b'EXISTS': 1}
        mock_client.move.return_value = None

        with patch.object(rules_engine, 'imap_connect', return_value=mock_client), \
             patch.object(rules_engine, 'resolve_folder', side_effect=lambda f, k: f):
            kept, moved = rules_engine.apply_rules_to_messages(
                msgs, TEST_ACCT, TEST_ACCT)

        kept_uids = {m['uid'] for m in kept}
        assert '20' not in kept_uids   # moved
        assert '21' in kept_uids       # kept
        assert '20' in moved
