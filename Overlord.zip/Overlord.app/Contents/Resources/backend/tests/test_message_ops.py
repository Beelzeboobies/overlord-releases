"""
O1–O8  Per-message operation characterization tests.

Routes under test:
    GET  /api/messages/uids         (O1 — observable consequence of delete)
    POST /api/messages/mark-read    (O2)
    POST /api/messages/<uid>/read   (O3)
    GET  /api/messages (cache path) (O4 — observable consequence of mark-read)
    POST /api/messages/delete       (O5)
    GET/PATCH /api/email/<uid>/meta (O6)
    GET  /api/messages (folder validation) (O7 — safe_folder '.' regression pin)
    POST /api/messages/<uid>/read   (O8 — unread counter decrement)
"""
import imap
from test_support import TEST_ACCT, seed_message, _mem


class TestMessageOps:

    # ── O1: delete → uids endpoint no longer lists deleted UID ──────────────

    def test_O1_deleted_uid_absent_from_uids_endpoint(self, client, logged_in):
        """O1 — after delete, /api/messages/uids omits the deleted UID."""
        seed_message(uid=1, folder='INBOX', account=TEST_ACCT)
        seed_message(uid=2, folder='INBOX', account=TEST_ACCT)
        seed_message(uid=3, folder='INBOX', account=TEST_ACCT)

        logged_in.select_folder.return_value = {b'EXISTS': 3}
        logged_in.move.return_value = None

        r = client.post('/api/messages/delete',
                        json={'uids': [2], 'folder': 'INBOX', 'account': TEST_ACCT})
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

        r2 = client.get(f'/api/messages/uids?folder=INBOX&account={TEST_ACCT}')
        assert r2.status_code == 200
        uids = r2.get_json()['uids']
        assert '2' not in uids
        assert '1' in uids
        assert '3' in uids

    # ── O2: bulk mark-read updates DB ────────────────────────────────────────

    def test_O2_bulk_mark_read_flips_db_flag(self, client, logged_in):
        """O2 — POST mark-read → ok=True and DB row has read=1."""
        seed_message(uid=10, read=0, folder='INBOX', account=TEST_ACCT)

        logged_in.select_folder.return_value = {b'EXISTS': 1}
        r = client.post('/api/messages/mark-read',
                        json={'uids': [10], 'folder': 'INBOX',
                              'account': TEST_ACCT, 'unread': False})
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

        row = _mem.execute(
            "SELECT read FROM message_cache WHERE account=? AND folder=? AND uid=?",
            (TEST_ACCT, 'INBOX', '10')
        ).fetchone()
        assert row is not None
        assert row['read'] == 1

    # ── O3: single mark-read calls IMAP add_flags ────────────────────────────

    def test_O3_single_mark_read_calls_add_flags(self, client, logged_in):
        """O3 — POST /api/messages/<uid>/read → ok=True, IMAP add_flags called."""
        seed_message(uid=20, read=0, folder='INBOX', account=TEST_ACCT)

        logged_in.select_folder.return_value = {b'EXISTS': 1}
        r = client.post(f'/api/messages/20/read?folder=INBOX&account={TEST_ACCT}')
        assert r.status_code == 200
        assert r.get_json()['ok'] is True
        logged_in.add_flags.assert_called_once_with([20], ['\\Seen'])

    # ── O4: mark-read → cache path reflects updated flag ─────────────────────

    def test_O4_cache_path_reflects_updated_read_flag(self, client, logged_in):
        """O4 — after mark-read, cache-path GET /api/messages returns read=True."""
        seed_message(uid=30, read=0, folder='INBOX', account=TEST_ACCT)

        logged_in.select_folder.return_value = {b'EXISTS': 1}
        client.post('/api/messages/mark-read',
                    json={'uids': [30], 'folder': 'INBOX',
                          'account': TEST_ACCT, 'unread': False})

        r = client.get(f'/api/messages?folder=INBOX&account={TEST_ACCT}')
        assert r.status_code == 200
        data = r.get_json()
        assert data['cached'] is True
        msgs = {m['uid']: m for m in data['messages']}
        assert msgs['30']['read'] is True

    # ── O5: delete removes DB rows ────────────────────────────────────────────

    def test_O5_delete_removes_db_rows(self, client, logged_in):
        """O5 — POST delete → ok=True and all specified rows removed from DB."""
        seed_message(uid=40, folder='INBOX', account=TEST_ACCT)
        seed_message(uid=41, folder='INBOX', account=TEST_ACCT)

        logged_in.select_folder.return_value = {b'EXISTS': 2}
        logged_in.move.return_value = None

        r = client.post('/api/messages/delete',
                        json={'uids': [40, 41], 'folder': 'INBOX',
                              'account': TEST_ACCT})
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

        rows = _mem.execute(
            "SELECT uid FROM message_cache WHERE account=? AND folder=? AND uid IN ('40','41')",
            (TEST_ACCT, 'INBOX')
        ).fetchall()
        assert len(rows) == 0

    # ── O7: safe_folder accepts '.' — no regression from _validate_folder_name ─

    def test_O7_dotted_server_folder_passes_safe_folder(self, client, logged_in):
        """O7 — GET /api/messages?folder=INBOX.Sent does NOT return 400.

        safe_folder() in imap.py has '.' in its allowed set; removing '.' from
        _validate_folder_name in folders.py (step 4) must not bleed into
        safe_folder.  If it did, every Dovecot subfolder (INBOX.Sent,
        INBOX.Archive, etc.) would be unreachable with a 400.

        Pins V1's read-only verification with a live route hit.
        """
        # Seed a message in the dotted folder so the cache path returns 200
        seed_message(uid=50, folder='INBOX.Sent', account=TEST_ACCT)

        r = client.get(f'/api/messages?folder=INBOX.Sent&account={TEST_ACCT}')
        assert r.status_code == 200, (
            f'Expected 200 but got {r.status_code} — '
            '"." may have been removed from safe_folder\'s allowed set'
        )

    # ── O8: mark-read decrements _unread_cache ────────────────────────────────

    def test_O8_mark_read_decrements_unread_counter(self, client, logged_in):
        """O8 — POST /api/messages/<uid>/read → _unread_cache[acct][folder] decremented.

        Counterpart to M7: the frontend calls this endpoint after render;
        the server must update the in-memory unread counter so the sidebar
        badge reflects the change without a full refresh.

        Specifically pins lines 499-503 in messages.py — the _unread_cache
        decrement that only fires when the message was previously unread.
        """
        seed_message(uid=60, read=0, folder='INBOX', account=TEST_ACCT)

        # Pre-populate the unread counter so the decrement is observable
        with imap._unread_cache_lock:
            imap._unread_cache[TEST_ACCT] = {'INBOX': 5}

        logged_in.select_folder.return_value = {b'EXISTS': 1}

        r = client.post(f'/api/messages/60/read?folder=INBOX&account={TEST_ACCT}')
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

        # Counter must drop by exactly 1: dict.fromkeys([folder, real_folder])
        # deduplicates before iterating, so when resolve_folder is identity
        # (INBOX → INBOX with an empty folder map) only one decrement fires.
        with imap._unread_cache_lock:
            count = imap._unread_cache.get(TEST_ACCT, {}).get('INBOX')
        assert count == 4, f'Expected _unread_cache INBOX=4, got {count}'

    # ── O6: email_meta PATCH + GET round-trip ────────────────────────────────

    def test_O6_email_meta_patch_and_get_roundtrip(self, client):
        """O6 — PATCH sets flagged; subsequent GET returns that value."""
        r_patch = client.patch('/api/email/99/meta',
                               json={'folder': 'INBOX', 'flagged': 1})
        assert r_patch.status_code == 200
        assert r_patch.get_json()['ok'] is True

        r_get = client.get('/api/email/99/meta')
        assert r_get.status_code == 200
        data = r_get.get_json()
        assert data['flagged'] == 1
        assert data['uid'] == '99'
