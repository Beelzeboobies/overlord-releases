"""
Tickets outbound mail — attachments on create/reply, sent by Overlord itself.

Routes under test (freecords_admin.py):
    POST /api/fadmin/tickets              (fadmin_tickets_create)
    POST /api/fadmin/tickets/<id>/reply   (fadmin_ticket_reply)
plus helpers._do_send's message_id / reply_to support they rely on.

Freecords' own endpoints are JSON-only and its create endpoint emails nobody
(confirmed live 2026-09-05), so with attachments — or send_email on create —
the email must go out through _do_send from support@ with Reply-To set to the
ticket's thread address, and be logged onto the thread afterwards.
"""
import base64
from unittest.mock import patch, MagicMock

import pytest

import freecords_admin as fa
import helpers as helpers_mod
from test_support import _mem, TEST_ACCT

SUPPORT = 'support@freecords.com'
B64 = base64.b64encode(b'hello pdf bytes').decode()
ATT = [{'filename': 'proof.pdf', 'data_base64': B64}]

GET_DETAIL = {
    'ticket': {'id': 'T1', 'ticket_number': 42, 'requester_email': 'artist@example.com',
               'subject': 'Cover art issue', 'thread_ref': 'tkabc123',
               'replyAddress': 'support+tkabc123@freecords.com'},
    'messages': [
        {'message_id': '<old@x>', 'created_at': '2026-09-01T00:00:00Z'},
        {'message_id': '<newest@x>', 'created_at': '2026-09-05T00:00:00Z'},
    ],
}
CREATE_RESP = {'ticket': {'id': 'T2', 'ticketNumber': 43, 'requesterEmail': 'support@routenote.com',
                          'threadRef': 'tkdef456', 'replyAddress': 'support+tkdef456@freecords.com'}}


class _NoThread:
    """Stand-in for threading.Thread so _do_send's Sent-folder append never runs."""
    def __init__(self, *a, **kw): pass
    def start(self): pass


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("CREATE TABLE IF NOT EXISTS ticket_manually_created (ticket_number INTEGER PRIMARY KEY, created_at TEXT)")
    _mem.execute("CREATE TABLE IF NOT EXISTS ticket_awaiting_reply (ticket_number INTEGER PRIMARY KEY, marked_at TEXT)")
    _mem.execute("DELETE FROM ticket_manually_created")
    _mem.commit()


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _api_router(get_detail=GET_DETAIL, create_resp=CREATE_RESP):
    calls = []
    def _api(method, path, **kw):
        calls.append((method, path, kw.get('json')))
        if method == 'GET':
            return get_detail, None
        if method == 'POST' and path == '/api/admin/tickets':
            return dict(create_resp), None
        return {'success': True}, None
    _api.calls = calls
    return _api


class TestReply:

    def test_R1_no_attachments_keeps_freecords_send_path(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), patch.object(fa, '_do_send') as send:
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': '<p>hi</p>', 'attachments': []})
        assert r.status_code == 200
        send.assert_not_called()
        # Detail is now always fetched first (needed to check requester_email
        # for the takedown-ticket-artist-redirect case below), then the
        # ordinary reply still goes straight to Freecords' own endpoint.
        assert api.calls == [
            ('GET', '/api/admin/tickets/T1', None),
            ('POST', '/api/admin/tickets/T1/reply', {'body': '<p>hi</p>'}),
        ]

    def test_R7_takedown_ticket_reply_redirects_to_real_artist_email(self, fclient):
        # Real, confirmed bug (2026-09-09): auto-generated takedown tickets
        # always have requester_email = freecords@freecords.com (a system
        # address nobody reads) — replying through either normal path sent
        # every reply nowhere useful. The real artist's email is embedded
        # in the ticket's own auto-generated message body.
        detail = {
            'ticket': {'id': 'T1', 'ticket_number': 99, 'requester_email': 'freecords@freecords.com',
                       'subject': 'Takedown Request — "Song" by Artist', 'thread_ref': 'tkxyz',
                       'replyAddress': 'support+tkxyz@freecords.com'},
            'messages': [{
                'message_id': '<auto@x>', 'created_at': '2026-09-09T00:00:00Z',
                'body': 'Takedown Request Received\n\nArtist: Real Artist (realartist@example.com)\nISRC: ABC123\n',
            }],
        }
        api = _api_router(get_detail=detail)
        with patch.object(fa, '_api', api), \
             patch.object(fa, 'get_all_accounts', return_value=[SUPPORT]), \
             patch.object(fa, '_do_send', return_value=(True, '', 0)) as send:
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': 'Your takedown is done.', 'attachments': []})
        assert r.status_code == 200, r.get_json()
        d = r.get_json()
        assert d['success'] is True and d['sentVia'] == 'overlord' and d['sentTo'] == 'realartist@example.com'
        assert send.call_args[0][0]['to'] == 'realartist@example.com'
        # Never sent to Freecords' hosted reply endpoint for this case.
        assert all(p != '/api/admin/tickets/T1/reply' for _, p, _ in api.calls)

    def test_R8_takedown_ticket_with_no_recoverable_artist_email_keeps_normal_path(self, fclient):
        # requester_email is the system address, but the body doesn't match
        # the expected "Artist: name (email)" shape — fall back to the
        # ordinary Freecords-hosted reply path rather than guessing.
        detail = {
            'ticket': {'id': 'T1', 'ticket_number': 99, 'requester_email': 'freecords@freecords.com',
                       'subject': 'Takedown Request', 'thread_ref': 'tkxyz',
                       'replyAddress': 'support+tkxyz@freecords.com'},
            'messages': [{'message_id': '<auto@x>', 'created_at': '2026-09-09T00:00:00Z', 'body': 'no structured info here'}],
        }
        api = _api_router(get_detail=detail)
        with patch.object(fa, '_api', api), patch.object(fa, '_do_send') as send:
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': 'hi', 'attachments': []})
        assert r.status_code == 200
        send.assert_not_called()
        assert ('POST', '/api/admin/tickets/T1/reply', {'body': 'hi'}) in api.calls

    def test_R2_attachments_sent_by_overlord_and_logged(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), \
             patch.object(fa, 'get_all_accounts', return_value=[TEST_ACCT, SUPPORT]), \
             patch.object(fa, '_do_send', return_value=(True, '', 0)) as send:
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': '<p>see attached</p>', 'attachments': ATT})
        assert r.status_code == 200, r.get_json()
        d = r.get_json()
        assert d['success'] is True and d['sentVia'] == 'overlord' and d['logged'] is True

        payload = send.call_args[0][0]
        assert payload['account'] == SUPPORT
        assert payload['to'] == 'artist@example.com'
        assert payload['reply_to'] == 'support+tkabc123@freecords.com'
        assert payload['subject'] == 'Re: Cover art issue'
        assert payload['in_reply_to'] == '<newest@x>'
        assert payload['attachments'] == ATT
        assert payload['message_id'] == d['messageId'] and d['messageId'].startswith('<')

        methods = [(m, p) for m, p, _ in api.calls]
        assert ('POST', '/api/admin/tickets/T1/reply') not in methods
        log = [j for m, p, j in api.calls if p == '/api/admin/tickets/T1/message'][0]
        assert log['direction'] == 'outbound'
        assert log['message_id'] == d['messageId']
        assert log['fromEmail'] == SUPPORT
        assert '<p>see attached</p>' in log['body'] and 'proof.pdf' in log['body']

    def test_R3_subject_not_double_prefixed(self, fclient):
        detail = dict(GET_DETAIL, ticket=dict(GET_DETAIL['ticket'], subject='RE: already a reply'))
        with patch.object(fa, '_api', _api_router(get_detail=detail)), \
             patch.object(fa, 'get_all_accounts', return_value=[SUPPORT]), \
             patch.object(fa, '_do_send', return_value=(True, '', 0)) as send:
            fclient.post('/api/fadmin/tickets/T1/reply', json={'body': 'x', 'attachments': ATT})
        assert send.call_args[0][0]['subject'] == 'RE: already a reply'

    def test_R4_support_account_missing_refuses_before_sending(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), \
             patch.object(fa, 'get_all_accounts', return_value=[TEST_ACCT]), \
             patch.object(fa, '_do_send') as send:
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': 'x', 'attachments': ATT})
        assert r.status_code == 502
        assert 'support@freecords.com' in r.get_json()['error']
        send.assert_not_called()
        assert all(p != '/api/admin/tickets/T1/message' for _, p, _ in api.calls)

    def test_R5_smtp_failure_surfaces_and_logs_nothing(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), \
             patch.object(fa, 'get_all_accounts', return_value=[SUPPORT]), \
             patch.object(fa, '_do_send', return_value=(False, 'SMTP authentication failed', 401)):
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': 'x', 'attachments': ATT})
        assert r.status_code == 502
        assert 'SMTP authentication failed' in r.get_json()['error']
        assert all(p != '/api/admin/tickets/T1/message' for _, p, _ in api.calls)

    def test_R6_oversized_attachments_rejected(self, fclient):
        big = base64.b64encode(b'x' * (fa.MAX_ATTACHMENTS_BYTES + 1)).decode()
        with patch.object(fa, '_api') as api, patch.object(fa, '_do_send') as send:
            r = fclient.post('/api/fadmin/tickets/T1/reply', json={'body': 'x', 'attachments': [{'filename': 'huge.bin', 'data_base64': big}]})
        assert r.status_code == 400
        api.assert_not_called(); send.assert_not_called()


class TestCreate:

    def test_C1_plain_create_unchanged(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), patch.object(fa, '_do_send') as send:
            r = fclient.post('/api/fadmin/tickets', json={'requesterEmail': 'a@b.c', 'subject': 'S', 'body': 'B', 'messageId': '<m@x>'})
        assert r.status_code == 201
        send.assert_not_called()
        assert api.calls[0][2] == {'requesterEmail': 'a@b.c', 'subject': 'S', 'body': 'B', 'messageId': '<m@x>'}
        assert _mem.execute("SELECT ticket_number FROM ticket_manually_created").fetchall()[0][0] == 43

    def test_C2_send_email_creates_then_mails_recipient(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), \
             patch.object(fa, 'get_all_accounts', return_value=[SUPPORT]), \
             patch.object(fa, '_do_send', return_value=(True, '', 0)) as send:
            r = fclient.post('/api/fadmin/tickets', json={
                'requesterEmail': 'support@routenote.com', 'subject': 'FW: takedown list',
                'body': '<p>Dear Colleagues</p>', 'messageId': '<m@x>', 'send_email': True, 'attachments': ATT,
            })
        assert r.status_code == 201, r.get_json()
        d = r.get_json()
        assert d['sentVia'] == 'overlord' and d['sentMessageId'].startswith('<')

        # upstream record: control keys stripped, body notes the files
        create_json = [j for m, p, j in api.calls if p == '/api/admin/tickets'][0]
        assert 'attachments' not in create_json and 'send_email' not in create_json
        assert create_json['body'].startswith('<p>Dear Colleagues</p>') and 'proof.pdf' in create_json['body']

        payload = send.call_args[0][0]
        assert payload['account'] == SUPPORT
        assert payload['to'] == 'support@routenote.com'
        assert payload['subject'] == 'FW: takedown list'
        assert payload['body'] == '<p>Dear Colleagues</p>'          # email carries the real files, not the note
        assert payload['reply_to'] == 'support+tkdef456@freecords.com'
        assert payload['attachments'] == ATT
        assert 'in_reply_to' not in payload
        assert ('DELETE', '/api/admin/tickets/T2') not in [(m, p) for m, p, _ in api.calls]

    def test_C3_send_failure_deletes_the_ticket(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), \
             patch.object(fa, 'get_all_accounts', return_value=[SUPPORT]), \
             patch.object(fa, '_do_send', return_value=(False, 'Send failed: boom', 500)):
            r = fclient.post('/api/fadmin/tickets', json={'requesterEmail': 'a@b.c', 'subject': 'S', 'body': 'B', 'messageId': '<m@x>', 'send_email': True})
        assert r.status_code == 502
        assert 'boom' in r.get_json()['error']
        assert ('DELETE', '/api/admin/tickets/T2') in [(m, p) for m, p, _ in api.calls]
        assert _mem.execute("SELECT count(*) FROM ticket_manually_created").fetchone()[0] == 0

    def test_C4_support_account_missing_refuses_before_creating(self, fclient):
        api = _api_router()
        with patch.object(fa, '_api', api), patch.object(fa, 'get_all_accounts', return_value=[TEST_ACCT]):
            r = fclient.post('/api/fadmin/tickets', json={'requesterEmail': 'a@b.c', 'subject': 'S', 'body': 'B', 'send_email': True})
        assert r.status_code == 400
        assert api.calls == []


class TestDoSendHeaders:

    def _send(self, body):
        mock_smtp = MagicMock()
        # Bypass the pooled-connection cache: it would hand back whichever
        # mock an earlier test left in _smtp_pool, not this one.
        with patch('helpers.get_all_accounts', return_value=[TEST_ACCT]), \
             patch('helpers.get_account_password', return_value='secret'), \
             patch('helpers.get_account_config', return_value={'smtp_host': 'smtp.example.com', 'smtp_port': '465'}), \
             patch('helpers._get_pooled_smtp', return_value=('test-key', mock_smtp)), \
             patch('helpers.threading.Thread', _NoThread):
            ok, err, _ = helpers_mod._do_send(body)
        assert ok, err
        return mock_smtp.sendmail.call_args[0][2].decode('utf-8', 'replace')

    def test_H1_message_id_and_reply_to_survive_attachment_wrapping(self):
        raw = self._send({
            'account': TEST_ACCT, 'to': 'artist@example.com', 'subject': 'Re: x',
            'body': '<p>body</p>', 'message_id': '<fixed-id@freecords.com>',
            'reply_to': 'support+tkabc123@freecords.com', 'attachments': ATT,
        })
        assert 'Message-ID: <fixed-id@freecords.com>' in raw
        assert 'Reply-To: support+tkabc123@freecords.com' in raw
        assert 'filename="proof.pdf"' in raw
        assert raw.count('Message-ID:') == 1
        assert raw.count('Reply-To:') == 1

    def test_H2_defaults_unchanged_without_new_fields(self):
        raw = self._send({'account': TEST_ACCT, 'to': 'b@example.com', 'subject': 's', 'body': 'plain'})
        assert 'Reply-To:' not in raw
        assert 'Message-ID: <' in raw
