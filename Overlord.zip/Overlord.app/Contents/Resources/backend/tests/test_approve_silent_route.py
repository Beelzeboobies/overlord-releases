"""Overlord's Approve must use Nik's approve-song-silent (full approval, no email), never approve-song-only."""
import freecords_admin as fa
from flask import Flask


def test_approve_calls_the_silent_route_with_the_song_id(monkeypatch):
    calls = []
    monkeypatch.setattr(fa, '_api', lambda method, path, **kw: (calls.append((method, path, kw.get('json'))) or ({'success': True}, None)))
    monkeypatch.setattr(fa, '_log_local_moderation_action', lambda *a, **k: None)
    app = Flask(__name__)
    with app.test_request_context(json={'song_id': 'abc'}):
        resp = fa.fadmin_mod_approve()
    assert calls == [('POST', '/api/admin/moderation/approve-song-silent', {'songId': 'abc'})]
    assert resp.get_json() == {'success': True}


def test_api_failure_is_reported_not_swallowed(monkeypatch):
    monkeypatch.setattr(fa, '_api', lambda *a, **k: (None, 'Song not found'))
    app = Flask(__name__)
    with app.test_request_context(json={'song_id': 'abc'}):
        resp, code = fa.fadmin_mod_approve()
    assert code == 503 and resp.get_json()['error'] == 'Song not found'
