"""2026-10-19 Freecords incident guards (Nik: "one at a time, don't set another until it's finished").
No live calls: everything here talks to fakes."""
import threading
import time

import freecords_admin as fa
import freecords_client as fc


# ── the guard: only one Freecords request in flight at a time ─────────────────
def test_only_one_request_is_ever_in_flight(monkeypatch):
    state = {'now': 0, 'peak': 0}
    lock = threading.Lock()

    def fake_inner(method, path, timeout=10, _retries=2, **kw):
        with lock:
            state['now'] += 1
            state['peak'] = max(state['peak'], state['now'])
        time.sleep(0.02)
        with lock:
            state['now'] -= 1
        return {'ok': True}, None

    monkeypatch.setattr(fc, '_api_inner', fake_inner)
    monkeypatch.setattr(fc, '_MIN_GAP_SECONDS', 0)
    threads = [threading.Thread(target=fc._api, args=('GET', '/x')) for _ in range(12)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert state['peak'] == 1


def test_waiting_too_long_returns_a_clear_error_not_a_pileup(monkeypatch):
    monkeypatch.setattr(fc, '_GATE_WAIT_SECONDS', 0.05)
    assert fc._GATE.acquire(timeout=1)            # someone else holds the only slot
    try:
        data, err = fc._api('GET', '/x')
    finally:
        fc._GATE.release()
    assert data is None and 'queued' in err


def test_retry_inside_the_guard_does_not_deadlock(monkeypatch):
    """A timeout triggers an internal retry: it must reuse the held slot, not wait for a new one."""
    calls = {'n': 0}

    class Resp:
        status_code = 200
        ok = True
        headers = {}
        def json(self):
            return {'done': True}

    def fake_request(*a, **kw):
        calls['n'] += 1
        if calls['n'] == 1:
            raise fc.http.exceptions.Timeout()
        return Resp()

    monkeypatch.setattr(fc.freecords_auth, 'get_token', lambda: 'tok')
    monkeypatch.setattr(fc.http, 'request', fake_request)
    monkeypatch.setattr(fc._gate_time, 'sleep', lambda s: None)
    monkeypatch.setattr(fc, '_GATE_WAIT_SECONDS', 1)
    data, err = fc._api('GET', '/x')
    assert err is None and data == {'done': True} and calls['n'] == 2


# ── page cap + one-page-at-a-time + short cache on the ticket scan ────────────
def _fake_tickets_api(total, log):
    def api(method, path, params=None, **kw):
        log.append(params['page'])
        return {'tickets': [{'id': f"t{params['page']}-{i}"} for i in range(3)],
                'pagination': {'total': total}}, None
    return api


def test_scan_is_capped_sequential_and_flags_capped(monkeypatch):
    log = []
    monkeypatch.setattr(fa, '_api', _fake_tickets_api(7000, log))
    monkeypatch.setattr(fa, 'TICKET_SCAN_MAX_PAGES', 10)
    fa._scan_cache.clear()
    tickets, total, capped, err = fa._fetch_all_matching_tickets({'status': 'open'})
    assert err is None and total == 7000 and capped is True
    assert log == list(range(1, 11))              # pages 1..10 in order, nothing beyond the cap
    assert len(tickets) == 30


def test_small_view_is_not_flagged_capped(monkeypatch):
    log = []
    monkeypatch.setattr(fa, '_api', _fake_tickets_api(250, log))
    monkeypatch.setattr(fa, 'TICKET_SCAN_MAX_PAGES', 10)
    fa._scan_cache.clear()
    _t, total, capped, _e = fa._fetch_all_matching_tickets({'status': 'closed'})
    assert capped is False and log == [1, 2, 3]


def test_a_failed_page_stops_the_scan_instead_of_hammering(monkeypatch):
    log = []

    def api(method, path, params=None, **kw):
        log.append(params['page'])
        if params['page'] == 3:
            return None, 'HTTP 504'
        return {'tickets': [{'id': 'x'}], 'pagination': {'total': 5000}}, None

    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa, 'TICKET_SCAN_MAX_PAGES', 10)
    fa._scan_cache.clear()
    _t, _total, capped, _e = fa._fetch_all_matching_tickets({'status': 'open'})
    assert capped is True and log == [1, 2, 3]    # stopped at the first failure


def test_same_scan_is_reused_then_refreshed_after_a_write(monkeypatch):
    log = []
    monkeypatch.setattr(fa, '_api', _fake_tickets_api(150, log))
    fa._scan_cache.clear()
    fa._fetch_all_matching_tickets({'status': 'open'})
    first = len(log)
    fa._fetch_all_matching_tickets({'status': 'open'})      # served from the 90s cache
    assert len(log) == first
    with fa._scan_cache_lock:                                # what PATCH/reply do after a change
        fa._scan_cache.clear()
    fa._fetch_all_matching_tickets({'status': 'open'})
    assert len(log) == first * 2
