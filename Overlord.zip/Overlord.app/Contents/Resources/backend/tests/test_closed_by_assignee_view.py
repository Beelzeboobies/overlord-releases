"""
Closed view + date filter + a chosen assignee = "what did this agent close in this window" (12 Nov 2026).
Closing assigns the ticket to the closer, so the assignee is the closer; the window is the ticket's last update.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _t(n, updated, status='closed', created='2026-10-01T10:00:00Z'):
    return {'id': f'U{n}', 'ticket_number': n, 'status': status, 'created_at': created,
            'updated_at': updated, 'assignee_id': 'nguyen', 'assignee_username': 'Nguyen'}


def _scan(by_status):
    calls = []

    def fake(upstream_params):
        calls.append(dict(upstream_params))
        return list(by_status.get(upstream_params.get('status'), [])), 0, False, None
    fake.calls = calls
    return fake


def _get(fclient, scan, **q):
    qs = {'status': 'closed', 'assignee': 'nguyen', 'date_from': '2026-11-01', 'order': 'desc', **q}
    with patch.object(fa, '_fetch_all_matching_tickets', scan), patch.object(fa, '_index_listed_tickets'):
        return fclient.get('/api/fadmin/tickets', query_string=qs)


def test_only_tickets_updated_inside_the_window_are_listed_newest_first(fclient):
    scan = _scan({'closed': [_t(1, '2026-11-12T17:50:00Z'), _t(2, '2026-10-20T09:00:00Z'), _t(3, '2026-11-05T08:00:00Z')],
                  'resolved': [_t(4, '2026-11-09T12:00:00Z', status='resolved')]})
    d = _get(fclient, scan).get_json()
    assert [t['ticket_number'] for t in d['tickets']] == [1, 4, 3]
    assert d['pagination']['total'] == 3


def test_a_ticket_created_before_the_window_but_closed_inside_it_still_counts(fclient):
    scan = _scan({'closed': [_t(7, '2026-11-12T10:00:00Z', created='2026-08-01T00:00:00Z')]})
    assert _get(fclient, scan).get_json()['pagination']['total'] == 1


def test_freecords_is_asked_by_assignee_and_not_by_creation_date(fclient):
    scan = _scan({})
    _get(fclient, scan)
    assert {c['status'] for c in scan.calls} == {'closed', 'resolved'}
    for c in scan.calls:
        assert c['assignee'] == 'nguyen' and 'date_from' not in c and 'page' not in c and 'limit' not in c


def test_oldest_first_and_paging(fclient):
    scan = _scan({'closed': [_t(n, f'2026-11-0{n}T10:00:00Z') for n in range(1, 6)]})
    d = _get(fclient, scan, order='asc', limit='2', page='2').get_json()
    assert [t['ticket_number'] for t in d['tickets']] == [3, 4] and d['pagination']['total'] == 5


def test_other_filters_such_as_priority_are_passed_on(fclient):
    scan = _scan({})
    _get(fclient, scan, priority='high')
    assert all(c.get('priority') == 'high' for c in scan.calls)


def test_a_failed_fetch_is_reported_not_shown_as_zero_tickets(fclient):
    def failing(upstream_params):
        return [], 0, True, 'Session expired'
    with patch.object(fa, '_fetch_all_matching_tickets', failing):
        r = fclient.get('/api/fadmin/tickets', query_string={'status': 'closed', 'assignee': 'n', 'date_from': '2026-11-01'})
    assert r.status_code == 503 and 'expired' in r.get_json()['error'].lower()


def test_without_an_assignee_the_old_closed_since_view_is_used(fclient):
    with patch.object(fa, '_fadmin_tickets_closed_since', return_value=('old-path', 200)) as old, \
         patch.object(fa, '_fadmin_tickets_closed_by_assignee') as new:
        fclient.get('/api/fadmin/tickets', query_string={'status': 'closed', 'date_from': '2026-11-01'})
    assert old.called and not new.called
