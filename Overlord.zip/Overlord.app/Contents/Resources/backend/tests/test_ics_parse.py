"""Google Calendar feeds: repeating events must show on every date, not only the first (9 Nov 2026)."""
import sqlite3
from datetime import datetime, timezone

from icalendar import Calendar

import ics_parse

NOW = datetime(2026, 11, 9, 12, 0, tzinfo=timezone.utc)


def _cal(*events):
    body = ''.join(f'BEGIN:VEVENT\r\n{e.strip()}\r\nEND:VEVENT\r\n' for e in events)
    return Calendar.from_ical(f'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//t//\r\n{body}END:VCALENDAR\r\n'.encode())


def _starts(items, uid_prefix=None):
    return sorted(i['start_iso'] for i in items if uid_prefix is None or i['uid'].startswith(uid_prefix))


def test_a_single_event_is_kept_as_it_was():
    items = ics_parse.ics_events(_cal('UID:one\r\nSUMMARY:Call\r\nDTSTART:20261109T150000Z\r\nDTEND:20261109T160000Z'), NOW)
    assert [(i['uid'], i['title'], i['start_iso'], i['end_iso'], i['all_day']) for i in items] == [
        ('one', 'Call', '2026-11-09T15:00:00Z', '2026-11-09T16:00:00Z', False)]


def test_a_weekly_meeting_shows_today_and_every_other_week_date():
    items = ics_parse.ics_events(_cal(
        'UID:dev\r\nSUMMARY:Dev meeting\r\nDTSTART:20260907T100000Z\r\nDTEND:20260907T110000Z\r\nRRULE:FREQ=WEEKLY;BYDAY=MO,WE'), NOW)
    starts = _starts(items)
    assert '2026-11-09T10:00:00Z' in starts                 # today (a Monday)
    assert '2026-11-11T10:00:00Z' in starts                 # Wednesday
    assert '2026-11-10T10:00:00Z' not in starts             # Tuesday is not in the rule
    assert all(i['end_iso'][11:] == '11:00:00Z' for i in items)   # duration kept


def test_the_first_occurrence_keeps_the_feed_uid_so_old_rows_are_updated_not_doubled():
    items = ics_parse.ics_events(_cal(
        'UID:dev\r\nSUMMARY:Dev\r\nDTSTART:20261105T100000Z\r\nDTEND:20261105T110000Z\r\nRRULE:FREQ=DAILY;COUNT=3'), NOW)
    uids = {i['start_iso']: i['uid'] for i in items}
    assert uids['2026-11-05T10:00:00Z'] == 'dev'
    assert uids['2026-11-06T10:00:00Z'] == 'dev#2026-11-06T10:00:00Z'


def test_count_and_interval_are_respected():
    items = ics_parse.ics_events(_cal(
        'UID:x\r\nSUMMARY:X\r\nDTSTART:20261101T090000Z\r\nDTEND:20261101T093000Z\r\nRRULE:FREQ=DAILY;INTERVAL=3;COUNT=4'), NOW)
    assert _starts(items) == ['2026-11-01T09:00:00Z', '2026-11-04T09:00:00Z', '2026-11-07T09:00:00Z', '2026-11-10T09:00:00Z']


def test_a_deleted_occurrence_is_left_out():
    items = ics_parse.ics_events(_cal(
        'UID:x\r\nSUMMARY:X\r\nDTSTART:20261106T090000Z\r\nDTEND:20261106T100000Z\r\nRRULE:FREQ=DAILY;COUNT=4\r\n'
        'EXDATE:20261108T090000Z'), NOW)
    assert _starts(items) == ['2026-11-06T09:00:00Z', '2026-11-07T09:00:00Z', '2026-11-09T09:00:00Z']


def test_a_moved_occurrence_shows_at_its_new_time_and_a_cancelled_one_not_at_all():
    items = ics_parse.ics_events(_cal(
        'UID:x\r\nSUMMARY:X\r\nDTSTART:20261106T090000Z\r\nDTEND:20261106T100000Z\r\nRRULE:FREQ=DAILY;COUNT=4',
        'UID:x\r\nRECURRENCE-ID:20261108T090000Z\r\nSUMMARY:X (moved)\r\nDTSTART:20261108T140000Z\r\nDTEND:20261108T150000Z',
        'UID:x\r\nRECURRENCE-ID:20261109T090000Z\r\nSTATUS:CANCELLED\r\nSUMMARY:X\r\nDTSTART:20261109T090000Z\r\nDTEND:20261109T100000Z'), NOW)
    assert _starts(items) == ['2026-11-06T09:00:00Z', '2026-11-07T09:00:00Z', '2026-11-08T14:00:00Z']
    assert any(i['title'] == 'X (moved)' for i in items)


def test_local_time_events_follow_daylight_saving():
    items = ics_parse.ics_events(_cal(
        'UID:l\r\nSUMMARY:L\r\nDTSTART;TZID=Europe/London:20261012T100000\r\nDTEND;TZID=Europe/London:20261012T110000\r\n'
        'RRULE:FREQ=WEEKLY;BYDAY=MO'), NOW)
    starts = _starts(items)
    assert '2026-10-19T09:00:00Z' in starts       # still summer time: 10:00 BST = 09:00 UTC
    assert '2026-11-02T10:00:00Z' in starts       # winter time: 10:00 GMT = 10:00 UTC


def test_all_day_repeats_and_an_until_in_utc_form():
    items = ics_parse.ics_events(_cal(
        'UID:a\r\nSUMMARY:Holiday\r\nDTSTART;VALUE=DATE:20261102\r\nDTEND;VALUE=DATE:20261103\r\n'
        'RRULE:FREQ=WEEKLY;UNTIL=20261116T000000Z'), NOW)
    assert all(i['all_day'] for i in items)
    assert _starts(items) == ['2026-11-02T00:00:00Z', '2026-11-09T00:00:00Z', '2026-11-16T00:00:00Z']


def test_a_cancelled_event_is_not_imported():
    assert ics_parse.ics_events(_cal('UID:c\r\nSTATUS:CANCELLED\r\nSUMMARY:C\r\nDTSTART:20261109T150000Z\r\nDTEND:20261109T160000Z'), NOW) == []


def test_the_meet_link_in_the_google_conference_field_is_passed_on():
    items = ics_parse.ics_events(_cal(
        'UID:m\r\nSUMMARY:M\r\nDTSTART:20261109T150000Z\r\nDTEND:20261109T160000Z\r\nX-GOOGLE-CONFERENCE:https://meet.google.com/abc-defg-hij'), NOW)
    assert 'meet.google.com/abc-defg-hij' in items[0]['url']


def test_syncing_twice_updates_instead_of_duplicating():
    conn = sqlite3.connect(':memory:')
    conn.row_factory = sqlite3.Row
    conn.execute('CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, start_dt TEXT, end_dt TEXT, all_day INTEGER, '
                 'location TEXT, description TEXT, meet_url TEXT, ical_uid TEXT, reminder_minutes TEXT, notified INTEGER DEFAULT 0)')
    items = ics_parse.ics_events(_cal(
        'UID:dev\r\nSUMMARY:Dev\r\nDTSTART:20261105T100000Z\r\nDTEND:20261105T110000Z\r\nRRULE:FREQ=DAILY;COUNT=5'), NOW)
    assert ics_parse.upsert_ics_events(conn, items, lambda t: '') == (5, 0)
    assert ics_parse.upsert_ics_events(conn, items, lambda t: '') == (0, 5)
    assert conn.execute('SELECT COUNT(*) FROM events').fetchone()[0] == 5
