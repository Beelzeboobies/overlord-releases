"""Attachment download matched by name: encoded-word filenames (Nguyen, 26 Oct, #70702: 'could not fetch attachment: 404')."""
import email

import messages


def _mail(*names):
    parts = ''.join(
        f'--b\r\nContent-Type: image/png; name="{n}"\r\nContent-Disposition: attachment; filename="{n}"\r\n'
        'Content-Transfer-Encoding: base64\r\n\r\niVBORw0K\r\n' for n in names)
    return email.message_from_bytes(
        ('From: a@b.c\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=b\r\n\r\n'
         + parts + '--b--\r\n').encode())


def _found(msg, filename):
    return [p for p in msg.walk() if messages._part_is_named(p, filename)]


def test_encoded_word_name_matches_the_decoded_name_the_ui_holds():
    msg = _mail('=?UTF-8?B?SU1HXzIwMjYxMDE0XzE4Mzg0OF8yMzRALTE4MzI3MzA2NTguanBn?=',
                '=?UTF-8?B?0KHQvdC40LzQvtC6INGN0LrRgNCw0L3QsCAoMSkucG5n?=')
    assert len(_found(msg, 'IMG_20261014_183848_234@-1832730658.jpg')) == 1
    assert len(_found(msg, 'Снимок экрана (1).png')) == 1


def _folded_mail():
    """The attachment's filename header is folded across two lines, as in mail 12256 (Luis, 29 Oct 2026)."""
    return email.message_from_bytes(
        (b'From: a@b.c\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=b\r\n\r\n'
         b'--b\r\nContent-Type: application/octet-stream\r\n'
         b'Content-Disposition: attachment;\r\n'
         b' filename="Freecords - Spotify September\r\n Artificial Streams.xlsx"\r\n'
         b'Content-Transfer-Encoding: base64\r\n\r\niVBORw0K\r\n--b--\r\n'))


def test_folded_filename_matches_both_the_raw_folded_name_and_the_cleaned_single_line_name():
    msg = _folded_mail()
    raw = [p.get_filename() for p in msg.walk() if p.get_filename()][0]
    assert '\n' in raw  # the fixture really is folded, so this test would have caught the 404
    assert len(_found(msg, raw)) == 1
    assert len(_found(msg, 'Freecords - Spotify September Artificial Streams.xlsx')) == 1
    assert _found(msg, 'Freecords - Spotify October Artificial Streams.xlsx') == []


def test_folded_encoded_word_name_matches_the_cleaned_name():
    msg = _mail('=?UTF-8?B?U2hvdA==?=\r\n =?UTF-8?B?IG9uZS5wbmc=?=')
    assert len(_found(msg, 'Shot one.png')) == 1


def test_empty_name_matches_nothing():
    assert _found(_mail('shot.png'), '') == []


def test_plain_name_still_matches_and_a_different_name_does_not():
    msg = _mail('shot.png')
    assert len(_found(msg, 'shot.png')) == 1
    assert _found(msg, 'other.png') == []
