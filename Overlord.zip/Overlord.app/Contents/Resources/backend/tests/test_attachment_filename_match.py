"""Attachment download matched by name: encoded-word filenames (Nguyen, 26 Oct, #70702: 'could not fetch attachment: 404')."""
import email

import messages


def _mail(*names):
    parts = ''.join(
        f'--b\r\nContent-Type: image/png; name="{n}"\r\nContent-Disposition: attachment; filename="{n}"\r\n'
        'Content-Transfer-Encoding: base64\r\n\r\niVBORw0K\r\n' for n in names)
    return email.message_from_bytes(
        ('From: a@b.c\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=b\r\n\r\n'
         + parts + '--b--\r\n').encode())


def _found(msg, filename):
    return [p for p in msg.walk() if messages._part_is_named(p, filename)]


def test_encoded_word_name_matches_the_decoded_name_the_ui_holds():
    msg = _mail('=?UTF-8?B?SU1HXzIwMjYxMDE0XzE4Mzg0OF8yMzRALTE4MzI3MzA2NTguanBn?=',
                '=?UTF-8?B?0KHQvdC40LzQvtC6INGN0LrRgNCw0L3QsCAoMSkucG5n?=')
    assert len(_found(msg, 'IMG_20261014_183848_234@-1832730658.jpg')) == 1
    assert len(_found(msg, 'Снимок экрана (1).png')) == 1


def test_plain_name_still_matches_and_a_different_name_does_not():
    msg = _mail('shot.png')
    assert len(_found(msg, 'shot.png')) == 1
    assert _found(msg, 'other.png') == []
