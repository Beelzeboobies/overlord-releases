"""
Tests for imap.fetch_and_cache — the batch-failure reset+retry path.

Before fetch_and_cache moved into imap.py, _tl_attr and _thread_local were
undefined at the reset site (lines 338-345), making it a live NameError whenever
a mini-batch chunk failed. Co-locating the function in imap.py resolved both
names. This test asserts that the reset sub-path actually runs and produces
correct, complete output.

Run with:
    cd backend
    <app-python> -m pytest tests/test_fetch_and_cache.py -v
where <app-python> is the bundled Python that has imapclient, flask, etc.
"""

import threading
from unittest.mock import MagicMock, patch

import pytest

# All module-level stubs (keyring, config, db, parsing) are installed by
# tests/conftest.py, which pytest loads before this module.  imap.get_db is
# bound to _shared_mem at conftest import time and never re-bound, so
# fetch_and_cache always writes there.
from test_support import _mem as _shared_mem

import imap


# ── Helpers ───────────────────────────────────────────────────────────────────

TEST_ACCT = 'test@example.com'


def _make_msg_data(subject='Test subject'):
    env = MagicMock()
    env.subject = subject.encode()
    env.date    = b'Mon, 1 Jan 2024 00:00:00 +0000'
    env.from_   = None
    env.cc      = None
    env.to      = None
    return {b'ENVELOPE': env, b'FLAGS': (b'\\Seen',), b'BODYSTRUCTURE': None}


def _register_client(client_obj):
    """Plant client_obj in the thread-local slot for TEST_ACCT."""
    setattr(imap._thread_local, imap._tl_attr(TEST_ACCT), client_obj)


def _slot_value():
    """Read the thread-local slot for TEST_ACCT (returns sentinel if absent)."""
    return getattr(imap._thread_local, imap._tl_attr(TEST_ACCT), 'ABSENT')


def _clear_db():
    # conftest._clean (autouse) already clears _shared_mem before each test;
    # this call is kept so the class can be run in isolation without conftest.
    _shared_mem.execute("DELETE FROM message_cache")
    _shared_mem.commit()


# ── Tests ──────────────────────────────────────────────────────────────────────

class TestFetchAndCacheResetPath:

    def setup_method(self):
        _clear_db()

    # ── Main target: the reset+retry sub-path ─────────────────────────────────

    def test_reset_path_runs_and_messages_complete(self):
        """
        6 UIDs, MINI=5 → two chunks: [1-5] and [6].

        Call sequence:
          0  outer batch          → raises   (enters mini-batch loop)
          1  chunk [1-5]          → raises   (enters reset+retry loop)
          2  UID 1 per-UID retry  → succeeds
          ...
          6  UID 5 per-UID retry  → succeeds
          7  chunk [6]            → succeeds (second chunk, no failure)

        The reset sub-path (imap.py lines 338-345) clears the thread-local slot
        to None before the per-UID loop. Detection: plant mock_client in the slot
        before the call; assert it's None afterward. The per-UID loop calls
        client.fetch directly and never calls imap_connect, so nothing
        repopulates the slot.
        """
        uids = [1, 2, 3, 4, 5, 6]
        uid_data = {uid: _make_msg_data(f'Subject {uid}') for uid in uids}
        call_n = {'n': 0}

        def fake_fetch(uid_list, data_items):
            n = call_n['n']
            call_n['n'] += 1
            if n == 0:
                raise Exception("Stale connection — outer batch")
            if n == 1:
                raise Exception("Stale chunk — triggers reset+retry")
            return {uid: uid_data[uid] for uid in uid_list}

        mock_client = MagicMock()
        mock_client.fetch = fake_fetch

        _register_client(mock_client)
        assert _slot_value() is mock_client, "Pre-condition: slot must hold mock_client"

        with patch.object(imap, 'get_all_accounts', return_value=[TEST_ACCT]):
            results = imap.fetch_and_cache(mock_client, 'INBOX', uids, TEST_ACCT)

        # ── Assert 1: reset sub-path ran ─────────────────────────────────────
        # Slot must be None: setattr(_thread_local, attr, None) was called.
        # Nothing repopulates it during per-UID retry, so it stays None.
        assert _slot_value() is None, (
            f"Thread-local slot is {_slot_value()!r} — expected None.\n"
            "The reset sub-path did not run, meaning _tl_attr or _thread_local "
            "did not resolve (the NameError that existed before imap.py move)."
        )

        # ── Assert 2: all 6 UIDs returned ────────────────────────────────────
        assert len(results) == 6, \
            f"Expected 6, got {len(results)}: {[r['uid'] for r in results]}"
        assert {int(r['uid']) for r in results} == set(uids)

        # ── Assert 3: content correct through the retry ───────────────────────
        uid_to_subj = {int(r['uid']): r['subject'] for r in results}
        for uid in uids:
            assert uid_to_subj[uid] == f'Subject {uid}', \
                f"UID {uid}: expected 'Subject {uid}', got {uid_to_subj[uid]!r}"

        # ── Assert 4: all 6 rows written to DB ───────────────────────────────
        # imap.get_db was captured from test_support._mem (via conftest) at
        # import time, so fetch_and_cache always writes there regardless of the
        # local _test_db_conn redirect in this file.
        rows = _shared_mem.execute(
            "SELECT uid FROM message_cache WHERE account=? AND folder=?",
            (TEST_ACCT, 'INBOX')
        ).fetchall()
        assert len(rows) == 6, f"DB has {len(rows)} rows, expected 6"
        assert {int(r['uid']) for r in rows} == set(uids)

    # ── Supporting tests ──────────────────────────────────────────────────────

    def test_happy_path_no_failure(self):
        """
        Outer batch succeeds — no reset, no retry, single fetch call.
        Baseline to confirm the retry machinery is transparent on the normal path.

        Negative control for test_reset_path_runs_and_messages_complete:
        when there is NO failure the thread-local slot must still hold the
        original client (i.e. the reset sub-path did NOT run).
        """
        uids = [10, 20, 30]
        mock_client = MagicMock()
        mock_client.fetch.return_value = {uid: _make_msg_data(f'Happy {uid}') for uid in uids}

        # Plant client in slot BEFORE the call
        _register_client(mock_client)
        assert _slot_value() is mock_client, "Pre-condition: slot must hold mock_client"

        results = imap.fetch_and_cache(mock_client, 'INBOX', uids, TEST_ACCT)

        assert len(results) == 3
        assert {int(r['uid']) for r in results} == set(uids)
        assert mock_client.fetch.call_count == 1  # no retry

        # Negative control: slot must still hold the original client (reset did NOT run)
        assert _slot_value() is mock_client, (
            "Thread-local slot was cleared on the happy path — "
            "the reset sub-path ran when it should not have."
        )

    def test_single_uid_failure_skips_not_retries(self):
        """
        Single-UID batch that fails is returned as [] immediately (line 325-327).
        The reset+retry path is NOT entered for a single-UID call.
        """
        mock_client = MagicMock()
        mock_client.fetch.side_effect = Exception("single UID error")

        results = imap.fetch_and_cache(mock_client, 'INBOX', [42], TEST_ACCT)

        assert results == []
        rows = _shared_mem.execute(
            "SELECT uid FROM message_cache WHERE account=? AND folder=?",
            (TEST_ACCT, 'INBOX')
        ).fetchall()
        assert len(rows) == 0

    def test_permanently_broken_uid_skipped_rest_returned(self):
        """
        One UID fails at every per-UID retry level; the rest are returned.
        Verifies the skip-and-continue behaviour at lines 348-352.
        """
        uids = [1, 2, 3, 4, 5, 6]
        uid_data = {uid: _make_msg_data(f'Msg {uid}') for uid in uids}
        bad_uid = 3
        call_n = {'n': 0}

        def fake_fetch(uid_list, data_items):
            n = call_n['n']
            call_n['n'] += 1
            if n == 0:
                raise Exception("Outer batch fails")
            if n == 1:
                raise Exception("First chunk fails")
            if uid_list == [bad_uid]:
                raise Exception(f"UID {bad_uid} permanently broken")
            return {uid: uid_data[uid] for uid in uid_list if uid in uid_data}

        mock_client = MagicMock()
        mock_client.fetch = fake_fetch
        _register_client(mock_client)

        with patch.object(imap, 'get_all_accounts', return_value=[TEST_ACCT]):
            results = imap.fetch_and_cache(mock_client, 'INBOX', uids, TEST_ACCT)

        returned_uids = {int(r['uid']) for r in results}
        assert bad_uid not in returned_uids, f"UID {bad_uid} should have been skipped"
        assert len(results) == 5
        assert returned_uids == {1, 2, 4, 5, 6}
