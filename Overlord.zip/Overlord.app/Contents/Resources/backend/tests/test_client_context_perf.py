"""
GET /api/fadmin/tickets/client-context — correctness after parallelizing
the up-to-10 full-thread fetches (2026-09-08, "slow loading issues
again"): fetches now run concurrently, but the assembled text must still
list tickets in their original order (newest-created first, per the
native_ticket_index query) regardless of which fetch happens to finish
first.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.commit()


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _index(num, native_id, subject, created_at):
    _mem.execute(
        "INSERT INTO native_ticket_index (ticket_number, native_id, subject, created_at, status, requester_email) "
        "VALUES (?,?,?,?,?,?)",
        (num, native_id, subject, created_at, 'open', 'a@b.com'),
    )
    _mem.commit()


def test_CC1_order_preserved_regardless_of_fetch_completion_order(fclient):
    _index(1, 'U1', 'first', '2026-09-08T12:00:00')   # newest -> listed first
    _index(2, 'U2', 'second', '2026-09-08T10:00:00')
    _index(3, 'U3', 'third', '2026-09-08T08:00:00')

    def stub(method, path, **kw):
        native_id = path.rsplit('/', 1)[-1]
        # Deliberately return in a DIFFERENT order than requested to prove
        # assembly order comes from `tickets`, not fetch-completion order.
        body = {'U3': 'body three', 'U1': 'body one', 'U2': 'body two'}[native_id]
        return {'ticket': {'description': body}, 'messages': []}, None

    with patch.object(fa, '_api', side_effect=stub):
        r = fclient.get('/api/fadmin/tickets/client-context?email=a@b.com')
    text = r.get_json()['context']
    i1, i2, i3 = text.index('Ticket #1'), text.index('Ticket #2'), text.index('Ticket #3')
    assert i1 < i2 < i3
    assert text.index('body one') < text.index('body two') < text.index('body three')


def test_CC2_budget_caps_at_ten_fetches(fclient):
    for n in range(1, 13):
        _index(n, f'U{n}', f'ticket {n}', f'2026-09-08T{12 - n:02d}:00:00')
    calls = []
    def stub(method, path, **kw):
        calls.append(path)
        return {'ticket': {'description': 'x'}, 'messages': []}, None
    with patch.object(fa, '_api', side_effect=stub):
        fclient.get('/api/fadmin/tickets/client-context?email=a@b.com')
    assert len(calls) == 10


def test_CC3_no_email_returns_empty_without_calling_api(fclient):
    with patch.object(fa, '_api') as api:
        r = fclient.get('/api/fadmin/tickets/client-context')
    api.assert_not_called()
    assert r.get_json()['context'] == ''


def test_CC4_failed_fetch_still_shows_ticket_header_without_content(fclient):
    _index(5, 'U5', 'flaky', '2026-09-08T09:00:00')
    with patch.object(fa, '_api', return_value=(None, 'boom')):
        r = fclient.get('/api/fadmin/tickets/client-context?email=a@b.com')
    text = r.get_json()['context']
    assert 'Ticket #5' in text
    assert 'flaky' in text
