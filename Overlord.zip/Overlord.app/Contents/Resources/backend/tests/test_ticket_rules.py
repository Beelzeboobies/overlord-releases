"""
Ticket rules — same one-condition/one-action, first-match-wins shape as
backend/rules_engine.py's email rules, applied to native tickets at
creation time. See backend/ticket_rules_engine.py's own docstring for why
creation-time only (a later re-check could clobber an agent's manual edit).
"""
from unittest.mock import patch

import pytest

import ticket_rules_engine as tre
from test_support import _mem


@pytest.fixture(autouse=True)
def _table():
    _mem.execute("DELETE FROM ticket_rules")
    _mem.commit()


def _add_rule(**kw):
    defaults = dict(name='', condition_field='subject', condition_op='contains',
                     condition_value='', action='add_tag', action_value='', active=1)
    defaults.update(kw)
    _mem.execute(
        '''INSERT INTO ticket_rules (name,condition_field,condition_op,condition_value,action,action_value,active)
           VALUES (?,?,?,?,?,?,?)''',
        (defaults['name'], defaults['condition_field'], defaults['condition_op'], defaults['condition_value'],
         defaults['action'], defaults['action_value'], defaults['active']),
    )
    _mem.commit()


def test_T1_subject_match_applies_add_tag():
    _add_rule(condition_field='subject', condition_op='contains', condition_value='takedown',
              action='add_tag', action_value='Takedown')
    with patch.object(tre, '_api') as api:
        api.return_value = ({}, None)
        tre.apply_ticket_rules('T1', 'Takedown Request — "GEE"', 'a@b.com')
    api.assert_called_once_with('PATCH', '/api/admin/tickets/T1', json={'tags': ['Takedown']})


def test_T2_requester_email_match_applies_set_priority():
    _add_rule(condition_field='requester_email', condition_op='equals', condition_value='vip@label.com',
              action='set_priority', action_value='urgent')
    with patch.object(tre, '_api') as api:
        api.return_value = ({}, None)
        tre.apply_ticket_rules('T2', 'anything', 'VIP@Label.com')  # case-insensitive match
    api.assert_called_once_with('PATCH', '/api/admin/tickets/T2', json={'priority': 'urgent'})


def test_T3_no_match_does_not_call_api():
    _add_rule(condition_field='subject', condition_op='contains', condition_value='takedown',
              action='add_tag', action_value='Takedown')
    with patch.object(tre, '_api') as api:
        tre.apply_ticket_rules('T3', 'unrelated subject', 'a@b.com')
    api.assert_not_called()


def test_T4_inactive_rule_ignored():
    _add_rule(condition_field='subject', condition_op='contains', condition_value='takedown',
              action='add_tag', action_value='Takedown', active=0)
    with patch.object(tre, '_api') as api:
        tre.apply_ticket_rules('T4', 'Takedown Request', 'a@b.com')
    api.assert_not_called()


def test_T5_first_match_wins():
    _add_rule(condition_field='subject', condition_op='contains', condition_value='urgent',
              action='set_priority', action_value='urgent')
    _add_rule(condition_field='subject', condition_op='contains', condition_value='request',
              action='add_tag', action_value='General')
    with patch.object(tre, '_api') as api:
        api.return_value = ({}, None)
        tre.apply_ticket_rules('T5', 'Urgent request', 'a@b.com')
    api.assert_called_once_with('PATCH', '/api/admin/tickets/T5', json={'priority': 'urgent'})


def test_T6_invalid_action_value_is_rejected_not_forwarded_raw():
    """set_priority/set_status validate against a fixed enum — a typo'd
    action_value shouldn't get forwarded to the remote API as garbage."""
    _add_rule(condition_field='subject', condition_op='contains', condition_value='x',
              action='set_priority', action_value='super-urgent!!')
    with patch.object(tre, '_api') as api:
        tre.apply_ticket_rules('T6', 'x', 'a@b.com')
    api.assert_not_called()


def test_T7_engine_error_does_not_raise():
    """A rule failing to apply must not be allowed to break ticket creation
    itself — same tolerance as rules_engine.py's per-action try/except."""
    _add_rule(condition_field='subject', condition_op='contains', condition_value='x',
              action='add_tag', action_value='Tag')
    with patch.object(tre, '_api', side_effect=RuntimeError('boom')):
        tre.apply_ticket_rules('T7', 'x', 'a@b.com')  # must not raise
