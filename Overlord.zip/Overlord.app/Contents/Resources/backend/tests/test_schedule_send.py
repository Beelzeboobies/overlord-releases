"""
SC1–SC4  Scheduled-send CRUD characterization tests.

Routes under test:
    POST   /api/schedule-send          (SC1)
    GET    /api/schedule-send          (SC2)
    DELETE /api/schedule-send/<id>     (SC3, SC4)

SC4 caveat (characterization): cancel_scheduled always returns ok=True even
for a nonexistent or already-sent ID because the route does not check whether
any row was actually deleted.  This test pins that CURRENT behaviour; it is
not an endorsement of that behaviour.
"""
import json
from test_support import TEST_ACCT, _mem


def _insert_scheduled(account=TEST_ACCT, send_at='2099-01-01T12:00:00Z',
                       status='pending', subject='Scheduled subject'):
    payload = json.dumps({'account': account, 'subject': subject,
                           'to': 'bob@example.com', 'body': 'Hi'})
    cur = _mem.execute(
        "INSERT INTO scheduled_sends (account, send_at_utc, payload, status) VALUES (?,?,?,?)",
        (account, send_at, payload, status)
    )
    _mem.commit()
    return cur.lastrowid


class TestScheduleSend:

    def test_SC1_create_scheduled_send(self, client, logged_in):
        """SC1 — POST /api/schedule-send stores the item and returns ok=True."""
        r = client.post('/api/schedule-send', json={
            'account': TEST_ACCT,
            'to': 'bob@example.com',
            'subject': 'Future email',
            'body': 'Hello from the future',
            'send_at_utc': '2099-06-01T09:00:00Z',
        })
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

        rows = _mem.execute(
            "SELECT * FROM scheduled_sends WHERE account=?", (TEST_ACCT,)
        ).fetchall()
        assert len(rows) == 1
        assert rows[0]['status'] == 'pending'

    def test_SC2_list_scheduled_includes_stored_item(self, client, logged_in):
        """SC2 — GET /api/schedule-send returns all stored items with expected keys."""
        _insert_scheduled(subject='My future email')

        r = client.get('/api/schedule-send')
        assert r.status_code == 200
        items = r.get_json()
        assert len(items) == 1
        item = items[0]
        for key in ('id', 'account', 'send_at_utc', 'status', 'subject'):
            assert key in item, f"Missing key: {key}"
        assert item['subject'] == 'My future email'
        assert item['status'] == 'pending'

    def test_SC3_cancel_pending_removes_row(self, client, logged_in):
        """SC3 — DELETE /api/schedule-send/<id> for pending item → ok=True, row gone."""
        sid = _insert_scheduled()

        r = client.delete(f'/api/schedule-send/{sid}')
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

        row = _mem.execute(
            "SELECT * FROM scheduled_sends WHERE id=?", (sid,)
        ).fetchone()
        assert row is None

    def test_SC4_cancel_nonexistent_returns_ok(self, client, logged_in):
        """SC4 (characterization) — cancelling a nonexistent ID returns ok=True.

        The route does DELETE WHERE id=? AND status='pending' without checking
        affected rows count.  Always-ok is the current behaviour; this test
        pins it so any future change to return 404 is visible.
        """
        r = client.delete('/api/schedule-send/99999')
        assert r.status_code == 200
        assert r.get_json()['ok'] is True
