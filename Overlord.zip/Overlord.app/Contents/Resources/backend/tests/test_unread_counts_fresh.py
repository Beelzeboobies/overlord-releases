"""
Sidebar/tab unread counts must be current, not one poll behind (17 Nov 2026: Inbox badge said 1 with nothing unread,
mail had been read on another computer), and bulk mark-unread must raise the counter, not lower it.
"""
import threading
import time

import pytest

import imap
from test_support import TEST_ACCT, seed_message


@pytest.fixture(autouse=True)
def _fresh_state():
    imap._counts_checked_at.clear()
    imap._counts_inflight.clear()
    yield
    imap._counts_checked_at.clear()
    imap._counts_inflight.clear()


def _fake_refresh(calls, unread_after, delay=0.0):
    def fake(account):
        calls.append(account)
        time.sleep(delay)
        with imap._unread_cache_lock:
            imap._folder_cache[account or 'default'] = [{'name': 'INBOX', 'flags': [], 'unread': unread_after, 'total': 9}]
    return fake


def _seed_cache(unread):
    with imap._unread_cache_lock:
        imap._folder_cache[TEST_ACCT] = [{'name': 'INBOX', 'flags': [], 'unread': unread, 'total': 9}]


def test_folders_answers_with_counts_from_a_refresh_it_waited_for(client, logged_in, monkeypatch):
    calls = []
    monkeypatch.setattr(imap, '_refresh_unread_counts', _fake_refresh(calls, unread_after=0))
    _seed_cache(unread=1)           # what the app showed: 1
    r = client.get(f'/api/folders?account={TEST_ACCT}')
    assert calls == [TEST_ACCT]
    assert r.get_json()[0]['unread'] == 0      # the answer already has the refreshed count


def test_counts_younger_than_the_limit_are_served_without_another_refresh(client, logged_in, monkeypatch):
    calls = []
    monkeypatch.setattr(imap, '_refresh_unread_counts', _fake_refresh(calls, unread_after=0))
    _seed_cache(unread=1)
    client.get(f'/api/folders?account={TEST_ACCT}')
    client.get(f'/api/folders?account={TEST_ACCT}')
    client.get(f'/api/folders?account={TEST_ACCT}')
    assert len(calls) == 1


def test_old_counts_are_refreshed_again(client, logged_in, monkeypatch):
    calls = []
    monkeypatch.setattr(imap, '_refresh_unread_counts', _fake_refresh(calls, unread_after=0))
    _seed_cache(unread=1)
    client.get(f'/api/folders?account={TEST_ACCT}')
    imap._counts_checked_at[TEST_ACCT] -= 60
    client.get(f'/api/folders?account={TEST_ACCT}')
    assert len(calls) == 2


def test_callers_arriving_during_a_refresh_share_it(monkeypatch):
    calls = []
    monkeypatch.setattr(imap, '_refresh_unread_counts', _fake_refresh(calls, 0, delay=0.3))
    ts = [threading.Thread(target=imap.refresh_unread_counts_if_stale, args=(TEST_ACCT,)) for _ in range(5)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    assert len(calls) == 1


def test_a_slow_refresh_does_not_hold_the_answer_past_the_wait(client, logged_in, monkeypatch):
    calls = []
    monkeypatch.setattr(imap, '_refresh_unread_counts', _fake_refresh(calls, 0, delay=1.0))
    _seed_cache(unread=1)
    t0 = time.time()
    imap.refresh_unread_counts_if_stale(TEST_ACCT, wait=0.1)
    assert time.time() - t0 < 0.6
    time.sleep(1.2)                  # let the refresh finish so it does not leak into the next test


def test_a_failing_refresh_still_answers_with_the_cached_counts(client, logged_in, monkeypatch):
    def boom(account):
        raise RuntimeError('imap down')
    monkeypatch.setattr(imap, '_refresh_unread_counts', boom)
    _seed_cache(unread=3)
    r = client.get(f'/api/folders?account={TEST_ACCT}')
    assert r.status_code == 200 and r.get_json()[0]['unread'] == 3
    assert not imap._counts_inflight          # a failed refresh does not wedge later ones


def test_first_ever_call_does_not_wait_for_the_refresh(client, logged_in, monkeypatch):
    calls = []
    monkeypatch.setattr(imap, '_refresh_unread_counts', _fake_refresh(calls, 0, delay=0.5))
    logged_in.list_folders.return_value = [((), b'.', 'INBOX')]
    t0 = time.time()
    r = client.get(f'/api/folders?account={TEST_ACCT}')
    assert time.time() - t0 < 0.4 and r.status_code == 200
    time.sleep(0.7)


# ── bulk mark read / unread moves the counter the right way ───────────────────

def _bulk(client, unread):
    return client.post('/api/messages/mark-read', json={'uids': [1, 2], 'folder': 'INBOX', 'account': TEST_ACCT, 'unread': unread})


def test_bulk_mark_unread_raises_the_counter(client, logged_in):
    seed_message(uid=1, read=1, folder='INBOX', account=TEST_ACCT)
    seed_message(uid=2, read=1, folder='INBOX', account=TEST_ACCT)
    with imap._unread_cache_lock:
        imap._unread_cache[TEST_ACCT] = {'INBOX': 5}
        imap._folder_cache[TEST_ACCT] = [{'name': 'INBOX', 'flags': [], 'unread': 5, 'total': 9}]
    assert _bulk(client, unread=True).status_code == 200
    assert imap._unread_cache[TEST_ACCT]['INBOX'] == 7
    assert imap._folder_cache[TEST_ACCT][0]['unread'] == 7


def test_bulk_mark_read_lowers_the_counter_once_per_message(client, logged_in):
    seed_message(uid=1, read=0, folder='INBOX', account=TEST_ACCT)
    seed_message(uid=2, read=0, folder='INBOX', account=TEST_ACCT)
    with imap._unread_cache_lock:
        imap._unread_cache[TEST_ACCT] = {'INBOX': 5}
        imap._folder_cache[TEST_ACCT] = [{'name': 'INBOX', 'flags': [], 'unread': 5, 'total': 9}]
    assert _bulk(client, unread=False).status_code == 200
    assert imap._unread_cache[TEST_ACCT]['INBOX'] == 3
    assert imap._folder_cache[TEST_ACCT][0]['unread'] == 3
