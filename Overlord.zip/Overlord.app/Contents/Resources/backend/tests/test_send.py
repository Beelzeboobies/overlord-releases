"""
S1–S7  Send and draft characterization tests.

Routes under test:
    POST /api/send     (send_email)
    POST /api/drafts   (save_draft)
    GET  /api/schedule-send  (list, basic sanity)

S6–S7 pin that both IMAP APPEND sites remain wrapped in bg_append_lock so a
later refactor can't silently drop the serialisation.
"""
from unittest.mock import patch, MagicMock

import imap
import send as send_mod
import helpers as helpers_mod
from test_support import TEST_ACCT


class TestSendEmail:

    def test_S1_send_success_returns_ok(self, client, logged_in):
        """S1 — _do_send succeeds → 200, ok=True."""
        with patch.object(send_mod, '_do_send', return_value=(True, None, 200)):
            r = client.post('/api/send', json={
                'account': TEST_ACCT,
                'to': 'bob@example.com',
                'subject': 'Test',
                'body': 'Hello',
            })
        assert r.status_code == 200
        assert r.get_json()['ok'] is True

    def test_S2_send_smtp_failure_returns_error(self, client, logged_in):
        """S2 — _do_send fails → error response with 'error' key present."""
        with patch.object(send_mod, '_do_send',
                          return_value=(False, 'SMTP connection refused', 500)):
            r = client.post('/api/send', json={
                'account': TEST_ACCT,
                'to': 'bob@example.com',
                'subject': 'Bad send',
                'body': 'Hello',
            })
        assert r.status_code == 500
        data = r.get_json()
        assert 'error' in data
        # Error message contains something about the failure
        assert len(data['error']) > 0

    def test_S3_save_draft_appends_to_imap(self, client, logged_in):
        """S3 — save_draft with a bg IMAP connection → 200, ok=True, folder returned."""
        # Pre-populate draft folder cache so force_new imap_connect is skipped
        imap._draft_folder_cache[TEST_ACCT] = 'Drafts'
        # Plant the mock as the background IMAP client
        imap._bg_imap_clients[TEST_ACCT] = logged_in

        r = client.post('/api/drafts', json={
            'account': TEST_ACCT,
            'to': 'bob@example.com',
            'subject': 'Draft subject',
            'body': '<p>Draft body</p>',
        })
        assert r.status_code == 200
        data = r.get_json()
        assert data['ok'] is True
        assert 'folder' in data
        logged_in.append.assert_called_once()

    def test_S4_save_draft_no_accounts_returns_401(self, client):
        """S4 — no logged-in account → save_draft returns 401."""
        r = client.post('/api/drafts', json={
            'to': 'bob@example.com',
            'subject': 'Draft',
            'body': 'Hello',
        })
        assert r.status_code == 401

    def test_S5_list_scheduled_empty_when_no_items(self, client, logged_in):
        """S5 — no scheduled sends in DB → GET /api/schedule-send returns []."""
        r = client.get('/api/schedule-send')
        assert r.status_code == 200
        assert r.get_json() == []

    def test_S6_save_draft_acquires_append_lock(self, client, logged_in):
        """S6 — save_draft enters bg_append_lock around the IMAP APPEND call.

        Regression pin: if the 'with bg_append_lock(account):' block is ever
        removed from save_draft, this test fails immediately.
        """
        imap._draft_folder_cache[TEST_ACCT] = 'Drafts'
        imap._bg_imap_clients[TEST_ACCT] = logged_in

        lock_entered = []

        class _TrackingLock:
            def __enter__(self):
                lock_entered.append(True)
                return self
            def __exit__(self, *a):
                pass

        # send.py imports bg_append_lock via 'from imap import ... bg_append_lock'
        # so the name lives in send's module namespace.
        with patch('send.bg_append_lock', return_value=_TrackingLock()):
            r = client.post('/api/drafts', json={
                'account': TEST_ACCT,
                'to': 'bob@example.com',
                'subject': 'Lock test',
                'body': '<p>hi</p>',
            })

        assert r.status_code == 200
        assert lock_entered, 'bg_append_lock.__enter__ was never called in save_draft'

    def test_S7_do_sent_append_acquires_append_lock(self):
        """S7 — do_sent_append enters bg_append_lock around list_folders + APPEND.

        Calls helpers._do_send with SMTP mocked and threading.Thread forced to
        run its target synchronously so we can observe the lock acquisition in
        the same call stack.

        Regression pin: if the 'with bg_append_lock(acct):' block is ever
        removed from do_sent_append, this test fails immediately.
        """
        lock_entered = []

        class _TrackingLock:
            def __enter__(self):
                lock_entered.append(True)
                return self
            def __exit__(self, *a):
                pass

        mock_bg = MagicMock()
        # list_folders returns one Sent folder; append is a no-op MagicMock
        mock_bg.list_folders.return_value = [((b'\\Sent',), b'.', 'Sent')]

        def _sync_thread(target=None, daemon=None):
            """Run the thread target synchronously so the test can observe it."""
            class _T:
                def start(self):
                    target()
            return _T()

        mock_smtp = MagicMock()

        # helpers.py imports bg_append_lock via 'from imap import ... bg_append_lock'
        with patch('helpers.bg_append_lock', return_value=_TrackingLock()), \
             patch('helpers._get_bg_imap', return_value=mock_bg), \
             patch('helpers.get_all_accounts', return_value=[TEST_ACCT]), \
             patch('helpers.get_account_password', return_value='secret'), \
             patch('helpers.get_account_config',
                   return_value={'smtp_host': 'smtp.example.com', 'smtp_port': '465'}), \
             patch('helpers.smtplib.SMTP_SSL', return_value=mock_smtp), \
             patch('helpers.threading.Thread', side_effect=_sync_thread):
            ok, err, status = helpers_mod._do_send({
                'account': TEST_ACCT,
                'to': 'bob@example.com',
                'subject': 'Lock test',
                'body': 'hello',
            })

        assert ok is True, f'_do_send failed unexpectedly: {err}'
        assert lock_entered, 'bg_append_lock.__enter__ was never called in do_sent_append'
