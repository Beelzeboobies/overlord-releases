"""Mail connections must trust the bundled CA list too (4 Nov: the host's new certificate chain failed to verify)."""
import re
from pathlib import Path

import certifi
import tls


def test_the_bundled_ca_list_is_added_on_top_of_the_system_one(monkeypatch):
    loaded = []

    class Ctx:
        def load_verify_locations(self, path):
            loaded.append(path)

    monkeypatch.setattr(tls.ssl, 'create_default_context', lambda: Ctx())
    assert isinstance(tls.tls_context(), Ctx)
    assert loaded == [certifi.where()]


def test_without_the_bundle_the_connection_still_uses_the_system_trust(monkeypatch):
    class Ctx:
        def load_verify_locations(self, path):
            raise OSError('no bundle')

    monkeypatch.setattr(tls.ssl, 'create_default_context', lambda: Ctx())
    assert isinstance(tls.tls_context(), Ctx)


def test_every_mail_connection_in_the_app_uses_it():
    """A new IMAPClient(...)/SMTP_SSL(...) added without the context would silently bring the problem back."""
    missing = []
    for f in Path(tls.__file__).parent.glob('*.py'):
        if f.name == 'standalone_poller.py':   # separate script, not part of the app
            continue
        for n, line in enumerate(f.read_text(encoding='utf-8').splitlines(), 1):
            if re.search(r'\bIMAPClient\(', line) and 'ssl_context' not in line:
                missing.append(f'{f.name}:{n}')
            if re.search(r'\bSMTP_SSL\(', line) and 'context=' not in line:
                missing.append(f'{f.name}:{n}')
            if re.search(r'\.starttls\(', line) and 'context=' not in line:
                missing.append(f'{f.name}:{n}')
    assert missing == []
