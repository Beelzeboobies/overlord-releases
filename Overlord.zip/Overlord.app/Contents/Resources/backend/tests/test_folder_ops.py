"""
F1–F9  Folder management characterization tests.

Routes under test:
    GET  /api/folders         (F1)
    POST /api/folders/create  (F2, F3, F5, F7)
    POST /api/folders/delete  (F4)
    POST /api/folders/rename  (F6, F8, F9)
"""
import imap
from test_support import TEST_ACCT


class TestFolderOps:

    def test_F1_list_folders_from_cache(self, client, logged_in):
        """F1 — _folder_cache populated → GET /api/folders returns the cached list."""
        fake_folders = [
            {'name': 'INBOX', 'flags': [], 'unread': 3, 'total': 50},
            {'name': 'Sent',  'flags': ['\\Sent'], 'unread': 0, 'total': 100},
        ]
        with imap._unread_cache_lock:
            imap._folder_cache[TEST_ACCT] = fake_folders

        r = client.get(f'/api/folders?account={TEST_ACCT}')
        assert r.status_code == 200
        names = [f['name'] for f in r.get_json()]
        assert 'INBOX' in names
        assert 'Sent' in names

    def test_F2_create_folder_slash_in_name_returns_400(self, client, logged_in):
        """F2 — name='new/sub' contains slash → _validate_folder_name fails → 400.

        Note: safe_folder() in imap.py allows '/' for existing server-assigned
        paths, but _validate_folder_name in folders.py uses regex
        [a-zA-Z0-9 _\\-]{1,100} which does NOT allow it.
        The create endpoint uses _validate_folder_name, so 'new/sub' → 400.
        """
        r = client.post('/api/folders/create',
                        json={'account': TEST_ACCT, 'name': 'new/sub'})
        assert r.status_code == 400
        assert 'error' in r.get_json()

    def test_F3_create_valid_folder_calls_imap(self, client, logged_in):
        """F3 — valid name → IMAP create_folder called, 200 ok=True + name."""
        logged_in.create_folder.return_value = True
        logged_in.list_folders.return_value = []   # for _build_folder_map after create

        r = client.post('/api/folders/create',
                        json={'account': TEST_ACCT, 'name': 'Projects'})
        assert r.status_code == 200
        data = r.get_json()
        assert data['ok'] is True
        assert 'Projects' in data['name']
        logged_in.create_folder.assert_called_once_with('Projects')

    def test_F4_delete_inbox_is_blocked(self, client, logged_in):
        """F4 — INBOX is a protected folder → delete returns 400, IMAP not touched."""
        r = client.post('/api/folders/delete',
                        json={'account': TEST_ACCT, 'name': 'INBOX'})
        assert r.status_code == 400
        assert 'error' in r.get_json()
        logged_in.delete_folder.assert_not_called()

    def test_F5_create_folder_dot_in_name_returns_400(self, client, logged_in):
        """F5 — name='a.b' contains dot → _validate_folder_name fails → 400.

        '.' is the Dovecot hierarchy separator.  Allowing it in a new folder name
        would silently create an unintended subfolder (e.g. 'a.b' becomes child
        'b' under parent 'a').  _validate_folder_name blocks it; IMAP is never
        called.
        """
        r = client.post('/api/folders/create',
                        json={'account': TEST_ACCT, 'name': 'a.b'})
        assert r.status_code == 400
        assert 'error' in r.get_json()
        logged_in.create_folder.assert_not_called()

    def test_F7_create_folder_with_parent_joins_with_delimiter(self, client, logged_in):
        """F7 — create leaf 'Reports' under parent 'INBOX' → create_folder called
        with 'INBOX.Reports'.  Pins the parent+leaf path construction so a later
        delimiter refactor can't silently break subfolder creation.

        list_folders returns a real (flags, b'.', name) entry so get_delimiter
        exercises the capture path, not the '.' fallback.  imapclient returns
        the delimiter as bytes; the capture normalises to str.
        """
        logged_in.create_folder.return_value = True
        # Real imapclient returns delimiter as bytes — use b'.' to match production
        logged_in.list_folders.return_value = [
            ((b'\\HasNoChildren',), b'.', 'INBOX'),
        ]

        r = client.post('/api/folders/create',
                        json={'account': TEST_ACCT,
                              'parent': 'INBOX',
                              'name': 'Reports'})
        assert r.status_code == 200
        logged_in.create_folder.assert_called_once_with('INBOX.Reports')

    def test_F8_rename_folder_replaces_leaf_preserves_parent(self, client, logged_in):
        """F8 — rename old_name='INBOX.Archive' with new_leaf='Old' → rename_folder
        called with ('INBOX.Archive', 'INBOX.Old').  Pins the split/replace/rejoin
        so the parent path segment is preserved correctly.

        list_folders returns b'.' so get_delimiter exercises the capture path.
        """
        logged_in.rename_folder.return_value = True
        # Real imapclient returns delimiter as bytes — use b'.' to match production
        logged_in.list_folders.return_value = [
            ((b'\\HasNoChildren',), b'.', 'INBOX.Archive'),
        ]

        r = client.post('/api/folders/rename',
                        json={'account': TEST_ACCT,
                              'old_name': 'INBOX.Archive',
                              'new_name': 'Old'})
        assert r.status_code == 200
        logged_in.rename_folder.assert_called_once_with('INBOX.Archive', 'INBOX.Old')

    def test_F9_rename_folder_slash_delimiter_server(self, client, logged_in):
        """F9 — account whose IMAP server uses '/' as hierarchy separator.

        Configures list_folders to report '/' as the delimiter, then renames
        'Work/Archive' to leaf 'Old'.  Asserts rename_folder is called with
        ('Work/Archive', 'Work/Old') — proving get_delimiter is read and the
        split/join uses '/' not the hardcoded '.'.

        Fails before C2 (hardcoded '.') because split('.') on 'Work/Archive'
        gives ['Work/Archive'] (single element), making the new_name = 'Old'
        (the leaf replaces the whole path, dropping 'Work/').
        """
        # Two folders, both reporting '/' as the separator (bytes form)
        logged_in.list_folders.return_value = [
            ((b'\\HasNoChildren',), b'/', 'Work'),
            ((b'\\HasNoChildren',), b'/', 'Work/Archive'),
        ]
        logged_in.rename_folder.return_value = True

        r = client.post('/api/folders/rename',
                        json={'account': TEST_ACCT,
                              'old_name': 'Work/Archive',
                              'new_name': 'Old'})
        assert r.status_code == 200
        logged_in.rename_folder.assert_called_once_with('Work/Archive', 'Work/Old')

    def test_F6_rename_folder_dot_in_leaf_returns_400(self, client, logged_in):
        """F6 — new_name='a.b' contains dot → _validate_folder_name fails → 400.

        rename_folder_api validates the leaf before building the new full path.
        If allowed, 'INBOX.Archive' renamed to leaf 'a.b' would produce IMAP
        path 'INBOX.a.b' — three levels — treating 'a' as a new intermediate
        folder.  The validator blocks it; IMAP rename is never called.
        """
        r = client.post('/api/folders/rename',
                        json={'account': TEST_ACCT,
                              'old_name': 'INBOX.Archive',
                              'new_name': 'a.b'})
        assert r.status_code == 400
        assert 'error' in r.get_json()
        logged_in.rename_folder.assert_not_called()
