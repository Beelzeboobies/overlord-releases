"""
Tracking when a ticket was actually closed, locally, instead of asking
Freecords' API for a close/update timestamp it doesn't have.

**User, directly** (2026-09-08), after an earlier version of this fix
tried to fake it by scanning the whole closed-ticket catalog and filtering
on updated_at: "why the fuck would we need any of the things you said
[...] we are building a CRM ourselves on top of a mail inbox" — every
close action already goes through this app's own single PATCH proxy
(fadmin_ticket_patch), so record the real close moment there instead.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("DELETE FROM ticket_closed_at")
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.commit()


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _index(ticket_number, native_id):
    _mem.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (?,?)", (ticket_number, native_id))
    _mem.commit()


class TestPatchRecordsClosedAt:

    def test_P1_closing_records_a_row(self, fclient):
        _index(100, 'U100')
        with patch.object(fa, '_api', return_value=({'ticket': {}}, None)):
            r = fclient.patch('/api/fadmin/tickets/U100', json={'status': 'closed'})
        assert r.status_code == 200
        assert _mem.execute(
            "SELECT COUNT(*) FROM ticket_closed_at WHERE ticket_number=100"
        ).fetchone()[0] == 1

    def test_P2_reopening_clears_the_row(self, fclient):
        _index(101, 'U101')
        _mem.execute("INSERT INTO ticket_closed_at (ticket_number) VALUES (101)")
        _mem.commit()
        with patch.object(fa, '_api', return_value=({'ticket': {}}, None)):
            fclient.patch('/api/fadmin/tickets/U101', json={'status': 'open'})
        assert _mem.execute(
            "SELECT COUNT(*) FROM ticket_closed_at WHERE ticket_number=101"
        ).fetchone()[0] == 0

    def test_P3_non_status_patch_does_not_touch_closed_at(self, fclient):
        _index(102, 'U102')
        with patch.object(fa, '_api', return_value=({'ticket': {}}, None)):
            fclient.patch('/api/fadmin/tickets/U102', json={'priority': 'high'})
        assert _mem.execute(
            "SELECT COUNT(*) FROM ticket_closed_at WHERE ticket_number=102"
        ).fetchone()[0] == 0

    def test_P4_unindexed_ticket_with_no_resolvable_ticket_number_does_not_raise(self, fclient):
        """Nothing in native_ticket_index AND the live GET fallback also
        comes back empty — must no-op, not crash."""
        with patch.object(fa, '_api', return_value=({'ticket': {}}, None)):
            r = fclient.patch('/api/fadmin/tickets/unknown-uuid', json={'status': 'closed'})
        assert r.status_code == 200

    def test_P5_unindexed_ticket_resolves_live_and_still_records_closed_at(self, fclient):
        """Real, confirmed live bug (2026-09-08): 5 tickets closed via this
        route recorded nothing in ticket_closed_at because they weren't yet
        in native_ticket_index — exactly the tickets a 'recently closed'
        view most needs (closed soon after creation, before any prior read
        had a chance to index them). The PATCH call itself always succeeds
        (Freecords doesn't need the local index at all), so this must not
        silently give up — resolve the real ticket_number with a live GET
        instead."""
        def _api_stub(method, path, **kw):
            if method == 'PATCH':
                return {'success': True}, None
            if method == 'GET':
                return {'ticket': {'id': 'U103', 'ticket_number': 103, 'subject': 's', 'status': 'closed'}}, None
            raise AssertionError(f'unexpected call: {method} {path}')
        with patch.object(fa, '_api', side_effect=_api_stub):
            r = fclient.patch('/api/fadmin/tickets/U103', json={'status': 'closed'})
        assert r.status_code == 200
        assert _mem.execute(
            "SELECT COUNT(*) FROM ticket_closed_at WHERE ticket_number=103"
        ).fetchone()[0] == 1
        # Backfilled for next time too, not just used-and-discarded.
        assert _mem.execute(
            "SELECT COUNT(*) FROM native_ticket_index WHERE ticket_number=103 AND native_id='U103'"
        ).fetchone()[0] == 1


class TestClosedSinceView:

    def test_C1_returns_ticket_closed_in_window(self, fclient):
        _index(200, 'U200')
        _mem.execute("INSERT INTO ticket_closed_at (ticket_number, closed_at) VALUES (200, '2026-09-08T10:00:00')")
        _mem.commit()
        with patch.object(fa, '_api', return_value=({'ticket': {'id': 'U200', 'ticket_number': 200}}, None)):
            r = fclient.get('/api/fadmin/tickets?status=closed&date_from=2026-09-07&page=1&limit=30')
        d = r.get_json()
        assert d['pagination']['total'] == 1
        assert d['tickets'][0]['ticket_number'] == 200
        assert d['pagination']['capped'] is False

    def test_C2_excludes_ticket_closed_before_the_window(self, fclient):
        _index(201, 'U201')
        _mem.execute("INSERT INTO ticket_closed_at (ticket_number, closed_at) VALUES (201, '2026-08-01T00:00:00')")
        _mem.commit()
        with patch.object(fa, '_api', return_value=({'ticket': {'id': 'U201', 'ticket_number': 201}}, None)):
            r = fclient.get('/api/fadmin/tickets?status=closed&date_from=2026-09-07&page=1&limit=30')
        assert r.get_json()['pagination']['total'] == 0

    def test_C3_no_matches_short_circuits_without_calling_api(self, fclient):
        with patch.object(fa, '_api') as api:
            r = fclient.get('/api/fadmin/tickets?status=closed&date_from=2026-09-07&page=1&limit=30')
        api.assert_not_called()
        assert r.get_json() == {'tickets': [], 'pagination': {'total': 0, 'page': 1, 'limit': 30, 'capped': False}}

    def test_C4_closed_without_date_filter_uses_the_normal_path_not_this_one(self, fclient):
        """Regression guard — only status=closed WITH a date filter should
        route here; plain 'All closed tickets' must keep using the normal
        remote-paged list (which, separately, fans a bare status=closed out
        into closed+resolved — see fadmin_tickets_list's own docstring —
        so two calls, not one, is the correct normal-path shape)."""
        with patch.object(fa, '_api', return_value=({'tickets': [], 'pagination': {'total': 0}}, None)) as api:
            fclient.get('/api/fadmin/tickets?status=closed&page=1&limit=30')
        assert api.call_count == 2
        assert all(call[0][1] == '/api/admin/tickets' for call in api.call_args_list)
        assert {call[1]['params']['status'] for call in api.call_args_list} == {'closed', 'resolved'}
