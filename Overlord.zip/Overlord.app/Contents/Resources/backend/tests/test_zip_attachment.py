"""Browsing a zip attachment (Nguyen, 27 Oct, #70638: the artist's screenshots came as one .zip nobody could open)."""
import io
import zipfile

from flask import Flask

import messages


def _zip(files, utf8_flag=True):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for name, data in files.items():
            z.writestr(name, data)
    return buf.getvalue()


def _client(monkeypatch, payload):
    monkeypatch.setattr(messages, '_load_attachment', lambda *a: (payload, 'application/zip', None))
    app = Flask(__name__)
    app.register_blueprint(messages.bp)
    return app.test_client()


Q = '?folder=INBOX&account=support@freecords.com&filename=shots.zip'


def test_list_shows_real_files_with_a_working_url_and_skips_folders_and_mac_junk(monkeypatch):
    c = _client(monkeypatch, _zip({
        'Shots/a.jpg': b'AAA', 'Shots/': b'', '__MACOSX/Shots/._a.jpg': b'x', 'Shots/.DS_Store': b'x',
        'Shots/link.txt': b'https://x.test'}))
    d = c.get('/api/messages/7/attachment/zip-list' + Q).get_json()
    assert [e['path'] for e in d['entries']] == ['Shots/a.jpg', 'Shots/link.txt']
    assert d['entries'][0]['name'] == 'a.jpg' and d['entries'][0]['size'] == 3 and not d['truncated']
    assert 'entry=Shots%2Fa.jpg' in d['entries'][0]['url'] and '/api/messages/7/attachment?' in d['entries'][0]['url']


def test_entry_download_returns_that_file_only(monkeypatch):
    c = _client(monkeypatch, _zip({'Shots/a.jpg': b'AAA', 'Shots/b.jpg': b'BBBB'}))
    r = c.get('/api/messages/7/attachment' + Q + '&entry=Shots/b.jpg')
    assert r.status_code == 200 and r.data == b'BBBB' and r.headers['Content-Type'] == 'image/jpeg'
    assert 'filename="b.jpg"' in r.headers['Content-Disposition']


def test_unknown_entry_is_404_and_a_path_outside_the_archive_is_never_opened(monkeypatch):
    c = _client(monkeypatch, _zip({'a.txt': b'1'}))
    assert c.get('/api/messages/7/attachment' + Q + '&entry=nope.txt').status_code == 404
    assert c.get('/api/messages/7/attachment' + Q + '&entry=../../etc/passwd').status_code == 404


def test_not_a_zip_is_a_clean_400(monkeypatch):
    c = _client(monkeypatch, b'plain text')
    assert c.get('/api/messages/7/attachment/zip-list' + Q).status_code == 400
    assert c.get('/api/messages/7/attachment' + Q + '&entry=a').status_code == 400


def test_without_entry_the_whole_attachment_is_returned_as_before(monkeypatch):
    z = _zip({'a.txt': b'1'})
    r = _client(monkeypatch, z).get('/api/messages/7/attachment' + Q)
    assert r.status_code == 200 and r.data == z


def test_cyrillic_names_stored_as_cp437_by_old_zip_tools_are_repaired():
    info = zipfile.ZipInfo('Снимок.png'.encode('utf-8').decode('cp437'))
    assert messages._zip_entry_name(info) == 'Снимок.png'
