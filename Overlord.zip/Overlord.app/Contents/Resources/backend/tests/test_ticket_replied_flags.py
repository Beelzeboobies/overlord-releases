"""Customer-replied flag (local table only) and customer attachments (from the support@ mailbox)."""
import sqlite3
import time
import freecords_admin as fa
from flask import Flask


class _Conn:
    def __init__(self, c): self.c = c
    def execute(self, *a): return self.c.execute(*a)
    def commit(self): self.c.commit()
    def close(self): pass


def _db():
    db = sqlite3.connect(':memory:', check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("CREATE TABLE native_ticket_index (ticket_number INTEGER, native_id TEXT, thread_ref TEXT, requester_email TEXT, created_at TEXT, status TEXT, subject TEXT)")
    db.execute("CREATE TABLE message_cache (account TEXT, folder TEXT, uid TEXT, date TEXT, from_addr TEXT, to_addrs TEXT, cc TEXT, has_attachment INTEGER, attachment_names TEXT)")
    return db


def test_awaiting_reply_route_never_reads_tickets_upstream(monkeypatch):
    """Per-ticket reads from this route starved the one-request-at-a-time Freecords queue."""
    db = _db()
    db.execute("CREATE TABLE ticket_awaiting_reply (ticket_number INTEGER)")
    db.execute("INSERT INTO ticket_awaiting_reply VALUES (7)")
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    calls = []
    monkeypatch.setattr(fa, '_api', lambda *a, **k: calls.append(a) or (None, 'must not be called'))
    app = Flask(__name__)
    with app.test_request_context('/?ticket_numbers=7,8,9&open=7,8,9'):
        out = fa.fadmin_tickets_awaiting_reply().get_json()
    assert calls == [] and out == {'awaiting': {'7': True}}


def test_mailbox_attachments_matched_by_thread_ref_and_opening_mail(monkeypatch):
    db = _db()
    created = '2026-10-02T20:49:10.000Z'
    db.execute("INSERT INTO native_ticket_index VALUES (68696, 'n', 'tk8be8e9fafd', 'micthemic49@gmail.com', ?, 'open', 's')", (created,))
    local = lambda ts: time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts))
    import datetime as dt
    c = dt.datetime.fromisoformat(created.replace('Z', '+00:00')).timestamp()
    rows = [
        ('1', local(c + 600), 'micthemic49@gmail.com', 'support+tk8be8e9fafd@freecords.com', 'shot1.png\nshot2.png'),   # the reply
        ('2', local(c - 300), 'micthemic49@gmail.com', 'info@freecords.com', 'opening.pdf'),                              # opening mail
        ('3', local(c - 5 * 3600), 'micthemic49@gmail.com', 'info@freecords.com', 'other-thread.pdf'),                   # unrelated, hours earlier
        ('4', local(c + 600), 'someone@else.com', 'support+tkdifferent@freecords.com', 'not-ours.png'),
    ]
    for uid, date, frm, to, names in rows:
        db.execute("INSERT INTO message_cache VALUES (?, 'INBOX', ?, ?, ?, ?, '', 1, ?)", (fa.SUPPORT_ACCOUNT, uid, date, frm, to, names))
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    app = Flask(__name__)
    with app.test_request_context('http://localhost:8000/'):
        names = sorted(a['name'] for a in fa._mailbox_attachments(68696))
    assert names == ['opening.pdf', 'shot1.png', 'shot2.png']
