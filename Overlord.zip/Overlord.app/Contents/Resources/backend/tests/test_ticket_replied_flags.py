"""Customer-replied flag (local table only) and customer attachments (from the support@ mailbox)."""
import sqlite3
import time
import freecords_admin as fa
from flask import Flask


class _Conn:
    def __init__(self, c): self.c = c
    def execute(self, *a): return self.c.execute(*a)
    def commit(self): self.c.commit()
    def close(self): pass


def _db():
    db = sqlite3.connect(':memory:', check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("CREATE TABLE native_ticket_index (ticket_number INTEGER, native_id TEXT, thread_ref TEXT, requester_email TEXT, created_at TEXT, status TEXT, subject TEXT)")
    db.execute("CREATE TABLE message_cache (account TEXT, folder TEXT, uid TEXT, date TEXT, from_addr TEXT, to_addrs TEXT, cc TEXT, has_attachment INTEGER, attachment_names TEXT)")
    return db


def test_awaiting_reply_route_never_reads_tickets_upstream(monkeypatch):
    """Per-ticket reads from this route starved the one-request-at-a-time Freecords queue."""
    db = _db()
    db.execute("CREATE TABLE ticket_awaiting_reply (ticket_number INTEGER)")
    db.execute("INSERT INTO ticket_awaiting_reply VALUES (7)")
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    calls = []
    monkeypatch.setattr(fa, '_api', lambda *a, **k: calls.append(a) or (None, 'must not be called'))
    app = Flask(__name__)
    with app.test_request_context('/?ticket_numbers=7,8,9&open=7,8,9'):
        out = fa.fadmin_tickets_awaiting_reply().get_json()
    assert calls == [] and out == {'awaiting': {'7': True}, 'pending': 0}


def test_mailbox_attachments_matched_by_thread_ref_and_opening_mail(monkeypatch):
    db = _db()
    created = '2026-10-02T20:49:10.000Z'
    db.execute("INSERT INTO native_ticket_index VALUES (68696, 'n', 'tk8be8e9fafd', 'micthemic49@gmail.com', ?, 'open', 's')", (created,))
    local = lambda ts: time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts))
    import datetime as dt
    c = dt.datetime.fromisoformat(created.replace('Z', '+00:00')).timestamp()
    rows = [
        ('1', local(c + 600), 'micthemic49@gmail.com', 'support+tk8be8e9fafd@freecords.com', 'shot1.png\nshot2.png'),   # the reply
        ('2', local(c - 300), 'micthemic49@gmail.com', 'info@freecords.com', 'opening.pdf'),                              # opening mail
        ('3', local(c - 5 * 3600), 'micthemic49@gmail.com', 'info@freecords.com', 'other-thread.pdf'),                   # unrelated, hours earlier
        ('4', local(c + 600), 'someone@else.com', 'support+tkdifferent@freecords.com', 'not-ours.png'),
    ]
    for uid, date, frm, to, names in rows:
        db.execute("INSERT INTO message_cache VALUES (?, 'INBOX', ?, ?, ?, ?, '', 1, ?)", (fa.SUPPORT_ACCOUNT, uid, date, frm, to, names))
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    app = Flask(__name__)
    with app.test_request_context('http://localhost:8000/'):
        names = sorted(a['name'] for a in fa._mailbox_attachments(68696))
    assert names == ['opening.pdf', 'shot1.png', 'shot2.png']


def test_customer_replied_reads_few_tickets_and_remembers_until_the_ticket_changes(monkeypatch):
    """Back-to-front of the 3.68 flood: only changed tickets, <= 4 reads per call, cached per updated_at."""
    db = _db()
    for n in range(1, 11):
        db.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (?, ?)", (n, f'n{n}'))
    threads = {f'n{n}': [('inbound', 'a'), ('outbound', 'b'), ('inbound', 'c')] if n == 1 else [('inbound', 'a'), ('inbound', 'b')]
               for n in range(1, 11)}
    reads = []
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))

    def api(method, path, **kw):
        reads.append((path, kw.get('lane')))
        return {'messages': [{'direction': d, 'created_at': t} for d, t in threads[path.rsplit('/', 1)[-1]]]}, None
    monkeypatch.setattr(fa, '_api', api)
    fa._replied_cache.clear()
    changed = [(str(n), 1000 + n, f'n{n}') for n in range(1, 11)]

    flags, pending = fa._customer_replied_flags(changed)
    assert len(reads) == 4 and pending == 6 and flags['1'] is True      # 4 per call, the rest still unknown
    assert all(lane == 'background' for _, lane in reads)

    flags, pending = fa._customer_replied_flags(changed)                 # next call: first 4 remembered, next 4 read
    assert len(reads) == 8 and pending == 2

    fa._customer_replied_flags(changed)
    flags, pending = fa._customer_replied_flags(changed)
    assert len(reads) == 10 and pending == 0                              # everything known, nothing re-read

    flags, _ = fa._customer_replied_flags([('1', 5000, 'n1')])                 # ticket 1 changed again -> read again
    assert len(reads) == 11


def test_awaiting_route_only_considers_open_changed_tickets(monkeypatch):
    db = _db()
    db.execute("CREATE TABLE ticket_awaiting_reply (ticket_number INTEGER)")
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    seen = {}
    monkeypatch.setattr(fa, '_customer_replied_flags', lambda ch: (seen.update(ch=ch) or ({'5': True}, 0)))
    app = Flask(__name__)
    with app.test_request_context('/?ticket_numbers=5,6&changed=5:1700000000:6388ea8f-5485,x:1:abc,6:abc,7:5:not*valid'):
        out = fa.fadmin_tickets_awaiting_reply().get_json()
    assert seen['ch'] == [('5', 1700000000, '6388ea8f-5485')] and out == {'awaiting': {'5': True}, 'pending': 0}
