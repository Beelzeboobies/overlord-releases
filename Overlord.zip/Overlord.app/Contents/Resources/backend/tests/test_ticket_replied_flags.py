"""Customer-replied flag (live, from the thread) and customer attachments (from the support@ mailbox)."""
import sqlite3
import time
import freecords_admin as fa
from flask import Flask


class _Conn:
    def __init__(self, c): self.c = c
    def execute(self, *a): return self.c.execute(*a)
    def commit(self): self.c.commit()
    def close(self): pass


def _db():
    db = sqlite3.connect(':memory:', check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("CREATE TABLE native_ticket_index (ticket_number INTEGER, native_id TEXT, thread_ref TEXT, requester_email TEXT, created_at TEXT, status TEXT, subject TEXT)")
    db.execute("CREATE TABLE message_cache (account TEXT, folder TEXT, uid TEXT, date TEXT, from_addr TEXT, to_addrs TEXT, cc TEXT, has_attachment INTEGER, attachment_names TEXT)")
    return db


def test_live_awaiting_flags_only_a_customer_reply_after_our_reply(monkeypatch):
    db = _db()
    for n in (1, 2, 3, 4):
        db.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (?, ?)", (n, f'n{n}'))
    threads = {
        'n1': [('inbound', 'a'), ('outbound', 'b'), ('inbound', 'c')],   # customer replied to us -> flag
        'n2': [('inbound', 'a'), ('outbound', 'b')],                      # we spoke last
        'n3': [('inbound', 'a')],                                         # never answered: not a "reply"
        'n4': [],
    }
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    monkeypatch.setattr(fa, '_api', lambda m, p, **k: ({'messages': [{'direction': d, 'created_at': t} for d, t in threads[p.rsplit('/', 1)[-1]]]}, None))
    fa._awaiting_live_cache.clear()
    assert fa._live_awaiting(['1', '2', '3', '4']) == {'1': True, '2': False, '3': False, '4': False}


def test_mailbox_attachments_matched_by_thread_ref_and_opening_mail(monkeypatch):
    db = _db()
    created = '2026-10-02T20:49:10.000Z'
    db.execute("INSERT INTO native_ticket_index VALUES (68696, 'n', 'tk8be8e9fafd', 'micthemic49@gmail.com', ?, 'open', 's')", (created,))
    local = lambda ts: time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts))
    import datetime as dt
    c = dt.datetime.fromisoformat(created.replace('Z', '+00:00')).timestamp()
    rows = [
        ('1', local(c + 600), 'micthemic49@gmail.com', 'support+tk8be8e9fafd@freecords.com', 'shot1.png\nshot2.png'),   # the reply
        ('2', local(c - 300), 'micthemic49@gmail.com', 'info@freecords.com', 'opening.pdf'),                              # opening mail
        ('3', local(c - 5 * 3600), 'micthemic49@gmail.com', 'info@freecords.com', 'other-thread.pdf'),                   # unrelated, hours earlier
        ('4', local(c + 600), 'someone@else.com', 'support+tkdifferent@freecords.com', 'not-ours.png'),
    ]
    for uid, date, frm, to, names in rows:
        db.execute("INSERT INTO message_cache VALUES (?, 'INBOX', ?, ?, ?, ?, '', 1, ?)", (fa.SUPPORT_ACCOUNT, uid, date, frm, to, names))
    monkeypatch.setattr(fa, 'get_db', lambda: _Conn(db))
    app = Flask(__name__)
    with app.test_request_context('http://localhost:8000/'):
        names = sorted(a['name'] for a in fa._mailbox_attachments(68696))
    assert names == ['opening.pdf', 'shot1.png', 'shot2.png']
