"""
Whoever closes a ticket becomes its assignee (user, 12 Nov 2026). Freecords keeps no "closed by", so the assignee is
the only place the closer is recorded. The close itself must never depend on it.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("DELETE FROM ticket_activity")
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (500, 'U500')")
    _mem.commit()
    fa._my_identity_cache.update({'name': None, 'id': None, 'at': 0})


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _router(me=({'id': 'admin-nguyen', 'username': 'Nguyen'}, None), patch_results=None):
    calls = []
    results = list(patch_results or [])

    def _api(method, path, **kw):
        calls.append((method, path, kw.get('json')))
        if method == 'GET' and path == '/api/admin/me':
            return me
        if method == 'PATCH':
            return results.pop(0) if results else ({'success': True}, None)
        return {}, None
    _api.calls = calls
    return _api


def _patches(api):
    return [(p, j) for m, p, j in api.calls if m == 'PATCH']


def test_closing_a_ticket_assigns_it_to_the_closer(fclient):
    api = _router()
    with patch.object(fa, '_api', api):
        r = fclient.patch('/api/fadmin/tickets/U500', json={'status': 'closed'})
    assert r.status_code == 200
    assert _patches(api) == [('/api/admin/tickets/U500', {'status': 'closed'}),
                             ('/api/admin/tickets/U500', {'assigneeId': 'admin-nguyen'})]


def test_other_status_changes_do_not_assign(fclient):
    api = _router()
    with patch.object(fa, '_api', api):
        fclient.patch('/api/fadmin/tickets/U500', json={'status': 'pending'})
    assert _patches(api) == [('/api/admin/tickets/U500', {'status': 'pending'})]


def test_an_explicit_assignee_from_the_assign_menu_is_left_alone(fclient):
    api = _router()
    with patch.object(fa, '_api', api):
        fclient.patch('/api/fadmin/tickets/U500', json={'assigneeId': 'someone-else'})
        fclient.patch('/api/fadmin/tickets/U500', json={'status': 'closed', 'assigneeId': 'someone-else'})
    assert [j for _, j in _patches(api)] == [{'assigneeId': 'someone-else'},
                                             {'status': 'closed', 'assigneeId': 'someone-else'}]


def test_the_close_still_succeeds_when_the_admin_id_cannot_be_resolved(fclient):
    api = _router(me=(None, 'upstream down'))
    with patch.object(fa, '_api', api):
        r = fclient.patch('/api/fadmin/tickets/U500', json={'status': 'closed'})
    assert r.status_code == 200 and r.get_json() == {'success': True}
    assert _patches(api) == [('/api/admin/tickets/U500', {'status': 'closed'})]


def test_the_close_still_succeeds_when_the_assignment_is_refused(fclient):
    api = _router(patch_results=[({'success': True}, None), (None, 'assignee not allowed')])
    with patch.object(fa, '_api', api):
        r = fclient.patch('/api/fadmin/tickets/U500', json={'status': 'closed'})
    assert r.status_code == 200 and r.get_json() == {'success': True}
    row = _mem.execute("SELECT status FROM native_ticket_index WHERE ticket_number=500").fetchone()
    assert row['status'] == 'closed'


def test_a_failed_close_does_not_assign(fclient):
    api = _router(patch_results=[(None, 'upstream 500')])
    with patch.object(fa, '_api', api):
        r = fclient.patch('/api/fadmin/tickets/U500', json={'status': 'closed'})
    assert r.status_code == 503
    assert _patches(api) == [('/api/admin/tickets/U500', {'status': 'closed'})]


def test_closing_several_tickets_looks_the_admin_up_only_once(fclient):
    api = _router()
    with patch.object(fa, '_api', api):
        for n in range(3):
            fclient.patch(f'/api/fadmin/tickets/U50{n}', json={'status': 'closed'})
    assert sum(1 for m, p, _ in api.calls if m == 'GET' and p == '/api/admin/me') == 1


def test_ticket_rules_close_through_their_own_call_and_never_assign():
    import ticket_rules_engine as engine
    src = open(engine.__file__, encoding='utf-8').read()
    assert "fadmin_ticket_patch" not in src   # rules talk to upstream directly, so automation never takes ownership


def test_bulk_send_and_close_assigns_the_closer():
    """Bulk "Send & Close" closes through its own upstream call, not fadmin_ticket_patch, and used to leave the
    ticket unassigned, so a rep who closes in bulk never showed up under the Closed + assignee view."""
    calls = []

    def _api(method, path, **kw):
        calls.append((method, path, kw.get('json')))
        if method == 'GET' and path == '/api/admin/me':
            return {'id': 'admin-nguyen', 'username': 'Nguyen'}, None
        return {'success': True}, None

    with patch.object(fa, '_api', _api):
        fa._run_fadmin_bulk_reply([{'ticket_id': 'T1', 'body': 'hi'}], close_after=True)

    patches = [c for c in calls if c[0] == 'PATCH' and c[1] == '/api/admin/tickets/T1']
    assert {'status': 'closed'} in [c[2] for c in patches]
    assert {'assigneeId': 'admin-nguyen'} in [c[2] for c in patches]


def test_bulk_reply_without_close_assigns_nobody():
    calls = []

    def _api(method, path, **kw):
        calls.append((method, path, kw.get('json')))
        return {'success': True}, None

    with patch.object(fa, '_api', _api):
        fa._run_fadmin_bulk_reply([{'ticket_id': 'T1', 'body': 'hi'}], close_after=False)

    assert not [c for c in calls if c[0] == 'PATCH']
