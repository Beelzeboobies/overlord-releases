"""SubmitHub AI-music detection (Nik's newer analysis, read from the web admin's own front end, 3 Nov)."""
import freecords_admin as fa
from flask import Flask

SONG = '98156c56-a370-4de0-8723-e9f439526a35'


def _call(monkeypatch, method, reply=({'analysis': None}, None), **ctx):
    calls = []
    monkeypatch.setattr(fa, '_api', lambda m, path, **kw: (calls.append((m, path, kw.get('timeout'))) or reply))
    with Flask(__name__).test_request_context(method=method, **ctx):
        out = fa.fadmin_mod_submithub()
    return calls, out


def test_reading_a_result_is_a_get_to_the_submithub_endpoint(monkeypatch):
    a = {'analysis': {'status': 'completed', 'prediction': 'Human Made', 'probability_ai_generated': 3.2}}
    calls, resp = _call(monkeypatch, 'GET', reply=(a, None), query_string={'song_id': SONG})
    assert calls == [('GET', f'/api/admin/moderation/submithub-analysis/{SONG}', 60)]
    assert resp.get_json() == a


def test_starting_a_run_is_a_post_and_returns_the_analysis(monkeypatch):
    a = {'analysis': {'status': 'processing'}}
    calls, resp = _call(monkeypatch, 'POST', reply=(a, None), json={'song_id': SONG})
    assert calls == [('POST', f'/api/admin/moderation/submithub-analysis/{SONG}', 60)]
    assert resp.get_json() == a


def test_a_song_with_no_result_yet_is_an_empty_analysis_not_an_error(monkeypatch):
    calls, resp = _call(monkeypatch, 'GET', reply=(None, None), query_string={'song_id': SONG})
    assert resp.get_json() == {'analysis': None}


def test_a_song_id_that_could_climb_out_of_the_path_is_refused(monkeypatch):
    for bad in ('', '../risk/score/x', 'a/b', 'x' * 100):
        calls, out = _call(monkeypatch, 'GET', query_string={'song_id': bad})
        assert calls == [] and out[1] == 400


def test_a_missing_song_id_is_a_400_not_a_crash(monkeypatch):
    calls, out = _call(monkeypatch, 'GET')
    assert calls == [] and out[1] == 400
    calls, out = _call(monkeypatch, 'POST', json={})
    assert calls == [] and out[1] == 400


def test_the_quota_or_api_error_text_reaches_the_screen(monkeypatch):
    calls, out = _call(monkeypatch, 'POST', reply=(None, 'Daily SubmitHub quota used up'), json={'song_id': SONG})
    resp, code = out
    assert code == 503 and resp.get_json()['error'] == 'Daily SubmitHub quota used up'
