"""
M1–M7  Message listing and retrieval characterization tests.

Routes under test:
    GET /api/messages           (list, cache and IMAP paths)
    GET /api/messages/<uid>     (single message body)
    GET /api/messages/uids      (uid list from cache)

M7 pins Report-5's by-design contract: GET /api/messages/<uid> deliberately
does NOT mark the message read — the frontend owns that timing via a separate
POST to /api/messages/<uid>/read.
"""
from unittest.mock import patch, MagicMock

import imap
import messages as messages_mod
from test_support import TEST_ACCT, seed_message, _mem


class TestListMessages:

    def test_M1_no_auth_returns_401(self, client):
        """M1 — not logged in, force refresh → 401."""
        # imap._accounts_cache is None (from _clean) → get_all_accounts() → []
        r = client.get('/api/messages?force=1')
        assert r.status_code == 401

    def test_M2_imap_path_returns_messages_and_meta(self, client, logged_in):
        """M2 — force=1, mock IMAP with two UIDs → 200, cached=False, two messages."""
        logged_in.select_folder.return_value = {b'EXISTS': 2}

        env1 = MagicMock()
        env1.subject = b'First'
        env1.date = b'Mon, 1 Jan 2024 00:00:00 +0000'
        env1.from_ = None; env1.cc = None; env1.to = None

        env2 = MagicMock()
        env2.subject = b'Second'
        env2.date = b'Tue, 2 Jan 2024 00:00:00 +0000'
        env2.from_ = None; env2.cc = None; env2.to = None

        def fake_fetch(uid_spec, data_items):
            if data_items == ['UID']:
                return {1: {b'UID': 10}, 2: {b'UID': 20}}
            return {
                10: {b'ENVELOPE': env1, b'FLAGS': (b'\\Seen',), b'BODYSTRUCTURE': None},
                20: {b'ENVELOPE': env2, b'FLAGS': (), b'BODYSTRUCTURE': None},
            }

        logged_in.fetch = fake_fetch

        r = client.get(f'/api/messages?force=1&account={TEST_ACCT}')
        assert r.status_code == 200
        data = r.get_json()
        assert data['cached'] is False
        assert isinstance(data['messages'], list)
        assert len(data['messages']) == 2
        assert {m['uid'] for m in data['messages']} == {'10', '20'}

    def test_M3_cache_hit_returns_cached_true(self, client, logged_in):
        """M3 — DB has recent cache rows → served from cache, cached=True."""
        seed_message(uid=100, subject='Cached msg', account=TEST_ACCT)

        r = client.get(f'/api/messages?account={TEST_ACCT}')
        assert r.status_code == 200
        data = r.get_json()
        assert data['cached'] is True
        assert any(m['subject'] == 'Cached msg' for m in data['messages'])

    def test_M4_invalid_folder_returns_400(self, client, logged_in):
        """M4 — folder='INBOX*' (* not in SAFE_FOLDER_CHARS) → 400, error key present."""
        r = client.get('/api/messages?folder=INBOX*')
        assert r.status_code == 400
        data = r.get_json()
        assert 'error' in data
        assert 'invalid' in data['error'].lower()

    def test_M5_filter_unread_returns_only_unseen(self, client, logged_in):
        """M5 — filter=unread (param name confirmed from source) → only UNSEEN UIDs."""
        logged_in.select_folder.return_value = {b'EXISTS': 3}
        logged_in.search.return_value = [30]

        env = MagicMock()
        env.subject = b'Unread one'
        env.date = b'Mon, 1 Jan 2024 00:00:00 +0000'
        env.from_ = None; env.cc = None; env.to = None
        logged_in.fetch.return_value = {
            30: {b'ENVELOPE': env, b'FLAGS': (), b'BODYSTRUCTURE': None}
        }

        r = client.get(f'/api/messages?filter=unread&force=1&account={TEST_ACCT}')
        assert r.status_code == 200
        data = r.get_json()
        msgs = data['messages']
        assert len(msgs) == 1
        assert msgs[0]['uid'] == '30'
        assert msgs[0]['read'] is False

    def test_M7_get_message_does_not_mark_read(self, client, logged_in):
        """M7 — GET /api/messages/<uid> does NOT call add_flags('\\Seen') and
        leaves the message unread in the DB cache.

        By-design contract (Report 5): the server never marks a message read on
        fetch — ReadingPane.jsx fires a separate POST /api/messages/<uid>/read
        after render so the frontend controls the timing.  If someone later
        adds server-side marking, this test fails with an explicit signal.
        """
        seed_message(uid=42, read=0, folder='INBOX', account=TEST_ACCT)

        raw_email = (
            b"From: alice@example.com\r\n"
            b"Subject: Unread\r\n"
            b"Content-Type: text/plain\r\n\r\n"
            b"Body text"
        )
        logged_in.fetch.return_value = {42: {b'RFC822': raw_email}}
        logged_in.select_folder.return_value = {b'EXISTS': 1}

        with patch.object(messages_mod, 'parse_body', return_value=('Body text', '', [])):
            r = client.get(f'/api/messages/42?account={TEST_ACCT}&folder=INBOX')

        assert r.status_code == 200
        # IMAP side: add_flags must never have been called (message not flagged Seen)
        logged_in.add_flags.assert_not_called()
        # DB side: cache row still shows read=0
        row = _mem.execute(
            "SELECT read FROM message_cache WHERE account=? AND folder=? AND uid=?",
            (TEST_ACCT, 'INBOX', '42')
        ).fetchone()
        assert row is not None
        assert row['read'] == 0, 'get_message must not flip read flag in DB cache'

    def test_M6_single_message_fetch_returns_body_keys(self, client, logged_in):
        """M6 — GET /api/messages/<uid> → 200 with uid, text, html, attachments."""
        raw_email = (
            b"From: alice@example.com\r\n"
            b"Subject: Hello\r\n"
            b"Content-Type: text/plain\r\n\r\n"
            b"Body text here"
        )
        logged_in.fetch.return_value = {42: {b'RFC822': raw_email}}
        logged_in.select_folder.return_value = {b'EXISTS': 1}

        with patch.object(messages_mod, 'parse_body',
                          return_value=('Body text here', '', [])):
            r = client.get(f'/api/messages/42?account={TEST_ACCT}')

        assert r.status_code == 200
        data = r.get_json()
        assert data['uid'] == '42'
        assert 'text' in data
        assert 'html' in data
        assert 'attachments' in data


class TestRelocatedMessage:
    """
    Real user report (2026-09-08): a mail rule moved a message out of INBOX
    to another folder under a new UID after the list's cached row was
    already showing it. GET /api/messages/<uid> then 404'd against the old
    folder/UID forever — the reading pane rendered nothing with no
    explanation, even though the message (attachment included) was intact
    one folder over. GET /api/messages/<uid> must now search other folders
    for a From+Subject+Date match and return the real content instead of
    just reporting the 404.
    """

    def test_R1_moved_message_is_found_and_returned_from_new_folder(self, client, logged_in):
        seed_message(uid=12027, folder='INBOX', account=TEST_ACCT,
                     subject='Re: Freecords Youtube SRAV missing publishing metadata',
                     from_addr='luis@nuemeta.com', date='2026-08-20 17:52:23')

        logged_in.list_folders.return_value = [
            ([], b'.', 'INBOX'),
            ([], b'.', 'INBOX.NueMeta'),
        ]
        logged_in.select_folder.return_value = {b'EXISTS': 1}
        logged_in.search.return_value = [149]

        from datetime import datetime
        env = MagicMock()
        env.date = datetime(2026, 8, 20, 17, 52, 23)

        raw_email = (
            b"From: luis@nuemeta.com\r\n"
            b"Subject: Re: Freecords Youtube SRAV missing publishing metadata\r\n"
            b"Content-Type: text/plain\r\n\r\n"
            b"Thank you, Eugene."
        )

        def fake_fetch(uid_spec, data_items):
            if data_items == ['RFC822'] and uid_spec == [12027]:
                return {}  # not found at the stale folder/uid — triggers the fallback
            if data_items == ['ENVELOPE']:
                return {149: {b'ENVELOPE': env}}
            if data_items == ['RFC822'] and uid_spec == [149]:
                return {149: {b'RFC822': raw_email}}
            return {}

        logged_in.fetch = fake_fetch

        with patch.object(messages_mod, 'parse_body', return_value=('Thank you, Eugene.', '', [])):
            r = client.get(f'/api/messages/12027?account={TEST_ACCT}&folder=INBOX')

        assert r.status_code == 200
        data = r.get_json()
        assert data.get('error') is None
        assert data['text'] == 'Thank you, Eugene.'
        assert data['relocated_from'] == 'INBOX'
        assert data['folder'] == 'INBOX.NueMeta'
        assert data['uid'] == '149'

        # Stale row must be gone so the old folder's cached list stops showing it
        row = _mem.execute(
            "SELECT * FROM message_cache WHERE account=? AND folder=? AND uid=?",
            (TEST_ACCT, 'INBOX', '12027')
        ).fetchone()
        assert row is None

    def test_R2_genuinely_deleted_message_still_reports_not_found(self, client, logged_in):
        """No other folder has a matching From+Subject+Date → still a clean 404,
        not a false-positive match on an unrelated message."""
        seed_message(uid=999, folder='INBOX', account=TEST_ACCT,
                     subject='Long gone', from_addr='nobody@example.com',
                     date='2026-01-01 00:00:00')
        logged_in.list_folders.return_value = [([], b'.', 'INBOX')]
        logged_in.fetch.return_value = {}
        logged_in.search.return_value = []

        r = client.get(f'/api/messages/999?account={TEST_ACCT}&folder=INBOX')
        assert r.status_code == 404
        assert r.get_json()['error'] == 'not found'
