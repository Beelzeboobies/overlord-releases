"""Double status inputs: per song, is it taken down and is its account banned."""
import freecords_admin as fa


def _api_factory(users, deliveries):
    def api(method, path, **kw):
        if '/dsp-deliveries' in path:
            return {'deliveries': deliveries.get(path.split('/')[-2], [])}, None
        return users[path.rsplit('/', 1)[-1]], None
    return api


def test_taken_down_needs_not_sent_plus_real_deliveries(monkeypatch):
    users = {'u1': {'user': {'is_banned': False}, 'songs': [
        {'id': 'a', 'distribution_status': 'Approved', 'nuemeta_delivery_status': 'not_sent'},     # delivered then taken down
        {'id': 'b', 'distribution_status': 'Approved', 'nuemeta_delivery_status': 'not_sent'},     # never distributed (Freecords only)
        {'id': 'c', 'distribution_status': 'Approved', 'nuemeta_delivery_status': 'delivered'},    # live
        {'id': 'd', 'distribution_status': 'Takedown', 'nuemeta_delivery_status': 'not_sent'},     # label says it
    ]}, 'u2': {'user': {'is_banned': True}, 'songs': [
        {'id': 'e', 'distribution_status': 'Approved', 'nuemeta_delivery_status': 'not_sent'},
    ]}}
    deliveries = {'a': [{'status': 'delivered'}], 'b': [{'status': 'pending'}], 'e': [{'status': 'sent'}]}
    monkeypatch.setattr(fa, '_api', _api_factory(users, deliveries))
    fa._artist_cache.clear(); fa._song_state_cache.clear()
    out = fa._song_states([{'id': i, 'artist_id': 'u1' if i in 'abcd' else 'u2'} for i in 'abcde'])
    assert (out['a']['taken_down'], out['a']['banned']) == (True, False)
    assert out['b']['taken_down'] is False and out['c']['taken_down'] is False
    assert out['d']['taken_down'] is True
    assert (out['e']['taken_down'], out['e']['banned']) == (True, True)


def test_unknown_artist_or_missing_ids_are_skipped(monkeypatch):
    monkeypatch.setattr(fa, '_api', lambda *a, **k: (None, 'boom'))
    fa._artist_cache.clear(); fa._song_state_cache.clear()
    assert fa._song_states([{'id': 'x'}, {'artist_id': 'u'}, {'id': 'y', 'artist_id': 'u'}]) == {}
