"""
A1–A5  Auth endpoint characterization tests.

Routes under test:
    GET  /api/auth-status
    GET  /api/accounts
    POST /api/login  (good path + bad path)
    POST /api/logout
"""
from unittest.mock import patch, MagicMock
import imap
from test_support import TEST_ACCT


class TestAuthStatus:

    def test_A1_logged_out_returns_false(self, client):
        """A1 — no accounts → logged_in=False, empty list."""
        # imap._accounts_cache is None and keyring returns None → []
        r = client.get('/api/auth-status')
        assert r.status_code == 200
        data = r.get_json()
        assert data['logged_in'] is False
        assert data['accounts'] == []
        assert data['email'] is None

    def test_A2_logged_in_returns_true(self, client, logged_in):
        """A2 — accounts populated → logged_in=True, accounts is list of strings."""
        r = client.get('/api/auth-status')
        assert r.status_code == 200
        data = r.get_json()
        assert data['logged_in'] is True
        assert isinstance(data['accounts'], list)
        assert TEST_ACCT in data['accounts']
        assert data['email'] == TEST_ACCT

    def test_A3_login_bad_credentials_returns_401(self, client):
        """A3 — login() raises → 401, ok=False, error key present, socket closed.

        Pins the connection-leak fix: the probe client must receive logout()
        even when login() fails (previously the finally block was absent and
        the TCP socket was left open).
        """
        with patch('auth.IMAPClient') as MockIMAP:
            mock_probe = MockIMAP.return_value
            mock_probe.login.side_effect = Exception(
                "b'[AUTHENTICATIONFAILED] Invalid credentials'"
            )
            r = client.post('/api/login', json={
                'email': TEST_ACCT,
                'password': 'wrong',
                'imap_host': 'imap.example.com',
                'imap_port': 993,
                'smtp_host': 'smtp.example.com',
                'smtp_port': 465,
            })
        assert r.status_code == 401
        data = r.get_json()
        assert data['ok'] is False
        assert 'error' in data
        # Socket must have been closed even though login raised
        mock_probe.logout.assert_called_once()

    def test_A3b_login_connection_refused_closes_socket(self, client):
        """A3b — IMAPClient constructor itself raises (connection refused).

        _probe stays None in this case, so the finally block skips logout —
        no socket was opened.  The response must still be 401.
        """
        with patch('auth.IMAPClient') as MockIMAP:
            MockIMAP.side_effect = Exception('Connection refused to imap.example.com:993')
            r = client.post('/api/login', json={
                'email': TEST_ACCT,
                'password': 'x',
                'imap_host': 'imap.example.com',
                'imap_port': 993,
                'smtp_host': 'smtp.example.com',
                'smtp_port': 465,
            })
        assert r.status_code == 401
        data = r.get_json()
        assert data['ok'] is False
        assert 'error' in data

    def test_A4_login_success_returns_account_list(self, client):
        """A4 — IMAP login succeeds → 200, ok=True, accounts contains email.

        Also pins the connection-leak fix: logout() must be called exactly once
        on the probe client even on the success path (via the finally block).
        """
        with patch('auth.IMAPClient') as MockIMAP:
            mc = MagicMock()
            MockIMAP.return_value = mc
            r = client.post('/api/login', json={
                'email': TEST_ACCT,
                'password': 'correct',
                'imap_host': 'imap.example.com',
                'imap_port': 993,
                'smtp_host': 'smtp.example.com',
                'smtp_port': 465,
            })
        assert r.status_code == 200
        data = r.get_json()
        assert data['ok'] is True
        assert isinstance(data['accounts'], list)
        assert TEST_ACCT in data['accounts']
        # Probe socket closed exactly once — not leaked, not double-closed
        mc.logout.assert_called_once()

    def test_A5_list_accounts_same_shape(self, client, logged_in):
        """A5 — /api/accounts returns accounts as a plain list of strings."""
        r = client.get('/api/accounts')
        assert r.status_code == 200
        data = r.get_json()
        accounts = data['accounts']
        assert isinstance(accounts, list)
        assert all(isinstance(a, str) for a in accounts)
        assert TEST_ACCT in accounts
