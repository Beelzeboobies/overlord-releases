"""Ticket attachments from the support@ mailbox (Nguyen, 26 Oct: #70460, #69893, #70536 showed no files)."""
import sqlite3
import time

import freecords_admin as fa
from flask import Flask

CREATED = '2026-10-11T21:07:33.000Z'
CREATED_TS = fa._parse_iso_ts(CREATED)
REF = 'tkc67c65d985'
SENDER = 'customer@example.com'


class _Db:
    """One in-memory connection that ignores close(), as fa.get_db() is opened and closed several times per call."""
    def __init__(self):
        self.c = sqlite3.connect(':memory:')
        self.c.row_factory = sqlite3.Row
        self.c.execute("CREATE TABLE native_ticket_index (ticket_number INTEGER, thread_ref TEXT, requester_email TEXT, created_at TEXT)")
        self.c.execute("CREATE TABLE message_cache (account TEXT, folder TEXT, uid TEXT, from_addr TEXT, to_addrs TEXT, cc TEXT, date TEXT, has_attachment INTEGER, attachment_names TEXT)")
        self.c.execute("INSERT INTO native_ticket_index VALUES (70536, ?, ?, ?)", (REF, SENDER, CREATED))

    def mail(self, uid, to, minutes_after, names='shot.jpg', sender=SENDER):
        local = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(CREATED_TS + minutes_after * 60))
        self.c.execute("INSERT INTO message_cache VALUES ('support@freecords.com','INBOX',?,?,?,'',?,1,?)", (str(uid), sender, to, local, names))

    def __call__(self):
        return self

    def execute(self, *a, **k):
        return self.c.execute(*a, **k)

    def close(self):
        pass


def _lookup(monkeypatch, db):
    synced = []
    monkeypatch.setattr(fa, 'get_db', db)
    monkeypatch.setattr(fa, '_sync_ticket_mails', lambda *a: synced.append(a))
    with Flask(__name__).test_request_context('/'):
        return fa._mailbox_attachments(70536), synced


def test_reply_to_the_thread_address_is_found_whenever_it_arrives(monkeypatch):
    db = _Db(); db.mail(1, f'support+{REF}@freecords.com', minutes_after=16 * 24 * 60, names='evidence.png')
    out, _ = _lookup(monkeypatch, db)
    assert [o['name'] for o in out] == ['evidence.png']


def test_mail_to_info_around_the_ticket_opening_is_found_even_32_minutes_before(monkeypatch):
    """#70536: the screenshot mail is dated 32 minutes before the ticket exists (intake lags the email)."""
    db = _Db(); db.mail(2, 'info@freecords.com', minutes_after=-32, names='1000295983.jpg')
    db.mail(6, 'info@freecords.com', minutes_after=28, names='later.jpg')
    out, _ = _lookup(monkeypatch, db)
    assert sorted(o['name'] for o in out) == ['1000295983.jpg', 'later.jpg']


def test_old_unrelated_mail_from_the_same_sender_is_not_attached(monkeypatch):
    db = _Db(); db.mail(3, 'info@freecords.com', minutes_after=3 * 24 * 60)
    db.mail(4, 'info@freecords.com', minutes_after=-4 * 60)
    out, _ = _lookup(monkeypatch, db)
    assert out == []


def test_mail_addressed_to_another_tickets_thread_is_not_this_tickets(monkeypatch):
    db = _Db(); db.mail(5, 'support+tk0000000000@freecords.com', minutes_after=60)
    out, _ = _lookup(monkeypatch, db)
    assert out == []


def test_the_live_mailbox_refresh_is_asked_for_with_the_tickets_identity(monkeypatch):
    out, synced = _lookup(monkeypatch, _Db())
    assert out == [] and synced and synced[0][:3] == (70536, REF, SENDER)


def test_a_picture_pasted_inline_is_listed_even_though_the_cache_flagged_no_attachment(monkeypatch):
    """#70536: has_attachment=0 in the cache, but the mail structure carries the file."""
    db = _Db(); db.mail(7, 'info@freecords.com', minutes_after=-32, names='')
    db.c.execute("UPDATE message_cache SET has_attachment=0 WHERE uid='7'")
    monkeypatch.setattr(fa, '_inline_files', lambda uids: {u: ['pasted.jpg'] for u in uids})
    out, _ = _lookup(monkeypatch, db)
    assert [o['name'] for o in out] == ['pasted.jpg']
