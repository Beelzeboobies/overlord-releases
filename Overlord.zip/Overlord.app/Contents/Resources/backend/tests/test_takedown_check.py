"""Takedown completeness (a workaround for takedowns that 'succeed' but never reach every store)."""
import datetime as dt
import freecords_admin as fa

T = dt.datetime(2026, 10, 13, 9, 54, tzinfo=dt.timezone.utc).timestamp()


def iso(offset_min):
    return (dt.datetime.fromtimestamp(T, dt.timezone.utc) + dt.timedelta(minutes=offset_min)).strftime('%Y-%m-%dT%H:%M:%S.000Z')


def row(name, status, sent=None, delivered=None, created='2026-06-05T08:38:42.000Z'):
    return {'dsp_name': name, 'status': status, 'sent_at': sent, 'delivered_at': delivered, 'created_at': created}


def test_all_stores_processed_after_the_run_is_complete():
    rows = [row('Spotify', 'delivered', iso(4), iso(4)), row('Deezer', 'delivered', iso(4), iso(2))]
    r = fa._takedown_check(rows, T, now=T + 3600)
    assert r['state'] == 'complete' and r['done'] == 2 and r['missing'] == []


def test_store_untouched_by_the_run_is_flagged_skipped():
    """TouchTunes kept its June delivery through the takedown run."""
    rows = [row('Spotify', 'delivered', iso(4), iso(4)),
            row('TouchTunes', 'delivered', '2026-06-05T08:42:00.000Z', '2026-06-05T08:43:00.000Z')]
    r = fa._takedown_check(rows, T, now=T + 3600)
    assert r['state'] == 'incomplete' and r['missing'] == ['TouchTunes']


def test_recent_run_waits_instead_of_flagging():
    rows = [row('TouchTunes', 'delivered', '2026-06-05T08:42:00.000Z', '2026-06-05T08:43:00.000Z')]
    assert fa._takedown_check(rows, T, now=T + 120)['state'] == 'in_progress'


def test_sent_but_never_delivered_turns_stuck_after_six_hours():
    rows = [row('Apple Music', 'sent', iso(4), '2026-06-05T08:43:00.000Z')]
    assert fa._takedown_check(rows, T, now=T + 3600)['state'] == 'in_progress'
    r = fa._takedown_check(rows, T, now=T + 7 * 3600)
    assert r['state'] == 'incomplete' and r['missing'] == ['Apple Music']


def test_soundcloud_and_never_delivered_stores_are_ignored():
    rows = [row('SoundCloud', 'pending'), row('Melon', 'pending'),
            row('Tidal', 'failed', '2026-06-05T08:40:00.000Z'),            # original delivery failed: never live
            row('Spotify', 'delivered', iso(4), iso(4))]
    r = fa._takedown_check(rows, T, now=T + 3600)
    assert r['state'] == 'complete' and r['total'] == 1


def test_failed_takedown_delivery_is_flagged():
    r = fa._takedown_check([row('Deezer', 'failed', iso(4))], T, now=T + 3600)
    assert r['state'] == 'incomplete' and r['missing'] == ['Deezer']


def test_unknown_run_is_inferred_from_the_newest_redelivery():
    """Takedown done from the web admin: no local record. The newest cluster is the run."""
    rows = [row('Spotify', 'delivered', iso(4), iso(4)),
            row('Audiomack', 'delivered', '2026-07-01T11:27:00.000Z', '2026-07-01T11:27:00.000Z')]
    r = fa._takedown_check(rows, None, now=T + 3600)
    assert r['run_inferred'] and r['state'] == 'incomplete' and r['missing'] == ['Audiomack']


def test_label_only_takedown_with_no_run_flags_everything():
    """Label says Takedown, but every store only ever got its original delivery."""
    rows = [row('Spotify', 'delivered', '2026-06-05T08:40:00.000Z', '2026-06-05T08:41:00.000Z'),
            row('TouchTunes', 'delivered', '2026-06-05T08:42:00.000Z', '2026-06-05T08:43:00.000Z')]
    r = fa._takedown_check(rows, None, now=T)
    assert r['state'] == 'incomplete' and not r['run_known'] and r['missing'] == ['Spotify', 'TouchTunes']
