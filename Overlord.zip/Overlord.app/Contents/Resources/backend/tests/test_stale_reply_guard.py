"""'Someone just replied, are you sure?': a reply is refused (409, nothing sent) when the thread has
messages the writer has not seen, unless force_stale is set."""
import freecords_admin as fa
from flask import Flask

TICKET = {'id': 't1', 'subject': 'Hi', 'requester_email': 'artist@example.com'}


def _msgs(*ids):
    return [{'id': i, 'direction': 'inbound' if i == 'c2' else 'outbound', 'from_email': 'artist@example.com',
             'sent_by_admin_id': 'a1', 'body': f'<p>text of {i}</p>', 'created_at': f'2026-10-21T10:0{n}:00.000Z'}
            for n, i in enumerate(ids)]


def _run(monkeypatch, thread, body):
    posted = []

    def api(method, path, **kw):
        if method == 'GET':
            return {'ticket': TICKET, 'messages': thread}, None
        posted.append((method, path, kw.get('json')))
        return {'success': True}, None
    monkeypatch.setattr(fa, '_api', api)
    app = Flask(__name__)
    with app.test_request_context(json=body):
        r = fa.fadmin_ticket_reply('t1')
    resp, code = r if isinstance(r, tuple) else (r, 200)
    return resp.get_json(), code, posted


def test_unseen_message_blocks_the_send(monkeypatch):
    out, code, posted = _run(monkeypatch, _msgs('m1', 'c2'), {'body': 'Hello', 'known_message_ids': ['m1']})
    assert code == 409 and out['stale'] is True and posted == []
    assert [m['id'] for m in out['new_messages']] == ['c2'] and out['new_messages'][0]['snippet'] == 'text of c2'


def test_force_stale_sends_and_is_not_forwarded_upstream(monkeypatch):
    out, code, posted = _run(monkeypatch, _msgs('m1', 'c2'), {'body': 'Hello', 'known_message_ids': ['m1'], 'force_stale': True})
    assert code == 200 and len(posted) == 1
    assert posted[0][2] == {'body': 'Hello'}


def test_up_to_date_client_sends_normally(monkeypatch):
    out, code, posted = _run(monkeypatch, _msgs('m1'), {'body': 'Hello', 'known_message_ids': ['m1']})
    assert code == 200 and posted[0][2] == {'body': 'Hello'}


def test_client_without_a_known_list_is_not_checked(monkeypatch):
    out, code, posted = _run(monkeypatch, _msgs('m1', 'c2'), {'body': 'Hello'})
    assert code == 200 and len(posted) == 1
