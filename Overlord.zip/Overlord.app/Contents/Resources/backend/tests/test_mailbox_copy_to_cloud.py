"""Files found only in the support@ mailbox are copied into the ticket in the cloud (4 Nov)."""
import sqlite3

import freecords_admin as fa
import messages
from flask import Flask


class _Db:
    def __init__(self, native_id='abc'):
        self.c = sqlite3.connect(':memory:')
        self.c.row_factory = sqlite3.Row
        self.c.execute("CREATE TABLE ticket_attachment_files (id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_number INTEGER, "
                       "filename TEXT, content_type TEXT, size INTEGER, file_path TEXT)")
        self.c.execute("CREATE TABLE native_ticket_index (ticket_number INTEGER, native_id TEXT)")
        if native_id:
            self.c.execute("INSERT INTO native_ticket_index VALUES (70310, ?)", (native_id,))

    def __call__(self):
        return self

    def execute(self, *a, **k):
        return self.c.execute(*a, **k)

    def close(self):
        pass


class _InlineThread:
    """Runs the worker right away so a test can look at what it did."""
    def __init__(self, target, args=(), daemon=None):
        self.target, self.args = target, args

    def start(self):
        self.target(*self.args)


def _reset(monkeypatch):
    monkeypatch.setattr(fa, '_mail_copy_busy', set())
    monkeypatch.setattr(fa, '_mail_copy_tried', {})
    monkeypatch.setattr(fa.threading, 'Thread', _InlineThread)
    # run inline, the worker would otherwise leave THIS thread in the background request lane for every later test
    monkeypatch.setattr(fa, '_set_bg', lambda: None)


def _worker(monkeypatch, cloud_names, mail, uploads, upload_error=None):
    """Run the copy for ticket 70310 where `mail` is {file name: payload bytes}."""
    _reset(monkeypatch)
    monkeypatch.setattr(fa, '_api', lambda m, path, **k: ({'attachments': [{'original_filename': n} for n in cloud_names]}, None))
    monkeypatch.setattr(messages, '_load_attachment', lambda uid, folder, name, acct: (mail[name], 'image/png', None))
    monkeypatch.setattr(fa, '_upload_attachment',
                        lambda name, ctype, data, user_id=None, ticket_id=None: (uploads.append((name, len(data), ticket_id)) or ({}, upload_error)))
    fa._copy_mailbox_files_to_cloud(Flask(__name__), 70310, 'abc', [('9', n) for n in mail])


def test_a_mailbox_file_missing_from_the_cloud_is_uploaded_to_the_ticket(monkeypatch):
    uploads = []
    _worker(monkeypatch, [], {'id.png': b'12345'}, uploads)
    assert uploads == [('id.png', 5, 'abc')]


def test_a_file_the_cloud_already_has_is_not_uploaded_again(monkeypatch):
    uploads = []
    _worker(monkeypatch, ['id.png'], {'id.png': b'12345', 'new.png': b'1'}, uploads)
    assert [u[0] for u in uploads] == ['new.png']


def test_empty_and_oversized_files_are_left_alone(monkeypatch):
    uploads = []
    _worker(monkeypatch, [], {'empty.png': b'', 'big.png': b'x' * (fa.MAIL_COPY_MAX_BYTES + 1), 'ok.png': b'1'}, uploads)
    assert [u[0] for u in uploads] == ['ok.png']


def test_a_failed_upload_does_not_stop_the_next_file_or_crash(monkeypatch):
    uploads = []
    _worker(monkeypatch, [], {'a.png': b'1', 'b.png': b'2'}, uploads, upload_error='storage down')
    assert [u[0] for u in uploads] == ['a.png', 'b.png']
    assert fa._mail_copy_busy == set()


def test_the_cloud_being_unreachable_uploads_nothing(monkeypatch):
    uploads = []
    _reset(monkeypatch)
    monkeypatch.setattr(fa, '_api', lambda *a, **k: (None, 'down'))
    monkeypatch.setattr(fa, '_upload_attachment', lambda *a, **k: uploads.append(1))
    fa._copy_mailbox_files_to_cloud(Flask(__name__), 70310, 'abc', [('9', 'a.png')])
    assert uploads == [] and fa._mail_copy_busy == set()


def test_the_same_file_is_not_retried_within_the_hour(monkeypatch):
    uploads = []
    _worker(monkeypatch, [], {'id.png': b'1'}, uploads, upload_error='storage down')
    fa._copy_mailbox_files_to_cloud(Flask(__name__), 70310, 'abc', [('9', 'id.png')])
    assert len(uploads) == 1
    monkeypatch.setitem(fa._mail_copy_tried, (70310, 'id.png'), -1e9)
    fa._copy_mailbox_files_to_cloud(Flask(__name__), 70310, 'abc', [('9', 'id.png')])
    assert len(uploads) == 2


def test_a_ticket_being_copied_is_not_started_twice(monkeypatch):
    uploads = []
    _worker(monkeypatch, [], {}, uploads)
    fa._mail_copy_busy.add(70310)
    monkeypatch.setattr(fa, '_upload_attachment', lambda *a, **k: uploads.append(1))
    fa._copy_mailbox_files_to_cloud(Flask(__name__), 70310, 'abc', [('9', 'x.png')])
    assert uploads == []


def _listing(monkeypatch, db, cloud, mail):
    copies = []
    monkeypatch.setattr(fa, 'get_db', db)
    monkeypatch.setattr(fa, '_api', lambda *a, **k: ({'attachments': cloud}, None))
    monkeypatch.setattr(fa, '_mailbox_attachments', lambda n: mail)
    monkeypatch.setattr(fa, '_copy_mailbox_files_to_cloud', lambda app, n, nid, files: copies.append((n, nid, files)))
    with Flask(__name__).test_request_context('/'):
        out = fa.fadmin_ticket_attachments_local(70310).get_json()['attachments']
    return out, copies


def test_opening_a_ticket_with_a_mailbox_only_file_starts_the_copy(monkeypatch):
    mail = [{'name': 'id.png', 'attachment_url': 'u', '_uid': '41', '_from_mailbox': True}]
    out, copies = _listing(monkeypatch, _Db(), [], mail)
    assert [a['name'] for a in out] == ['id.png']
    assert copies == [(70310, 'abc', [('41', 'id.png')])]


def test_a_mailbox_file_already_in_the_cloud_is_listed_once_and_not_copied(monkeypatch):
    mail = [{'name': 'id.png', 'attachment_url': 'u', '_uid': '41', '_from_mailbox': True}]
    cloud = [{'id': '1', 'original_filename': 'id.png', 'content_type': 'image/png', 'size_bytes': '5', 'key': 'k'}]
    out, copies = _listing(monkeypatch, _Db(), cloud, mail)
    assert [a['name'] for a in out] == ['id.png'] and copies == []


def test_a_ticket_unknown_to_the_cloud_is_not_copied(monkeypatch):
    mail = [{'name': 'id.png', 'attachment_url': 'u', '_uid': '41', '_from_mailbox': True}]
    out, copies = _listing(monkeypatch, _Db(native_id=None), [], mail)
    assert [a['name'] for a in out] == ['id.png'] and copies == []


def test_the_same_file_twice_in_the_cloud_is_listed_once(monkeypatch):
    cloud = [{'id': str(i), 'original_filename': 'id.png', 'content_type': 'image/png', 'size_bytes': '5', 'key': f'k{i}'} for i in (1, 2)]
    out, _ = _listing(monkeypatch, _Db(), cloud, [])
    assert [a['name'] for a in out] == ['id.png']
