"""The Freecords note field is shared by every install and the web admin, so
adding a note must append to what is there RIGHT NOW — never rebuild it from
anything local — and must refuse to write when the current note can't be read."""
import freecords_admin as fa
from flask import Flask


def _client(monkeypatch, store, read_error=None):
    calls = []

    def api(method, path, json=None, **kw):
        calls.append(method)
        if method == 'GET':
            if read_error:
                return None, read_error
            return {'note': {'content': store['note']}}, None
        store['note'] = json['note']
        return {}, None

    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa, '_rescue_local_notes', lambda uid, content: content)
    monkeypatch.setattr(fa, '_get_current_admin_name', lambda: 'Eugene')
    app = Flask(__name__)
    app.register_blueprint(fa.bp)
    return app.test_client(), calls


def test_appends_without_erasing_notes_written_elsewhere(monkeypatch):
    store = {'note': 'FRAUD WARNING from the web admin'}
    client, _ = _client(monkeypatch, store)
    r = client.post('/api/fadmin/notes-log', json={'user_id': 'u1', 'note': 'Mac note B'})
    assert r.status_code == 200
    assert store['note'].startswith('FRAUD WARNING from the web admin')
    assert store['note'].endswith('Eugene: Mac note B')


def test_empty_upstream_gets_just_the_entry(monkeypatch):
    store = {'note': ''}
    client, _ = _client(monkeypatch, store)
    client.post('/api/fadmin/notes-log', json={'user_id': 'u1', 'note': 'first'})
    assert store['note'].startswith('[') and store['note'].endswith('Eugene: first')
    assert '\n\n' not in store['note']


def test_unreadable_upstream_is_not_overwritten(monkeypatch):
    store = {'note': 'precious history'}
    client, calls = _client(monkeypatch, store, read_error='boom')
    r = client.post('/api/fadmin/notes-log', json={'user_id': 'u1', 'note': 'x'})
    assert r.status_code == 503
    assert calls == ['GET']
    assert store['note'] == 'precious history'


def test_note_blob_round_trips_through_the_parser():
    blob = 'typed in web admin\n\n[2026-10-01 10:00:00] Eugene: one\n\n[2026-10-01 11:00:00] Ann: two'
    entries = fa._parse_note_blob(blob, 'Web', '2026-09-30T00:00:00Z')
    assert [e['author'] for e in entries] == ['Web', 'Eugene', 'Ann']
    assert entries[1]['note'] == 'one'


def test_text_without_a_header_stays_attributed_to_whoever_created_the_note(monkeypatch):
    """3 Nov 2026: "Identity verified..." typed by Nikola in the web admin showed as the last person
    who added a note in Overlord, with their date, and changed again with every new note."""
    note = {'content': 'Identity verified by artist in December 2025\n\n[2026-11-03 11:11:29] Eugene: FNAF',
            'created_by': 'Nikola Jevtic', 'created_at': '2026-11-02T12:15:27.672Z',
            'updated_by': 'Eugene', 'updated_at': '2026-11-03T11:12:18.671Z'}
    monkeypatch.setattr(fa, '_api', lambda *a, **k: ({'note': note}, None))
    content, by, at, err = fa._fetch_remote_note('u1')
    entries = fa._parse_note_blob(content, by, at)
    assert err is None
    assert (entries[0]['author'], entries[0]['created_at']) == ('Nikola Jevtic', '2026-11-02T12:15:27.672Z')
    assert entries[1]['author'] == 'Eugene'


def _delete_client(monkeypatch, store, me='Eugene'):
    puts = []

    def api(method, path, json=None, **kw):
        if method == 'GET':
            return {'note': {'content': store['note'], 'created_by': 'Nikola', 'created_at': '2026-11-02T12:00:00Z'}}, None
        puts.append(json['note'])
        store['note'] = json['note']
        return {}, None

    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa, '_get_current_admin_name', lambda: me)
    monkeypatch.setattr(fa, '_log_local_moderation_action', lambda *a, **k: None)
    monkeypatch.setattr(fa, 'get_db', lambda: (_ for _ in ()).throw(RuntimeError('no db in test')))
    app = Flask(__name__)
    app.register_blueprint(fa.bp)
    return app.test_client(), puts


BLOB = ('Identity verified by artist\n\n[2026-11-03 11:11:29] Eugene: first\nsecond line\n\n'
        '[2026-11-03 11:12:18] Ann: hers\n\n[2026-11-03 11:13:00] Eugene: last')


def test_delete_own_note_removes_only_that_entry(monkeypatch):
    store = {'note': BLOB}
    client, puts = _delete_client(monkeypatch, store)
    r = client.delete('/api/fadmin/notes-log', json={'user_id': 'u1', 'created_at': '2026-11-03T11:11:29Z',
                                                    'note': 'first\nsecond line'})
    assert r.status_code == 200 and r.get_json() == {'ok': True}
    assert store['note'] == ('Identity verified by artist\n\n[2026-11-03 11:12:18] Ann: hers\n\n'
                             '[2026-11-03 11:13:00] Eugene: last')


def test_delete_last_and_only_notes(monkeypatch):
    store = {'note': '[2026-11-03 11:13:00] Eugene: only'}
    client, _ = _delete_client(monkeypatch, store)
    assert client.delete('/api/fadmin/notes-log', json={'user_id': 'u1', 'created_at': '2026-11-03T11:13:00Z',
                                                       'note': 'only'}).status_code == 200
    assert store['note'] == ''


def test_cannot_delete_someone_elses_note(monkeypatch):
    store = {'note': BLOB}
    client, puts = _delete_client(monkeypatch, store)
    r = client.delete('/api/fadmin/notes-log', json={'user_id': 'u1', 'created_at': '2026-11-03T11:12:18Z', 'note': 'hers'})
    assert r.status_code == 403 and puts == [] and store['note'] == BLOB


def test_delete_refuses_when_the_note_changed_or_is_unstamped(monkeypatch):
    store = {'note': BLOB}
    client, puts = _delete_client(monkeypatch, store)
    for body in ({'created_at': '2026-11-03T11:11:29Z', 'note': 'first'},            # text no longer matches
                 {'created_at': '2026-01-01T00:00:00Z', 'note': 'last'},              # stamp not there
                 {'created_at': '2026-11-02T12:00:00Z', 'note': 'Identity verified by artist'}):  # web-admin text
        assert client.delete('/api/fadmin/notes-log', json={'user_id': 'u1', **body}).status_code == 404
    assert puts == [] and store['note'] == BLOB


def test_notes_log_marks_only_my_stamped_entries_as_mine(monkeypatch):
    store = {'note': BLOB}
    client, _ = _delete_client(monkeypatch, store)
    monkeypatch.setattr(fa, '_rescue_local_notes', lambda uid, content: content)
    notes = client.get('/api/fadmin/notes-log?user_id=u1').get_json()['notes']
    assert {(n['author'], n['mine']) for n in notes} == {('Nikola', False), ('Eugene', True), ('Ann', False)}
