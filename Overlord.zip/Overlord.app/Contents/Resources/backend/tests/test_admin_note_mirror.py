"""The Freecords note field is shared by every install and the web admin, so
adding a note must append to what is there RIGHT NOW — never rebuild it from
anything local — and must refuse to write when the current note can't be read."""
import freecords_admin as fa
from flask import Flask


def _client(monkeypatch, store, read_error=None):
    calls = []

    def api(method, path, json=None, **kw):
        calls.append(method)
        if method == 'GET':
            if read_error:
                return None, read_error
            return {'note': {'content': store['note']}}, None
        store['note'] = json['note']
        return {}, None

    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa, '_rescue_local_notes', lambda uid, content: content)
    monkeypatch.setattr(fa, '_get_current_admin_name', lambda: 'Eugene')
    app = Flask(__name__)
    app.register_blueprint(fa.bp)
    return app.test_client(), calls


def test_appends_without_erasing_notes_written_elsewhere(monkeypatch):
    store = {'note': 'FRAUD WARNING from the web admin'}
    client, _ = _client(monkeypatch, store)
    r = client.post('/api/fadmin/notes-log', json={'user_id': 'u1', 'note': 'Mac note B'})
    assert r.status_code == 200
    assert store['note'].startswith('FRAUD WARNING from the web admin')
    assert store['note'].endswith('Eugene: Mac note B')


def test_empty_upstream_gets_just_the_entry(monkeypatch):
    store = {'note': ''}
    client, _ = _client(monkeypatch, store)
    client.post('/api/fadmin/notes-log', json={'user_id': 'u1', 'note': 'first'})
    assert store['note'].startswith('[') and store['note'].endswith('Eugene: first')
    assert '\n\n' not in store['note']


def test_unreadable_upstream_is_not_overwritten(monkeypatch):
    store = {'note': 'precious history'}
    client, calls = _client(monkeypatch, store, read_error='boom')
    r = client.post('/api/fadmin/notes-log', json={'user_id': 'u1', 'note': 'x'})
    assert r.status_code == 503
    assert calls == ['GET']
    assert store['note'] == 'precious history'


def test_note_blob_round_trips_through_the_parser():
    blob = 'typed in web admin\n\n[2026-10-01 10:00:00] Eugene: one\n\n[2026-10-01 11:00:00] Ann: two'
    entries = fa._parse_note_blob(blob, 'Web', '2026-09-30T00:00:00Z')
    assert [e['author'] for e in entries] == ['Web', 'Eugene', 'Ann']
    assert entries[1]['note'] == 'one'
