"""Ticket attachment rows lost on 30 Sep (6,291 -> 1,494) while the files stayed on disk (user, 3 Nov)."""
import sqlite3

import freecords_admin as fa
import helpers
from flask import Flask


class _Db:
    """One in-memory connection that ignores close(), as get_db() is opened and closed several times per call."""
    def __init__(self):
        self.c = sqlite3.connect(':memory:')
        self.c.row_factory = sqlite3.Row
        self.c.execute(
            "CREATE TABLE ticket_attachment_files (id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_number INTEGER NOT NULL, "
            "filename TEXT NOT NULL, content_type TEXT, size INTEGER, file_path TEXT NOT NULL, "
            "downloaded_at TEXT DEFAULT (datetime('now')))")
        self.c.execute("CREATE TABLE native_ticket_index (ticket_number INTEGER, native_id TEXT, thread_ref TEXT, "
                       "requester_email TEXT, subject TEXT, created_at TEXT)")

    def __call__(self):
        return self

    def execute(self, *a, **k):
        return self.c.execute(*a, **k)

    def commit(self):
        self.c.commit()

    def close(self):
        pass

    def rows(self):
        return sorted((r['ticket_number'], r['filename'], r['content_type'], r['size'])
                      for r in self.c.execute("SELECT * FROM ticket_attachment_files"))


def _put(root, ticket, name, data=b'x'):
    d = root / 'ticket_attachments' / str(ticket)
    d.mkdir(parents=True, exist_ok=True)
    (d / name).write_bytes(data)


def _setup(monkeypatch, tmp_path):
    db = _Db()
    monkeypatch.setattr(helpers, 'get_db', db)
    monkeypatch.setattr(helpers, 'APP_SUPPORT', tmp_path)
    return db


def test_files_on_disk_with_no_row_are_listed_again(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    _put(tmp_path, 64084, 'inline_1.png', b'abc')
    _put(tmp_path, 64084, 'ID card.pdf', b'abcdef')
    assert helpers.reindex_ticket_attachments_from_disk() == 2
    assert db.rows() == [
        (64084, 'ID card.pdf', 'application/pdf', 6, ),
        (64084, 'inline_1.png', 'image/png', 3),
    ]
    path = db.c.execute("SELECT file_path FROM ticket_attachment_files WHERE filename='ID card.pdf'").fetchone()[0]
    assert (tmp_path / path).read_bytes() == b'abcdef'


def test_running_it_twice_adds_nothing(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    _put(tmp_path, 1, 'a.png')
    assert helpers.reindex_ticket_attachments_from_disk() == 1
    assert helpers.reindex_ticket_attachments_from_disk() == 0
    assert len(db.rows()) == 1


def test_a_file_that_already_has_a_row_is_not_duplicated_even_when_its_stored_name_differs(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    # the original name had a character the saver replaced on disk
    _put(tmp_path, 7, 'a_b.png')
    db.execute("INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
               "VALUES (7, 'a:b.png', 'image/png', 1, 'ticket_attachments\\7\\a_b.png')")
    assert helpers.reindex_ticket_attachments_from_disk() == 0
    assert db.rows() == [(7, 'a:b.png', 'image/png', 1)]


def test_a_row_whose_name_differs_only_in_letter_case_counts_as_the_same_file(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    _put(tmp_path, 64944, 'screenshot_1.png')
    db.execute("INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
               "VALUES (64944, 'Screenshot_1.png', 'image/png', 1, 'ticket_attachments\\64944\\Screenshot_1.png')")
    assert helpers.reindex_ticket_attachments_from_disk() == 0
    assert len(db.rows()) == 1


def test_stray_system_files_and_non_ticket_folders_are_ignored(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    _put(tmp_path, 5, 'Thumbs.db')
    _put(tmp_path, 5, 'desktop.ini')
    _put(tmp_path, 'notes', 'x.txt')
    assert helpers.reindex_ticket_attachments_from_disk() == 0
    assert db.rows() == []


def test_no_attachments_folder_is_fine(monkeypatch, tmp_path):
    _setup(monkeypatch, tmp_path)
    assert helpers.reindex_ticket_attachments_from_disk() == 0


def _listing(monkeypatch, db, cloud):
    db.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (64084, 'abc')")
    monkeypatch.setattr(fa, 'get_db', db)
    monkeypatch.setattr(fa, '_api', lambda *a, **k: ({'attachments': cloud}, None))
    monkeypatch.setattr(fa, '_mailbox_attachments', lambda n: [])
    with Flask(__name__).test_request_context('/'):
        return fa.fadmin_ticket_attachments_local(64084).get_json()['attachments']


def test_two_identical_rows_for_one_file_are_listed_once(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    for _ in range(2):
        db.execute("INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
                   "VALUES (64084, 'shot.png', 'image/png', 5, 'x')")
    assert [a['name'] for a in _listing(monkeypatch, db, [])] == ['shot.png']


def test_a_file_in_both_places_is_listed_once_and_odd_names_are_url_safe(monkeypatch, tmp_path):
    db = _setup(monkeypatch, tmp_path)
    db.execute("INSERT INTO ticket_attachment_files (ticket_number, filename, content_type, size, file_path) "
               "VALUES (64084, 'scan #1 (final).pdf', 'application/pdf', 5, 'x')")
    cloud = [{'id': '1', 'original_filename': 'scan #1 (final).pdf', 'content_type': 'application/pdf', 'size_bytes': '5', 'key': 'k1'},
             {'id': '2', 'original_filename': 'only-in-cloud.png', 'content_type': 'image/png', 'size_bytes': '9', 'key': 'k2'}]
    out = _listing(monkeypatch, db, cloud)
    assert [a['name'] for a in out] == ['scan #1 (final).pdf', 'only-in-cloud.png']
    assert out[0]['attachment_url'].endswith('/64084/scan%20%231%20%28final%29.pdf')
