"""Anything that is not a PDF/image goes to Nik's any-file-type attachments route
(presign-upload -> PUT -> confirm); PDFs/images keep using the profile-docs endpoint."""
import freecords_admin as fa
from flask import Flask


class _Resp:
    def __init__(self, code=200, content=b'', headers=None):
        self.status_code, self.content, self.headers = code, content, headers or {}
    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(self.status_code)


def _setup(monkeypatch, put_code=200, source_name='proof.zip'):
    calls = {'api': [], 'put': [], 'docs': []}

    def api(method, path, json=None, **kw):
        calls['api'].append((method, path, json))
        if path.endswith('/presign-upload'):
            return {'uploadUrl': 'https://spaces.example/put', 'key': 'users/u1/abc-proof.zip'}, None
        if path.endswith('/confirm'):
            return {'attachment': {'id': 'a1', 'original_filename': 'proof.zip'}}, None
        if path.endswith('/docs'):
            calls['docs'].append(path)
            return {'id': 'doc'}, None
        return {}, None
    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa.http, 'put', lambda url, data=None, headers=None, timeout=None: (calls['put'].append((url, data, headers)), _Resp(put_code))[1])
    monkeypatch.setattr(fa.http, 'get', lambda url, timeout=None: _Resp(200, b'PK\x03\x04zipbytes', {'Content-Type': 'application/zip'}))
    monkeypatch.setattr(fa, '_url_is_fetchable', lambda u: True)
    app = Flask(__name__); app.register_blueprint(fa.bp)
    return app.test_client(), calls


def _post(c, name):
    return c.post('/api/fadmin/docs/from-url', json={'user_id': 'u1', 'category': 'identity', 'source_url': 'https://x/y', 'filename': name})


def test_zip_goes_through_the_attachments_route_untouched(monkeypatch):
    c, calls = _setup(monkeypatch)
    r = _post(c, 'Freecords proof .zip')
    assert r.status_code == 200 and r.get_json()['stored_as'] == 'attachment'
    presign = [x for x in calls['api'] if x[1].endswith('/presign-upload')][0][2]
    assert presign == {'filename': 'Freecords proof .zip', 'contentType': 'application/zip', 'fileSize': len(b'PKzipbytes'), 'userId': 'u1'}
    assert calls['put'][0][2] == {'Content-Type': 'application/zip'}      # same Content-Type as signed
    assert calls['put'][0][1] == b'PK\x03\x04zipbytes'              # the bytes, unchanged
    assert any(x[1].endswith('/confirm') and x[2] == {'key': 'users/u1/abc-proof.zip'} for x in calls['api'])
    assert calls['docs'] == []                                       # legacy docs endpoint not used


def test_pdf_and_images_still_use_the_profile_docs_endpoint(monkeypatch):
    c, calls = _setup(monkeypatch)
    assert _post(c, 'ID card.JPG').status_code == 200
    assert calls['docs'] == ['/api/admin/user/u1/docs'] and calls['put'] == []


def test_failed_storage_upload_is_an_error_not_a_silent_success(monkeypatch):
    c, calls = _setup(monkeypatch, put_code=403)
    r = _post(c, 'a.docx')
    assert r.status_code == 503 and 'HTTP 403' in r.get_json()['error']
    assert not any(x[1].endswith('/confirm') for x in calls['api'])  # never confirm a file that is not there
