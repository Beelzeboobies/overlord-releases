"""'Select all N' inside the Untagged group must resolve the real untagged
tickets — Freecords itself matches nothing for the synthetic tag=__untagged__."""
import freecords_admin as fa
from flask import Flask


def _client(monkeypatch, tickets):
    def api(method, path, params=None, **kw):
        if (params or {}).get('tag') == '__untagged__':
            return {'tickets': [], 'pagination': {'total': 0}}, None   # what Freecords really does
        page, limit = params.get('page', 1), params.get('limit', 100)
        chunk = tickets[(page - 1) * limit: page * limit]
        return {'tickets': chunk, 'pagination': {'total': len(tickets)}}, None
    monkeypatch.setattr(fa, '_api', api)
    app = Flask(__name__)
    app.register_blueprint(fa.bp)
    return app.test_client()


def _t(i, tags=()):
    return {'id': f't{i}', 'subject': f's{i}', 'tags': list(tags), 'created_at': f'2026-10-{(i % 28) + 1:02d}T00:00:00.000Z'}


def test_untagged_group_resolves_only_untagged_tickets_across_pages(monkeypatch):
    tickets = [_t(i, ['x'] if i % 5 == 0 else []) for i in range(250)]
    r = _client(monkeypatch, tickets).get('/api/fadmin/tickets/matching-ids?status=open&tag=__untagged__').get_json()
    assert len(r['ids']) == 200
    assert all(not t['tags'] for t in r['tickets'])


def test_normal_tag_still_forwarded(monkeypatch):
    seen = {}
    def api(method, path, params=None, **kw):
        seen['tag'] = params.get('tag')
        return {'tickets': [_t(1)], 'pagination': {'total': 1}}, None
    monkeypatch.setattr(fa, '_api', api)
    app = Flask(__name__); app.register_blueprint(fa.bp)
    r = app.test_client().get('/api/fadmin/tickets/matching-ids?status=open&tag=Cover%20Art').get_json()
    assert seen['tag'] == 'Cover Art' and r['ids'] == ['t1']


def test_auto_tag_apply_async_runs_in_parallel_and_reports_progress(monkeypatch):
    import time
    def api(method, path, **kw):
        time.sleep(0.2)
        return {}, None
    monkeypatch.setattr(fa, '_api', api)
    app = Flask(__name__); app.register_blueprint(fa.bp)
    c = app.test_client()
    items = [{'id': f't{i}', 'tag': 'Cover Art'} for i in range(12)]
    t0 = time.time()
    assert c.post('/api/fadmin/tickets/auto-tag/apply-async', json={'items': items}).get_json()['total'] == 12
    st = {}
    for _ in range(50):
        st = c.get('/api/fadmin/tickets/auto-tag/apply-async/status').get_json()
        if st['state'] == 'done':
            break
        time.sleep(0.1)
    elapsed = time.time() - t0
    assert st['state'] == 'done' and st['done'] == 12 and st['ok'] == 12 and st['failed'] == 0
    assert elapsed < 1.5, f'12 x 0.2s should take ~0.6s with 4 workers, took {elapsed:.1f}s'
