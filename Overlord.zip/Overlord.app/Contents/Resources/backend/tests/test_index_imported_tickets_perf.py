"""
_index_imported_tickets — correctness after parallelizing the per-ticket
resolution loop (2026-09-08, "make anything faster"). Each ticket's own
inner page-scan stays sequential-with-early-exit; only the outer loop
across independent tickets is now concurrent.
"""
from unittest.mock import patch

import freecords_admin as fa
from test_support import _mem


def _cleanup():
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.commit()


def test_I1_each_ticket_resolved_and_indexed():
    _cleanup()
    tickets = [
        {'ticketNumber': 900, 'createdAt': '2026-09-01T00:00:00Z'},
        {'ticketNumber': 901, 'createdAt': '2026-09-02T00:00:00Z'},
    ]
    def stub(method, path, params=None, **kw):
        return {'tickets': [
            {'ticket_number': 900, 'id': 'U900'},
            {'ticket_number': 901, 'id': 'U901'},
        ]}, None
    with patch.object(fa, '_api', side_effect=stub):
        fa._index_imported_tickets({'tickets': tickets}, {})
    rows = {r['ticket_number']: r['native_id'] for r in _mem.execute(
        "SELECT ticket_number, native_id FROM native_ticket_index WHERE ticket_number IN (900, 901)"
    ).fetchall()}
    assert rows == {900: 'U900', 901: 'U901'}
    _cleanup()


def test_I2_unresolvable_ticket_is_silently_skipped():
    _cleanup()
    with patch.object(fa, '_api', return_value=({'tickets': []}, None)):
        fa._index_imported_tickets({'tickets': [{'ticketNumber': 902}]}, {})  # must not raise
    assert _mem.execute(
        "SELECT COUNT(*) FROM native_ticket_index WHERE ticket_number=902"
    ).fetchone()[0] == 0
    _cleanup()


def test_I3_single_ticket_request_shape_still_works():
    """Body without a 'tickets' wrapper (single-ticket import shape)."""
    _cleanup()
    with patch.object(fa, '_api', return_value=({'tickets': [{'ticket_number': 903, 'id': 'U903'}]}, None)):
        fa._index_imported_tickets({'ticketNumber': 903, 'createdAt': '2026-09-01T00:00:00Z'}, {})
    assert _mem.execute(
        "SELECT native_id FROM native_ticket_index WHERE ticket_number=903"
    ).fetchone()['native_id'] == 'U903'
    _cleanup()
