"""Per-store takedown: one store only, never the song-wide takedown, never a label flip."""
import freecords_admin as fa
from flask import Flask


def _call(monkeypatch, body, api):
    logged = []
    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa, '_log_local_moderation_action', lambda *a, **k: logged.append((a, k)))
    app = Flask(__name__)
    with app.test_request_context(json=body):
        return fa.fadmin_song_takedown_store(), logged


def test_calls_the_store_takedown_endpoint_with_song_and_delivery(monkeypatch):
    calls = []
    api = lambda method, path, **kw: (calls.append((method, path, kw.get('json'))) or ({'success': True}, None))
    resp, logged = _call(monkeypatch, {'songId': 's1', 'deliveryId': 'd1'}, api)
    assert calls == [('POST', '/api/admin/ddex/takedown-nuemeta-store', {'songId': 's1', 'deliveryId': 'd1'})]
    assert resp.get_json() == {'success': True}
    assert logged and logged[0][0][0] == 'takedown_store'


def test_never_flips_the_song_label_or_uses_the_song_wide_takedown(monkeypatch):
    calls = []
    api = lambda method, path, **kw: (calls.append((method, path)) or ({}, None))
    _call(monkeypatch, {'songId': 's1', 'deliveryId': 'd1'}, api)
    assert all(m == 'POST' for m, _ in calls)
    assert not any('nuemeta-dsp-action' in p or '/api/admin/song/' in p for _, p in calls)


def test_missing_ids_are_rejected_without_calling_freecords(monkeypatch):
    calls = []
    api = lambda *a, **k: (calls.append(a) or ({}, None))
    for body in ({'songId': 's1'}, {'deliveryId': 'd1'}, {}):
        resp, _ = _call(monkeypatch, body, api)
        assert resp[1] == 400
    assert calls == []


def test_api_failure_is_reported_and_not_logged_as_done(monkeypatch):
    resp, logged = _call(monkeypatch, {'songId': 's1', 'deliveryId': 'd1'}, lambda *a, **k: (None, 'boom'))
    body, code = resp
    assert code == 503 and body.get_json()['error'] == 'boom'
    assert logged == []
