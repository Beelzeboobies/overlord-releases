"""
Saved ticket lists (16 Nov 2026). Freecords' ticket-list call took 8-12 s per page and calls go one at a time, so a
cold scan of the Open view (757 tickets = 8 pages) was ~90 s of "Loading...", and every close or reply threw the
saved scan away. Now a scan older than the TTL is shown at once and refreshed once in the background, the saved
scans survive a restart, and a close / assignment edits them in place.
"""
import json
import time
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _clean():
    fa._scan_cache.clear()
    fa._scan_refreshing.clear()
    fa._scan_disk['loaded'] = True          # tests never read the real saved file
    fa._scan_tl.stale = False
    _mem.execute("CREATE TABLE IF NOT EXISTS ticket_closed_at (ticket_number INTEGER PRIMARY KEY, closed_at TEXT)")
    _mem.execute("CREATE TABLE IF NOT EXISTS ticket_awaiting_reply (ticket_number INTEGER PRIMARY KEY, marked_at TEXT)")
    _mem.execute("DELETE FROM ticket_activity")
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (900, 'T900')")
    _mem.commit()
    fa._my_identity_cache.update({'name': None, 'id': None, 'at': 0})
    yield
    fa._scan_cache.clear()


def _t(i, status='open', **kw):
    return {'id': f'T{i}', 'ticket_number': i, 'status': status, 'created_at': '2026-11-10T10:00:00Z',
            'assignee_id': None, 'priority': 'medium', 'tags': [], **kw}


def _api_pages(total, log, status='open', tag='new'):
    def api(method, path, params=None, **kw):
        log.append(params['page'])
        return {'tickets': [_t(f"{tag}{params['page']}-{i}", status) for i in range(3)],
                'pagination': {'total': total}}, None
    return api


def _wait(cond, seconds=3):
    end = time.time() + seconds
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


KEY_OPEN = json.dumps({'status': 'open'}, sort_keys=True)


def _put(params, tickets, age=0, capped=False, total=None):
    fa._scan_cache[json.dumps(params, sort_keys=True)] = {
        'at': time.time() - age, 'tickets': list(tickets), 'total': len(tickets) if total is None else total,
        'capped': capped, 'params': dict(params)}


# ── stale-while-refreshing ─────────────────────────────────────────────────────
def test_a_scan_older_than_the_ttl_is_shown_at_once_and_refreshed_once_in_the_background():
    old = [_t(1), _t(2)]
    _put({'status': 'open'}, old, age=fa._SCAN_TTL + 60)
    log = []
    with patch.object(fa, '_api', _api_pages(150, log)):
        got, total, capped, err = fa._fetch_all_matching_tickets({'status': 'open'})
        assert [t['id'] for t in got] == ['T1', 'T2'] and err is None       # the OLD list, immediately
        assert getattr(fa._scan_tl, 'stale', False) is True
        fa._fetch_all_matching_tickets({'status': 'open'})                  # a second view while it refreshes
        assert _wait(lambda: fa._scan_cache[KEY_OPEN]['tickets'][0]['id'].startswith('Tnew'))
    assert sorted(set(log)) == [1, 2]                                       # ONE refresh: pages 1 and 2, once each
    assert _wait(lambda: not fa._scan_refreshing)


def test_a_fresh_scan_is_served_without_any_refresh():
    _put({'status': 'open'}, [_t(1)], age=5)
    log = []
    with patch.object(fa, '_api', _api_pages(150, log)):
        got, *_ = fa._fetch_all_matching_tickets({'status': 'open'})
    assert [t['id'] for t in got] == ['T1'] and log == [] and not getattr(fa._scan_tl, 'stale', False)


def test_a_scan_older_than_the_stale_limit_is_scanned_cold():
    _put({'status': 'open'}, [_t(1)], age=fa._SCAN_STALE_MAX + 60)
    log = []
    with patch.object(fa, '_api', _api_pages(100, log)):
        got, *_ = fa._fetch_all_matching_tickets({'status': 'open'})
    assert got[0]['id'].startswith('Tnew') and log == [1]


def test_a_background_refresh_that_breaks_off_keeps_the_complete_saved_scan():
    _put({'status': 'open'}, [_t(1), _t(2)], age=fa._SCAN_TTL + 60)

    def api(method, path, params=None, **kw):
        if params['page'] == 2:
            return None, 'HTTP 504'
        return {'tickets': [_t('x')], 'pagination': {'total': 500}}, None

    with patch.object(fa, '_api', api):
        fa._fetch_all_matching_tickets({'status': 'open'})
        assert _wait(lambda: not fa._scan_refreshing)
    assert [t['id'] for t in fa._scan_cache[KEY_OPEN]['tickets']] == ['T1', 'T2']


def test_the_list_route_tells_the_screen_when_it_was_answered_from_a_saved_scan():
    from flask import Flask
    app = Flask(__name__)
    app.testing = True
    app.register_blueprint(fa.bp)
    _put({'status': 'open'}, [_t(1)], age=fa._SCAN_TTL + 60)
    with patch.object(fa, '_api', _api_pages(100, [])), patch.object(fa, '_index_listed_tickets'):
        d = app.test_client().get('/api/fadmin/tickets?status=open&page=1&limit=30').get_json()
        assert d['pagination']['stale'] is True
        assert _wait(lambda: not fa._scan_refreshing)
        _put({'status': 'open'}, [_t(1)], age=1)
        d2 = app.test_client().get('/api/fadmin/tickets?status=open&page=1&limit=30').get_json()
    assert d2['pagination']['stale'] is False


# ── edited in place ────────────────────────────────────────────────────────────
def test_closing_a_ticket_moves_it_from_the_saved_open_list_to_the_saved_closed_list():
    _put({'status': 'open'}, [_t(1), _t(2), _t(3)], total=3)
    _put({'status': 'closed'}, [_t(9, 'closed')], total=1)
    fa._scan_cache_apply_change('T2', {'status': 'closed', 'assignee_id': 'me'})
    openl = fa._scan_cache[KEY_OPEN]
    closed = fa._scan_cache[json.dumps({'status': 'closed'}, sort_keys=True)]
    assert [t['id'] for t in openl['tickets']] == ['T1', 'T3'] and openl['total'] == 2
    assert closed['tickets'][0]['id'] == 'T2' and closed['tickets'][0]['assignee_id'] == 'me' and closed['total'] == 2


def test_a_closed_ticket_is_not_added_to_a_saved_list_filtered_for_someone_else():
    _put({'status': 'open'}, [_t(1)], total=1)
    _put({'status': 'closed', 'assignee': 'someone-else'}, [], total=0)
    fa._scan_cache_apply_change('T1', {'status': 'closed', 'assignee_id': 'me'})
    assert fa._scan_cache[json.dumps({'status': 'closed', 'assignee': 'someone-else'}, sort_keys=True)]['tickets'] == []


def test_assigning_updates_the_assignee_in_every_saved_list_that_still_matches_and_drops_it_from_the_others():
    _put({'status': 'open'}, [_t(1, assignee_id='a')], total=1)
    _put({'status': 'open', 'assignee': 'a'}, [_t(1, assignee_id='a')], total=1)
    fa._scan_cache_apply_change('T1', {'assignee_id': 'b'})
    assert fa._scan_cache[KEY_OPEN]['tickets'][0]['assignee_id'] == 'b'
    mine = fa._scan_cache[json.dumps({'status': 'open', 'assignee': 'a'}, sort_keys=True)]
    assert mine['tickets'] == [] and mine['total'] == 0


def test_a_list_made_with_a_filter_that_cannot_be_judged_keeps_the_ticket_updated():
    _put({'status': 'open', 'q': 'refund'}, [_t(1)], total=1)
    fa._scan_cache_apply_change('T1', {'status': 'closed'})
    ent = fa._scan_cache[json.dumps({'status': 'open', 'q': 'refund'}, sort_keys=True)]
    assert ent['tickets'][0]['status'] == 'closed'      # left for the normal refresh, not silently deleted


# ── the routes ────────────────────────────────────────────────────────────────
@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def test_closing_through_the_route_updates_the_saved_lists_and_does_not_rescan(fclient):
    _put({'status': 'open'}, [_t(900), _t(901)], total=2)
    _put({'status': 'closed'}, [], total=0)
    calls = []

    def api(method, path, **kw):
        calls.append((method, path))
        if path == '/api/admin/me':
            return {'id': 'admin-1', 'username': 'Nguyen'}, None
        return {'success': True}, None

    with patch.object(fa, '_api', api):
        r = fclient.patch('/api/fadmin/tickets/T900', json={'status': 'closed'})
    assert r.status_code == 200
    openl = fa._scan_cache[KEY_OPEN]['tickets']
    closed = fa._scan_cache[json.dumps({'status': 'closed'}, sort_keys=True)]['tickets']
    assert [t['id'] for t in openl] == ['T901']
    assert closed[0]['id'] == 'T900' and closed[0]['assignee_id'] == 'admin-1' and closed[0]['assignee_username'] == 'Nguyen'
    assert not [c for c in calls if c[1] == '/api/admin/tickets' and c[0] == 'GET']      # no list scan was started


def test_an_explicit_assignment_updates_the_saved_lists(fclient):
    _put({'status': 'open'}, [_t(900)], total=1)
    with patch.object(fa, '_api', lambda *a, **k: ({'success': True}, None)):
        fclient.patch('/api/fadmin/tickets/T900', json={'assigneeId': 'agent-7'})
    assert fa._scan_cache[KEY_OPEN]['tickets'][0]['assignee_id'] == 'agent-7'


def test_replying_through_overlords_own_mail_path_keeps_the_saved_lists(fclient):
    _put({'status': 'open'}, [_t(900)], total=1, age=5)
    before = dict(fa._scan_cache)
    detail = {'ticket': {'id': 'T900', 'ticket_number': 900, 'requester_email': 'a@example.com', 'subject': 's',
                         'thread_ref': 'tkabc', 'replyAddress': 'support+tkabc@freecords.com'}, 'messages': []}

    def api(method, path, **kw):
        if method == 'GET':
            return detail, None
        return {'success': True}, None

    with patch.object(fa, '_api', api), patch.object(fa, 'get_all_accounts', return_value=['support@freecords.com']), \
         patch.object(fa, '_do_send', return_value=(True, '', 0)):
        r = fclient.post('/api/fadmin/tickets/T900/reply', json={'body': '<p>hi</p>'})
    assert r.status_code == 200
    assert fa._scan_cache.keys() == before.keys() and fa._scan_cache[KEY_OPEN]['tickets'][0]['id'] == 'T900'
    assert time.time() - fa._scan_cache[KEY_OPEN]['at'] < fa._SCAN_TTL          # still fresh, not expired


# ── survives a restart ─────────────────────────────────────────────────────────
def test_saved_scans_are_written_to_disk_and_come_back_after_a_restart(tmp_path):
    path = tmp_path / 'ticket_scan_cache.json'
    _put({'status': 'open'}, [_t(1), _t(2)], total=2, age=30)
    with patch.object(fa, '_scan_disk_path', lambda: path):
        fa._scan_disk_save()
        assert path.exists()
        fa._scan_cache.clear()
        fa._scan_disk['loaded'] = False
        fa._scan_disk_load_once()
    assert [t['id'] for t in fa._scan_cache[KEY_OPEN]['tickets']] == ['T1', 'T2']
    assert fa._scan_cache[KEY_OPEN]['params'] == {'status': 'open'}


def test_a_scan_saved_longer_ago_than_the_stale_limit_is_not_brought_back(tmp_path):
    path = tmp_path / 'ticket_scan_cache.json'
    _put({'status': 'open'}, [_t(1)], age=fa._SCAN_STALE_MAX + 100)
    with patch.object(fa, '_scan_disk_path', lambda: path):
        fa._scan_disk_save()
        fa._scan_cache.clear()
        fa._scan_disk['loaded'] = False
        fa._scan_disk_load_once()
    assert fa._scan_cache == {}


def test_a_damaged_saved_file_just_means_a_cold_start(tmp_path):
    path = tmp_path / 'ticket_scan_cache.json'
    path.write_text('{ not json', encoding='utf-8')
    with patch.object(fa, '_scan_disk_path', lambda: path):
        fa._scan_disk['loaded'] = False
        fa._scan_disk_load_once()
    assert fa._scan_cache == {}


def test_nothing_is_written_to_disk_while_tests_run():
    assert fa._scan_disk_path() is None
