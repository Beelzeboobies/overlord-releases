"""A takedown must send the DSP takedown AND flip distribution_status to
Takedown - the DSP route alone doesn't, and songs reverted to Approved."""
import freecords_admin as fa
from flask import Flask


def _client(monkeypatch, put_error=None, dsp_error=None):
    calls = []

    def api(method, path, json=None, **kw):
        calls.append((method, path, json))
        if path.endswith('/nuemeta-dsp-action'):
            return (None, dsp_error) if dsp_error else ({'success': True}, None)
        if method == 'PUT':
            return (None, put_error) if put_error else ({'message': 'ok'}, None)
        return {}, None
    monkeypatch.setattr(fa, '_api', api)
    monkeypatch.setattr(fa, '_log_local_moderation_action', lambda *a, **k: None)
    app = Flask(__name__)
    app.register_blueprint(fa.bp)
    return app.test_client(), calls


def test_takedown_sends_dsp_action_then_flips_status(monkeypatch):
    c, calls = _client(monkeypatch)
    r = c.post('/api/fadmin/takedown', json={'song_id': 's1'})
    assert r.status_code == 200 and 'status_flip_error' not in r.get_json()
    assert calls[0][1].endswith('/nuemeta-dsp-action') and calls[0][2]['deliveryType'] == 'TakeDown'
    assert calls[1] == ('PUT', '/api/admin/song/s1', {'distribution_status': 'Takedown'})


def test_song_takedown_and_dsp_action_takedown_also_flip(monkeypatch):
    for path, body in (('/api/fadmin/song-takedown', {'songId': 's2'}),
                       ('/api/fadmin/song-dsp-action', {'songId': 's2', 'deliveryType': 'TakeDown'})):
        c, calls = _client(monkeypatch)
        assert c.post(path, json=body).status_code == 200
        assert ('PUT', '/api/admin/song/s2', {'distribution_status': 'Takedown'}) in calls


def test_other_dsp_actions_do_not_touch_status(monkeypatch):
    c, calls = _client(monkeypatch)
    c.post('/api/fadmin/song-dsp-action', json={'songId': 's3', 'deliveryType': 'FullUpdate'})
    assert not any(m == 'PUT' for m, *_ in calls)


def test_failed_flip_is_reported_but_takedown_still_succeeds(monkeypatch):
    c, _ = _client(monkeypatch, put_error='boom')
    r = c.post('/api/fadmin/takedown', json={'song_id': 's4'})
    assert r.status_code == 200 and r.get_json()['status_flip_error'] == 'boom'


def test_failed_dsp_takedown_does_not_flip_status(monkeypatch):
    c, calls = _client(monkeypatch, dsp_error='nope')
    assert c.post('/api/fadmin/takedown', json={'song_id': 's5'}).status_code == 503
    assert not any(m == 'PUT' for m, *_ in calls)
