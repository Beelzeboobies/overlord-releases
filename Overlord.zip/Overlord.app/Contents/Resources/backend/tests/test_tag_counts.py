"""
GET /api/fadmin/tickets/tag-counts — correctness after parallelizing the
page-scan and per-tag follow-up passes (2026-09-08, "slow loading issues
again": both used to run one request at a time, confirmed live at 3.3s on
a cold cache). Same output as the old sequential version, just concurrent.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


@pytest.fixture(autouse=True)
def _reset_cache():
    fa._tag_counts_cache.update(at=0, key=None, counts={})


PAGE1 = {
    'tickets': [{'tags': ['Cover Art']}, {'tags': []}, {'tags': ['Cover Art', 'Copyright']}],
    'pagination': {'total': 150},  # >100 so page 2 is actually needed
}
PAGE2 = {
    'tickets': [{'tags': []}, {'tags': ['Copyright']}],
    'pagination': {'total': 150},
}


def _api_stub(method, path, params=None, **kw):
    params = params or {}
    if 'tag' in params:
        counts = {'Cover Art': 2, 'Copyright': 2}
        return {'pagination': {'total': counts.get(params['tag'], 0)}}, None
    if params.get('page') == 1:
        return PAGE1, None
    if params.get('page') == 2:
        return PAGE2, None
    return {'tickets': [], 'pagination': {'total': 5}}, None


def test_TC1_counts_correct_across_multiple_pages(fclient):
    with patch.object(fa, '_api', side_effect=_api_stub):
        r = fclient.get('/api/fadmin/tickets/tag-counts?status=open')
    counts = r.get_json()['counts']
    assert counts['Cover Art'] == 2
    assert counts['Copyright'] == 2
    assert counts['__untagged__'] == 2  # one blank ticket per page


def test_TC2_single_page_when_total_fits(fclient):
    def stub(method, path, params=None, **kw):
        params = params or {}
        if 'tag' in params:
            return {'pagination': {'total': 1}}, None
        return {'tickets': [{'tags': ['Solo']}], 'pagination': {'total': 1}}, None
    with patch.object(fa, '_api', side_effect=stub) as api:
        r = fclient.get('/api/fadmin/tickets/tag-counts?status=open&force=1')
    assert r.get_json()['counts'] == {'Solo': 1}
    # One page-scan call + one tag-count call, no wasted page-2+ calls.
    assert api.call_count == 2


def test_TC3_a_failed_page_is_skipped_not_fatal(fclient):
    def stub(method, path, params=None, **kw):
        params = params or {}
        if 'tag' in params:
            return {'pagination': {'total': 1}}, None
        if params.get('page') == 2:
            return None, 'boom'
        return {'tickets': [{'tags': ['X']}], 'pagination': {'total': 300}}, None
    with patch.object(fa, '_api', side_effect=stub):
        r = fclient.get('/api/fadmin/tickets/tag-counts?status=open&force=1')
    assert r.status_code == 200
    assert 'X' in r.get_json()['counts']
