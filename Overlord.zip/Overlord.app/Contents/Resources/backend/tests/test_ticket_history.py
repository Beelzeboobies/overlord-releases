"""
Tickets "History" — every ticket any agent has replied to or changed the
status of, most-recent-activity first, tagged with who did it. **User,
directly** (2026-09-08), choosing this scope over "just Closed, renamed":
"every ticket any agent has touched... but so that there is also clear and
immediate indication of which agent touched it."
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("DELETE FROM ticket_activity")
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.commit()
    fa._my_identity_cache['name'] = None
    fa._my_identity_cache['at'] = 0


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _index(ticket_number, native_id):
    _mem.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (?,?)", (ticket_number, native_id))
    _mem.commit()


class TestRecordActivity:

    def test_A1_my_agent_name_resolves_and_caches(self):
        with patch.object(fa, '_api', return_value=({'username': 'Trismegistus'}, None)) as api:
            assert fa._my_agent_name() == 'Trismegistus'
            assert fa._my_agent_name() == 'Trismegistus'
        api.assert_called_once()  # second call served from cache

    def test_A2_status_patch_records_activity_with_agent(self, fclient):
        _index(300, 'U300')
        def _api_stub(method, path, **kw):
            if method == 'PATCH':
                return {'success': True}, None
            return {'username': 'Nguyen'}, None
        with patch.object(fa, '_api', side_effect=_api_stub):
            fclient.patch('/api/fadmin/tickets/U300', json={'status': 'closed'})
        row = _mem.execute(
            "SELECT action, agent_name FROM ticket_activity WHERE ticket_number=300"
        ).fetchone()
        assert row['action'] == 'status_changed:closed'
        assert row['agent_name'] == 'Nguyen'

    def test_A3_reply_records_activity(self, fclient):
        _index(301, 'U301')
        # fadmin_ticket_reply now always fetches ticket detail first (to
        # check requester_email for the takedown-artist-redirect case) —
        # that GET needs a real ticket shape, distinct from the agent-name
        # lookup's GET /api/admin/me.
        def _api_stub(method, path, **kw):
            if method == 'POST':
                return {'success': True}, None
            if path == '/api/admin/tickets/U301':
                return {'ticket': {'id': 'U301', 'requester_email': 'artist@example.com'}, 'messages': []}, None
            return {'username': 'Deshad'}, None
        with patch.object(fa, '_api', side_effect=_api_stub):
            fclient.post('/api/fadmin/tickets/U301/reply', json={'body': 'hi'})
        row = _mem.execute(
            "SELECT action, agent_name FROM ticket_activity WHERE ticket_number=301"
        ).fetchone()
        assert row['action'] == 'replied'
        assert row['agent_name'] == 'Deshad'

    def test_A4_activity_recording_failure_does_not_break_the_reply(self, fclient):
        """_record_activity is best-effort — a broken agent-name lookup
        must never surface as a failed reply."""
        _index(302, 'U302')
        def _api_stub(method, path, **kw):
            if method == 'POST':
                return {'success': True}, None
            if path == '/api/admin/tickets/U302':
                return {'ticket': {'id': 'U302', 'requester_email': 'artist@example.com'}, 'messages': []}, None
            raise RuntimeError('boom')
        with patch.object(fa, '_api', side_effect=_api_stub):
            r = fclient.post('/api/fadmin/tickets/U302/reply', json={'body': 'hi'})
        assert r.status_code == 200


class TestHistoryView:

    def test_H1_most_recent_activity_first(self, fclient):
        _index(400, 'U400'); _index(401, 'U401')
        _mem.execute("INSERT INTO ticket_activity (ticket_number, action, agent_name, at) VALUES (400,'replied','A','2026-09-08T10:00:00')")
        _mem.execute("INSERT INTO ticket_activity (ticket_number, action, agent_name, at) VALUES (401,'replied','B','2026-09-08T12:00:00')")
        _mem.commit()
        def _get(uuid_ticket):
            return {'ticket': {'id': uuid_ticket, 'ticket_number': 400 if uuid_ticket == 'U400' else 401}}, None
        with patch.object(fa, '_api', side_effect=lambda m, p, **kw: _get(p.rsplit('/', 1)[-1])):
            r = fclient.get('/api/fadmin/tickets?history=1&page=1&limit=30')
        d = r.get_json()
        assert [t['ticket_number'] for t in d['tickets']] == [401, 400]
        assert d['tickets'][0]['_lastActivity']['agent_name'] == 'B'

    def test_H2_no_activity_returns_empty_without_calling_api(self, fclient):
        with patch.object(fa, '_api') as api:
            r = fclient.get('/api/fadmin/tickets?history=1&page=1&limit=30')
        api.assert_not_called()
        assert r.get_json()['tickets'] == []

    def test_H3_second_event_on_same_ticket_uses_the_newer_one(self, fclient):
        """Same ticket replied to, then later closed — history shows the
        latest event (closed), not the first."""
        _index(402, 'U402')
        _mem.execute("INSERT INTO ticket_activity (ticket_number, action, agent_name, at) VALUES (402,'replied','A','2026-09-08T09:00:00')")
        _mem.execute("INSERT INTO ticket_activity (ticket_number, action, agent_name, at) VALUES (402,'status_changed:closed','A','2026-09-08T11:00:00')")
        _mem.commit()
        with patch.object(fa, '_api', return_value=({'ticket': {'id': 'U402', 'ticket_number': 402}}, None)):
            r = fclient.get('/api/fadmin/tickets?history=1&page=1&limit=30')
        assert r.get_json()['tickets'][0]['_lastActivity']['action'] == 'status_changed:closed'

    def test_H4_plain_list_without_history_param_is_unaffected(self, fclient):
        with patch.object(fa, '_api', return_value=({'tickets': [], 'pagination': {'total': 0}}, None)) as api:
            fclient.get('/api/fadmin/tickets?page=1&limit=30')
        api.assert_called_once()
        assert api.call_args[0][1] == '/api/admin/tickets'
