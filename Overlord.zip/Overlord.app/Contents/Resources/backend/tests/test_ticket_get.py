"""
GET /api/fadmin/tickets/<id> — a deleted/merged remote ticket must surface
as a real error, not a fake-successful empty response.

Real bug found live (2026-09-08, ticket #9824): freecords_client._api()
returns a 404 as ({'_not_found': True}, None) — err is None — so this
route used to fall through to `jsonify(data or {})`, returning 200 with a
body carrying no messages/notes/error key at all. The frontend rendered
that identically to a genuinely-empty ticket ("no messages captured"),
completely hiding that the ticket itself no longer exists remotely.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _table():
    _mem.execute("DELETE FROM ticket_read_state")
    _mem.commit()


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def test_G1_not_found_surfaces_as_a_real_error(fclient):
    with patch.object(fa, '_api', return_value=({'_not_found': True}, None)):
        r = fclient.get('/api/fadmin/tickets/deleted-uuid')
    assert r.status_code == 404
    assert 'no longer exists' in r.get_json()['error']


def test_G2_not_found_does_not_mark_read_state(fclient):
    """A ticket that doesn't exist anymore shouldn't get a read-state row —
    there's nothing real to mark as read."""
    with patch.object(fa, '_api', return_value=({'_not_found': True}, None)):
        fclient.get('/api/fadmin/tickets/deleted-uuid')
    assert _mem.execute(
        "SELECT COUNT(*) FROM ticket_read_state WHERE ticket_id='deleted-uuid'"
    ).fetchone()[0] == 0


def test_G3_genuine_ticket_still_loads_and_marks_read(fclient):
    real = {'ticket': {'id': 'T1'}, 'messages': [], 'notes': []}
    with patch.object(fa, '_api', return_value=(real, None)):
        r = fclient.get('/api/fadmin/tickets/T1')
    assert r.status_code == 200
    assert r.get_json() == real
    assert _mem.execute(
        "SELECT COUNT(*) FROM ticket_read_state WHERE ticket_id='T1'"
    ).fetchone()[0] == 1


def test_G4_upstream_error_still_returns_503():
    """Unrelated regression guard — a real transport/API error (not a 404)
    must keep returning 503, not get swept into the new 404 branch."""
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    client = a.test_client()
    with patch.object(fa, '_api', return_value=(None, 'connection refused')):
        r = client.get('/api/fadmin/tickets/T1')
    assert r.status_code == 503
