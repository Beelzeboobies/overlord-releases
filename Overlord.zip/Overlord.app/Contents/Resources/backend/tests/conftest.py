"""
Shared stubs and fixtures for the Overlord backend test suite.

Module-level code here runs before any test module is collected, so all
stubs are in place when imap.py, messages.py, etc. first load.
Shared constants and the in-memory DB live in backend/test_support.py so
test modules can import from it directly (backend/ is in sys.path).
"""
import pytest
from unittest.mock import MagicMock

# ── 1. Shared constants + in-memory DB ───────────────────────────────────────
from test_support import TEST_ACCT, _mem, _NC, seed_message

# ── 2. Stub keyring (no stored passwords, no keychain writes) ─────────────────
import keyring as _kr
_kr.get_password    = lambda *a, **kw: None
_kr.set_password    = lambda *a, **kw: None
_kr.delete_password = lambda *a, **kw: None

# ── 3. Stub config constants ──────────────────────────────────────────────────
import config as _cfg
_cfg.KEYRING_SERVICE   = 'overlord-test'
_cfg.DEFAULT_IMAP_HOST = 'imap.example.com'
_cfg.DEFAULT_IMAP_PORT = 993

# ── 4. Redirect all get_db() calls to the in-memory DB ───────────────────────
#
# IMPORT-ORDER CONTRACT — read before adding new test files
# ─────────────────────────────────────────────────────────
# Python's import cache means that `from db import get_db` in any app module
# (imap.py, messages.py, …) captures the function object at the moment that
# module is first imported.  Because conftest.py is loaded by pytest BEFORE any
# test module, the assignment below wins: every app module that is subsequently
# imported via `import imap` / `import messages` etc. (lines below in this
# file) binds get_db to `lambda: _NC(_mem)`.
#
# Consequence: a future test file that does `_db_mod.get_db = <something else>`
# at module level will have NO effect on app modules already in the import
# cache.  The re-assignment changes db.get_db (the module attribute) but NOT
# the closure already stored in imap.get_db, messages.get_db, etc.  It will be
# silently inert.  Verified empirically: test_fetch_and_cache.py used to do
# exactly this and fetch_and_cache always wrote to _mem regardless.
#
# Rule: never re-patch db.get_db in a test file.  Use seed_message() to
# pre-populate _mem, and read _mem directly for DB assertions.
import db as _db_mod
_db_mod.get_db = lambda: _NC(_mem)

# ── 5. Stub parsing helpers used by fetch_and_cache ──────────────────────────
import parsing as _p
_p._addr            = lambda addrs: ('', '') if not addrs else ('Name', 'addr@example.com')
_p._addr_list       = lambda addrs: ''
_p._decode_env      = lambda v: str(v) if v else ''
_p.check_attachment = lambda bstr: (False, [])

# ── 6. Safe to import app modules now ────────────────────────────────────────
import imap
import auth
import messages as messages_mod
import send as send_mod
import folders as folders_mod
import rules as rules_mod
import rules_engine


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _clean():
    """Wipe mutable state before every test."""
    # DB tables
    for tbl in ('message_cache', 'email_meta', 'scheduled_sends',
                 'rules', 'contacts', 'account_configs'):
        _mem.execute(f"DELETE FROM {tbl}")
    _mem.commit()

    # imap module globals
    imap._accounts_cache = None
    imap._folder_maps.clear()
    imap._folder_delimiters.clear()
    imap._bg_imap_clients.clear()
    imap._draft_folder_cache.clear()
    imap._sent_folder_cache.clear()
    imap._search_total_cache.clear()
    imap._unread_cache.clear()
    imap._total_cache.clear()
    imap._folder_cache.clear()

    yield

    # Post-test: clear thread-local connection for TEST_ACCT
    attr = imap._tl_attr(TEST_ACCT)
    if hasattr(imap._thread_local, attr):
        setattr(imap._thread_local, attr, None)


@pytest.fixture
def mock_imap():
    m = MagicMock()
    m.fetch.return_value = {}
    m.search.return_value = []
    m.select_folder.return_value = {b'EXISTS': 0}
    m.list_folders.return_value = []
    m.noop.return_value = None
    return m


@pytest.fixture
def logged_in(mock_imap):
    """
    Simulate a logged-in session for TEST_ACCT.

    Sets imap._accounts_cache so get_all_accounts() returns [TEST_ACCT]
    without touching keyring, and plants mock_imap in the thread-local
    slot so imap_connect() returns it immediately (noop check passes).
    """
    imap._accounts_cache = [TEST_ACCT]
    attr = imap._tl_attr(TEST_ACCT)
    setattr(imap._thread_local, attr, mock_imap)
    yield mock_imap


@pytest.fixture
def app():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(auth.bp)
    a.register_blueprint(messages_mod.bp)
    a.register_blueprint(send_mod.bp)
    a.register_blueprint(folders_mod.bp)
    a.register_blueprint(rules_mod.bp)
    return a


@pytest.fixture
def client(app):
    return app.test_client()
