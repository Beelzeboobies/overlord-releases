"""The startup ticket-index backfill must be incremental (2026-10-19 Freecords incident) and
must never fire requests in parallel or in a tight loop. Fakes only - no live calls."""
import random
import sqlite3

import ticket_index


def _db(tmp_path, have):
    path = str(tmp_path / 'idx.db')
    c = sqlite3.connect(path)
    c.execute("""CREATE TABLE native_ticket_index (ticket_number INTEGER PRIMARY KEY, native_id TEXT, requester_email TEXT,
                 subject TEXT, created_at TEXT, status TEXT, thread_ref TEXT)""")
    for n in have:
        c.execute("INSERT INTO native_ticket_index VALUES (?,?,?,?,?,?,?)", (n, f'id{n}', 'a@b.c', 's', f'2026-01-01T00:{n % 60:02d}:00Z', 'open', 'ref'))
    c.commit()
    c.close()

    def get_db():
        conn = sqlite3.connect(path)
        conn.row_factory = sqlite3.Row
        return conn
    return get_db


def _count(get_db):
    c = get_db()
    n = c.execute("SELECT COUNT(*) AS n FROM native_ticket_index").fetchone()['n']
    c.close()
    return n


def _upstream(numbers, newest_first=True, fail_after=None):
    """Fake Freecords: `numbers` are the tickets that exist; created_at grows with the number."""
    nums = sorted(numbers, reverse=newest_first)
    if not newest_first:
        random.Random(1).shuffle(nums)
    calls = []

    def api_get(params):
        calls.append(dict(params))
        if fail_after is not None and len(calls) > fail_after:
            return None, 'HTTP 504'
        if params.get('limit') == 1:
            return {'tickets': [], 'pagination': {'total': len(nums)}}, None
        p, lim = params['page'], params['limit']
        chunk = nums[(p - 1) * lim:p * lim]
        return {'tickets': [{'ticket_number': n, 'id': f'id{n}', 'requester_email': 'x@y.z', 'subject': 's',
                             'created_at': f'2026-02-{(n // 1000) % 28 + 1:02d}T{(n // 60) % 24:02d}:{n % 60:02d}:00Z',
                             'status': 'open', 'thread_ref': 'r'} for n in chunk],
                'pagination': {'total': len(nums)}}, None
    return api_get, calls


def _run(api_get, get_db):
    sleeps = []
    result = ticket_index.run(api_get, get_db, sleep=sleeps.append, log=lambda m: None)
    return result, sleeps


def test_up_to_date_makes_only_the_probe_request(tmp_path):
    db = _db(tmp_path, range(1, 301))
    api, calls = _upstream(range(1, 301))
    result, _ = _run(api, db)
    assert result == 'already up to date' and len(calls) == 1


def test_a_days_new_tickets_cost_one_or_two_pages_not_the_whole_catalogue(tmp_path):
    db = _db(tmp_path, range(1, 5001))                       # index is 40 tickets behind a 5,040 catalogue
    api, calls = _upstream(range(1, 5041))
    result, _ = _run(api, db)
    assert _count(db) == 5040
    assert len(calls) <= 3, calls                            # probe + 1 page (+1 to confirm) - never 51 pages
    assert result.startswith('incremental')


def test_stops_after_two_pages_with_nothing_new_even_if_the_total_is_not_reached(tmp_path):
    db = _db(tmp_path, range(1, 1001))
    api_get, calls = _upstream(range(1, 1021))               # 20 new tickets exist
    # upstream claims 10 more tickets than it will ever show us (e.g. deleted/merged) -> total never reached
    real = api_get

    def api(params):
        data, err = real(params)
        if data:
            data['pagination']['total'] += 10
        return data, err
    result, _ = _run(api, db)
    assert _count(db) == 1020
    assert len(calls) <= 5, calls                            # probe + new page + 2 known pages, not 11 pages
    assert 'caught up' in result


def test_order_that_is_not_newest_first_falls_back_to_a_full_walk(tmp_path):
    db = _db(tmp_path, range(1, 201))
    api, calls = _upstream(range(1, 451), newest_first=False)
    result, _ = _run(api, db)
    assert 'full scan' in result
    assert _count(db) == 450                                 # everything indexed, nothing skipped
    assert len([c for c in calls if c.get('limit') == 100]) == 5


def test_rows_missing_new_columns_force_a_full_walk(tmp_path):
    db = _db(tmp_path, range(1, 301))
    c = db()
    c.execute("UPDATE native_ticket_index SET requester_email=NULL WHERE ticket_number=7")
    c.commit()
    c.close()
    api, calls = _upstream(range(1, 301))                    # same total, but a row needs backfilling
    result, _ = _run(api, db)
    assert 'full scan' in result and len([c for c in calls if c.get('limit') == 100]) == 3


def test_incremental_mode_stops_on_a_failure_instead_of_pushing_on(tmp_path):
    db = _db(tmp_path, range(1, 1001))
    api, calls = _upstream(range(1, 1301), fail_after=1)     # probe works, every page fails
    result, sleeps = _run(api, db)
    assert 'stopped on failure' in result
    assert len(calls) == 1 + 3                               # probe + 3 attempts on page 1, then it gives up
    assert _count(db) == 1000


def test_pauses_between_pages_and_never_goes_parallel(tmp_path):
    db = _db(tmp_path, [])
    api, calls = _upstream(range(1, 451), newest_first=False)   # forces a full walk of 5 pages
    result, sleeps = _run(api, db)
    assert sleeps.count(ticket_index.PACE_SECONDS) == 4         # a pause after each page except the last
