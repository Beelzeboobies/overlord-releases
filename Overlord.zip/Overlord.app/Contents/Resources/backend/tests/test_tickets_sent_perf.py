"""
GET /api/fadmin/tickets?sent=1 — correctness after parallelizing both the
per-UUID fetch loop and the fallback page scan (2026-09-08, "slow loading
issues again"). Same output as the old sequential version, just concurrent.
"""
from unittest.mock import patch

import pytest

import freecords_admin as fa
from test_support import _mem


@pytest.fixture(autouse=True)
def _tables():
    _mem.execute("CREATE TABLE IF NOT EXISTS freshdesk_sync_map (freshdesk_id INTEGER, native_ticket_id TEXT)")
    _mem.execute("DELETE FROM ticket_manually_created")
    _mem.execute("DELETE FROM freshdesk_sync_map")
    _mem.execute("DELETE FROM native_ticket_index")
    _mem.commit()


@pytest.fixture
def fclient():
    from flask import Flask
    a = Flask(__name__)
    a.testing = True
    a.register_blueprint(fa.bp)
    return a.test_client()


def _sent(num):
    _mem.execute("INSERT OR REPLACE INTO ticket_manually_created (ticket_number) VALUES (?)", (num,))
    _mem.commit()


def _index(num, uuid):
    _mem.execute("INSERT INTO native_ticket_index (ticket_number, native_id) VALUES (?,?)", (num, uuid))
    _mem.commit()


def test_S1_all_uuids_known_fetches_each_via_api(fclient):
    _sent(500); _index(500, 'U500')
    _sent(501); _index(501, 'U501')
    fetched = set()
    def stub(method, path, **kw):
        uuid = path.rsplit('/', 1)[-1]
        fetched.add(uuid)
        num = 500 if uuid == 'U500' else 501
        return {'ticket': {'id': uuid, 'ticket_number': num, 'created_at': '2026-09-08T10:00:00Z'}}, None
    with patch.object(fa, '_api', side_effect=stub):
        r = fclient.get('/api/fadmin/tickets?sent=1&page=1&limit=30')
    assert fetched == {'U500', 'U501'}
    d = r.get_json()
    assert {t['ticket_number'] for t in d['tickets']} == {500, 501}
    assert d['pagination']['total'] == 2


def test_S2_unknown_uuid_falls_back_to_page_scan(fclient):
    """A sent ticket with no cached UUID anywhere (composed directly,
    never synced) must still be found via the fallback scan."""
    _sent(600)  # no native_ticket_index / freshdesk_sync_map row at all
    def stub(method, path, params=None, **kw):
        params = params or {}
        if params.get('page') == 1:
            return {'tickets': [{'ticket_number': 600, 'created_at': '2026-09-08T10:00:00Z'}],
                    'pagination': {'total': 1}}, None
        return {'tickets': [], 'pagination': {'total': 1}}, None
    with patch.object(fa, '_api', side_effect=stub):
        r = fclient.get('/api/fadmin/tickets?sent=1&page=1&limit=30')
    assert r.get_json()['pagination']['total'] == 1
    assert r.get_json()['tickets'][0]['ticket_number'] == 600


def test_S3_fallback_scan_spans_multiple_pages(fclient):
    _sent(700)  # unknown UUID, sits on page 2 of the fallback scan
    def stub(method, path, params=None, **kw):
        params = params or {}
        page = params.get('page')
        if page == 1:
            return {'tickets': [{'ticket_number': 999, 'created_at': 't'}], 'pagination': {'total': 150}}, None
        if page == 2:
            return {'tickets': [{'ticket_number': 700, 'created_at': '2026-09-08T10:00:00Z'}], 'pagination': {'total': 150}}, None
        return {'tickets': [], 'pagination': {'total': 150}}, None
    with patch.object(fa, '_api', side_effect=stub):
        r = fclient.get('/api/fadmin/tickets?sent=1&page=1&limit=30')
    numbers = {t['ticket_number'] for t in r.get_json()['tickets']}
    assert 700 in numbers
    assert 999 not in numbers  # not a sent ticket, correctly excluded


def test_S4_no_sent_tickets_returns_empty_without_calling_api(fclient):
    with patch.object(fa, '_api') as api:
        r = fclient.get('/api/fadmin/tickets?sent=1&page=1&limit=30')
    api.assert_not_called()
    assert r.get_json()['tickets'] == []
