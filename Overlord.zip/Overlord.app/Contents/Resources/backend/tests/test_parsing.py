"""
Tests for parsing.extract_plain_body — the shared "best-effort plain text
body from a raw RFC822 message" helper.

Added because main.py's support@freecords.com ticket-creation path used to
re-implement its own body extraction inline, looking only for a text/plain
part. An HTML-only automated sender (e.g. AWS SES notification emails with
no text/plain alternative) silently produced an empty ticket body — the
ticket got created, but with no message content at all. extract_plain_body
wraps the already-shared parse_body() and adds an HTML fallback so that
case can't happen, and is unit-testable without any IMAP mocking.

Run with:
    cd backend
    <app-python> -m pytest tests/test_parsing.py -v
"""

from parsing import extract_plain_body, parse_body


def _msg(headers, body):
    return (headers + '\r\n\r\n' + body).encode()


def test_text_plain_part_is_used_directly():
    raw = _msg(
        'From: a@example.com\r\nSubject: hi\r\nContent-Type: text/plain',
        'hello there',
    )
    assert extract_plain_body(raw) == 'hello there'


def test_html_only_message_falls_back_to_stripped_html():
    raw = (
        b'From: a@example.com\r\n'
        b'Subject: hi\r\n'
        b'Content-Type: text/html\r\n'
        b'\r\n'
        b'<p>Takedown Request Received</p><br>Release: <b>Masango</b>'
    )
    body = extract_plain_body(raw)
    assert 'Takedown Request Received' in body
    assert 'Masango' in body
    assert '<' not in body


def test_multipart_alternative_html_only_falls_back():
    raw = (
        b'From: a@example.com\r\n'
        b'Subject: hi\r\n'
        b'Content-Type: multipart/alternative; boundary="B"\r\n'
        b'\r\n'
        b'--B\r\n'
        b'Content-Type: text/html\r\n'
        b'\r\n'
        b'<div>ACTION REQUIRED</div>\r\n'
        b'--B--\r\n'
    )
    body = extract_plain_body(raw)
    assert body == 'ACTION REQUIRED'


def test_no_usable_content_returns_empty_string():
    raw = _msg('From: a@example.com\r\nSubject: hi\r\nContent-Type: text/plain', '')
    assert extract_plain_body(raw) == ''


def _multipart_takedown_msg():
    """Shape of Freecords' real automated takedown-notification email —
    multipart/alternative with both a text/plain and a text/html part."""
    return (
        b'From: Freecords <freecords@freecords.com>\r\n'
        b'To: info@freecords.com\r\n'
        b'Subject: Takedown Request\r\n'
        b'MIME-Version: 1.0\r\n'
        b'Content-Type: multipart/alternative; boundary="B123"\r\n'
        b'\r\n'
        b'--B123\r\n'
        b'Content-Type: text/plain; charset=utf-8\r\n'
        b'\r\n'
        b'Takedown Request Received\r\n\r\nType: Manual Support Request\r\nRelease: GEE (Single)\r\n'
        b'--B123\r\n'
        b'Content-Type: text/html; charset=utf-8\r\n'
        b'\r\n'
        b'<h2>Takedown Request Received</h2><p>Release: GEE</p>\r\n'
        b'--B123--\r\n'
    )


def test_full_raw_multipart_takedown_email_extracts_plain_part():
    """The fetch path main.py's ticket-creation loop now uses (single
    'RFC822' item, whole message in one blob) must extract real content
    from this exact shape of email — this is what #10644-#10666 lost
    their message content for, see main.py's fetch_support comment."""
    body = extract_plain_body(_multipart_takedown_msg())
    assert 'Takedown Request Received' in body
    assert 'Release: GEE (Single)' in body


def test_header_and_text_fetched_as_separate_imap_items_can_silently_lose_the_body():
    """Documents the actual root cause (not just the fix): RFC822.HEADER
    and RFC822.TEXT are "functionally equivalent" to BODY[HEADER]/BODY[TEXT]
    per RFC 3501 but aren't guaranteed to come back keyed under the same
    name — parsing.py's parse_envelope already has a fallback for HEADER
    (`RFC822.HEADER` or `BODY[HEADER]`); the old ticket-creation code had
    none for TEXT. Simulates that exact failure: the IMAP response dict has
    the header under one key and nothing at all under 'RFC822.TEXT' (as if
    the server answered with 'BODY[TEXT]' instead) — the old code's
    `data_s.get(b'RFC822.TEXT', b'')` silently falls through to b'', losing
    the entire message body with no error anywhere."""
    raw = _multipart_takedown_msg()
    sep = raw.index(b'\r\n\r\n') + 4
    data_s = {b'RFC822.HEADER': raw[:sep]}  # no b'RFC822.TEXT' key at all
    reconstructed = data_s.get(b'RFC822.HEADER', b'') + b'\r\n' + data_s.get(b'RFC822.TEXT', b'')
    assert extract_plain_body(reconstructed) == ''
    # The fix: fetch the single 'RFC822' item, which has no such key to miss.
    assert extract_plain_body(raw) != ''


def test_html_only_list_items_stay_on_separate_lines():
    """Real bug, confirmed live on a Freshdesk canned reply: a numbered
    list of setup steps collapsed into one run-on line because <li> tags
    were silently stripped with no separator, unlike <br>/</p>."""
    raw = (
        b'From: a@example.com\r\n'
        b'Subject: hi\r\n'
        b'Content-Type: text/html\r\n'
        b'\r\n'
        b'<p>Follow these steps:</p>'
        b'<ol><li>Go to your dashboard</li>'
        b'<li>Navigate to your Profile</li>'
        b'<li>Click Fix Issue</li></ol>'
    )
    body = extract_plain_body(raw)
    lines = [l.strip() for l in body.split('\n') if l.strip()]
    assert 'Go to your dashboard' in lines
    assert 'Navigate to your Profile' in lines
    assert 'Click Fix Issue' in lines


def test_real_attachment_with_a_content_id_is_still_listed_as_an_attachment():
    """Real, confirmed live bug (2026-09-08, user-reported): couldn't see
    an artist's attached screenshots at all once the message was opened,
    even though the message-list view correctly showed them present.
    Gmail (and others) commonly stamps a Content-ID on an image even when
    it's sent as a real attachment, not an inline cid:-referenced one —
    parse_body's inline-image detection used to trigger on Content-ID
    alone, swallowing genuine attachments into the inline-image map before
    the actual attachment check ever ran."""
    raw = (
        b'From: artist@example.com\r\n'
        b'Subject: proof\r\n'
        b'Content-Type: multipart/mixed; boundary="B"\r\n'
        b'\r\n'
        b'--B\r\n'
        b'Content-Type: text/plain\r\n'
        b'\r\n'
        b'See attached screenshot.\r\n'
        b'--B\r\n'
        b'Content-Type: image/png\r\n'
        b'Content-ID: <img1>\r\n'
        b'Content-Disposition: attachment; filename="screenshot.png"\r\n'
        b'\r\n'
        b'fakebinarydata\r\n'
        b'--B--\r\n'
    )
    text, html, attachments = parse_body(raw)
    assert len(attachments) == 1
    assert attachments[0]['filename'] == 'screenshot.png'


def test_attachment_filename_with_rfc2047_encoding_is_decoded():
    """Found alongside the Content-ID fix above: email.message_from_bytes's
    get_filename() returns the raw '=?UTF-8?B?...?=' encoded-word string,
    not the real name, unless explicitly decoded — confirmed live with a
    Cyrillic filename showing up as literal encoded gibberish once the
    attachment itself was no longer being swallowed by the Content-ID bug."""
    raw = (
        b'From: artist@example.com\r\n'
        b'Subject: proof\r\n'
        b'Content-Type: multipart/mixed; boundary="B"\r\n'
        b'\r\n'
        b'--B\r\n'
        b'Content-Type: text/plain\r\n'
        b'\r\n'
        b'See attached.\r\n'
        b'--B\r\n'
        b'Content-Type: image/jpeg\r\n'
        b'Content-Disposition: attachment; filename="=?UTF-8?B?0LnQvtGDLmpwZw==?="\r\n'
        b'\r\n'
        b'fakebinarydata\r\n'
        b'--B--\r\n'
    )
    _, _, attachments = parse_body(raw)
    assert len(attachments) == 1
    assert attachments[0]['filename'] == 'йоу.jpg'


def test_genuinely_inline_cid_image_is_not_listed_as_an_attachment():
    """Regression guard for the fix above — an image truly meant to be
    inlined (no attachment disposition) must still resolve via cid_map,
    not start showing up as a spurious attachment."""
    raw = (
        b'From: a@example.com\r\n'
        b'Subject: hi\r\n'
        b'Content-Type: multipart/related; boundary="B"\r\n'
        b'\r\n'
        b'--B\r\n'
        b'Content-Type: text/html\r\n'
        b'\r\n'
        b'<p>Look: <img src="cid:img1"></p>\r\n'
        b'--B\r\n'
        b'Content-Type: image/png\r\n'
        b'Content-ID: <img1>\r\n'
        b'\r\n'
        b'fakebinarydata\r\n'
        b'--B--\r\n'
    )
    text, html, attachments = parse_body(raw)
    assert attachments == []
    assert 'data:image/png;base64,' in html
