"""
A picture pasted into a reply (Nguyen, ticket #71614, 12 Nov 2026).

The editor stores the picture as <img src="data:image/jpeg;base64,...">. Two things went wrong:
  1. the logged copy on the ticket was cut at 20,000 characters inside the picture's data, so the thread showed
     the reply ending at the picture (steps and sign-off after it were lost, although the email itself was whole);
  2. the email carried the picture as a data: URL, which Gmail and others do not display.
"""
import base64
import email
from email import policy
from unittest.mock import patch, MagicMock

import freecords_admin as fa
import helpers as helpers_mod
from test_support import TEST_ACCT

# a real (tiny) PNG so MIMEImage accepts it
PNG = base64.b64decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==')
PNG_B64 = base64.b64encode(PNG).decode()
BIG_B64 = base64.b64encode(b'\x89PNG' + b'x' * 150_000).decode()   # a screenshot-sized blob, far over 20,000 chars


class _NoThread:
    def __init__(self, *a, **kw): pass
    def start(self): pass


def _send(body):
    mock_smtp = MagicMock()
    with patch('helpers.get_all_accounts', return_value=[TEST_ACCT]), \
         patch('helpers.get_account_password', return_value='secret'), \
         patch('helpers.get_account_config', return_value={'smtp_host': 'smtp.example.com', 'smtp_port': '465'}), \
         patch('helpers._get_pooled_smtp', return_value=('test-key', mock_smtp)), \
         patch('helpers.threading.Thread', _NoThread):
        ok, err, _ = helpers_mod._do_send(body)
    assert ok, err
    return email.message_from_bytes(mock_smtp.sendmail.call_args[0][2], policy=policy.default)


def _html_of(msg):
    return msg.get_body(preferencelist=('html',)).get_content()


def test_pasted_picture_is_sent_as_an_inline_cid_part_not_a_data_url():
    html = f'<p>Before</p><img src="data:image/png;base64,{PNG_B64}" width="300"><p>After the picture</p>'
    msg = _send({'account': TEST_ACCT, 'to': 'a@example.com', 'subject': 'Re: x', 'body': html})
    body = _html_of(msg)
    assert 'data:image' not in body
    assert 'After the picture' in body and 'Before' in body
    parts = [p for p in msg.walk() if p.get_content_type() == 'image/png']
    assert len(parts) == 1 and parts[0].get_payload(decode=True) == PNG
    cid = parts[0]['Content-ID'].strip('<>')
    assert f'src="cid:{cid}"' in body
    # image lives in a multipart/related so clients resolve the cid
    assert msg.get_content_type() == 'multipart/related'


def test_two_pictures_get_two_different_cids():
    html = (f'<img src="data:image/png;base64,{PNG_B64}"><p>mid</p>'
            f'<img src="data:image/jpeg;base64,{PNG_B64}">')
    msg = _send({'account': TEST_ACCT, 'to': 'a@example.com', 'subject': 's', 'body': html})
    cids = [p['Content-ID'] for p in msg.walk() if p.get_content_maintype() == 'image']
    assert len(cids) == 2 and len(set(cids)) == 2


def test_picture_with_a_signature_and_a_file_attachment_keeps_every_part():
    html = f'<p>Hi</p><img src="data:image/png;base64,{PNG_B64}"><p>Bye</p>'
    msg = _send({'account': TEST_ACCT, 'to': 'a@example.com', 'subject': 's', 'body': html,
                 'signature_html': '<p>Freecords Team</p>',
                 'attachments': [{'filename': 'proof.pdf', 'data_base64': base64.b64encode(b'pdf').decode()}]})
    assert msg.get_content_type() == 'multipart/mixed'
    body = _html_of(msg)
    assert 'Freecords Team' in body and 'data:image' not in body
    assert any(p.get_filename() == 'proof.pdf' for p in msg.walk())
    assert any(p.get_content_type() == 'image/png' for p in msg.walk())


def test_a_mail_without_pictures_is_built_exactly_as_before():
    msg = _send({'account': TEST_ACCT, 'to': 'a@example.com', 'subject': 's', 'body': '<p>plain</p>'})
    assert msg.get_content_type() == 'multipart/alternative'
    assert not [p for p in msg.walk() if p.get_content_maintype() == 'image']


def test_a_picture_in_the_quoted_thread_is_also_made_inline():
    msg = _send({'account': TEST_ACCT, 'to': 'a@example.com', 'subject': 's', 'body': '<p>reply</p>',
                 'reply_quote_html': f'<blockquote><img src="data:image/png;base64,{PNG_B64}"></blockquote>'})
    assert 'data:image' not in _html_of(msg)
    assert any(p.get_content_type() == 'image/png' for p in msg.walk())


def test_an_undecodable_picture_is_left_alone_and_does_not_break_the_send():
    html = '<p>x</p><img src="data:image/png;base64,">'
    msg = _send({'account': TEST_ACCT, 'to': 'a@example.com', 'subject': 's', 'body': html})
    assert 'x' in _html_of(msg)


def test_strip_data_images_replaces_the_whole_tag_with_a_note():
    out = helpers_mod.strip_data_images(f'<p>a</p><img src="data:image/png;base64,{BIG_B64}" width="10"><p>b</p>')
    assert out == '<p>a</p><em>[picture sent in the email]</em><p>b</p>'


def test_the_ticket_log_keeps_the_whole_reply_when_a_big_picture_was_pasted():
    html = (f'<p>Hi Nick,</p><img src="data:image/jpeg;base64,{BIG_B64}">'
            '<p>You can make the necessary adjustments by following these steps</p><p>Warmest Regards, Freecords Team</p>')
    assert len(html) > 20000 and html.index('Warmest') > 20000   # the old cut would have lost the sign-off
    posted = {}

    def fake_api(method, path, **kw):
        posted['json'] = kw.get('json')
        return {'ok': True}, None

    with patch.object(fa, '_api', fake_api):
        assert fa._log_outbound_message('T1', html, '<id@x>') is True
    logged = posted['json']['body']
    assert 'Hi Nick' in logged and 'following these steps' in logged and 'Warmest Regards, Freecords Team' in logged
    assert 'base64' not in logged and '[picture sent in the email]' in logged
