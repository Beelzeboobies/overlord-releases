import email
import email.header
import re
import subprocess
import sys
import threading
from pathlib import Path

from flask import Blueprint, request, jsonify, Response

from db import get_db
from imap import (imap_connect, resolve_folder, safe_folder, fetch_and_cache,
                  get_all_accounts, select_folder_once,
                  _unread_cache, _total_cache, _search_total_cache,
                  _folder_cache, _unread_cache_lock)
from parsing import parse_body
from rules_engine import apply_rules_to_messages
from helpers import render_xlsx_table, render_docx_table

bp = Blueprint('messages', __name__)

CACHE_TTL = 86400  # 24 hours — cache survives restarts; user force-refreshes for new mail


@bp.route('/api/messages')
def list_messages():
    import time
    folder  = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    force   = request.args.get('force') == '1'
    if not safe_folder(folder):
        return jsonify(error='invalid folder name'), 400
    page      = max(1, int(request.args.get('page', 1)))
    per_page  = 30
    filt      = request.args.get('filter', 'all')  # all | unread | read | flagged

    accounts = get_all_accounts()
    if not accounts:
        return jsonify(error='not logged in'), 401
    account_key = account if (account and account in accounts) else accounts[0]

    conn = get_db()

    # ── Serve from cache (stale-while-revalidate: always prefer cache) ──────────
    # Filtered views (unread/read/flagged) used to trust the local
    # message_cache.read column for which rows to return, while computing the
    # *total* shown in the tab from a live IMAP SEARCH — those two numbers
    # come from different sources and can disagree. Confirmed live: sidebar/
    # tab said 9 unread (live IMAP UNSEEN count) but only 3 rows came back
    # filtered from the DB cache, because message_cache's read flag can go
    # stale (it's only updated when this app changes it — a message read from
    # another client, or one that arrived and was cached before this session
    # last flipped its flag, silently disagrees with the server). Filtered
    # views now go straight to the live-IMAP-search path below (same one the
    # cache-miss branch already used), so the count and the list can never
    # diverge — only the unfiltered 'all' view still uses the DB-only fast path.
    if not force and filt == 'all':
        cutoff = time.time() - CACHE_TTL
        # Try fresh cache first; fall back to any cache (even stale) to avoid IMAP conflicts
        cached = conn.execute("""
            SELECT * FROM message_cache
            WHERE account=? AND folder=? AND cached_at > ?
            ORDER BY date DESC LIMIT ? OFFSET ?
        """, (account_key, folder, cutoff, per_page, (page-1)*per_page)).fetchall()

        # Fall back to stale cache if the fresh-only query returned a short page.
        # A short page means some rows haven't been re-fetched since the last
        # restart — the cutoff filter is silently dropping them.  We'd rather
        # show slightly stale data than a page with 3 rows.
        if not cached or len(cached) < per_page:
            stale = conn.execute("""
                SELECT * FROM message_cache
                WHERE account=? AND folder=?
                ORDER BY date DESC LIMIT ? OFFSET ?
            """, (account_key, folder, per_page, (page-1)*per_page)).fetchall()
            if len(stale) > len(cached):
                cached = stale

        if cached:
            real_folder_key = resolve_folder(folder, account_key)
            with _unread_cache_lock:
                folder_totals = _total_cache.get(account_key, {})
                search_total  = (_search_total_cache.get((account_key, folder))
                                 or _search_total_cache.get((account_key, real_folder_key)))
            if search_total:
                total = search_total
            else:
                # No authoritative total yet — spawn background fetch and use approximation
                def _bg_search_total(acct, acct_key, folder_name, real_f):
                    try:
                        c = imap_connect(acct)
                        if not c: return
                        # Use SELECT EXISTS — instant even on 100k mailboxes
                        st = c.select_folder(real_f, readonly=True)
                        n = int(st.get(b'EXISTS', 0))
                        # thread-local connection — leave open for reuse
                        with _unread_cache_lock:
                            _search_total_cache[(acct_key, folder_name)] = n
                            _search_total_cache[(acct_key, real_f)] = n
                    except Exception:
                        pass
                threading.Thread(target=_bg_search_total,
                                 args=(account, account_key, folder, real_folder_key),
                                 daemon=True).start()
                total = (folder_totals.get(folder)
                         or next((v for k, v in folder_totals.items() if k.lower() == folder.lower()), None)
                         or conn.execute("SELECT COUNT(*) FROM message_cache WHERE account=? AND folder=?",
                                         (account_key, folder)).fetchone()[0])
            messages = []
            for row in cached:
                uid = row['uid']
                meta = conn.execute('SELECT * FROM email_meta WHERE uid=?', (uid,)).fetchone()
                is_flagged = bool(meta['flagged']) if meta else bool(row['flagged_imap'])
                att_names_raw = row['attachment_names'] if 'attachment_names' in row.keys() else ''
                row_keys = row.keys() if hasattr(row, 'keys') else []
                messages.append({
                    'uid': uid,
                    'from_name': row['from_name'] or row['from_addr'],
                    'from_addr': row['from_addr'],
                    'subject':   row['subject'] or '(no subject)',
                    'date':      row['date'],
                    'read':      bool(row['read']),
                    'flagged_imap': bool(row['flagged_imap']),
                    'has_attachment': bool(row['has_attachment']),
                    'attachment_names': [n for n in (att_names_raw or '').split('\n') if n],
                    'flagged':      is_flagged,
                    'completed':    bool(meta['completed']) if meta else False,
                    'custom_status': meta['custom_status'] if meta else None,
                    'reminder_at':   meta['reminder_at'] if meta else None,
                    'cc':        row['cc'] if 'cc' in row_keys else '',
                    'to_addrs':  row['to_addrs'] if 'to_addrs' in row_keys else '',
                    'reply_to':  row['reply_to'] if 'reply_to' in row_keys else '',
                })
            conn.close()
            return jsonify(messages=messages, total=total, page=page, per_page=per_page, cached=True)

    conn.close()

    # ── Cache miss or forced refresh — hit IMAP ───────────────────────────────
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401

    real_folder = resolve_folder(folder, account_key)
    try:
        status_data = client.select_folder(real_folder, readonly=True)
    except Exception:
        # Connection corrupted — force fresh and retry once
        client = imap_connect(account, force_new=True)
        if not client:
            return jsonify(error='not logged in'), 401
        status_data = client.select_folder(real_folder, readonly=True)

    if filt == 'all':
        # Use EXISTS count from SELECT — no SEARCH needed, works instantly on 100k mailboxes
        total = int(status_data.get(b'EXISTS', 0))
        # Fetch last N messages by sequence number (most recent first)
        # imapclient uses UIDs by default — temporarily switch to seq mode
        seq_end   = max(1, total - (page - 1) * per_page)
        seq_start = max(1, seq_end - per_page + 1)
        if seq_start > seq_end or total == 0:
            page_uids = []
        else:
            try:
                client.use_uid = False
                seq_data = client.fetch(f'{seq_start}:{seq_end}', ['UID'])
                client.use_uid = True
                # Sort descending so most recent is first
                page_uids = sorted([v[b'UID'] for v in seq_data.values()], reverse=True)
            except Exception:
                client.use_uid = True
                page_uids = []
        with _unread_cache_lock:
            _total_cache.setdefault(account_key, {})[real_folder] = total
            _search_total_cache[(account_key, folder)]      = total
            _search_total_cache[(account_key, real_folder)] = total
    else:
        # Filtered views: SEARCH is unavoidable but result sets are much smaller
        if filt == 'unread':
            imap_criteria = ['UNSEEN']
        elif filt == 'read':
            imap_criteria = ['SEEN']
        else:
            imap_criteria = ['FLAGGED']
        all_uids  = list(reversed(client.search(imap_criteria)))
        total     = len(all_uids)
        page_uids = all_uids[(page - 1) * per_page: page * per_page]

    messages = []
    if page_uids:
        raw_messages = fetch_and_cache(client, folder, page_uids, account_key)
        conn = get_db()
        for msg in raw_messages:
            uid  = msg['uid']
            meta = conn.execute('SELECT * FROM email_meta WHERE uid=?', (uid,)).fetchone()
            msg['flagged']      = bool(meta['flagged']) if meta else msg['flagged_imap']
            msg['completed']    = bool(meta['completed']) if meta else False
            msg['custom_status'] = meta['custom_status'] if meta else None
            msg['reminder_at']   = meta['reminder_at'] if meta else None
            messages.append(msg)
        conn.close()

    # Apply rules to INBOX only (on fresh fetch)
    if folder.upper() == 'INBOX' and messages:
        messages, _ = apply_rules_to_messages(messages, account, account_key)

    return jsonify(messages=messages, total=total, page=page, per_page=per_page, cached=False)


def _parse_single_message(raw, uid, acct_key, folder):
    """Parse a raw RFC822 bytes blob and return a jsonify-ready dict."""
    text, html, attachments = parse_body(raw)
    # Cache snippet for bulk-export
    try:
        snip = (text or html or '').strip()[:500].replace('\n', ' ')
        conn = get_db(); conn.execute(
            "UPDATE message_cache SET snippet=? WHERE account=? AND folder=? AND uid=?",
            [snip, acct_key, folder, str(uid)]); conn.commit(); conn.close()
    except Exception:
        pass
    # Parse headers for draft editing
    try:
        parsed = email.message_from_bytes(raw)
        def decode_hdr(val):
            if not val: return ''
            parts = email.header.decode_header(val)
            return ''.join(b.decode(enc or 'utf-8', errors='replace') if isinstance(b, bytes) else b
                           for b, enc in parts)
        hdr_to  = decode_hdr(parsed.get('To', ''))
        hdr_cc  = decode_hdr(parsed.get('Cc', ''))
        hdr_bcc = decode_hdr(parsed.get('Bcc', ''))
    except Exception:
        hdr_to = hdr_cc = hdr_bcc = ''
    return dict(uid=str(uid), text=text, html=html, attachments=attachments,
                hdr_to=hdr_to, hdr_cc=hdr_cc, hdr_bcc=hdr_bcc)


@bp.route('/api/messages/batch-bodies')
def get_message_batch():
    """Fetch bodies for multiple UIDs in a single IMAP call.
    Used by the frontend prefetcher — returns {uid: body_dict, ...}."""
    folder  = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    uids_raw = request.args.get('uids', '')
    if not safe_folder(folder):
        return jsonify(error='invalid folder'), 400
    try:
        uids = [int(u) for u in uids_raw.split(',') if u.strip().isdigit()]
    except Exception:
        return jsonify(error='invalid uids'), 400
    if not uids:
        return jsonify({}), 200

    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    select_folder_once(client, resolve_folder(folder, acct_key), acct_key, readonly=True)
    data = client.fetch(uids, ['RFC822'])

    results = {}
    for uid in uids:
        row = data.get(uid)
        if not row:
            continue
        raw = row.get(b'RFC822')
        if not raw:
            continue
        results[str(uid)] = _parse_single_message(raw, uid, acct_key, folder)
    return jsonify(results)


def _locate_moved_message(client, acct_key, stale_folder, stale_real_folder, stale_uid):
    """A mail rule (ours or the server's) can move a message to another
    folder with a brand-new UID after the list snapshot the user is looking
    at was taken — the old folder/UID then 404s forever even though the
    message is sitting intact one folder over (real case: an email moved
    to NueMeta by a filing rule, its attachment still there under a new
    UID). Rather than just reporting the 404, search every other folder
    for a message matching the stale cached row's From+Subject+Date and
    return it directly so the user sees the real content, not an error.

    Returns (folder, uid, raw_rfc822) for the best match, or None if no
    other folder has anything matching — i.e. it's genuinely gone.
    """
    conn = get_db()
    row = conn.execute(
        "SELECT from_addr, subject, date FROM message_cache WHERE account=? AND folder=? AND uid=?",
        (acct_key, stale_folder, str(stale_uid))
    ).fetchone()
    conn.close()
    if not row or not row['from_addr']:
        return None
    from_addr = row['from_addr']
    subject = row['subject'] or ''
    stale_date = (row['date'] or '')[:16]  # 'YYYY-MM-DD HH:MM' — minute precision is enough to disambiguate a thread

    try:
        all_folders = [name for _, _, name in client.list_folders()]
    except Exception:
        return None

    has_non_ascii = any(ord(ch) > 127 for ch in subject)
    charset = 'UTF-8' if has_non_ascii else None

    for fname in all_folders:
        if fname == stale_real_folder:
            continue
        try:
            # select_folder_once (not a raw client.select_folder) keeps the
            # thread-local "currently selected folder" bookkeeping correct —
            # calling the client directly here without it would leave that
            # cache pointing at stale_real_folder even though the connection
            # has actually moved on, corrupting the next select_folder_once
            # call anywhere else in this request/thread.
            select_folder_once(client, fname, acct_key, readonly=True)
            criteria = ['FROM', from_addr]
            if subject:
                criteria += ['SUBJECT', subject]
            uids = client.search(criteria, charset=charset) if charset else client.search(criteria)
            if not uids:
                continue
            # A thread can have several messages sharing From+Subject (e.g.
            # a reply chain) — fetch all candidates' envelopes and pick the
            # one whose date actually matches the stale row, not just the
            # newest one in the folder.
            envs = client.fetch(uids, ['ENVELOPE'])
            best_uid = None
            for cand_uid, cand_data in envs.items():
                env = cand_data.get(b'ENVELOPE')
                if not env or not env.date:
                    continue
                cand_date = env.date.strftime('%Y-%m-%d %H:%M')
                if cand_date == stale_date:
                    best_uid = cand_uid
                    break
            if best_uid is None:
                best_uid = max(uids)  # no exact date match — fall back to newest candidate
            data = client.fetch([best_uid], ['RFC822'])
            if not data:
                continue
            raw = list(data.values())[0][b'RFC822']
            return fname, best_uid, raw
        except Exception:
            continue
    return None


@bp.route('/api/messages/<uid>')
def get_message(uid):
    folder = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    if not safe_folder(folder):
        return jsonify(error='invalid folder name'), 400
    try:
        uid_int = int(uid)
    except ValueError:
        return jsonify(error='invalid uid'), 400

    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401

    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    real_folder = resolve_folder(folder, acct_key)
    select_folder_once(client, real_folder, acct_key, readonly=True)
    data = client.fetch([uid_int], ['RFC822'])

    if not data:
        located = _locate_moved_message(client, acct_key, folder, real_folder, uid_int)
        if located:
            found_folder, found_uid, raw = located
            result = _parse_single_message(raw, found_uid, acct_key, found_folder)
            result['relocated_from'] = folder
            result['folder'] = found_folder
            # Drop the stale row so the old folder's cached list stops showing it
            conn = get_db()
            conn.execute("DELETE FROM message_cache WHERE account=? AND folder=? AND uid=?",
                         (acct_key, folder, str(uid_int)))
            conn.commit(); conn.close()
            return jsonify(**result)
        return jsonify(error='not found'), 404

    raw = list(data.values())[0][b'RFC822']
    return jsonify(**_parse_single_message(raw, uid_int, acct_key, folder))


@bp.route('/api/messages/move', methods=['POST', 'OPTIONS'])
def move_messages():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json()
    uids = [int(u) for u in body.get('uids', []) if str(u).isdigit()]
    from_folder = body.get('from_folder', 'INBOX')
    to_folder = body.get('to_folder', '')
    account = body.get('account') or None
    if not uids or not to_folder:
        return jsonify(error='missing uids or to_folder'), 400
    if not safe_folder(from_folder) or not safe_folder(to_folder):
        return jsonify(error='invalid folder name'), 400
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    real_from = resolve_folder(from_folder, acct_key)
    real_to   = resolve_folder(to_folder,   acct_key)
    client.select_folder(real_from)
    client.move(uids, real_to)
    # Delete the now-stale message_cache rows for the source folder. Without
    # this, a moved message stays visible in that folder's cached view —
    # confirmed live: MessageList.jsx's mount effect does a forced (live)
    # load first, then a second *unforced* load 5s later to pick up the
    # background total-search result, and that second load serves straight
    # from message_cache. A moved-away message that was never deleted from
    # the cache reappears in that second render, which is exactly what a
    # restart (a fresh mount, re-running the same two-stage load) surfaces —
    # real user report: successfully-filed emails "coming back" to Inbox
    # after restarting the app, even though the IMAP move itself had already
    # succeeded and the message was genuinely gone from the server (verified
    # via a live IMAP SEARCH against INBOX finding nothing, while the target
    # folder still had it). Same gap exists in rules_engine.py's automatic
    # move action — fixed there too.
    conn = get_db()
    conn.execute(
        f"DELETE FROM message_cache WHERE account=? AND folder=? AND uid IN ({','.join('?'*len(uids))})",
        [acct_key, from_folder] + [str(u) for u in uids]
    )
    conn.commit()
    conn.close()
    # Bust folder cache for both source and destination so the next list fetch
    # reflects the new counts instead of serving stale data.
    with _unread_cache_lock:
        if acct_key in _folder_cache:
            for entry in _folder_cache[acct_key]:
                if entry.get('name') in (from_folder, real_from):
                    entry['total'] = max(0, entry.get('total', 0) - len(uids))
                # Increment destination count if we have it cached
                if entry.get('name') in (to_folder, real_to):
                    entry['total'] = entry.get('total', 0) + len(uids)
    return jsonify(ok=True)


def _delete_uids_in_folder(client, uids, folder, real_folder, acct_key, trash_folder):
    """Shared by delete_messages (explicit UIDs) and delete_all (whole
    folder, no UIDs needed) — move-to-Trash-or-expunge, then purge cache
    and update in-memory folder totals the same way for both."""
    client.select_folder(real_folder)
    if trash_folder and real_folder != trash_folder:
        # Move to Trash rather than permanently expunge
        client.move(uids, trash_folder)
    else:
        # Already in Trash — permanently delete
        client.delete_messages(uids)
        client.expunge()

    # Purge from SQLite cache
    conn = get_db()
    conn.execute(
        f"DELETE FROM message_cache WHERE account=? AND folder=? AND uid IN ({','.join('?'*len(uids))})",
        [acct_key, folder] + [str(u) for u in uids]
    )
    conn.commit()
    conn.close()

    # Update folder totals in memory
    with _unread_cache_lock:
        if acct_key in _folder_cache:
            for entry in _folder_cache[acct_key]:
                if entry.get('name') in (folder, real_folder):
                    entry['total'] = max(0, entry.get('total', 0) - len(uids))
                # If we moved to Trash (not a permanent delete), increment Trash count
                if trash_folder and real_folder != trash_folder:
                    if entry.get('name') in ('Trash', trash_folder):
                        entry['total'] = entry.get('total', 0) + len(uids)


@bp.route('/api/messages/delete', methods=['POST', 'OPTIONS'])
def delete_messages():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json()
    uids = [int(u) for u in body.get('uids', []) if str(u).isdigit()]
    folder = body.get('folder', 'INBOX')
    account = body.get('account') or None
    if not uids or not safe_folder(folder):
        return jsonify(error='invalid request'), 400
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    real_folder = resolve_folder(folder, acct_key)
    trash_folder = resolve_folder('Trash', acct_key)
    _delete_uids_in_folder(client, uids, folder, real_folder, acct_key, trash_folder)
    return jsonify(ok=True)


@bp.route('/api/messages/delete-all', methods=['POST', 'OPTIONS'])
def delete_all():
    """Delete every message in a folder (no UIDs needed) — the
    selectAllFolder counterpart to delete_messages, same shape as
    mark_all_read above. **User-reported, with a screenshot**: the
    "Select all N" bulk-delete flow showed "All 228 selected" but the
    confirm dialog said "Delete 30 messages?" and only 30 were actually
    removed — deleteSelected() on the frontend never had a
    selectAllFolder-aware branch the way markSelectedRead() already did,
    so a select-all delete silently fell back to whatever the last
    small, page-scoped `selected` Set happened to contain."""
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json(force=True) or {}
    folder = body.get('folder', 'INBOX')
    account = body.get('account') or None
    if not safe_folder(folder):
        return jsonify(error='invalid request'), 400
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    real_folder = resolve_folder(folder, acct_key)
    trash_folder = resolve_folder('Trash', acct_key)
    client.select_folder(real_folder)
    all_uids = client.search(['ALL'])
    if all_uids:
        _delete_uids_in_folder(client, all_uids, folder, real_folder, acct_key, trash_folder)
    return jsonify(ok=True, affected=len(all_uids))


@bp.route('/api/messages/uids', methods=['GET'])
def get_message_uids():
    """Return UIDs for the first N pages of a folder (newest-first). Used for multi-page selection."""
    folder  = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    n_pages = max(1, int(request.args.get('n_pages', 1)))
    per_page = max(1, int(request.args.get('per_page', 30)))
    limit   = n_pages * per_page
    conn = get_db()
    q = "SELECT uid FROM message_cache WHERE folder=?"
    params = [folder]
    if account:
        q += " AND account=?"
        params.append(account)
    q += " ORDER BY date DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    conn.close()
    return jsonify(uids=[str(r['uid']) for r in rows])


@bp.route('/api/messages/export', methods=['POST'])
def export_messages():
    """
    Save a bulk selection of messages to Downloads as a single JSON file —
    same idea as Tickets' /api/fadmin/tickets/export.

    User-reported: this only ever wrote header fields (from/subject/date/
    read/flagged/cc/to) straight from message_cache — "not just the
    headers" was the explicit ask. Now also does a real IMAP fetch per
    batch (same RFC822 + _parse_single_message pattern already used by
    /api/messages/batch-bodies) and merges in the actual body text/html
    and attachment list, same shape /api/messages/<uid> itself returns.

    Body: { uids: [...], folder, account }
    """
    body = request.get_json(force=True) or {}
    uids = [str(u) for u in (body.get('uids') or [])]
    folder = body.get('folder', 'INBOX')
    account = body.get('account') or None
    if not uids:
        return jsonify({'error': 'no messages selected'}), 400
    if not safe_folder(folder):
        return jsonify({'error': 'invalid folder name'}), 400

    accounts = get_all_accounts()
    account_key = account if (account and account in accounts) else (accounts[0] if accounts else '')

    conn = get_db()
    placeholders = ','.join('?' * len(uids))
    rows = conn.execute(
        f"SELECT uid, from_name, from_addr, subject, date, read, flagged_imap, has_attachment, cc, to_addrs "
        f"FROM message_cache WHERE account=? AND folder=? AND uid IN ({placeholders})",
        [account_key, folder] + uids,
    ).fetchall()
    conn.close()
    messages = [dict(r) for r in rows]
    if not messages:
        return jsonify({'error': 'none of the selected messages were found in the local cache'}), 400

    # Real IMAP fetch for full body/attachments, merged onto the header
    # rows above. Best-effort — if the connection or a specific fetch
    # fails, the export still proceeds with headers-only for those
    # messages rather than failing the whole export over one bad UID.
    try:
        client = imap_connect(account)
        if client:
            int_uids = [int(u) for u in uids if u.isdigit()]
            select_folder_once(client, resolve_folder(folder, account_key), account_key, readonly=True)
            data = client.fetch(int_uids, ['RFC822'])
            bodies = {}
            for u in int_uids:
                row = data.get(u)
                raw = row.get(b'RFC822') if row else None
                if not raw:
                    continue
                parsed = _parse_single_message(raw, u, account_key, folder)
                bodies[str(u)] = {
                    'text': parsed.get('text', ''),
                    'html': parsed.get('html', ''),
                    'attachments': parsed.get('attachments', []),
                }
            for m in messages:
                m.update(bodies.get(str(m['uid']), {'text': '', 'html': '', 'attachments': []}))
    except Exception:
        # Headers-only export is still useful and already assembled above —
        # don't turn a body-fetch hiccup into a total export failure.
        for m in messages:
            m.setdefault('text', ''); m.setdefault('html', ''); m.setdefault('attachments', [])

    import json as _json
    from pathlib import Path as _Path
    from datetime import datetime as _dt
    downloads = _Path.home() / 'Downloads'
    stamp = _dt.now().strftime('%Y-%m-%d_%H%M%S')
    dest = downloads / f'emails-export-{stamp}.json'
    n = 1
    while dest.exists():
        dest = downloads / f'emails-export-{stamp} ({n}).json'
        n += 1
    try:
        dest.write_text(_json.dumps(messages, indent=2, ensure_ascii=False), encoding='utf-8')
    except Exception as e:
        return jsonify({'error': f'could not save file: {e}'}), 500

    import sys as _sys, subprocess as _subprocess
    if _sys.platform == 'darwin':
        try:
            _subprocess.run(['open', '-R', str(dest)], timeout=5)
        except Exception:
            pass

    return jsonify({'success': True, 'path': str(dest), 'filename': dest.name, 'count': len(messages)})


@bp.route('/api/messages/mark-read', methods=['POST', 'OPTIONS'])
def bulk_mark_read():
    """Mark multiple messages as read or unread."""
    if request.method == 'OPTIONS':
        return '', 204
    body    = request.get_json(force=True) or {}
    uids    = [int(u) for u in body.get('uids', []) if str(u).isdigit()]
    folder  = body.get('folder', 'INBOX')
    account = body.get('account') or None
    unread  = body.get('unread', False)  # True → mark unread
    if not uids or not safe_folder(folder):
        return jsonify(error='bad request'), 400
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts  = get_all_accounts()
    acct_key  = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key))
    if unread:
        client.remove_flags(uids, ['\\Seen'])
    else:
        client.add_flags(uids, ['\\Seen'])
    # Update SQLite cache
    conn = get_db()
    conn.execute(
        f"UPDATE message_cache SET read=? WHERE account=? AND folder=? AND uid IN ({','.join('?'*len(uids))})",
        [int(not unread), acct_key, folder] + [str(u) for u in uids]
    )
    conn.commit()

    # Count how many were actually flipped (only previously-unread messages matter for counters)
    changed = conn.execute(
        f"SELECT COUNT(*) FROM message_cache WHERE account=? AND folder=? AND uid IN ({','.join('?'*len(uids))})",
        [acct_key, folder] + [str(u) for u in uids]
    ).fetchone()[0]
    conn.close()

    # Update in-memory unread counters immediately so sidebar refreshes correctly
    real_folder = resolve_folder(folder, acct_key)
    delta = len(uids) if not unread else -len(uids)
    with _unread_cache_lock:
        # Patch _unread_cache
        if acct_key in _unread_cache:
            for key in [folder, real_folder]:
                if key in _unread_cache[acct_key]:
                    _unread_cache[acct_key][key] = max(0, _unread_cache[acct_key][key] - (delta if not unread else -delta))
        # Patch _folder_cache
        if acct_key in _folder_cache:
            for entry in _folder_cache[acct_key]:
                if entry.get('name') in (folder, real_folder):
                    entry['unread'] = max(0, entry.get('unread', 0) - (delta if not unread else -delta))

    return jsonify(ok=True)


@bp.route('/api/messages/mark-all-read', methods=['POST', 'OPTIONS'])
def mark_all_read():
    """Mark every message in a folder as read or unread (no UIDs needed)."""
    if request.method == 'OPTIONS':
        return '', 204
    body    = request.get_json(force=True) or {}
    folder  = body.get('folder', 'INBOX')
    account = body.get('account') or None
    unread  = body.get('unread', False)
    if not safe_folder(folder):
        return jsonify(error='bad request'), 400
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    real_folder = resolve_folder(folder, acct_key)
    client.select_folder(real_folder)
    # Search all messages in folder
    all_uids = client.search(['ALL'])
    if all_uids:
        if unread:
            client.remove_flags(all_uids, ['\\Seen'])
        else:
            client.add_flags(all_uids, ['\\Seen'])
    # Update SQLite cache
    conn = get_db()
    conn.execute(
        "UPDATE message_cache SET read=? WHERE account=? AND folder=?",
        [int(not unread), acct_key, folder]
    )
    conn.commit()
    conn.close()
    # Wipe in-memory unread counters
    with _unread_cache_lock:
        new_count = len(all_uids) if unread else 0
        if acct_key in _unread_cache:
            for key in [folder, real_folder]:
                if key in _unread_cache[acct_key]:
                    _unread_cache[acct_key][key] = new_count
        if acct_key in _folder_cache:
            for entry in _folder_cache[acct_key]:
                if entry.get('name') in (folder, real_folder):
                    entry['unread'] = new_count
    return jsonify(ok=True, affected=len(all_uids))


@bp.route('/api/messages/<uid>/read', methods=['POST', 'OPTIONS'])
def mark_read(uid):
    if request.method == 'OPTIONS':
        return '', 204
    folder = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    if not safe_folder(folder):
        return jsonify(error='invalid folder name'), 400
    try:
        uid_int = int(uid)
    except ValueError:
        return jsonify(error='invalid uid'), 400

    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key))
    client.add_flags([uid_int], ['\\Seen'])
    conn = get_db()
    was_unread = conn.execute(
        "SELECT read FROM message_cache WHERE account=? AND folder=? AND uid=?",
        (acct_key, folder, str(uid_int))
    ).fetchone()
    conn.execute("UPDATE message_cache SET read=1 WHERE account=? AND folder=? AND uid=?",
                 (acct_key, folder, str(uid_int)))
    conn.commit(); conn.close()
    # Decrement in-memory counters by 1 if message was previously unread
    if was_unread and not was_unread[0]:
        real_folder = resolve_folder(folder, acct_key)
        with _unread_cache_lock:
            if acct_key in _unread_cache:
                # dict.fromkeys deduplicates while preserving order: when
                # resolve_folder is identity (folder == real_folder), we only
                # decrement once instead of twice.
                for key in dict.fromkeys([folder, real_folder]):
                    if key in _unread_cache[acct_key]:
                        _unread_cache[acct_key][key] = max(0, _unread_cache[acct_key][key] - 1)
            if acct_key in _folder_cache:
                for entry in _folder_cache[acct_key]:
                    if entry.get('name') in (folder, real_folder):
                        entry['unread'] = max(0, entry.get('unread', 0) - 1)
    return jsonify(ok=True)


# ── Email meta ────────────────────────────────────────────────────────────────

@bp.route('/api/email/<uid>/meta', methods=['GET', 'PATCH', 'OPTIONS'])
def email_meta(uid):
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'PATCH':
        body = request.get_json()
        conn.execute("""
            INSERT INTO email_meta (uid, folder, flagged, completed, custom_status, reminder_at)
            VALUES (:uid, :folder, :flagged, :completed, :custom_status, :reminder_at)
            ON CONFLICT(uid) DO UPDATE SET
                flagged       = COALESCE(:flagged, flagged),
                completed     = COALESCE(:completed, completed),
                custom_status = COALESCE(:custom_status, custom_status),
                reminder_at   = COALESCE(:reminder_at, reminder_at)
        """, {
            'uid': uid,
            'folder': body.get('folder', 'INBOX'),
            'flagged': body.get('flagged'),
            'completed': body.get('completed'),
            'custom_status': body.get('custom_status'),
            'reminder_at': body.get('reminder_at'),
        })
        conn.commit()
        conn.close()
        return jsonify(ok=True)
    row = conn.execute('SELECT * FROM email_meta WHERE uid=?', (uid,)).fetchone()
    conn.close()
    return jsonify(dict(row) if row else {})


# ── Link preview ──────────────────────────────────────────────────────────────

@bp.route('/api/link-preview', methods=['GET', 'OPTIONS'])
def link_preview():
    """Fetch Open Graph / meta tags for a URL."""
    if request.method == 'OPTIONS': return '', 204
    url = (request.args.get('url') or '').strip()
    if not url or not url.startswith(('http://', 'https://')):
        return jsonify({'ok': False}), 400
    try:
        import urllib.request as _ur
        req = _ur.Request(url, headers={'User-Agent': 'Mozilla/5.0 (compatible; Overlord/1.0)'})
        with _ur.urlopen(req, timeout=6) as resp:
            ct = resp.headers.get('Content-Type', '')
            if 'html' not in ct: return jsonify({'ok': False})
            html = resp.read(40000).decode('utf-8', errors='ignore')
        import re as _re2
        def og(prop):
            m = _re2.search(rf'<meta[^>]+property=["\']og:{prop}["\'][^>]+content=["\']([^"\']+)["\']', html, _re2.I)
            if m: return m.group(1)
            m = _re2.search(rf'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:{prop}["\']', html, _re2.I)
            return m.group(1) if m else None
        def meta(name):
            m = _re2.search(rf'<meta[^>]+name=["\'](?:twitter:)?{name}["\'][^>]+content=["\']([^"\']+)["\']', html, _re2.I)
            return m.group(1) if m else None
        title = og('title') or meta('title') or (_re2.search(r'<title[^>]*>([^<]+)</title>', html, _re2.I) or [None,None])[1]
        desc  = og('description') or meta('description') or ''
        image = og('image') or meta('image') or ''
        site  = og('site_name') or ''
        return jsonify({'ok': True, 'title': (title or '')[:120], 'description': (desc or '')[:300], 'image': image[:500], 'site': site[:80], 'url': url})
    except Exception as ex:
        return jsonify({'ok': False, 'error': str(ex)})

# ── Attachment download ───────────────────────────────────────────────────────

@bp.route('/api/messages/<uid>/attachment')
def download_attachment(uid):
    folder   = request.args.get('folder', 'INBOX')
    filename = request.args.get('filename', '')
    account  = request.args.get('account') or None
    if not safe_folder(folder) or not filename:
        return jsonify(error='invalid request'), 400
    try:
        uid_int = int(uid)
    except ValueError:
        return jsonify(error='invalid uid'), 400

    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401

    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key), readonly=True)
    data = client.fetch([uid_int], ['RFC822'])

    if not data:
        return jsonify(error='not found'), 404

    raw = list(data.values())[0][b'RFC822']
    msg = email.message_from_bytes(raw)

    for part in msg.walk():
        part_filename = part.get_filename()
        if part_filename and part_filename == filename:
            payload = part.get_payload(decode=True)
            content_type = part.get_content_type() or 'application/octet-stream'
            # filename comes from the email itself (sender-controlled) and is
            # interpolated into a raw header value below — strip CR/LF so a
            # crafted attachment name can't inject headers or crash the
            # response (Werkzeug rejects any header value containing them).
            safe_filename = filename.replace('\r', '').replace('\n', '').replace('"', "'")
            return Response(
                payload,
                headers={
                    'Content-Disposition': f'attachment; filename="{safe_filename}"',
                    'Content-Type': content_type,
                    'Content-Length': str(len(payload)),
                }
            )

    return jsonify(error='attachment not found'), 404


@bp.route('/api/messages/<uid>/attachment/table', methods=['POST'])
def attachment_table(uid):
    """Inline preview for spreadsheet/document attachments (xlsx/xlsm/docx)
    that AttachmentPreviewModal can't just show as an <img>/<embed> — parses
    server-side and returns structured JSON the frontend renders as a plain
    HTML table, never raw HTML from the file itself.
    """
    body     = request.get_json(force=True) or {}
    folder   = body.get('folder', 'INBOX')
    filename = body.get('filename', '')
    account  = body.get('account') or None
    if not safe_folder(folder) or not filename:
        return jsonify(error='invalid request'), 400
    try:
        uid_int = int(uid)
    except ValueError:
        return jsonify(error='invalid uid'), 400

    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401

    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key), readonly=True)
    data = client.fetch([uid_int], ['RFC822'])

    if not data:
        return jsonify(error='not found'), 404

    raw = list(data.values())[0][b'RFC822']
    msg = email.message_from_bytes(raw)

    for part in msg.walk():
        part_filename = part.get_filename()
        if part_filename and part_filename == filename:
            payload = part.get_payload(decode=True)
            if len(payload) > 15 * 1024 * 1024:
                return jsonify(error='file too large to preview'), 400

            ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            try:
                if ext in ('xlsx', 'xlsm'):
                    return jsonify(render_xlsx_table(payload))
                elif ext == 'docx':
                    return jsonify(render_docx_table(payload))
                else:
                    return jsonify(error='unsupported file type for inline preview'), 400
            except Exception as e:
                return jsonify(error=f'could not parse file: {e}'), 500

    return jsonify(error='attachment not found'), 404


@bp.route('/api/messages/<uid>/attachment/save', methods=['POST'])
def save_attachment(uid):
    """
    Same lookup as download_attachment above, but writes straight to
    ~/Downloads server-side instead of returning the bytes over HTTP. The
    desktop window is a WKWebView, which doesn't reliably honor the HTML5
    `download` attribute (even for blob: URLs) — clicking a download link
    just displays the file inline with no way back. See freecords_admin.py's
    fadmin_download_file, which solves the same problem for CRM attachments;
    this is the personal-email equivalent, reading from IMAP instead of a URL.
    """
    body      = request.get_json(force=True) or {}
    folder    = body.get('folder', 'INBOX')
    filename  = body.get('filename', '')
    account   = body.get('account') or None
    save_path = (body.get('save_path') or '').strip()  # set only on Windows, via a real Save As dialog
    if not safe_folder(folder) or not filename:
        return jsonify(error='invalid request'), 400
    try:
        uid_int = int(uid)
    except ValueError:
        return jsonify(error='invalid uid'), 400

    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401

    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key), readonly=True)
    data = client.fetch([uid_int], ['RFC822'])

    if not data:
        return jsonify(error='not found'), 404

    raw = list(data.values())[0][b'RFC822']
    msg = email.message_from_bytes(raw)

    for part in msg.walk():
        part_filename = part.get_filename()
        if part_filename and part_filename == filename:
            payload = part.get_payload(decode=True)

            if save_path:
                dest = Path(save_path)
                try:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(payload)
                except Exception as e:
                    return jsonify(error=f'could not save file: {e}'), 500
                return jsonify(success=True, path=str(dest), filename=dest.name)

            safe_name = re.sub(r'[/\\:*?"<>|]', '_', filename.replace('\r', '').replace('\n', '')) or 'download'
            downloads = Path.home() / 'Downloads'
            dest = downloads / safe_name
            stem, suffix = dest.stem, dest.suffix
            n = 1
            while dest.exists():
                dest = downloads / f'{stem} ({n}){suffix}'
                n += 1

            try:
                dest.write_bytes(payload)
            except Exception as e:
                return jsonify(error=f'could not save file: {e}'), 500

            if sys.platform == 'darwin':
                try:
                    subprocess.run(['open', '-R', str(dest)], timeout=5)
                except Exception:
                    pass

            return jsonify(success=True, path=str(dest), filename=dest.name)

    return jsonify(error='attachment not found'), 404


# ── Mark as unread ────────────────────────────────────────────────────────────

@bp.route('/api/messages/<uid>/unread', methods=['POST', 'OPTIONS'])
def mark_unread(uid):
    if request.method == 'OPTIONS':
        return '', 204
    folder  = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    if not safe_folder(folder):
        return jsonify(error='invalid folder name'), 400
    try:
        uid_int = int(uid)
    except ValueError:
        return jsonify(error='invalid uid'), 400
    client = imap_connect(account)
    if not client:
        return jsonify(error='not logged in'), 401
    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key))
    client.remove_flags([uid_int], ['\\Seen'])
    conn = get_db()
    conn.execute("UPDATE message_cache SET read=0 WHERE account=? AND folder=? AND uid=?",
                 (acct_key, folder, str(uid_int)))
    conn.commit(); conn.close()
    with _unread_cache_lock:
        _unread_cache.pop(acct_key, None)
    return jsonify(ok=True)


# ── Print view ────────────────────────────────────────────────────────────────

@bp.route('/api/messages/<uid>/print-open', methods=['POST', 'OPTIONS'])
def print_open(uid):
    """Tell the OS to open the print page in the default browser."""
    if request.method == 'OPTIONS':
        return '', 204
    body    = request.get_json(silent=True) or {}
    folder  = body.get('folder', 'INBOX')
    account = body.get('account') or ''
    if not safe_folder(folder):
        return jsonify(error='invalid folder'), 400
    import webbrowser, urllib.parse
    params = urllib.parse.urlencode({'folder': folder, 'account': account})
    url = f'http://localhost:8000/print/{uid}?{params}'
    webbrowser.open(url)
    return jsonify(ok=True)


@bp.route('/print/<uid>')
def print_message(uid):
    """Return a self-printing HTML page for the given message.
    Opened in the system browser (Safari) since WKWebView has no print support."""
    folder  = request.args.get('folder', 'INBOX')
    account = request.args.get('account') or None
    if not safe_folder(folder):
        return 'invalid folder', 400
    try:
        uid_int = int(uid)
    except ValueError:
        return 'invalid uid', 400

    client = imap_connect(account)
    if not client:
        return 'not logged in', 401

    accounts = get_all_accounts()
    acct_key = account if (account and account in accounts) else (accounts[0] if accounts else '')
    client.select_folder(resolve_folder(folder, acct_key), readonly=True)
    data = client.fetch([uid_int], ['RFC822'])
    if not data:
        return 'not found', 404

    raw = list(data.values())[0][b'RFC822']
    text, html, _ = parse_body(raw)

    import email as _email
    import email.header as _hdr
    parsed = _email.message_from_bytes(raw)
    def dh(v):
        if not v: return ''
        parts = _hdr.decode_header(v)
        out = []
        for b, enc in parts:
            out.append(b.decode(enc or 'utf-8', errors='replace') if isinstance(b, bytes) else b)
        return ''.join(out)
    subject = dh(parsed.get('Subject', ''))
    from_   = dh(parsed.get('From', ''))
    to_     = dh(parsed.get('To', ''))
    date_   = dh(parsed.get('Date', ''))

    body_html = html or f'<pre style="white-space:pre-wrap;font-family:inherit">{text or ""}</pre>'

    page = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{subject}</title>
<style>
  body {{ font-family: -apple-system, sans-serif; padding: 32px; color: #000; background: #fff; max-width: 860px; margin: 0 auto; }}
  .meta {{ margin-bottom: 16px; font-size: 14px; line-height: 1.6; }}
  .meta strong {{ display: inline-block; width: 60px; }}
  hr {{ border: none; border-top: 1px solid #ccc; margin: 16px 0; }}
  @media print {{ .no-print {{ display: none; }} }}
</style>
</head><body>
<div class="no-print" style="margin-bottom:24px">
  <button onclick="window.print()" style="padding:8px 20px;font-size:14px;cursor:pointer">Print / Save as PDF</button>
</div>
<h2 style="margin:0 0 12px">{subject}</h2>
<div class="meta">
  <div><strong>From:</strong> {from_}</div>
  <div><strong>To:</strong> {to_}</div>
  <div><strong>Date:</strong> {date_}</div>
</div>
<hr>
{body_html}
<script>window.onload = function() {{ window.print(); }}</script>
</body></html>"""

    from flask import Response as _Resp
    return _Resp(page, mimetype='text/html')
