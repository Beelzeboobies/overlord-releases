"""
Shared test constants and DB helpers.

Imported by tests/conftest.py and by individual test modules.
This file imports only stdlib, so it is safe to import before or after
the keyring/config/db stubs that conftest.py installs.
"""
import sqlite3
import time

TEST_ACCT = 'test@example.com'
_NOW = time.time()


# ── In-memory SQLite (shared across the whole test session) ───────────────────

_mem = sqlite3.connect(':memory:', check_same_thread=False)
_mem.row_factory = sqlite3.Row
_mem.executescript("""
    CREATE TABLE IF NOT EXISTS message_cache (
        account          TEXT NOT NULL DEFAULT '',
        folder           TEXT NOT NULL DEFAULT 'INBOX',
        uid              TEXT NOT NULL,
        from_name        TEXT,
        from_addr        TEXT,
        subject          TEXT,
        date             TEXT,
        read             INTEGER DEFAULT 0,
        flagged_imap     INTEGER DEFAULT 0,
        has_attachment   INTEGER DEFAULT 0,
        attachment_names TEXT DEFAULT '',
        cached_at        REAL,
        cc               TEXT DEFAULT '',
        to_addrs         TEXT DEFAULT '',
        snippet          TEXT DEFAULT '',
        reply_to         TEXT DEFAULT '',
        PRIMARY KEY (account, folder, uid)
    );
    CREATE TABLE IF NOT EXISTS email_meta (
        uid           TEXT PRIMARY KEY,
        folder        TEXT NOT NULL DEFAULT 'INBOX',
        flagged       INTEGER DEFAULT 0,
        completed     INTEGER DEFAULT 0,
        custom_status TEXT,
        reminder_at   TEXT
    );
    CREATE TABLE IF NOT EXISTS account_configs (
        email     TEXT PRIMARY KEY,
        imap_host TEXT, imap_port INTEGER,
        smtp_host TEXT, smtp_port INTEGER
    );
    CREATE TABLE IF NOT EXISTS scheduled_sends (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        account     TEXT NOT NULL,
        send_at_utc TEXT NOT NULL,
        payload     TEXT NOT NULL,
        status      TEXT DEFAULT 'pending',
        created_at  TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS rules (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT NOT NULL DEFAULT '',
        condition_field TEXT NOT NULL DEFAULT 'subject',
        condition_op    TEXT NOT NULL DEFAULT 'contains',
        condition_value TEXT NOT NULL DEFAULT '',
        action          TEXT NOT NULL DEFAULT 'move',
        action_value    TEXT DEFAULT '',
        active          INTEGER DEFAULT 1,
        created_at      TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS native_ticket_index (
        ticket_number    INTEGER PRIMARY KEY,
        native_id        TEXT,
        subject          TEXT,
        created_at       TEXT,
        status           TEXT,
        requester_email  TEXT,
        thread_ref       TEXT
    );
    CREATE TABLE IF NOT EXISTS ticket_awaiting_reply (
        ticket_number  INTEGER PRIMARY KEY,
        marked_at      TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS ticket_manually_created (
        ticket_number  INTEGER PRIMARY KEY,
        created_at     TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS ticket_activity (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_number  INTEGER NOT NULL,
        action         TEXT NOT NULL,
        agent_name     TEXT,
        at             TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS ticket_closed_at (
        ticket_number  INTEGER PRIMARY KEY,
        closed_at      TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS ticket_read_state (
        ticket_id  TEXT PRIMARY KEY,
        read_at    TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS ticket_rules (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT NOT NULL DEFAULT '',
        condition_field TEXT NOT NULL DEFAULT 'subject',
        condition_op    TEXT NOT NULL DEFAULT 'contains',
        condition_value TEXT NOT NULL DEFAULT '',
        action          TEXT NOT NULL DEFAULT 'add_tag',
        action_value    TEXT DEFAULT '',
        active          INTEGER DEFAULT 1,
        created_at      TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS contacts (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        name       TEXT NOT NULL,
        email      TEXT UNIQUE NOT NULL,
        tags       TEXT DEFAULT '[]',
        city TEXT, timezone TEXT, notes TEXT, dob TEXT,
        created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
    CREATE TABLE IF NOT EXISTS labels (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        color TEXT NOT NULL DEFAULT '#e8a020',
        created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS email_labels (
        account  TEXT NOT NULL,
        uid      TEXT NOT NULL,
        label_id INTEGER NOT NULL,
        PRIMARY KEY (account, uid, label_id)
    );
""")
_mem.commit()


class _NC:
    """Thin wrapper: close() is a no-op to keep the in-memory DB alive."""
    def __init__(self, c):
        self._c = c
    def execute(self, *a, **kw):
        return self._c.execute(*a, **kw)
    def executemany(self, *a, **kw):
        return self._c.executemany(*a, **kw)
    def executescript(self, *a, **kw):
        return self._c.executescript(*a, **kw)
    def commit(self):
        return self._c.commit()
    def close(self):
        pass


def seed_message(uid, subject='Hello', read=0, folder='INBOX',
                 account=TEST_ACCT, **kw):
    """Insert one row into message_cache (cached_at within the 24 h TTL)."""
    _mem.execute("""
        INSERT OR REPLACE INTO message_cache
        (account, folder, uid, from_name, from_addr, subject, date,
         read, flagged_imap, has_attachment, attachment_names, cached_at, cc, to_addrs)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        account, folder, str(uid),
        kw.get('from_name', 'Alice'),
        kw.get('from_addr', 'alice@example.com'),
        subject,
        kw.get('date', 'Mon, 1 Jan 2024 00:00:00 +0000'),
        read,
        kw.get('flagged_imap', 0),
        kw.get('has_attachment', 0),
        kw.get('attachment_names', ''),
        _NOW - 60,      # recently cached — inside the 24 h TTL
        kw.get('cc', ''),
        kw.get('to_addrs', ''),
    ))
    _mem.commit()
