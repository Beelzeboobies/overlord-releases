"""
claude_bulk_classify.py — shared Claude-powered bulk ticket classification
and reply-drafting.

Used by both freshdesk.py's and freecords_admin.py's group-tool routes.
Lives here rather than in either blueprint, per the project rule that
shared logic between two blueprints goes in a shared module, never a
cross-blueprint import — Freshdesk tickets and native Freecords tickets
have different id/fetch shapes, but the actual "send N tickets + an
instruction to Claude, get back qualify/extract/draft per ticket" logic
is identical once the caller has normalized ticket data into
{id, subject, tags, description}.
"""
import json
import re

import keyring

from config import ANTHROPIC_KEYRING

BATCH_SIZE = 10  # tickets per Claude call. Progress can only tick once per
                  # batch (Claude returns the whole batch's JSON at once,
                  # nothing streams mid-call) — confirmed live that 25 made
                  # the bar sit at 0 through most of a batch's ~60-90s call
                  # then jump by 25 all at once, reading as stuck rather
                  # than working. Smaller batches trade a few more API
                  # calls for a progress bar that actually moves.

CREDIT_ERROR_CODE = 'claude_out_of_credits'
CANCELLED_CODE = 'cancelled'


def get_anthropic_client():
    """Build an Anthropic client from the stored key, adding the
    anthropic-workspace-id header when one's configured. Anthropic now
    requires every request from an organization account to declare which
    workspace it belongs to — confirmed live, a freshly-issued key
    (including one explicitly scoped to "Organization", not a specific
    workspace) still gets rejected with "This API key is not scoped to a
    workspace, so this request must include the anthropic-workspace-id
    header..." without it. Not a code regression on our side — this is an
    Anthropic API behavior change on keys that didn't require it before.
    The workspace id is stored the same way as the key (keychain), entered
    in Settings — see freshdesk.py's anthropic-key routes.

    Returns (client, error) — error is 'no_anthropic_key' if nothing's
    configured yet. The one place all three Anthropic() call sites in this
    app (here x2, freshdesk.py's chat endpoint) should build a client, so
    this only has to exist once.
    """
    api_key = keyring.get_password(ANTHROPIC_KEYRING, 'api_key')
    if not api_key:
        return None, 'no_anthropic_key'
    workspace_id = (keyring.get_password(ANTHROPIC_KEYRING, 'workspace_id') or '').strip()
    import anthropic as _anthropic
    kwargs = {'api_key': api_key}
    if workspace_id:
        kwargs['default_headers'] = {'anthropic-workspace-id': workspace_id}
    return _anthropic.Anthropic(**kwargs), None


def is_credit_error(e):
    """True only for Anthropic's low-balance error ("Your credit balance is
    too low to access the Claude API..."), not other failures (bad key,
    rate limit, network blip, overloaded) — those should keep surfacing
    their own real message rather than getting relabeled as a billing
    issue. Every Claude call site in this app funnels its exception
    through this so a real "you're out of credits" reads as one clean,
    consistent signal everywhere instead of raw exception text buried in
    a draft box or a per-ticket reasoning field."""
    return 'credit balance' in str(e).lower()


def suggest_instructions(tag_name, subjects):
    """
    Quick, cheap suggestion of a few ready-to-click instructions for the
    group-browse panel's Ask Claude tool, tailored to what's actually in
    this group — not a hardcoded per-tag guess. One small call (subjects
    only, no descriptions, low max_tokens) so this is near-instant, unlike
    the full classify run which reads every ticket's full body and can
    take minutes.

    tag_name: the active group's tag (or '__untagged__').
    subjects: a small sample of ticket subjects from that group (the
    frontend already has these loaded for the visible list — no extra
    fetch needed to build the sample).

    Returns (suggestions, error). suggestions is a list of up to 3 short
    instruction strings.
    """
    client, err = get_anthropic_client()
    if err:
        return None, err

    sample_block = '\n'.join(f'- {s}' for s in subjects[:12] if s) or '(no subjects available)'
    label = 'Untagged' if tag_name == '__untagged__' else tag_name
    prompt = f"""You are looking at a sample of support ticket subjects from a group labeled "{label}" at a music distribution company.

Sample subjects:
{sample_block}

Suggest 3 short, useful instructions a support lead could run against this whole group with an AI ticket-triage tool. That tool classifies which tickets qualify per the instruction, extracts relevant fields (e.g. ISRC), and drafts a reply for each qualifying one. Each suggestion should be one sentence, specific to what this group actually seems to contain based on the subjects above, phrased as a direct instruction (not a question).

Respond with ONLY a JSON array of 3 strings, no other text: ["...", "...", "..."]"""

    try:
        resp = client.messages.create(
            model='claude-sonnet-5', max_tokens=400,
            messages=[{'role': 'user', 'content': prompt}],
        )
        text = ''.join(b.text for b in (resp.content or []) if getattr(b, 'type', None) == 'text')
        cleaned = re.sub(r'^```(?:json)?\s*|\s*```\s*$', '', text.strip())
        suggestions = json.loads(cleaned)
        if not isinstance(suggestions, list):
            raise ValueError('response was not a JSON array')
        return [str(s) for s in suggestions][:3], None
    except Exception as e:
        return None, CREDIT_ERROR_CODE if is_credit_error(e) else str(e)


def classify_and_draft(tickets, instruction, on_progress=None, should_cancel=None):
    """
    tickets: list of {id, subject, tags, description} (description = plain
    text, HTML already stripped by the caller).
    instruction: free-text instruction describing which tickets qualify
    and what a drafted reply should contain.
    on_progress: optional callback(done_count) invoked after each batch.
    should_cancel: optional callable, checked before each batch — if it
    returns truthy, stops immediately and returns whatever's been
    classified so far with error=CANCELLED_CODE (a real batch call can
    take 60-90s, so this is checked between batches, not mid-call —
    there's no way to abort an in-flight Anthropic request).

    Returns (results, error). results is a list of
    {id, qualifies, extracted, draft, reasoning}. Batches internally
    (BATCH_SIZE tickets per call) — a single call over hundreds of tickets
    would be both slow and unreliable to parse back as one JSON blob, and
    a failed batch shouldn't take down every other batch's results with it.
    """
    client, err = get_anthropic_client()
    if err:
        return None, err

    results = []
    for i in range(0, len(tickets), BATCH_SIZE):
        if should_cancel and should_cancel():
            return results, CANCELLED_CODE
        batch = tickets[i:i + BATCH_SIZE]
        try:
            resp = client.messages.create(
                model='claude-sonnet-5',
                max_tokens=8192,
                messages=[{'role': 'user', 'content': _build_prompt(batch, instruction)}],
            )
            text = ''.join(b.text for b in (resp.content or []) if getattr(b, 'type', None) == 'text')
            results.extend(_parse_results(text, batch))
        except Exception as e:
            if is_credit_error(e):
                # Every remaining batch will fail with this exact same
                # error — no point burning through them one by one just to
                # produce a wall of identical per-ticket "reasoning" text.
                # Bail out now with one clean top-level error instead.
                return None, CREDIT_ERROR_CODE
            for t in batch:
                results.append({
                    'id': t['id'], 'qualifies': False, 'extracted': {},
                    'draft': None, 'reasoning': f'error calling Claude: {e}',
                })
        if on_progress:
            on_progress(min(i + BATCH_SIZE, len(tickets)))

    return results, None


def _build_prompt(batch, instruction):
    tickets_block = '\n\n'.join(
        f"TICKET {t['id']}\n"
        f"Requester name: {t.get('requester_name') or '(unknown — use a generic greeting)'}\n"
        f"Subject: {t.get('subject', '')}\n"
        f"Tags: {', '.join(t.get('tags') or []) or 'none'}\n"
        f"Description: {(t.get('description') or '(empty)')[:3000]}"
        for t in batch
    )
    return f"""You are triaging a batch of customer support tickets for a music distribution company.

Instruction from the support lead: {instruction}

For EACH ticket below, decide whether it qualifies per the instruction. If it qualifies and the instruction implies drafting a reply, write a complete, ready-to-send reply in the "draft" field — professional, references that ticket's specific details (song title, artist, ISRC, etc. as applicable), ready for a support rep to read and send with minimal editing. Start the draft with "Hi {{first name from Requester name}}," on its own line — if Requester name is unknown, use "Hi there," instead of guessing a name. Write as the support team using "we"/"us"/"our", never "I"/"me"/"my" — you're replying on behalf of the whole team, not one person. Do NOT add a sign-off, closing line, or name at the end of the draft — a signature is appended automatically after it when sent, so ending it with one would double it up. End on the actual content, not a farewell. Never use markdown formatting in the draft — no **bold**, no *italics*, no bullet points with - or *, no # headings. This is a plain-text/rich-text email, not a markdown document. If it doesn't qualify, or no draft is implied by the instruction, leave "draft" null. If the ticket text explicitly names which distribution channel/aggregator/store the release went through or is missing from (e.g. "not on Nuemeta", "distributed via EVEARA", "on RouteNote", "still pending on ADA/Boomplay/YouTube Music") — extracted key "channel" with exactly that channel name. Only include it if the ticket text actually says so; don't guess.

Respond with ONLY a JSON array, one object per ticket, no other text before or after:
[{{"id": <ticket id, same type as given>, "qualifies": true|false, "extracted": {{...any fields relevant to the instruction, e.g. isrc, channel...}}, "draft": "..." or null, "reasoning": "one sentence"}}]

Tickets:
{tickets_block}"""


def _parse_results(text, batch):
    cleaned = re.sub(r'^```(?:json)?\s*|\s*```\s*$', '', text.strip())
    try:
        parsed = json.loads(cleaned)
        if not isinstance(parsed, list):
            raise ValueError('response was not a JSON array')
    except Exception:
        # Surface as "couldn't classify" per ticket rather than silently
        # dropping the whole batch's worth of tickets from the results.
        return [{
            'id': t['id'], 'qualifies': False, 'extracted': {}, 'draft': None,
            'reasoning': "Claude's response for this batch could not be parsed as JSON",
        } for t in batch]

    by_id = {str(r.get('id')): r for r in parsed if isinstance(r, dict)}
    out = []
    for t in batch:
        r = by_id.get(str(t['id']))
        if r:
            out.append({
                'id': t['id'],
                'qualifies': bool(r.get('qualifies')),
                'extracted': r.get('extracted') or {},
                'draft': r.get('draft'),
                'reasoning': r.get('reasoning') or '',
            })
        else:
            out.append({
                'id': t['id'], 'qualifies': False, 'extracted': {}, 'draft': None,
                'reasoning': 'Claude did not return a result for this ticket',
            })
    return out


def _item_isrc(item):
    return (item.get('isrc') or (item.get('metadata') or {}).get('isrc') or '').strip()


# Confirmed live: neither /api/admin/moderation/search nor the full song
# detail endpoint (/api/admin/moderation/song/{id}) has any channel/
# distributor field at all — Freecords' catalog API just doesn't expose
# which aggregator (NueMeta, EVEARA, ADA, RouteNote, Boomplay, YouTube
# Music, Tuned Global — the same set ModerationView.jsx's ChannelBadge
# already has colors for) a song went through. The *only* pathway Overlord
# has a real integration for is NueMeta (/api/admin/ddex/nuemeta-dsp-action,
# /dsp-deliveries) — so "does this song have NueMeta delivery records" is
# used as the reliable proxy for "is this on NueMeta", and the specific
# other channel (if any) is only known when a ticket's own text happens to
# say so (see _build_prompt's "channel" extraction) — never guessed.
def resolve_buckets(results, on_progress=None, should_cancel=None):
    """
    Second pass, deterministic — no LLM involved for the bucket decision
    itself (an optional 'channel' in `extracted` may already be a Claude
    read of the ticket text, kept as-is). For every ticket Claude said
    qualifies, look up any extracted ISRC against Freecords' actual catalog
    (same lookup Moderation's Individual Search already uses), then check
    NueMeta DSP-delivery records for that song, and assign a bucket:
      - 'not_relevant'      — Claude said this ticket doesn't qualify at all.
        Kept collapsed/hidden by default in the UI — just noise otherwise.
      - 'manual_resolution' — qualifies but missing an ISRC, the ISRC
        doesn't resolve to a real song, OR the song resolved but has zero
        NueMeta delivery records. Confirmed live this is exactly the "not
        on NueMeta, needs manual admin-panel action through whichever
        channel it's actually on" case — a real ticket said so explicitly:
        "This release was not on Nuemeta. Manual takedown action is needed
        from the admin panel."
      - 'ready'             — qualifies, ISRC resolved to a real song with
        real NueMeta delivery records. Safe to queue for one-by-one,
        human-confirmed reply + (optional) takedown via the existing
        NueMeta DDEX action.

    Mutates and returns `results` in place: adds 'bucket' to every item,
    and 'distribution': {song_id, song_name, deliveries} to any item whose
    ISRC resolved to a real song (regardless of bucket — even a Manual
    resolution ticket should show what was actually found, empty
    deliveries included, not just "needs a human").
    Import of freecords_client is local — this module is also used by
    freshdesk.py, which has no other reason to depend on the Freecords
    admin client, so keep the dependency scoped to just this function.
    """
    from freecords_client import _api

    for i, r in enumerate(results):
        if should_cancel and should_cancel():
            # Leave every not-yet-resolved item bucketed as manual_resolution
            # rather than with no 'bucket' at all — an unbucketed item would
            # silently vanish from the UI (it matches none of the ready/
            # manual/not_relevant filters), which reads as "lost", not
            # "cancelled". Whether it actually qualifies is already known
            # from classify_and_draft; a human just hasn't had the
            # distribution check run for it yet.
            for r2 in results[i:]:
                if 'bucket' not in r2:
                    r2['bucket'] = 'not_relevant' if not r2.get('qualifies') else 'manual_resolution'
                    if r2['bucket'] == 'manual_resolution':
                        r2['reasoning'] = (r2.get('reasoning') or '').rstrip('.') + '. Cancelled before the distribution check ran for this ticket.'
            break
        if not r.get('qualifies'):
            r['bucket'] = 'not_relevant'
        else:
            isrc = None
            for k, v in (r.get('extracted') or {}).items():
                if k.lower() == 'isrc' and v:
                    isrc = str(v).strip()
                    break

            if not isrc:
                r['bucket'] = 'manual_resolution'
            else:
                search_data, err = _api('GET', '/api/admin/moderation/search', params={'q': isrc})
                song = None
                if not err and search_data:
                    matches = search_data.get('results') or []
                    song = next((s for s in matches if _item_isrc(s).upper() == isrc.upper()), None) \
                        or (matches[0] if matches else None)

                if not song:
                    r['bucket'] = 'manual_resolution'
                    r['reasoning'] = (r.get('reasoning') or '').rstrip('.') + f'. ISRC {isrc} was not found in the catalog.'
                else:
                    song_id = song.get('songId') or song.get('id')
                    deliveries = []
                    if song_id:
                        d_data, d_err = _api('GET', f'/api/admin/song/{song_id}/dsp-deliveries')
                        if not d_err and d_data:
                            deliveries = d_data.get('deliveries') or []

                    song_name = song.get('title') or song.get('name') or song.get('songName') or ''
                    r['distribution'] = {
                        'song_id': song_id, 'song_name': song_name, 'deliveries': deliveries,
                        'artist_id': song.get('artist_id'),
                    }

                    if deliveries:
                        r['bucket'] = 'ready'
                    else:
                        r['bucket'] = 'manual_resolution'
                        mentioned_channel = ''
                        for k, v in (r.get('extracted') or {}).items():
                            if k.lower() == 'channel' and v:
                                mentioned_channel = str(v).strip()
                                break
                        via = f' (ticket says: {mentioned_channel})' if mentioned_channel else ' — check EVEARA/ADA/RouteNote/other channels directly, Overlord has no lookup for them'
                        r['reasoning'] = (r.get('reasoning') or '').rstrip('.') + \
                            f'. "{song_name}" has no NueMeta delivery records{via}.'

        if on_progress:
            on_progress(i + 1)

    return results
