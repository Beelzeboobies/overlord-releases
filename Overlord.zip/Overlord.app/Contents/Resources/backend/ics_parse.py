"""Reads an iCalendar feed (Google Calendar's secret iCal address, or an uploaded .ics) into plain events.

Why this exists (9 Nov 2026): a Google event that repeats (a weekly meeting, say) is ONE entry in the feed with an
RRULE; the old import stored only that entry, so the event showed on its first date and never on later ones, which
is why "today's" meeting was missing. Repeating events are now expanded here into one event per occurrence inside a
window around today, honouring INTERVAL / COUNT / UNTIL, deleted occurrences (EXDATE), and moved or cancelled single
occurrences (RECURRENCE-ID overrides).

The first occurrence keeps the feed's own UID, so rows imported before this change are updated in place instead of
being duplicated; later occurrences get "<uid>#<start>".
"""
from datetime import date as _date, datetime as _dt, timedelta as _td, timezone as _tz

PAST_DAYS = 60            # occurrences this far back are still created
FUTURE_DAYS = 550         # ...and this far ahead
MAX_PER_EVENT = 800       # safety cap for an event that repeats very often


def _to_iso(d):
    if isinstance(d, _dt):
        if d.tzinfo is None:
            return d.isoformat()
        return d.astimezone(_tz.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    return d.isoformat() + 'T00:00:00Z'


def _is_all_day(d):
    return isinstance(d, _date) and not isinstance(d, _dt)


def _key(d):
    """A comparable identity for an occurrence start (UTC for timed events, the date for all-day ones)."""
    if isinstance(d, _dt):
        if d.tzinfo is None:
            return d.replace(microsecond=0).isoformat()
        return d.astimezone(_tz.utc).strftime('%Y-%m-%dT%H:%M:%S')
    return d.isoformat()


def _prop_dt(component, name):
    p = component.get(name)
    return getattr(p, 'dt', None) if p is not None else None


def _exdates(component):
    out = set()
    ex = component.get('EXDATE')
    if ex is None:
        return out
    for item in (ex if isinstance(ex, list) else [ex]):
        for d in getattr(item, 'dts', []) or []:
            out.add(_key(d.dt))
    return out


def _base_fields(component):
    desc = str(component.get('DESCRIPTION', '') or '')[:4000]
    loc = str(component.get('LOCATION', '') or '')[:500]
    url = str(component.get('URL', '') or '')
    conf = str(component.get('X-GOOGLE-CONFERENCE', '') or '')
    return {
        'title': str(component.get('SUMMARY', 'Untitled'))[:500],
        'desc': desc, 'loc': loc, 'url': (url + ' ' + conf).strip(),
    }


def _occurrences(master, dtstart, window_start, window_end):
    """Start datetimes/dates of a repeating event inside the window."""
    from dateutil.rrule import rrulestr
    rule = master.get('RRULE')
    rule = rule[0] if isinstance(rule, list) else rule
    parts = {k: list(v) if isinstance(v, (list, tuple)) else [v] for k, v in rule.items()}
    until = (parts.pop('UNTIL', None) or [None])[0]
    text = ';'.join(f"{k}={','.join(str(x) for x in v)}" for k, v in parts.items())

    all_day = _is_all_day(dtstart)
    start = _dt(dtstart.year, dtstart.month, dtstart.day) if all_day else dtstart
    aware = start.tzinfo is not None
    lo = window_start if aware else window_start.replace(tzinfo=None)
    hi = window_end if aware else window_end.replace(tzinfo=None)
    if not aware:
        lo, hi = lo - _td(days=1), hi + _td(days=1)

    rr = rrulestr(text, dtstart=start)
    until_dt = None
    if until is not None:
        until_dt = _dt(until.year, until.month, until.day, 23, 59, 59) if _is_all_day(until) else until
        if aware and until_dt.tzinfo is None:
            until_dt = until_dt.replace(tzinfo=start.tzinfo)
        if not aware and until_dt.tzinfo is not None:
            until_dt = until_dt.astimezone(_tz.utc).replace(tzinfo=None)

    out = []
    for occ in rr.between(lo, hi, inc=True):
        if until_dt is not None and occ > until_dt:
            continue
        out.append(occ.date() if all_day else occ)
        if len(out) >= MAX_PER_EVENT:
            break
    return out


def ics_events(cal, now=None):
    """Every event in `cal` as {uid, title, desc, loc, url, all_day, start_iso, end_iso}, repeats expanded."""
    now = now or _dt.now(_tz.utc)
    window_start = now - _td(days=PAST_DAYS)
    window_end = now + _td(days=FUTURE_DAYS)

    masters, overrides = [], {}
    for c in cal.walk():
        if c.name != 'VEVENT':
            continue
        rid = _prop_dt(c, 'RECURRENCE-ID')
        if rid is not None:
            overrides[(str(c.get('UID', '')), _key(rid))] = c
        else:
            masters.append(c)

    items = []

    def add(uid, component, start, end):
        base = _base_fields(component)
        items.append({'uid': uid, **base, 'all_day': _is_all_day(start),
                      'start_iso': _to_iso(start), 'end_iso': _to_iso(end)})

    for m in masters:
        try:
            uid = str(m.get('UID', ''))
            dtstart = _prop_dt(m, 'DTSTART')
            if dtstart is None:
                continue
            dtend = _prop_dt(m, 'DTEND') or dtstart
            if str(m.get('STATUS', '')).upper() == 'CANCELLED':
                continue
            if m.get('RRULE') is None:
                add(uid, m, dtstart, dtend)
                continue
            span = dtend - dtstart
            skip = _exdates(m)
            first_key = _key(dtstart)
            for occ in _occurrences(m, dtstart, window_start, window_end):
                k = _key(occ)
                if k in skip or (uid, k) in overrides:
                    continue
                add(uid if k == first_key else f'{uid}#{_to_iso(occ)}', m, occ, occ + span)
        except Exception:
            continue

    for (uid, rid_key), c in overrides.items():
        try:
            if str(c.get('STATUS', '')).upper() == 'CANCELLED':
                continue
            dtstart = _prop_dt(c, 'DTSTART')
            if dtstart is None:
                continue
            dtend = _prop_dt(c, 'DTEND') or dtstart
            # an occurrence moved to a new time is its own event; named after the original occurrence
            add(f'{uid}#{rid_key}', c, dtstart, dtend)
        except Exception:
            continue
    return items


def upsert_ics_events(conn, items, find_conf_url):
    """Store parsed events (insert new, update known by ical_uid). Returns (imported, updated)."""
    imported = updated = 0
    for it in items:
        try:
            meet_url = find_conf_url(it['url'] + ' ' + it['desc'] + ' ' + it['loc'])
            existing = conn.execute('SELECT id FROM events WHERE ical_uid=? AND ical_uid != ""', (it['uid'],)).fetchone()
            if existing:
                conn.execute(
                    '''UPDATE events SET title=?,start_dt=?,end_dt=?,all_day=?,location=?,
                       description=?,meet_url=?,notified=0 WHERE id=?''',
                    (it['title'], it['start_iso'], it['end_iso'], 1 if it['all_day'] else 0, it['loc'],
                     it['desc'], meet_url, existing['id']))
                updated += 1
            else:
                conn.execute(
                    '''INSERT INTO events (title,start_dt,end_dt,all_day,location,description,meet_url,ical_uid,reminder_minutes)
                       VALUES (?,?,?,?,?,?,?,?,10)''',
                    (it['title'], it['start_iso'], it['end_iso'], 1 if it['all_day'] else 0, it['loc'],
                     it['desc'], meet_url, it['uid']))
                imported += 1
        except Exception:
            continue
    return imported, updated
