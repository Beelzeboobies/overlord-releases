import json

from flask import Blueprint, request, jsonify

bp = Blueprint('notifications', __name__)


@bp.route('/api/notify/telegram', methods=['POST', 'OPTIONS'])
def notify_telegram():
    """Send a Telegram message via the user's bot."""
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json() or {}
    token   = (body.get('token') or '').strip()
    chat_id = (body.get('chat_id') or '').strip()
    text    = (body.get('text') or '').strip()
    if not token or not chat_id or not text:
        return jsonify({'ok': False, 'error': 'missing token, chat_id or text'}), 400
    try:
        import urllib.request as _ureq, urllib.parse as _uparse
        url  = f'https://api.telegram.org/bot{token}/sendMessage'
        data = _uparse.urlencode({'chat_id': chat_id, 'text': text, 'parse_mode': 'MarkdownV2'}).encode()
        req  = _ureq.Request(url, data=data, method='POST')
        with _ureq.urlopen(req, timeout=8) as resp:
            result = json.loads(resp.read())
        return jsonify({'ok': result.get('ok', False)})
    except Exception as ex:
        return jsonify({'ok': False, 'error': str(ex)}), 500
