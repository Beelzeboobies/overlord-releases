import json
import os
import subprocess
import sys
from pathlib import Path

from flask import Blueprint, request, jsonify, send_from_directory

from config import APP_SUPPORT, SETTINGS_PATH, FRONTEND_DIST, FRONTEND_PUBLIC
from db import get_db

bp = Blueprint('settings', __name__)

# ── Path constants ────────────────────────────────────────────────────────────

ALLOWED_IMAGE_TYPES = {'image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/svg+xml'}
ALLOWED_AUDIO_TYPES = {'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/aac', 'audio/x-wav', 'audio/wave'}
ALLOWED_FONT_EXTS = {'ttf', 'otf', 'woff', 'woff2'}

# Default Support Signature (ticket replies/new tickets, via
# SupportCompose.jsx — the compose component Tickets uses).
#
# Text only, deliberately no logo embedded here — SupportCompose.jsx
# already appends the real Freecords logo to every send on its own
# (FREECORDS_LOGO_URL, a live https://my.freecords.com/... asset,
# concatenated after the signature text in both new-ticket and reply
# paths, gated on the same `useSignature` toggle). Confirmed live via the
# actual New Ticket compose window that this already renders correctly.
# An earlier version of this default embedded its own base64 logo image
# inside the text — that would have shown the logo twice in every sent
# reply, so it's just the text here.
DEFAULT_SUPPORT_SIGNATURE = 'Warmest Regards,\nFreecords Team'

# User-uploaded sounds live in the exact same folder as the bundled
# defaults, by design — every sound (default or user-added) is one flat
# collection in one place, not split across a repo location and an
# Application Support location depending on which kind it is.
#
# Write to BOTH SOUNDS_DIST (frontend/dist/sounds, what's actually being
# served right now) and SOUNDS_PUBLIC (frontend/public/sounds, Vite's own
# source folder) on every upload. This is what makes it safe against a
# rebuild: `vite build` only ever empties and regenerates `dist/` from
# `public/` — it never touches or deletes anything already inside
# `public/` itself. So as long as an upload is also written to
# SOUNDS_PUBLIC, a later `npm run build` can't wipe it — the next build
# just copies it straight back into `dist/` along with every other file
# already there. A rebuild adds the newly-built defaults' changes on top;
# it never subtracts a file a user placed in `public/`.
SOUNDS_DIST   = FRONTEND_DIST   / 'sounds'
SOUNDS_PUBLIC = FRONTEND_PUBLIC / 'sounds'
SOUNDS_DIST.mkdir(parents=True, exist_ok=True)
SOUNDS_PUBLIC.mkdir(parents=True, exist_ok=True)


# ── Client-side error reporting (temporary debug aid) ──────────────────────────
# Overlord's production window is a WKWebView with no DevTools access (see
# CLAUDE.md's WebView2 debugging note — same problem exists on Mac, just no
# documented workaround yet). A React crash there just shows a blank white
# screen with zero diagnostic info. This lets the frontend's window.onerror /
# unhandledrejection handlers (see main.jsx) POST the real error here so it
# lands in backend.log where it's actually visible.
@bp.route('/api/client-error', methods=['POST', 'OPTIONS'])
def client_error():
    body = request.get_json(force=True) or {}
    # print()/logging both go nowhere from a background-thread Flask app in
    # this codebase (see main.py's _sync_log docstring) — direct file write,
    # same workaround, so this is actually visible in backend.log.
    import datetime as _dt
    try:
        with open(APP_SUPPORT / 'logs' / 'backend.log', 'a') as f:
            f.write(f"[{_dt.datetime.now().isoformat(timespec='seconds')}] "
                     f"[client_error] {body.get('message')}\n{body.get('stack', '')}\n")
    except Exception:
        pass
    return jsonify(ok=True)


# ── Custom statuses ───────────────────────────────────────────────────────────

@bp.route('/api/custom-statuses', methods=['GET', 'POST', 'OPTIONS'])
def custom_statuses():
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'POST':
        body = request.get_json()
        conn.execute('INSERT OR IGNORE INTO custom_statuses (name,color) VALUES (?,?)',
                     (body['name'], body.get('color', '#e8a020')))
        conn.commit()
        conn.close()
        return jsonify(ok=True)
    rows = conn.execute('SELECT * FROM custom_statuses ORDER BY name').fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@bp.route('/api/custom-statuses/<int:sid>', methods=['DELETE', 'OPTIONS'])
def delete_status(sid):
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    conn.execute('DELETE FROM custom_statuses WHERE id=?', (sid,))
    conn.commit()
    conn.close()
    return jsonify(ok=True)


# ── Custom folders ────────────────────────────────────────────────────────────

@bp.route('/api/custom-folders', methods=['GET', 'POST', 'OPTIONS'])
def custom_folders():
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'POST':
        body = request.get_json()
        conn.execute('INSERT OR IGNORE INTO custom_folders (name) VALUES (?)', (body['name'],))
        conn.commit()
        conn.close()
        return jsonify(ok=True)
    rows = conn.execute('SELECT * FROM custom_folders ORDER BY name').fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@bp.route('/api/custom-folders/<int:fid>', methods=['DELETE', 'OPTIONS'])
def delete_folder(fid):
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    conn.execute('DELETE FROM custom_folders WHERE id=?', (fid,))
    conn.commit()
    conn.close()
    return jsonify(ok=True)


# ── Settings ──────────────────────────────────────────────────────────────────

@bp.route('/api/settings', methods=['GET', 'OPTIONS'])
def get_settings():
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    rows = conn.execute('SELECT key, value FROM settings').fetchall()
    conn.close()
    data = {r['key']: r['value'] for r in rows}
    data.setdefault('sound_inbox_vol', '0.3')
    data.setdefault('sound_send_vol',  '0.3')
    # setdefault alone isn't enough here: an existing row with value ''
    # (the common case — the field's been sitting blank in Settings) is
    # present, not absent, so setdefault would never apply and the
    # frontend's own `d?.support_signature || d?.signature_html || ...`
    # fallback chain would skip straight past this to the general Email
    # Signature instead.
    if not data.get('support_signature'):
        data['support_signature'] = DEFAULT_SUPPORT_SIGNATURE
    # Support Signature's image slot, mirroring Email Signature's
    # signature_image/sig_img_width/sig_img_layout exactly (see
    # /api/settings/support-signature-image below) — defaults to the
    # same live, publicly-hosted Freecords logo SupportCompose.jsx
    # already used before this slot existed, not a bundled/localhost
    # asset, since a Freshdesk-sent reply has to render for the actual
    # recipient's email client, not just inside Overlord.
    if not data.get('support_signature_image'):
        data['support_signature_image'] = 'https://my.freecords.com/logo/musical-note-icon.svg'
    data.setdefault('support_sig_img_width', '80')
    data.setdefault('support_sig_img_layout', 'below')
    return jsonify(data)

@bp.route('/api/settings', methods=['POST'])
def save_settings():
    body = request.get_json()
    # context_folders/context_files_extra/context_urls/context_excludes are
    # per-scope now (see claude.py's _build_context_text) — 'email'/'support'
    # suffixed variants replace the old bare keys, which nothing writes to
    # any more. claude_chat_name/claude_chat_steps/claude_conv_url/claude_mode
    # backed the retired single-email "send to Claude Desktop/browser" (S key)
    # hand-off — removed with that feature; Reply with Claude (the paid,
    # inline-draft replacement) has no equivalent settings.
    allowed = {'signature_html', 'support_signature', 'support_signature_image', 'support_sig_img_width', 'support_sig_img_layout', 'timezone', 'date_format', 'display_name', 'signature_image', 'theme', 'shortcuts', 'auto_refresh', 'ui_scale',
               'context_folders_email', 'context_files_extra_email', 'context_urls_email', 'context_excludes_email',
               'context_folders_support', 'context_files_extra_support', 'context_urls_support', 'context_excludes_support',
               'calendar_notifications', 'calendar_default_reminder', 'calendar_default_view', 'gcal_ics_url', 'gcal_sync_interval', 'sig_img_layout', 'sig_img_width', 'account_notifications', 'notif_macos_enabled', 'notif_macos_sound', 'notif_telegram_enabled', 'notif_telegram_token', 'notif_telegram_chat_id', 'undo_send_delay', 'claude_default_instruction', 'canned_responses', 'sound_inbox', 'sound_send', 'sound_inbox_vol', 'sound_send_vol', 'sound_inbox_cooldown', 'compose_font', 'compose_font_url', 'compose_font_name', 'custom_fonts', 'muted_accounts', 'freecords_admin_base_url', 'email_body_bg', 'thread_mode_accounts', 'tickets_thread_mode', 'fadmin_group_instructions',
               'ticket_expiry_enabled', 'duplicate_ticket_cleanup_enabled',
               # 'hotkeys' (Mail's 1-9 folder jump) was never in this list: the
               # frontend posted it on every autosave and it was silently
               # dropped, so only a legacy row from before the allow-list
               # existed ever persisted. mod_* are Moderation's own hotkeys,
               # which used to live only in the webview's localStorage.
               'hotkeys', 'mod_hotkeys', 'mod_deny_hotkeys'}
    conn = get_db()
    for key, value in body.items():
        if key in allowed:
            # Real, confirmed incident (2026-09-18): ticket_creation_from_mail_enabled
            # found back on with nobody able to account for it -- the second
            # unexplained change to this exact setting (first was 2026-09-07,
            # opposite direction). The settings table only ever held the
            # current value, so there was never anything to check "who/what
            # changed this and when" against. Log every actual change (old
            # value differs from new, including key-didn't-exist-before) --
            # skip a write that doesn't actually change anything so routine
            # autosave of an unchanged field doesn't spam the log.
            old_row = conn.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
            old_value = old_row['value'] if old_row else None
            if old_value != value:
                conn.execute(
                    'INSERT INTO settings_change_log (key, old_value, new_value) VALUES (?, ?, ?)',
                    (key, old_value, value),
                )
            conn.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
    conn.commit()
    conn.close()
    return jsonify(ok=True)


@bp.route('/api/settings/change-log')
def settings_change_log():
    """Real answer to "who/what changed this setting and when" -- see
    save_settings' own comment. Optional ?key= filters to one setting
    (e.g. ?key=ticket_creation_from_mail_enabled); otherwise returns
    everything, newest first, capped at 500 rows."""
    key = request.args.get('key', '').strip()
    conn = get_db()
    if key:
        rows = conn.execute(
            'SELECT key, old_value, new_value, changed_at FROM settings_change_log '
            'WHERE key=? ORDER BY id DESC LIMIT 500', (key,)
        ).fetchall()
    else:
        rows = conn.execute(
            'SELECT key, old_value, new_value, changed_at FROM settings_change_log '
            'ORDER BY id DESC LIMIT 500'
        ).fetchall()
    conn.close()
    return jsonify(changes=[dict(r) for r in rows])

@bp.route('/api/settings/signature-image', methods=['POST', 'OPTIONS'])
def upload_signature_image():
    if request.method == 'OPTIONS':
        return '', 204
    if 'file' not in request.files:
        return jsonify(error='no file'), 400
    f = request.files['file']
    if f.content_type not in ALLOWED_IMAGE_TYPES:
        return jsonify(error='unsupported file type'), 400
    # Limit to 2MB
    f.seek(0, 2)
    size = f.tell()
    f.seek(0)
    if size > 2 * 1024 * 1024:
        return jsonify(error='file too large (max 2MB)'), 400
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else 'png'
    dest = SETTINGS_PATH / f'signature.{ext}'
    f.save(dest)
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('signature_image', ?)", (f'/api/uploads/signature.{ext}',))
    conn.commit()
    conn.close()
    return jsonify(ok=True, url=f'/api/uploads/signature.{ext}')

@bp.route('/api/settings/support-signature-image', methods=['POST', 'OPTIONS'])
def upload_support_signature_image():
    """
    Mirrors upload_signature_image() above exactly, own file/setting key so
    it doesn't collide with the Email Signature's image. One real
    difference worth knowing if this ever needs revisiting: unlike the
    Email Signature (sent via helpers.py's own SMTP path), the Support
    Signature's image only ever gets used by SupportCompose.jsx sending
    through the Freshdesk/native ticket APIs — those just forward the
    HTML as-is, no image embedding step. An uploaded file here is served
    from THIS machine (/api/uploads/support-signature.{ext}), which is
    fine for the in-app preview but won't resolve for an actual ticket
    recipient once the reply leaves this machine — same reason
    get_settings()'s default for support_signature_image is a real
    public URL, not a bundled asset. The frontend surfaces this as a
    plain warning rather than blocking the upload, since a self-hosted
    reachable URL is a legitimate thing to point this at.
    """
    if request.method == 'OPTIONS':
        return '', 204
    if 'file' not in request.files:
        return jsonify(error='no file'), 400
    f = request.files['file']
    if f.content_type not in ALLOWED_IMAGE_TYPES:
        return jsonify(error='unsupported file type'), 400
    f.seek(0, 2)
    size = f.tell()
    f.seek(0)
    if size > 2 * 1024 * 1024:
        return jsonify(error='file too large (max 2MB)'), 400
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else 'png'
    dest = SETTINGS_PATH / f'support-signature.{ext}'
    f.save(dest)
    conn = get_db()
    conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('support_signature_image', ?)",
                 (f'/api/uploads/support-signature.{ext}',))
    conn.commit()
    conn.close()
    return jsonify(ok=True, url=f'/api/uploads/support-signature.{ext}')

@bp.route('/api/settings/signature', methods=['GET', 'POST', 'OPTIONS'])
def account_signature():
    """Per-account signature: GET ?account=email  /  POST {account, html, image}"""
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key='account_signatures'").fetchone()
    sigs = json.loads(row[0]) if row else {}

    if request.method == 'GET':
        account = request.args.get('account', '')
        sig = sigs.get(account, {})
        conn.close()
        return jsonify(html=sig.get('html', ''), image=sig.get('image', ''))

    # POST — save html + image for one account
    body    = request.get_json(force=True) or {}
    account = body.get('account', '')
    if not account:
        conn.close()
        return jsonify(error='account required'), 400
    sigs[account] = {'html': body.get('html', ''), 'image': body.get('image', '')}
    conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('account_signatures',?)",
                 (json.dumps(sigs),))
    conn.commit()
    conn.close()
    return jsonify(ok=True)


@bp.route('/api/settings/signature-image-account', methods=['POST', 'OPTIONS'])
def upload_signature_image_account():
    """Upload a signature image for a specific account; returns its URL."""
    if request.method == 'OPTIONS':
        return '', 204
    account = request.args.get('account', '')
    if not account:
        return jsonify(error='account required'), 400
    if 'file' not in request.files:
        return jsonify(error='no file'), 400
    f = request.files['file']
    if f.content_type not in ALLOWED_IMAGE_TYPES:
        return jsonify(error='unsupported file type'), 400
    f.seek(0, 2); size = f.tell(); f.seek(0)
    if size > 2 * 1024 * 1024:
        return jsonify(error='file too large (max 2MB)'), 400
    import hashlib
    acct_slug = hashlib.sha256(account.encode()).hexdigest()[:8]
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else 'png'
    dest = SETTINGS_PATH / f'signature_{acct_slug}.{ext}'
    f.save(dest)
    url = f'/api/uploads/signature_{acct_slug}.{ext}'
    # Persist image URL into account_signatures immediately
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key='account_signatures'").fetchone()
    sigs = json.loads(row[0]) if row else {}
    sigs.setdefault(account, {})['image'] = url
    conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('account_signatures',?)",
                 (json.dumps(sigs),))
    conn.commit()
    conn.close()
    return jsonify(ok=True, url=url)


@bp.route('/api/settings/font', methods=['POST', 'OPTIONS'])
def upload_font():
    if request.method == 'OPTIONS':
        return '', 204
    if 'file' not in request.files:
        return jsonify(error='no file'), 400
    f = request.files['file']
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else ''
    if ext not in ALLOWED_FONT_EXTS:
        return jsonify(error=f'unsupported font type (use ttf, otf, woff, woff2)'), 400
    f.seek(0, 2); size = f.tell(); f.seek(0)
    if size > 10 * 1024 * 1024:
        return jsonify(error='file too large (max 10MB)'), 400
    font_name = f.filename.rsplit('.', 1)[0]
    safe_name = ''.join(c if c.isalnum() or c in '-_' else '_' for c in font_name)
    dest = SETTINGS_PATH / f'font_{safe_name}.{ext}'
    f.save(dest)
    url = f'/api/uploads/font_{safe_name}.{ext}'
    css_family = f'"{font_name}"'
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key='custom_fonts'").fetchone()
    fonts = json.loads(row[0]) if row else []
    # Replace entry with same name if it exists, otherwise append
    fonts = [x for x in fonts if x.get('name') != font_name]
    fonts.append({'name': font_name, 'url': url, 'css_family': css_family})
    conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('custom_fonts', ?)", (json.dumps(fonts),))
    conn.commit()
    conn.close()
    return jsonify(ok=True, url=url, name=font_name, css_family=css_family)

@bp.route('/api/settings/font/delete', methods=['POST', 'OPTIONS'])
def delete_font():
    if request.method == 'OPTIONS':
        return '', 204
    data = request.get_json(silent=True) or {}
    font_name = data.get('name')
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key='custom_fonts'").fetchone()
    fonts = json.loads(row[0]) if row else []
    to_delete = next((x for x in fonts if x.get('name') == font_name), None)
    if to_delete:
        fname = to_delete['url'].lstrip('/').replace('api/uploads/', '')
        path = SETTINGS_PATH / fname
        if path.exists():
            path.unlink()
        fonts = [x for x in fonts if x.get('name') != font_name]
        conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES ('custom_fonts', ?)", (json.dumps(fonts),))
    # If selected font was deleted, clear compose_font
    compose_row = conn.execute("SELECT value FROM settings WHERE key='compose_font'").fetchone()
    if compose_row and compose_row[0] == f'"{font_name}"':
        conn.execute("DELETE FROM settings WHERE key='compose_font'")
    conn.commit()
    conn.close()
    return jsonify(ok=True)

@bp.route('/api/settings/sound', methods=['POST', 'OPTIONS'])
def upload_sound():
    if request.method == 'OPTIONS':
        return '', 204
    event = request.form.get('event', '')  # 'inbox' or 'send'
    if event not in ('inbox', 'send'):
        return jsonify(error='invalid event'), 400
    if 'file' not in request.files:
        return jsonify(error='no file'), 400
    f = request.files['file']
    ct = f.content_type or ''
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else ''
    if ct not in ALLOWED_AUDIO_TYPES and ext not in ('mp3', 'wav', 'ogg', 'aac', 'm4a'):
        return jsonify(error='unsupported file type — use mp3, wav, ogg, or aac'), 400
    if not ext:
        ext = 'mp3'
    f.seek(0, 2); size = f.tell(); f.seek(0)
    if size > 5 * 1024 * 1024:
        return jsonify(error='file too large (max 5MB)'), 400

    # Find next available index for this event
    idx = 0
    while any(SOUNDS_DIST.glob(f'sound_{event}_{idx}.*')):
        idx += 1
    fname = f'sound_{event}_{idx}.{ext}'
    data = f.read()
    (SOUNDS_DIST   / fname).write_bytes(data)
    (SOUNDS_PUBLIC / fname).write_bytes(data)
    url = f'/sounds/{fname}'

    original_name = f.filename or f'sound.{ext}'
    try:
        gain = float(request.form.get('gain', 1))
        gain = max(0.01, min(gain, 20))
    except (TypeError, ValueError):
        gain = 1.0
    entry = {'url': url, 'name': original_name, 'gain': round(gain, 4)}

    # Append to JSON array in settings
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (f'sound_{event}',)).fetchone()
    existing = json.loads(row[0]) if row and row[0] else []
    if not isinstance(existing, list):
        existing = [existing] if existing else []
    existing.append(entry)
    conn.execute('INSERT OR REPLACE INTO settings (key,value) VALUES (?, ?)',
                 (f'sound_{event}', json.dumps(existing)))
    conn.commit()
    conn.close()
    return jsonify(ok=True, url=url, urls=existing)


@bp.route('/api/settings/sound/delete', methods=['POST', 'OPTIONS'])
def delete_sound():
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json(force=True) or {}
    event = body.get('event', '')
    url   = body.get('url', '')
    if event not in ('inbox', 'send') or not url:
        return jsonify(error='bad request'), 400
    # Remove from settings array
    conn = get_db()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (f'sound_{event}',)).fetchone()
    urls = json.loads(row[0]) if row and row[0] else []
    if not isinstance(urls, list):
        urls = [urls] if urls else []
    urls = [u for u in urls if (u if isinstance(u, str) else u.get('url', '')) != url]
    conn.execute('INSERT OR REPLACE INTO settings (key,value) VALUES (?, ?)',
                 (f'sound_{event}', json.dumps(urls)))
    conn.commit()
    conn.close()
    # Delete physical file from both locations
    if url.startswith('/sounds/'):
        fname = url[len('/sounds/'):]
        (SOUNDS_DIST   / fname).unlink(missing_ok=True)
        (SOUNDS_PUBLIC / fname).unlink(missing_ok=True)
    else:
        # Legacy /api/uploads/ path
        fname = url.lstrip('/').replace('api/uploads/', '')
        (SETTINGS_PATH / fname).unlink(missing_ok=True)
    return jsonify(ok=True, urls=urls)


@bp.route('/api/settings/sound/move', methods=['POST', 'OPTIONS'])
def move_sound():
    """Move a sound entry between inbox and send pools."""
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json(force=True) or {}
    from_event = body.get('from', '')
    to_event   = body.get('to', '')
    url        = body.get('url', '')
    if from_event not in ('inbox', 'send') or to_event not in ('inbox', 'send') or not url or from_event == to_event:
        return jsonify(error='bad request'), 400
    conn = get_db()
    from_row = conn.execute("SELECT value FROM settings WHERE key=?", (f'sound_{from_event}',)).fetchone()
    to_row   = conn.execute("SELECT value FROM settings WHERE key=?", (f'sound_{to_event}',)).fetchone()
    from_list = json.loads(from_row[0]) if from_row and from_row[0] else []
    to_list   = json.loads(to_row[0])   if to_row   and to_row[0]   else []
    entry = next((e for e in from_list if (e if isinstance(e, str) else e.get('url', '')) == url), None)
    if not entry:
        conn.close()
        return jsonify(error='not found'), 404
    from_list = [e for e in from_list if (e if isinstance(e, str) else e.get('url', '')) != url]
    to_list.append(entry)
    conn.execute('INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)', (f'sound_{from_event}', json.dumps(from_list)))
    conn.execute('INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)', (f'sound_{to_event}',   json.dumps(to_list)))
    conn.commit()
    conn.close()
    return jsonify(ok=True, from_list=from_list, to_list=to_list)


@bp.route('/api/open-external', methods=['POST', 'OPTIONS'])
def open_external():
    """Open an http(s) URL in the system default browser.

    The app's webview swallows link clicks: an email rendered in the
    reading pane's sandboxed iframe navigates the iframe itself (blank —
    the target page won't render in a sandboxed frame), and HTML rendered
    via dangerouslySetInnerHTML divs (ticket threads) would navigate the
    entire webview. User-reported with a sign-in-link email: "If I click
    this link - it wont bring me to the web address, instead the email
    itself will turn blank." Frontend intercepts those clicks and posts
    the URL here instead — same webbrowser.open pattern print-open uses.
    Strictly http/https only; anything else (file:, javascript:, ...) is
    rejected.
    """
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json(silent=True) or {}
    url = (body.get('url') or '').strip()
    if not url.lower().startswith(('http://', 'https://')):
        return jsonify(error='only http(s) URLs can be opened'), 400
    import webbrowser
    webbrowser.open(url)
    return jsonify(ok=True)


@bp.route('/api/copy-text', methods=['POST', 'OPTIONS'])
def copy_text():
    """Copy text to the system clipboard, backend-side.

    The webview's own navigator.clipboard is permission-fussy inside an
    embedded shell (and unavailable to content in the sandboxed email
    iframe), so the link context menu's "Copy link address" posts here —
    reuses clipboard.py's copy_to_clipboard, the same writer the Claude
    paste hand-off already depends on.
    """
    if request.method == 'OPTIONS':
        return '', 204
    body = request.get_json(silent=True) or {}
    text = body.get('text')
    if not text or not isinstance(text, str):
        return jsonify(error='text required'), 400
    try:
        from clipboard import copy_to_clipboard
        copy_to_clipboard(text)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(error=f'clipboard write failed: {e}'), 500


@bp.route('/api/sounds/open-folder', methods=['POST', 'OPTIONS'])
def open_sounds_folder():
    """Open the sounds folder in the OS file browser (Finder/Explorer) —
    the same folder holds both bundled defaults and every user upload."""
    if request.method == 'OPTIONS':
        return '', 204
    if sys.platform == 'win32':
        os.startfile(str(SOUNDS_DIST))
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', str(SOUNDS_DIST)])
    else:
        subprocess.Popen(['xdg-open', str(SOUNDS_DIST)])
    return jsonify(ok=True)


@bp.route('/api/backup/status')
def backup_status():
    """Surfaces backup.py's rotating-backup state — when the app runs the
    backups silently in the background, there was otherwise no way to
    actually confirm it's working short of checking the filesystem by
    hand."""
    import backup as _backup_mod
    backups = sorted(_backup_mod.BACKUP_DIR.glob('mail-*.db')) if _backup_mod.BACKUP_DIR.is_dir() else []
    last = backups[-1] if backups else None
    return jsonify(
        backup_count=len(backups),
        last_backup=last.stem.replace('mail-', '') if last else None,
        last_backup_size=last.stat().st_size if last else None,
        backup_dir=str(_backup_mod.BACKUP_DIR),
    )


@bp.route('/api/uploads/<filename>')
def serve_upload(filename):
    from flask import send_from_directory
    return send_from_directory(SETTINGS_PATH, filename)


@bp.route('/api/settings/pick-folder', methods=['POST', 'OPTIONS'])
def pick_folder():
    """Open a native macOS folder-picker dialog via osascript and return the chosen path."""
    if request.method == 'OPTIONS':
        return '', 204
    try:
        script = 'choose folder with prompt "Select context folder for Overlord AI assistance"'
        result = subprocess.run(
            ['osascript', '-e', script],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode != 0:
            # User cancelled
            return jsonify(ok=False, cancelled=True)
        # osascript returns path in HFS format: "alias Macintosh HD:Users:ozz:..."
        hfs = result.stdout.strip()
        # Convert HFS to POSIX
        posix_result = subprocess.run(
            ['osascript', '-e', f'POSIX path of ("{hfs}")'],
            capture_output=True, text=True, timeout=5
        )
        posix = posix_result.stdout.strip().rstrip('/')
        if not posix or not Path(posix).is_dir():
            return jsonify(ok=False, error='Invalid path returned')
        return jsonify(ok=True, path=posix)
    except Exception as e:
        return jsonify(ok=False, error=str(e))


@bp.route('/api/settings/pick-file', methods=['POST', 'OPTIONS'])
def pick_file():
    """Open a native macOS file-picker dialog and return the chosen path."""
    if request.method == 'OPTIONS':
        return '', 204
    try:
        script = 'choose file with prompt "Select a file for Overlord AI context"'
        result = subprocess.run(['osascript', '-e', script], capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            return jsonify(ok=False, cancelled=True)
        hfs = result.stdout.strip()
        posix_result = subprocess.run(['osascript', '-e', f'POSIX path of ("{hfs}")'],
                                      capture_output=True, text=True, timeout=5)
        posix = posix_result.stdout.strip().rstrip('/')
        if not posix or not Path(posix).is_file():
            return jsonify(ok=False, error='Invalid file path')
        return jsonify(ok=True, path=posix)
    except Exception as e:
        return jsonify(ok=False, error=str(e))


@bp.route('/api/settings/pick-any', methods=['POST', 'OPTIONS'])
def pick_any():
    """Open a native picker that accepts both files and folders, returning path + is_dir."""
    if request.method == 'OPTIONS':
        return '', 204
    try:
        script = 'choose file or folder'
        result = subprocess.run(['osascript', '-e', script], capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            return jsonify(ok=False, cancelled=True)
        hfs = result.stdout.strip()
        posix_result = subprocess.run(['osascript', '-e', f'POSIX path of ("{hfs}")'],
                                      capture_output=True, text=True, timeout=5)
        posix = posix_result.stdout.strip().rstrip('/')
        if not posix:
            return jsonify(ok=False, error='Invalid path')
        return jsonify(ok=True, path=posix, is_dir=Path(posix).is_dir())
    except Exception as e:
        return jsonify(ok=False, error=str(e))
