import json

from flask import Blueprint, request, jsonify

from db import get_db

bp = Blueprint('contacts', __name__)


@bp.route('/api/contacts', methods=['GET', 'POST', 'OPTIONS'])
def contacts():
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'POST':
        b = request.get_json()
        tags = json.dumps(b.get('tags') or [])
        conn.execute(
            'INSERT OR REPLACE INTO contacts (name, email, city, timezone, notes, dob, tags) VALUES (?,?,?,?,?,?,?)',
            (b['name'], b['email'], b.get('city'), b.get('timezone'), b.get('notes'), b.get('dob'), tags)
        )
        conn.commit()
        conn.close()
        return jsonify(ok=True)
    rows = conn.execute('SELECT * FROM contacts ORDER BY name').fetchall()
    conn.close()
    out = []
    for r in rows:
        d = dict(r)
        try: d['tags'] = json.loads(d.get('tags') or '[]')
        except: d['tags'] = []
        out.append(d)
    return jsonify(out)


@bp.route('/api/contacts/search', methods=['GET', 'OPTIONS'])
def contacts_search():
    if request.method == 'OPTIONS':
        return '', 204
    q = (request.args.get('q') or '').strip().lower()
    if not q:
        return jsonify([])
    account = request.args.get('account', '')
    conn = get_db()
    # 1. Explicit contacts
    rows = conn.execute(
        "SELECT name, email FROM contacts WHERE lower(name) LIKE ? OR lower(email) LIKE ? ORDER BY name LIMIT 20",
        (f'%{q}%', f'%{q}%')
    ).fetchall()
    results = {r['email'].lower(): {'name': r['name'], 'email': r['email']} for r in rows if r['email']}

    # 2. Email history — senders and recipients from message_cache
    like = f'%{q}%'
    cache_rows = conn.execute(
        """SELECT from_addr, from_name, to_addrs, cc FROM message_cache
           WHERE (lower(from_addr) LIKE ? OR lower(from_name) LIKE ?
                  OR lower(to_addrs) LIKE ? OR lower(cc) LIKE ?)
           LIMIT 200""",
        (like, like, like, like)
    ).fetchall()

    def parse_addrs(raw):
        """Extract (name, email) pairs from a comma-separated address string."""
        out = []
        for part in (raw or '').split(','):
            part = part.strip()
            if not part:
                continue
            if '<' in part:
                name = part[:part.index('<')].strip().strip('"')
                addr = part[part.index('<')+1:part.index('>')].strip().lower() if '>' in part else ''
            else:
                name, addr = '', part.strip().lower()
            if addr and '@' in addr:
                out.append((name, addr))
        return out

    for r in cache_rows:
        for field, name_hint in [(r['from_addr'], r['from_name']), (r['to_addrs'], ''), (r['cc'], '')]:
            for (nm, em) in parse_addrs(field if field else ''):
                if em not in results:
                    display = nm or name_hint or em
                    if q in em or q in display.lower():
                        results[em] = {'name': display, 'email': em}

    conn.close()
    out = sorted(results.values(), key=lambda x: (0 if q in x['email'] else 1, x['name'].lower()))
    return jsonify(out[:10])


@bp.route('/api/contacts/<int:cid>', methods=['GET', 'PATCH', 'DELETE', 'OPTIONS'])
def contact(cid):
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM contacts WHERE id=?', (cid,))
        conn.commit()
        conn.close()
        return jsonify(ok=True)
    if request.method == 'PATCH':
        b = request.get_json()
        if 'tags' in b:
            b = dict(b)
            b['tags'] = json.dumps(b.get('tags') or [])
        fields = {k: v for k, v in b.items() if k in ('name','email','city','timezone','notes','dob','tags')}
        if fields:
            sets = ', '.join(f'{k}=?' for k in fields)
            conn.execute(f'UPDATE contacts SET {sets} WHERE id=?', (*fields.values(), cid))
            conn.commit()
        conn.close()
        return jsonify(ok=True)
    row = conn.execute('SELECT * FROM contacts WHERE id=?', (cid,)).fetchone()
    conn.close()
    if not row:
        return jsonify({})
    d = dict(row)
    try: d['tags'] = json.loads(d.get('tags') or '[]')
    except: d['tags'] = []
    return jsonify(d)


@bp.route('/api/contacts/tags', methods=['GET', 'OPTIONS'])
def all_contact_tags():
    """Return all unique tags used across all contacts."""
    if request.method == 'OPTIONS':
        return '', 204
    conn = get_db()
    rows = conn.execute("SELECT tags FROM contacts WHERE tags IS NOT NULL AND tags != '[]'").fetchall()
    conn.close()
    tag_set = set()
    for r in rows:
        try:
            for t in json.loads(r['tags'] or '[]'):
                if t: tag_set.add(t)
        except: pass
    return jsonify(sorted(tag_set))


@bp.route('/api/contacts/by-email', methods=['GET', 'OPTIONS'])
def contact_by_email():
    """Return tags for a given email address."""
    if request.method == 'OPTIONS':
        return '', 204
    email_addr = (request.args.get('email') or '').strip().lower()
    if not email_addr:
        return jsonify({'tags': []})
    conn = get_db()
    row = conn.execute("SELECT tags FROM contacts WHERE lower(email)=?", (email_addr,)).fetchone()
    conn.close()
    if not row:
        return jsonify({'tags': []})
    try:
        return jsonify({'tags': json.loads(row['tags'] or '[]')})
    except:
        return jsonify({'tags': []})
