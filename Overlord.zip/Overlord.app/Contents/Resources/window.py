#!/usr/bin/env python3
"""Opens Overlord as a standalone native macOS window."""

import os
import subprocess
import sys
import tempfile
import time
import urllib.request

BASE        = os.path.dirname(os.path.abspath(__file__))
SERVER_ONLY = '--server-only' in sys.argv  # launched by the Swift launcher

# Single-instance lock file — OS temp dir rather than a hardcoded /tmp path
# (Windows doesn't have /tmp by default).
LOCK_FILE = os.path.join(tempfile.gettempdir(), "freecords-mail.pid")

# ── Server-only mode (launched by Swift WKWebView launcher) ──────────────────
if SERVER_ONLY:
    BACKEND_DIR = os.path.join(BASE, "backend")
    sys.path.insert(0, BACKEND_DIR)
    from config import APP_SUPPORT  # single source of truth for the data dir — see backend/config.py
    LOGS_DIR = os.path.join(APP_SUPPORT, "logs")

    os.makedirs(LOGS_DIR, exist_ok=True)

    import atexit
    def _cleanup():
        try: os.remove(LOCK_FILE)
        except: pass
    atexit.register(_cleanup)
    open(LOCK_FILE, "w").write(str(os.getpid()))

    # Re-register with LaunchServices on every startup so the Dock/Spotlight icon
    # stays correct after rebuilds. Works in both bundle mode and dev mode.
    def _fix_icon():
        try:
            _lsreg = ('/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/'
                      'LaunchServices.framework/Versions/A/Support/lsregister')
            # Bundle mode: window.py is inside Contents/Resources, bundle is two levels up
            _bundle_candidate = os.path.dirname(os.path.dirname(BASE))
            if _bundle_candidate.endswith('.app'):
                _bundle = _bundle_candidate
            else:
                # Dev mode: window.py sits next to Overlord.app
                _bundle = os.path.join(BASE, 'Overlord.app')
            if os.path.isdir(_bundle):
                subprocess.Popen([_lsreg, '-f', _bundle],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    import threading as _icon_thread
    _icon_thread.Thread(target=_fix_icon, daemon=True).start()

    import logging, threading as _threading
    backend_log_path = os.path.join(LOGS_DIR, "backend.log")
    log_file = open(backend_log_path, "a")
    handler = logging.StreamHandler(log_file)
    logging.getLogger('werkzeug').handlers = []
    logging.getLogger('werkzeug').addHandler(handler)
    logging.getLogger('werkzeug').setLevel(logging.INFO)
    import main as backend
    backend.app.run(host='127.0.0.1', port=8000, debug=False, threaded=True, use_reloader=False)
    sys.exit(0)

# ── Claim Overlord identity BEFORE webview/NSApplication initialises ──────────
# This must happen as early as possible so macOS registers the process under
# our bundle (com.freecords.overlord) rather than com.apple.python3.
try:
    from AppKit import NSApplication, NSImage
    _app = NSApplication.sharedApplication()
    _app.setActivationPolicy_(0)  # NSApplicationActivationPolicyRegular

    # Set our icon so ⌘-Tab shows the Overlord icon, not the Python rocket
    _icns = os.path.join(BASE, "Overlord.icns")  # bundle path
    if not os.path.exists(_icns):
        _icns = os.path.join(BASE, "Overlord.app", "Contents", "Resources", "Overlord.icns")  # dev path
    if os.path.exists(_icns):
        _icon = NSImage.alloc().initWithContentsOfFile_(_icns)
        if _icon:
            _app.setApplicationIconImage_(_icon)

    # Rename the process so Activity Monitor / ⌘-Tab shows "Overlord"
    from Foundation import NSProcessInfo
    NSProcessInfo.processInfo().setValue_forKey_("Overlord", "processName")

    # Update LaunchServices display name via private API
    try:
        import ctypes, ctypes.util
        _LS = ctypes.CDLL('/System/Library/Frameworks/CoreServices.framework/CoreServices')
        _CF = ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        # _LSSetApplicationInformationItem(kLSDefaultSessionID=-2, asn, key, value, 0)
        _CF.CFStringCreateWithCString.restype = ctypes.c_void_p
        _CF.CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
        _LS._LSGetCurrentApplicationASN.restype = ctypes.c_uint64
        _LS._LSSetApplicationInformationItem.restype = ctypes.c_int32
        _LS._LSSetApplicationInformationItem.argtypes = [
            ctypes.c_int32, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
        asn = _LS._LSGetCurrentApplicationASN()
        key = _CF.CFStringCreateWithCString(None, b'LSDisplayName', 0x08000100)
        val = _CF.CFStringCreateWithCString(None, b'Overlord', 0x08000100)
        _LS._LSSetApplicationInformationItem(-2, asn, key, val, None)
    except Exception:
        pass
except Exception:
    pass

import webview
BACKEND_DIR = os.path.join(BASE, "backend")
sys.path.insert(0, BACKEND_DIR)
from config import APP_SUPPORT  # single source of truth for the data dir — see backend/config.py
LOGS_DIR = os.path.join(APP_SUPPORT, "logs")

os.makedirs(LOGS_DIR, exist_ok=True)

# ── Single-instance guard ─────────────────────────────────────────────────────
def _already_running():
    if not os.path.exists(LOCK_FILE):
        return False
    try:
        pid = int(open(LOCK_FILE).read().strip())
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, ValueError, OSError):
        return False

if _already_running():
    subprocess.run([
        "osascript", "-e",
        'tell application "System Events" to set frontmost of (processes whose name is "Overlord") to true'
    ])
    sys.exit(0)

open(LOCK_FILE, "w").write(str(os.getpid()))

# Set process name to Overlord (shows in Activity Monitor / Mission Control)
try:
    import ctypes, ctypes.util
    libc = ctypes.CDLL(ctypes.util.find_library('c'), use_errno=True)
    libc.pthread_setname_np(b'Overlord')
except Exception:
    pass

def _cleanup():
    try: os.remove(LOCK_FILE)
    except: pass

import atexit
atexit.register(_cleanup)

# ── Server helpers ────────────────────────────────────────────────────────────
def _port_open(port):
    try:
        urllib.request.urlopen(f"http://localhost:{port}", timeout=1)
        return True
    except Exception:
        return False

def _kill_port(port):
    try:
        out = subprocess.check_output(["lsof", "-ti", f":{port}"], text=True).strip()
        for pid in out.splitlines():
            subprocess.call(["kill", "-9", pid])
        time.sleep(0.5)
    except Exception:
        pass

_servers_started = False

def _start_servers():
    # _on_shown (which calls this) is an AppKit callback that can legitimately
    # fire more than once per launch — confirmed via backend.log showing the
    # background sync thread's startup line logged 4 times in a single,
    # continuously-running process. Each call spun up its own independent
    # copy of every background thread (mail prefetch, Freshdesk sync loop,
    # ticket-index backfill, etc.), all hitting the same SQLite file and
    # APIs concurrently — the likely cause of a lot of "why is this so slow/
    # inconsistent" behavior traced back to this session. Guard so it only
    # ever runs once per process, no matter how many times _on_shown fires.
    global _servers_started
    if _servers_started:
        return
    _servers_started = True

    # Kill any stale process on port 8000
    _kill_port(8000)

    # Run Flask in-process as a daemon thread so osascript calls
    # inherit Overlord's Accessibility permission (not a separate python3 process)
    backend_log_path = os.path.join(LOGS_DIR, "backend.log")
    sys.path.insert(0, BACKEND_DIR)

    def _run_backend():
        import logging
        log_file = open(backend_log_path, "a")
        handler = logging.StreamHandler(log_file)
        logging.getLogger('werkzeug').handlers = []
        logging.getLogger('werkzeug').addHandler(handler)
        logging.getLogger('werkzeug').setLevel(logging.INFO)
        logging.getLogger('overlord.draft').handlers = []
        logging.getLogger('overlord.draft').addHandler(handler)
        logging.getLogger('overlord.draft').setLevel(logging.DEBUG)
        logging.getLogger('overlord.draft').propagate = False
        # Root logger too — otherwise a bare logging.error()/logging.exception()
        # anywhere else in the backend has no handler at all (Python's default
        # "last resort" handler writes to stderr, which goes nowhere visible
        # since this runs as an in-process thread, not a redirected subprocess).
        # Found the hard way: an error-logging call in the ticket-index backfill
        # silently vanished instead of showing up here.
        logging.getLogger().addHandler(handler)
        logging.getLogger().setLevel(logging.INFO)
        try:
            import main as backend
            backend.app.run(host='127.0.0.1', port=8000, debug=False, threaded=True, use_reloader=False)
        except Exception as e:
            log_file.write(f"[backend] fatal: {e}\n")
            log_file.flush()

    import threading as _threading
    t = _threading.Thread(target=_run_backend, daemon=True)
    t.start()

# ── Loading screen ────────────────────────────────────────────────────────────
LOADING_HTML = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    background: #1a1a1a;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    height: 100vh; font-family: -apple-system, sans-serif;
    color: #fff;
  }
  .logo { font-size: 42px; margin-bottom: 20px; }
  .name { font-size: 20px; font-weight: 600; color: #fff; margin-bottom: 6px; }
  .sub  { font-size: 13px; color: #555; margin-bottom: 40px; }
  .bar  { width: 220px; height: 3px; background: #2a2a2a; border-radius: 99px; overflow: hidden; }
  .fill {
    height: 100%; background: #e8a020; border-radius: 99px;
    animation: load 2.2s ease-in-out infinite;
  }
  @keyframes load {
    0%   { width: 0%;   margin-left: 0; }
    50%  { width: 60%;  margin-left: 20%; }
    100% { width: 0%;   margin-left: 100%; }
  }
  .status { font-size: 11px; color: #444; margin-top: 18px; min-height: 16px; transition: opacity 0.3s; }
</style>
</head>
<body>
  <div class="logo">✉</div>
  <div class="name">Overlord</div>
  <div class="sub">Booting the empire…</div>
  <div class="bar"><div class="fill"></div></div>
  <div class="status" id="s"></div>
  <script>
    const msgs = [
      "Bribing the IMAP gods…",
      "Untangling someone's reply-all thread…",
      "Polishing the inbox to a mirror shine…",
      "Convincing servers to behave…",
      "Scanning for passive-aggressive emails…",
      "Teaching electrons to carry mail…",
      "Decrypting 47 unread newsletters…",
      "Waking up the hamsters…",
      "Negotiating with port 993…",
      "Performing inbox feng shui…",
      "Alphabetising the chaos…",
      "Scouting for meeting links…",
      "Checking if the server ghosts us…",
      "Brewing the context coffee…",
      "Syncing calendars across timezones…",
      "Telling the spam filter to be aggressive…",
      "Counting unread emails (pray for you)…",
      "Almost there. Probably.",
    ]
    let i = 0
    const el = document.getElementById('s')
    function next() {
      if (i >= msgs.length) return
      el.style.opacity = 0
      setTimeout(() => {
        el.textContent = msgs[i++]
        el.style.opacity = 1
        if (i < msgs.length) setTimeout(next, 1600)
      }, 300)
    }
    next()
  </script>
</body>
</html>"""

# ── Dock menu + proper quit ───────────────────────────────────────────────────
def _setup_dock():
    """Set app name, icon, dock menu and handle Cmd+Q."""
    try:
        from AppKit import NSApplication, NSMenu, NSMenuItem, NSImage
        import objc

        app = NSApplication.sharedApplication()

        # Set the correct app icon (so alt-tab shows Overlord icon, not Python)
        icns_path = os.path.join(BASE, "Overlord.icns")  # bundle path
        if not os.path.exists(icns_path):
            icns_path = os.path.join(BASE, "Overlord.app", "Contents", "Resources", "Overlord.icns")  # dev path
        if os.path.exists(icns_path):
            icon = NSImage.alloc().initWithContentsOfFile_(icns_path)
            if icon:
                app.setApplicationIconImage_(icon)

        # Dock menu with Quit item
        dock_menu = NSMenu.alloc().initWithTitle_("Overlord")
        quit_item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
            "Quit Overlord", "terminate:", "q"
        )
        dock_menu.addItem_(quit_item)
        app.setDockMenu_(dock_menu)

        # Ensure Cmd+Q in the main menu also works
        main_menu = app.mainMenu()
        if main_menu:
            app_menu_item = main_menu.itemAtIndex_(0)
            if app_menu_item:
                app_submenu = app_menu_item.submenu()
                if app_submenu and not app_submenu.itemWithTitle_("Quit Overlord"):
                    sep = NSMenuItem.separatorItem()
                    app_submenu.addItem_(sep)
                    q = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
                        "Quit Overlord", "terminate:", "q"
                    )
                    app_submenu.addItem_(q)

        # Add standard Edit menu so Cmd+X/C/V/A/Z work in all text inputs
        if main_menu and not main_menu.itemWithTitle_("Edit"):
            edit_menu    = NSMenu.alloc().initWithTitle_("Edit")
            edit_item    = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("Edit", None, "")
            edit_item.setSubmenu_(edit_menu)

            def _add(title, action, key, modifier=None):
                item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, action, key)
                if modifier is not None:
                    item.setKeyEquivalentModifierMask_(modifier)
                edit_menu.addItem_(item)

            from AppKit import NSCommandKeyMask
            _add("Undo",       "undo:",              "z")
            _add("Redo",       "redo:",              "Z")
            edit_menu.addItem_(NSMenuItem.separatorItem())
            _add("Cut",        "cut:",               "x")
            _add("Copy",       "copy:",              "c")
            _add("Paste",      "paste:",             "v")
            _add("Select All", "selectAll:",         "a")
            edit_menu.addItem_(NSMenuItem.separatorItem())
            _add("Find…",      "performFindPanelAction:", "f")

            main_menu.addItem_(edit_item)

    except Exception as e:
        print(f"[dock] {e}", flush=True)

# ── Main ──────────────────────────────────────────────────────────────────────
win = webview.create_window(
    "Overlord",
    html=LOADING_HTML,
    width=1400, height=900,
    resizable=True, min_size=(900, 600),
    fullscreen=True,
)

def _assert_identity():
    """Re-assert Overlord process identity — called after all imports settle."""
    try:
        from Foundation import NSProcessInfo
        NSProcessInfo.processInfo().setValue_forKey_("Overlord", "processName")
    except Exception:
        pass
    try:
        import ctypes
        _LS = ctypes.CDLL('/System/Library/Frameworks/CoreServices.framework/CoreServices')
        _CF = ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        _CF.CFStringCreateWithCString.restype = ctypes.c_void_p
        _CF.CFStringCreateWithCString.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
        _LS._LSGetCurrentApplicationASN.restype = ctypes.c_uint64
        _LS._LSSetApplicationInformationItem.restype = ctypes.c_int32
        _LS._LSSetApplicationInformationItem.argtypes = [
            ctypes.c_int32, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
        asn = _LS._LSGetCurrentApplicationASN()
        key = _CF.CFStringCreateWithCString(None, b'LSDisplayName', 0x08000100)
        val = _CF.CFStringCreateWithCString(None, b'Overlord', 0x08000100)
        _LS._LSSetApplicationInformationItem(-2, asn, key, val, None)
    except Exception:
        pass

def _reassert_icon():
    """Re-set the app icon a few seconds after startup to win against the Dock cache."""
    try:
        from AppKit import NSApplication, NSImage
        icns = os.path.join(BASE, "Overlord.icns")  # bundle path
        if not os.path.exists(icns):
            icns = os.path.join(BASE, "Overlord.app", "Contents", "Resources", "Overlord.icns")  # dev path
        if os.path.exists(icns):
            img = NSImage.alloc().initWithContentsOfFile_(icns)
            if img:
                NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception:
        pass

def _on_shown():
    _assert_identity()
    _setup_dock()
    _start_servers()
    for _ in range(120):
        if _port_open(8000):
            break
        time.sleep(0.25)
    win.load_url("http://localhost:8000")
    # Re-assert icon after pywebview has fully settled — defeats Dock cache reversion
    threading.Timer(3.0, _reassert_icon).start()

webview.start(_on_shown, gui='cocoa')
